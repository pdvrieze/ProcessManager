package meta.lang;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.LocalVariable;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.languages.UnaryOperatorTokens;


public class UnaryPrimitiveOperator extends FunctionRef {

  private final Primitive aPrimitive;

  private final UnaryOperatorTokens aOperator;

  public UnaryPrimitiveOperator(final LinePosition pPos, final Primitive pPrimitive, final UnaryOperatorTokens pOperator) {
    super(pPos, "operator" + pOperator.toString(), getFuncType(pOperator, pPrimitive));
    aPrimitive = pPrimitive;
    aOperator = pOperator;
  }

  private static FunctionType getFuncType(final UnaryOperatorTokens pOperator, final Primitive pPrimitive) {
    final TypeRef<Primitive> primitive = pPrimitive.getRef();
    final Primitive returnType;
    {
      switch (pOperator) {
        case NOT:
          returnType = primitive.getReferredType();
          break;
        case PARENCLOSE:
        case PARENOPEN:
          throw new IllegalArgumentException("The operator is not supported for the type");
        case POSTDEC:
        case POSTINC:
        case PREDEC:
        case PREINC:
          returnType = primitive.getReferredType();
          break;
        default:
          throw new IllegalStateException("Code should be unreachable");
      }
    }
    return new FunctionType(null, FunctionType._PUBLIC, returnType.getRef(), primitive, TypeRef.emptyList());
  }

  @Override
  public Literal<?> evalCall(final Scope pScope, final Expression pTarget, final Expression... pArgs) throws CompilationException {
    if ((pArgs != null) && (pArgs.length > 0)) {
      pScope.getContext().error(this, CompilationErrors.INVALID_ARGUMENT_COUNT);
      return null;
    }
    switch (aOperator) {
      case NOT:
        return Literal.createBool(null, !MEvaluator.getBool(pScope.expectLiteral(pTarget.eval(pScope)), pScope));
      case PARENOPEN:
      case PARENCLOSE:
        throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
      case POSTDEC:
        return evalPostInc(pTarget, Literal.createInt(null, -1), pScope);
      case POSTINC:
        return evalPostInc(pTarget, Literal.createInt(null, 1), pScope);
      case PREDEC:
        return evalPreInc(pTarget, Literal.createInt(null, -1), pScope);
      case PREINC:
        return evalPreInc(pTarget, Literal.createInt(null, 1), pScope);
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalPostInc(final Expression pTarget, final Literal<?> pIncrement, final Scope pScope) throws CompilationException {
    final int increment = MEvaluator.getInt(pIncrement, pScope.getContext());
    final NamedObject object = MEvaluator.getNamedObject(pTarget, pScope);
    final TypeRef<?> targetType = object.getReferredType(pScope);
    if (targetType.getReferredType() instanceof Primitive) {
      final Primitive type = (Primitive) targetType.getReferredType();
      final Literal<?> result = pScope.expectLiteral(pTarget.eval(pScope));
      Literal<?> newValue;
      switch (type) {
        case MByte:
          newValue = Literal.createByte(getPos(), (byte) (MEvaluator.getInt(result, pScope.getContext()) + increment));
          break;
        case MShort:
          newValue = Literal.createShort(getPos(), (short) (MEvaluator.getInt(result, pScope.getContext()) + increment));
          break;
        case MChar:
          newValue = Literal.createChar(getPos(), (char) (MEvaluator.getInt(result, pScope.getContext()) + increment));
          break;
        case MInt:
          newValue = Literal.createInt(getPos(), (MEvaluator.getInt(result, pScope.getContext()) + increment));
          break;
        case MLong:
          newValue = Literal.createLong(getPos(), (MEvaluator.getLong(result, pScope.getContext()) + increment));
          break;
        default:
          throw new UnsupportedOperationException("Operation not defined for booleans or floats");
      }
      pScope.setVar(object, newValue);
      return result;
    }
    throw new UnsupportedOperationException("This should never be called on any other type but a primitive");
  }

  private Literal<?> evalPreInc(final Expression pTarget, final Literal<?> pIncrement, final Scope pScope) throws CompilationException {
    final int increment = MEvaluator.getInt(pIncrement, pScope.getContext());
    final NamedObject object = MEvaluator.getNamedObject(pTarget, pScope);
    if (object == null) {
      pScope.getContext().error(pTarget, "The expression does not evaluate to an assignable object (lvalue)");
      return null;
    }
    final TypeRef<?> targetType = object.getReferredType(pScope);
    if (targetType.getReferredType() instanceof Primitive) {
      final Primitive type = (Primitive) targetType.getReferredType();
      final Literal<?> initValue = pScope.expectLiteral(pTarget.eval(pScope));
      Literal<?> result;
      switch (type) {
        case MByte:
          result = Literal.createByte(getPos(), (byte) (MEvaluator.getInt(initValue, pScope.getContext()) + increment));
          break;
        case MShort:
          result = Literal.createShort(getPos(), (short) (MEvaluator.getInt(initValue, pScope.getContext()) + increment));
          break;
        case MChar:
          result = Literal.createChar(getPos(), (char) (MEvaluator.getInt(initValue, pScope.getContext()) + increment));
          break;
        case MInt:
          result = Literal.createInt(getPos(), (MEvaluator.getInt(initValue, pScope.getContext()) + increment));
          break;
        case MLong:
          result = Literal.createLong(getPos(), (MEvaluator.getLong(initValue, pScope.getContext()) + increment));
          break;
        default:
          throw new UnsupportedOperationException("Operation not defined for booleans or floats");
      }
      pScope.setVar(object, result);
      return result;
    }
    throw new UnsupportedOperationException("This should never be called on any other type but a primitive");
  }

  @Override
  public TypeRef<?> compileCall(final Expression pTarget, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression[] pArgs) throws CompilationException {
    if ((pArgs != null) && (pArgs.length > 0)) {
      pScope.getContext().error(this, "Unary operators do not have arguments, only targets");
    }
    return compileCall(pTarget, pScope, pCleanupStack);
  }

  private TypeRef<?> compileCall(final Expression pTarget, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    switch (aOperator) {
      case NOT:
        pTarget.compile(pScope, false);
        if (aPrimitive == Primitive.MBoolean) {
          pScope.getCompiler().getIntCompiler().compileBuiltinNot(this, pScope, pCleanupStack);
          return Primitive.MBoolean.getRef();
        }
        break;
      case PARENCLOSE:
      case PARENOPEN:
        break;
      case POSTDEC: {
        final LocalVariable localVar = getLocalVar(pTarget, pScope);
        switch (aPrimitive) {
          case MByte:
          case MChar:
          case MShort:
          case MInt:
            pScope.getCompiler().getIntCompiler().compileBuiltinPostAdd(this, localVar, -1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          case MLong:
            pScope.getCompiler().getLongCompiler().compileBuiltinPostAdd(this, localVar, -1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          default:
            break;
        }
        break;
      }
      case POSTINC: {
        final LocalVariable localVar = getLocalVar(pTarget, pScope);
        switch (aPrimitive) {
          case MByte:
          case MChar:
          case MShort:
          case MInt:
            pScope.getCompiler().getIntCompiler().compileBuiltinPostAdd(this, localVar, 1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          case MLong:
            pScope.getCompiler().getLongCompiler().compileBuiltinPostAdd(this, localVar, 1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          default:
            break;
        }
        break;
      }
      case PREDEC: {
        final LocalVariable localVar = getLocalVar(pTarget, pScope);
        switch (aPrimitive) {
          case MByte:
          case MChar:
          case MShort:
          case MInt:
            pScope.getCompiler().getIntCompiler().compileBuiltinPreAdd(this, localVar, -1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          case MLong:
            pScope.getCompiler().getLongCompiler().compileBuiltinPreAdd(this, localVar, -1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          default:
            break;
        }
        break;
      }
      case PREINC: {
        final LocalVariable localVar = getLocalVar(pTarget, pScope);
        switch (aPrimitive) {
          case MByte:
          case MChar:
          case MShort:
          case MInt:
            pScope.getCompiler().getIntCompiler().compileBuiltinPreAdd(this, localVar, 1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          case MLong:
            pScope.getCompiler().getLongCompiler().compileBuiltinPreAdd(this, localVar, 1, pScope, pCleanupStack);
            return aPrimitive.getRef();
          default:
            break;
        }
        break;
      }
    }

    throw new IllegalArgumentException("operator" + aOperator.toString() + ": unsupported builtin");
  }

  private static LocalVariable getLocalVar(final Expression pTarget, final Scope pScope) throws CompilationException {
    if (pTarget.getTokenType() == MLang.SYMBOL) {
      final NamedObject resolvedSymbol = pScope.resolveSymbol(((Symbol) pTarget).getName());
      if (!(resolvedSymbol instanceof LocalVariable)) {
        pScope.getContext().error(pTarget, "The variable is not a local variable");
        return null;
      }
      return (LocalVariable) resolvedSymbol;
      //    } else if (pTarget.getTokenType()==MLang.BINARYOPERATOR) {
      //      BinaryExpression bin= (BinaryExpression) pTarget;
      //      if (bin.getOperator()==BinaryOperatorTokens.MEMBERACCESS) {
      //        
      //      }
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public Primitive getPrimitive() {
    return aPrimitive;
  }

}
