package meta.lang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.CompilationResult;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.*;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;
import net.devrieze.util.StringUtil;


public class MClass extends JavaReferenceType implements Expression {

  private final String aName;

  private final TypeRef<? extends JavaReferenceType> aParent;

  private final List<TypeRef<? extends JavaReferenceType>> aInterfaces;

  private final List<VarAssign> aAttributes;

  private final List<Function> aMethods;

  private final GenericType[] aGenParams;

  private final List<AnnotateToken> aFlags;

  private final LinePosition aPosition;

  private final Scope aParentScope;

  public MClass(final LinePosition pPosition, final List<AnnotateToken> pFlags, final String pName, final TypeRef<? extends JavaReferenceType> pParent, final List<TypeRef<? extends JavaReferenceType>> pInterfaces, final List<VarAssign> pAttributes, final List<Function> pMethods, final Scope pScope) {
    aPosition = pPosition;
    aFlags = pFlags;
    aName = pName;
    aParent = pParent == null ? TypeRef.create(pPosition, Object.class).asReferenceType() : pParent;
    aInterfaces = pInterfaces == null ? new ArrayList<TypeRef<? extends JavaReferenceType>>(0) : pInterfaces;
    aAttributes = pAttributes == null ? new ArrayList<VarAssign>(0) : new ArrayList<>(pAttributes);
    aMethods = pMethods == null ? new ArrayList<Function>(0) : new ArrayList<>(pMethods);
    for (final Function method : aMethods) {
      method.setOwner(this);
    }
    aGenParams = new GenericType[0];
    aParentScope = pScope;
  }

  public CompilationResult compileClass(final Scope pScope) throws CompilationException {
    return pScope.getCompiler().compileClass(this, pScope);
  }

  public MLang type() {
    return MLang.CLASS;
  }

  @Override
  public boolean hasParent(final TypeRef<? extends JavaReferenceType> pCandidate) {
    if ((!pCandidate.isInterface()) && pCandidate.getReferredType().equals(this)) {
      return true;
    }
    if (pCandidate.isInterface()) {
      for (final TypeRef<? extends JavaReferenceType> iface : aInterfaces) {
        if (iface.getReferredType().hasParent(pCandidate)) {
          return true;
        }
      }
    }
    return aParent.getReferredType().hasParent(pCandidate);
  }

  public List<Function> getLocalMethods() {
    return aMethods;
  }

  @Override
  public List<FunctionRef> getMethods(final List<FunctionRef> pReceiver) {
    aParent.getReferredType().getMethods(pReceiver);
    for (final Function method : aMethods) {
      pReceiver.add(method.getRef());
    }
    return pReceiver;
  }

  @Override
  public List<FieldRef> getFields(final List<FieldRef> pReceiver) throws CompilationException {
    aParent.getReferredType().getFields(pReceiver);
    for (final VarAssign method : aAttributes) {
      final FieldRef fieldRef = new FieldRef(getRef(), method, aParentScope);
      pReceiver.add(fieldRef);
    }
    return pReceiver;
  }

  @Override
  public String getDescriptor() {
    return 'L' + getInternalName() + ';';
  }

  public String getClassDescriptor() {
    final StringBuilder result = new StringBuilder();
    result.append('L').append(aParent.getInternalName()).append(';');
    for (final TypeRef<? extends JavaReferenceType> intface : aInterfaces) {
      result.append('L').append(intface.getInternalName()).append(';');
    }
    return result.toString();
  }

  @Override
  public String getSignature() {
    return null; // TODO See if this works, just no signatures yet
  }

  public CharSequence getClassSignature() {
    final StringBuilder result = new StringBuilder();
    if ((aGenParams != null) && (aGenParams.length > 0)) {
      result.append('<');
      for (int i = 0; i < aGenParams.length; ++i) {
        if (i > 0) {
          result.append(',');
        }
        result.append(aGenParams[i].getFormalTypeParameter());
      }
      result.append('>');
    }
    result.append(aParent.getSignature());
    for (final TypeRef<? extends JavaReferenceType> mInterface : aInterfaces) {
      result.append(mInterface.getSignature());
    }
    return result;
  }

  @Override
  public String getInternalName() {
    return aName;
  }

  @Override
  public GenericType[] getGenericParams() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public TypeRef<MClass> getRef() {
    return TypeRef.create(null, this);
  }

  @SafeVarargs
  @Override
  public final TypeRef<? extends Type> getRef(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return TypeRef.create(null, this, pGenericParams);
  }

  public boolean isInterface() {
    return aFlags.contains(new AnnotateToken(null, "interface"));
  }

  public Function[] resolveFunctionName(final String pName) {
    final ArrayList<Function> result = new ArrayList<>();

    for (final Function f : aMethods) {
      if (f.getName().equals(pName)) {
        result.add(f);
      }
    }
    return result.toArray(new Function[0]);
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    final String name = pName.getName();
    final ArrayList<Function> result = new ArrayList<>();
    boolean constructor = false;
    if (name.equals(getClassName()) || name.equals("<init>")) {
      constructor = true;
    }
    boolean seenConstructor = false;

    for (final Function f : aMethods) {
      if (f.getName().equals(name) || (constructor && f.isConstructor(pScope))) {
        seenConstructor = seenConstructor || constructor;
        switch (f.getFunctionType().match(pParamTypes, pScope)) {
          case PERFECT:
            return f.getRef();
          case PARTIAL:
            result.add(f);
            break;
          case NONE:
            break;
          default:
            throw new IllegalStateException("This should be unreachable");
        }
      }
    }

    if (result.size() == 0) {
      if (constructor && (!seenConstructor)) {
        final FunctionType ft = new FunctionType(getPos(), FunctionType._PUBLIC, getRef(), null, TypeRef.emptyList());
        final Function f = new Function(getPos(), name, ft, new Return(getPos()));
        aMethods.add(f);
        return f.getRef();
      } else {
        return null;
      }
    }
    if (result.size() >= 2) {
      pScope.getContext().error(pName, ambiguousResolveMessage(name, pParamTypes, result));
    }
    return result.get(0).getRef();
  }

  private static String ambiguousResolveMessage(final String pName, final TypeRef<?>[] pParamTypes, final ArrayList<Function> pCandidates) {
    final StringBuilder b = new StringBuilder("Ambiguous resolve results for ");
    b.append(pName).append('(');
    boolean first = true;
    for (final TypeRef<?> type : pParamTypes) {
      if (!first) {
        b.append(", ");
      }
      first = false;
      b.append(type.toString());
    }
    b.append("), candidates are:");
    for (final Function candidate : pCandidates) {
      b.append('\n').append(candidate.toString());
    }
    return b.toString();
  }

  public Function resolveFunction(final FunctionRef pRef) {
    for (final Function f : aMethods) {
      if (f.getRef().equals(pRef)) {
        return f;
      }
    }
    return null;
  }

  @Override
  public FieldRef resolveField(final Symbol pField, final Scope pScope) throws CompilationException {
    for (final VarAssign attribute : aAttributes) {
      final Symbol nameSymbol = MEvaluator.toSymbol(attribute.getLValue());
      if (nameSymbol.getName().equals(pField.getName())) {
        return new FieldRef(getRef(), attribute, pScope);
      }
    }
    return null;
  }


  @Override
  public Literal<?> evalCallStatic(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    if ((pFunction.getOwner() != null) && (pFunction.getOwner().getReferredType() != this)) {
      pScope.getContext().error(pFunction, "The function " + pFunction.toString() + " is not a function on this type: " + aName);
    }
    final Function f = resolveFunction(pFunction);
    if (f != null) {
      if (!(f.getFunctionType().isStatic() || f.isConstructor(pScope))) {
        pScope.getContext().error(pFunction, "Calling nonstatic methods on an MClass is not possible");
        return null;
      }
      return f.evalCall(pScope, pFunction.getPos(), null, pArgs);
    }
    pScope.getContext().error(pFunction, EvaluationErrors.NO_SUCH_METHOD);
    return null;
  }

  @Override
  public Literal<?> evalCallDynamic(final Literal<?> pTarget, final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    if ((pFunction.getOwner() != null) && (pFunction.getOwner().getReferredType() != this)) {
      pScope.getContext().error(pFunction, "The function " + pFunction.toString() + " is not a function on this type: " + aName);
    }
    final Function f = resolveFunction(pFunction);
    if (f != null) {
      Object objValue;
      if (f.isConstructor(pScope) && (pTarget == null)) {
        objValue = new ClassInstance(getRef());
      } else {
        objValue = pTarget.getObjValue();
      }
      if (!(objValue instanceof ClassInstance)) {
        pScope.getContext().error(pFunction, "The target for the evaluation is not a class instance");
        return null;
      }
      final ClassInstance instance = (ClassInstance) objValue;
      return instance.evalCall(pFunction, pScope, pArgs);
    }
    pScope.getContext().error(pFunction, EvaluationErrors.NO_SUCH_METHOD);
    return null;
  }

  // TODO verify that the return value is of the declared type
  // TODO share code with evaluation of dynamic functions in ClassInstance
  public Literal<?> evalStaticFunction(final Function pFunction, final Expression... pArgs) throws CompilationException {
    final Expression[] impl = pFunction.getImplementation();
    final Scope scope = aParentScope.newClassScope(this).newFunctionScope(pFunction);
    final VarAssign[] paramDefs = pFunction.getFunctionType().getParams();
    for (int i = 0; i < paramDefs.length; ++i) {
      scope.setVar(MEvaluator.toSymbol(paramDefs[i].getLValue()), (Literal<?>) pArgs[i]);
    }
    EvalResult result = null;
    for (final Expression v : impl) {
      result = v.eval(scope);
      if (result instanceof ReturnValue) {
        break;
      }
    }
    // TODO fix this gratuitous cast
    return result == null ? null : result.toLiteral();
  }

  @Override
  public Literal<?> eval(final Scope pScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().mClassCompileTransform(pToken, pTargetType, pExpr, pScope, pCleanupStack);
  }

  @Override
  public boolean isAssignableFrom(final Type pOther) {
    if (!(pOther instanceof JavaType)) {
      return false;
    }
    if (equals(pOther)) {
      return true;
    }
    if (pOther instanceof MClass) {
      final MClass other = (MClass) pOther;
      TypeRef<?> mostChild = other.getRef();
      while (mostChild != null) {
        if (this.equals(mostChild.getReferredType())) {
          return true;
        }
        mostChild = mostChild.getParent();
      }
      return false;
      // XXX todo implement better
    } else {
      return false;
    }
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != MClass.class)) {
      return false;
    }
    final MClass other = (MClass) pObj;
    boolean equal = aName.equals(other.aName);
    equal = equal && aParent.equals(other.aParent);
    equal = equal && aInterfaces.equals(other.aInterfaces);
    equal = equal && aAttributes.equals(other.aAttributes);
    equal = equal && aMethods.equals(other.aMethods);
    equal = equal && Arrays.equals(aGenParams, other.aGenParams);
    equal = equal && aFlags.equals(other.aFlags);
    return equal;
  }

  @Override
  public int hashCode() {
    int result = aName.hashCode();
    result = (result * 31) + aParent.hashCode();
    result = (result * 31) + aInterfaces.hashCode();
    result = (result * 31) + aAttributes.hashCode();
    result = (result * 31) + aMethods.hashCode();
    result = (result * 31) + aGenParams.hashCode();
    result = (result * 31) + aFlags.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "MClass: " + aName;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    // TODO support more
    final StringBuilder result = new StringBuilder();
    for (final AnnotateToken flag : aFlags) {
      result.append(flag.toMetaCode()).append(' ');
    }
    result.append(aName.replace('/', '.'));
    // XXX remove line below
    //    result.append(" : ").append(getType().toMetaCode(pIndent + 4));
    result.append(" = class(");
    if (TypeRef.create(null, Object.class).equals(aParent)) {
      if (aInterfaces.size() > 0) {
        result.append("(), (");
      }
    } else {
      if (aInterfaces.size() > 0) {
        result.append(aParent.toMetaCode(pIndent + 4)).append(", (");
      } else {
        result.append(aParent.toMetaCode(pIndent + 4));
      }
    }
    boolean first = true;
    for (final TypeRef<? extends JavaReferenceType> iface : aInterfaces) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      result.append(iface.toMetaCode(0));
    }
    if (aInterfaces.size() > 0) {
      result.append(")) (\n\n");
    } else {
      result.append(") (\n\n");
    }
    for (final Function method : aMethods) {
      result.append(method.toMetaCode(pIndent + 2)).append('\n');
    }


    StringUtil.addChars(result, pIndent, ' ').append(")\n");
    return result.toString();
  }

  @SafeVarargs
  @Override
  public final TypeRef<? extends JavaReferenceType> getParent(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return aParent;
  }

  @SafeVarargs
  @Override
  public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return aInterfaces;
  }

  public String getName() {
    return aName;
  }


  public TypeRef<? extends JavaReferenceType> getParent() {
    return aParent;
  }


  public List<TypeRef<? extends JavaReferenceType>> getInterfaces() {
    return aInterfaces;
  }


  public List<VarAssign> getAttributes() {
    return aAttributes;
  }


  public GenericType[] getGenParams() {
    return aGenParams;
  }


  public List<AnnotateToken> getFlags() {
    return aFlags;
  }

  public EnumSet<ClassFlags> getFlagSet() throws CompilationException {
    final List<ClassFlags> result = new ArrayList<>(0);
    for (final AnnotateToken f : aFlags) {
      final ClassFlags flag = ClassFlags.fromString(f.getName());
      if (flag != null) {
        if ((f.getParams(aParentScope) != null) && (f.getParams(aParentScope).length > 0)) {
          aParentScope.getContext().error(f, "Builtin annotations do not have parameters");
        }
        result.add(flag);
      }
    }
    if (result.size() == 0) {
      return EnumSet.noneOf(ClassFlags.class);
    }
    return EnumSet.copyOf(result);
  }

  /**
   * Get just the class name.
   * 
   * @return the name of the class, without the package
   */
  @Override
  public String getClassName() {
    final int i = aName.lastIndexOf('/');
    return aName.substring(i + 1);
  }

  public Scope.ClassInstanceScope getClassInstanceScope(final ClassInstance pClassInstance) {
    return aParentScope.newClassInstanceScope(pClassInstance);
  }

  @Override
  public MLang getTokenType() {
    return MLang.CLASS;
  }

  @Override
  public LinePosition getPos() {
    return aPosition;
  }

  public boolean isAnnotation() {
    return false; // TODO support being an annotation
  }

}
