package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class TypeCast extends AbstractExpression {

  private final Expression aTargetType;

  private final Expression aExpr;

  public TypeCast(final LinePosition pPosition, final Expression pTargetType, final Expression pExpr) {
    super(pPosition);
    aTargetType = pTargetType;
    aExpr = pExpr;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final TypeRef<?> targetType = MEvaluator.toTypeRef(aTargetType, pScope);
    return aExpr.getEvalType(pScope).compileTransform(this, targetType, aExpr, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return MEvaluator.toTypeRef(aTargetType, pScope);
  }

  @Override
  public MLang getTokenType() {
    return MLang.TYPECAST;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    return "cast<" + aTargetType.toMetaCode(pIndent + 4) + ">(" + aExpr.toMetaCode(pIndent + 4) + ")";
  }

}
