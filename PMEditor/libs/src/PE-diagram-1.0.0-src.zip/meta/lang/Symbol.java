package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvaluationErrors;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


// TODO evaluate whether this should be renamed
public class Symbol extends AbstractExpression {

  private final String aName;

  public Symbol(final LinePosition pPosition, final String pName) {
    super(pPosition);
    aName = pName;
  }

  // TODO check the sanity of this
  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final NamedObject val = pScope.resolveSymbol(getName());
    if (val == null) {
      pScope.getContext().error(this, "Unresolved Variable: " + getName());
      return null;
    }
    return val.compileRef(this, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    final NamedObject val = pScope.resolveSymbol(getName());
    if (val == null) {
      pScope.getContext().error(this, "Unresolved Variable: " + getName());
      return null;
    }
    return val.getReferredType(pScope);
  }

  @Override
  public Literal<?> eval(final Scope pScope) throws CompilationException {
    final Literal<?> result = pScope.getValue(this);
    if (result != null) {
      return result;
    }
    pScope.getContext().error(this, EvaluationErrors.NO_SUCH_VARIABLE, getName());
    return null;
  }

  @Override
  public String toString() {
    return "Symbol(\"" + getName() + "\")";
  }

  @Override
  public String toMetaCode(final int pIndent) {
    return getName();
  }

  @Override
  public MLang getTokenType() {
    return MLang.SYMBOL;
  }

  public String getName() {
    return aName;
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    return getEvalType(pScope).resolveFunction(pScope, pName, pParamTypes);
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != Symbol.class)) {
      return false;
    }
    final Symbol other = (Symbol) pObj;
    return ((aName != null) && aName.equals(other.aName));
  }

  @Override
  public int hashCode() {
    // TODO Auto-generated method stub
    // return super.hashCode();
    throw new UnsupportedOperationException("Not yet implemented");
  }

}
