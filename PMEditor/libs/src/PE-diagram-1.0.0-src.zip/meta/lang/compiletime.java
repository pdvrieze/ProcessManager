package meta.lang;

import java.lang.annotation.*;


/**
 * An annotation to mark that a method is compile time
 * 
 * @author Paul de Vrieze
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface compiletime {

  public static enum CompilerDirectives {
    /** Indicates that scope info must be passed to the method by the compiler */
    SCOPE,
    /** Indicates that the current class must be passed by the compiler */
    CLASS,
    /** Indicates that the method performs parsing */
    PARSE,
  }

  CompilerDirectives[] value();
  // No body
}
