package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;
import net.devrieze.util.StringUtil;


public class ForEach extends AbstractExpression {

  /** The main loop body */
  private final MTupple aBody;

  private final Expression aReceiver;

  private final Expression aCollection;

  public ForEach(final LinePosition pPosition, final Expression pReceiver, final Expression pCollection, final MTupple pBody) {
    super(pPosition);
    aReceiver = pReceiver;
    aCollection = pCollection;
    aBody = pBody;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (!pCleanupStack) {
      pScope.getContext().error(this, "Loops do not have a result variable");
    }
    final Loop loop = toLoop(pScope);
    return loop.compile(pScope, pCleanupStack);
  }

  public Loop toLoop(final Scope pScope) throws CompilationException {
    return Loop.newForEach(getPos(), aReceiver, aCollection, aBody, pScope);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    return toLoop(pScope).eval(pScope);
  }

  @Override
  public MLang getTokenType() {
    return MLang.FOREACH;
  }

  public static ForEach newForEach(final LinePosition pPos, final Expression pReceiver, final Expression pCollection, final MTupple pBody) {
    MTupple body;
    if (pBody.getTokenType() == MLang.TUPPLE) {
      body = pBody;
    } else {
      body = new MTupple(pPos, pBody);
    }

    return new ForEach(pPos, pReceiver, pCollection, body);
  }


  public Expression getBody() {
    return aBody;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("for(").append(aReceiver.toMetaCode(pIndent + 4));
    result.append(" ← ").append(aCollection.toMetaCode(pIndent + 4));
    result.append("(\n");
    for (final Expression elem : aBody) {
      result.append(StringUtil.charRepeat(pIndent + 2, ' '));
      result.append(elem.toMetaCode(pIndent + 4)).append('\n');
    }
    result.append(StringUtil.charRepeat(pIndent, ' ')).append(')');
    return result.toString();
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append("forEach(").append(aReceiver);
    result.append(" ← ").append(aCollection);
    result.append("(\n");
    for (final Expression elem : aBody) {
      result.append(StringUtil.charRepeat(2, ' '));
      result.append(elem).append('\n');
    }
    result.append(')');
    return result.toString();
  }

}
