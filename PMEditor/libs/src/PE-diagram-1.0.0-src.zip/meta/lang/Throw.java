package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvaluationThrownException;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class Throw extends AbstractExpression {

  private final Expression aExpr;

  /**
   * Create a return statement
   * 
   * @param pExpression The expression to return
   */
  public Throw(final LinePosition pPosition, final Expression pExpression) {
    super(pPosition);
    aExpr = pExpression;
  }

  public Throw(final LinePosition pPosition) {
    super(pPosition);
    aExpr = null;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileThrow(this, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return aExpr == null ? null : aExpr.getEvalType(pScope);
  }

  public Expression getExpr() {
    return aExpr;
  }

  @Override
  public Literal<?> eval(final Scope pScope) throws CompilationException {
    if (aExpr == null) {
      pScope.getContext().error(this, "Empty throw statement");
    }
    final Literal<?> expr = pScope.expectLiteral(aExpr.eval(pScope));
    final Object o = expr.getObjValue();
    if (!(o instanceof Throwable)) {
      pScope.getContext().error(this, "The expression of a throw statement must be Throwable");
    }
    throw new EvaluationThrownException(this, (Throwable) o);
  }

  @Override
  public String toString() {
    return "throw " + aExpr;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("throw ").append(aExpr.toMetaCode(pIndent + 2));
    return result.toString();
  }

  @Override
  public MLang getTokenType() {
    return MLang.THROW;
  }

}
