package meta.lang;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.tokens.AbstractLinedToken;


public class FunctionRef extends AbstractLinedToken<MLang> implements NamedObject {

  private final FunctionType aType;

  private final String aName;

  public FunctionRef(final LinePosition pPosition, final String pName, final FunctionType pType) {
    super(MLang.FUNCREF, pPosition);
    aName = pName;
    aType = pType;
  }

  public FunctionRef(final LinePosition pPosition, final Method pMethod) {
    this(pPosition, pMethod.getName(), new FunctionType(pMethod));
  }

  public FunctionRef(final LinePosition pPosition, final Constructor<?> pConstructor) {
    this(pPosition, "<init>", new FunctionType(pConstructor));
  }

  public Expression getReturnType() {
    return aType.getReturnType();
  }

  public TypeRef<?> getReturnType(final Scope pScope) throws CompilationException {
    return aType.getReturnType(pScope);
  }

  public FunctionType getFunctionType() {
    return aType;
  }

  /**
   * Evaluate calling the referred to function
   * 
   * @param pScope TODO
   * @param pTarget The object to call the function on.
   * @param pArgs The arguments of the function
   * @return the result of the evaluation
   * @throws CompilationException
   */
  // TODO fix order
  public Literal<?> evalCall(final Scope pScope, final Expression pTarget, final Expression... pArgs) throws CompilationException {
    final TypeRef<?> owner = aType.getOwner();
    if (owner != null) {
      if (isStatic() || isConstructor()) {
        return owner.getReferredType().evalCallStatic(this, pScope, MEvaluator.toLiterals(pScope, pArgs));
      } else {
        final Literal<?> target = pScope.expectLiteral(pTarget.eval(pScope));
        return owner.getReferredType().evalCallDynamic(target, this, pScope, MEvaluator.toLiterals(pScope, pArgs));
      }
    } else {
      return pScope.getContext().evalGlobal(this, pScope, MEvaluator.toLiterals(pScope, pArgs));
    }
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public TypeRef<?> compileCall(final Expression pTarget, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression[] pArgs) throws CompilationException {
    assert aType.getParams().length == pArgs.length;
    return pScope.getCompiler().compileFuncCall(this, pTarget, pScope, pCleanupStack, pIsSuperCall, pArgs);
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pEvalScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public final String getFunctionName() {
    return aName;
  }

  public final boolean isInterfaceMethod() {
    return aType.getOwner().isInterface();
  }

  public final TypeRef<?> getOwner() {
    return aType.getOwner();
  }

  public final boolean isStatic() {
    return aType.isStatic();
  }

  public final boolean isConstructor() {
    if ("<init>".equals(aName)) {
      return true;
    }
    final TypeRef<?> owner = aType.getOwner();
    if (owner == null) {
      return false;
    }
    final TypeRef<? extends JavaReferenceType> refType = owner.asReferenceType();
    if (refType == null) {
      return false;
    }
    final String ownerName = refType.getReferredType().getClassName();
    return aName.equals(ownerName);
  }

  public final boolean isPublic() {
    return aType.isPublic();
  }

  @Override
  public String toString() {
    return aName + ":" + aType.toMetaCode(0);
  }

  @Override
  public boolean equals(final Object pOther) {
    if (pOther == this) {
      return true;
    }
    if (pOther.getClass() != FunctionRef.class) {
      return false;
    }
    final FunctionRef other = (FunctionRef) pOther;
    return aName.equals(other.aName) && aType.equals(other.aType);
  }

  @Override
  public int hashCode() {
    return (aName.hashCode() * 31) + aType.hashCode();
  }

  /**
   * Like equals, but only looks at the signature.
   * 
   * @param pScope TODO
   * @throws CompilationException
   */
  public boolean isSame(final FunctionRef pOther, final Scope pScope) throws CompilationException {
    if (pOther == this) {
      return true;
    }
    if (pOther.getClass() != FunctionRef.class) {
      return false;
    }
    return aName.equals(pOther.aName) && aType.isSame(pOther.aType, pScope);
  }

}
