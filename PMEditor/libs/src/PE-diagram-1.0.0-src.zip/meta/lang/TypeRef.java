package meta.lang;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.BuiltinOperatorEq;
import net.devrieze.meta.compile.CompilationError;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.ClassInstance;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


/**
 * A reference to a type
 * 
 * @author Paul de Vrieze
 */
public class TypeRef<T extends JavaType> extends AbstractExpression {


  public static class ClassWrapper<U> extends JavaReferenceType {

    public final Class<? extends U> aClass;

    public ClassWrapper(final Class<? extends U> pClass) {
      if (pClass.isArray()) {
        throw new IllegalArgumentException("ClassWrapper does not wrap arrays");
      }
      aClass = pClass;
    }

    @Override
    public String getDescriptor() {
      return 'L' + getInternalName() + ';';
    }

    @Override
    public GenericType[] getGenericParams() {
      final TypeVariable<?>[] jparams = aClass.getTypeParameters();
      final GenericType[] result = new GenericType[jparams.length];
      for (int i = result.length - 1; i >= 0; --i) {
        //        result[i] = new GenericType(jparams[i]);
      }
      return result;
    }

    @Override
    public String getInternalName() {
      return aClass.getName().replace('.', '/');
    }

    @Override
    public String getSignature() {
      // TODO Auto-generated method stub
      // return null;
      throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public String getClassName() {
      final String name = aClass.getName();
      return name.substring(name.lastIndexOf('/') + 1);
    }

    public Class<? extends U> getJClass() {
      return aClass;
    }

    @SafeVarargs
    @Override
    public final TypeRef<? extends JavaReferenceType> getRef(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
      return TypeRef.create(null, this, pGenericParams);
    }

    @Override
    public boolean isAssignableFrom(final Type pOther) {
      if (pOther instanceof ClassWrapper<?>) {
        final ClassWrapper<?> other = (ClassWrapper<?>) pOther;
        return aClass.isAssignableFrom(other.aClass);
      }
      if (pOther == ANY) {
        return true;
      }
      if (pOther instanceof MClass) {
        final MClass other = (MClass) pOther;
        if (other.getDescriptor().equals(getDescriptor())) {
          return true;
        }
        return other.hasParent(getRef(TypeRef.<JavaReferenceType> emptyList()));
      }
      if (pOther instanceof Primitive) {
        return false;
      }
      if (pOther instanceof ArrayType) {
        if (aClass.isArray()) {
          // TODO in the future don't support covariant arrays
          return TypeRef.create(null, aClass.getComponentType()).isAssignableFrom(((ArrayType) pOther).getElementType());
        }
        return false;
      }
      System.err.println("Further types are not yet implemented");
      return false;
    }

    @Override
    public String toString() {
      return aClass == null ? "_" : aClass.toString();
    }

    @Override
    public String toMetaCode(final int pIndent) {
      if (aClass == null) {
        return "_";
      }
      return aClass.getName().replace('/', '.');
    }

    @SafeVarargs
    @Override
    public final TypeRef<? extends JavaReferenceType> getParent(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
      final java.lang.reflect.Type parent = aClass.getGenericSuperclass();
      if (parent == null) {
        return null;
      }
      return TypeRef.create(null, parent).asReferenceType();
    }

    @SafeVarargs
    @Override
    public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
      return Arrays.asList(asReferenceType(createList(aClass.getGenericInterfaces())));
    }

    @Override
    public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
      final String name = pName.getName();
      //      final Class<?>[] parameterTypes = asClass(pParamTypes);
      //      if (parameterTypes == null) { // TODO In case the parameters are not classes it can't match
      //        return null;
      //      }
      if ((!aClass.isInterface()) && (name.equals("<init>") || name.equals(getClassName()))) {
        final Constructor<?>[] candidates = aClass.getConstructors();
        Constructor<?> result = null;
        for (final Constructor<?> candidate : candidates) {
          if (superClasses(TypeRef.createList(candidate.getParameterTypes()), pParamTypes, candidate.isVarArgs()) == Decision.True) {
            final Decision match = result == null ? Decision.True
                : superClasses(result.getParameterTypes(), candidate.getParameterTypes(), result.isVarArgs());
            switch (match) {
              case True:
                result = candidate;
                break;
              case False:
                break;
              default:
                pScope.getContext().error(pName, "Function can not be unambiguously be resolved");
                return null;
            }
          }
        }
        return result == null ? null : new FunctionRef(pName.getPos(), result);
      } else {
        Method result = getMatch(aClass.getMethods(), pName, pParamTypes, pScope);
        if ((result == null) && aClass.isInterface()) {
          result = getMatch(Object.class.getMethods(), pName, pParamTypes, pScope);
        }
        if (result == null) {
          if ("operator==".equals(name)) {
            return new BuiltinOperatorEq(pName.getPos(), true);
          } else if ("operator!=".equals(name) || "operator≠".equals(name)) {
            return new BuiltinOperatorEq(pName.getPos(), false);
          }
        }
        if (result == null) {
          return null;
        }
        return new FunctionRef(pName.getPos(), result);
      }
    }

    private static Method getMatch(final Method[] pMethods, final Symbol pName, final TypeRef<?>[] pParamTypes, final Scope pScope) throws CompilationException {
      Method result = null;
      final String name = pName.getName();
      for (final Method m : pMethods) {
        if (m.getName().equals(name)
            && (superClasses(TypeRef.createList(m.getParameterTypes()), pParamTypes, m.isVarArgs()) == Decision.True)) {
          if (result == null) {
            result = m;
          } else {
            final Decision match = superClasses(result.getParameterTypes(), m.getParameterTypes(), m.isVarArgs());
            switch (match) {
              case True:
                result = m;
                break;
              case False:
                break;
              default:
                pScope.getContext().error(pName, "Function can not be unambiguously be resolved");
                return null;
            }
          }
        }
      }
      return result;
    }

    private static Decision superClasses(final TypeRef<?>[] pParents, final TypeRef<?>[] pChildren, final boolean pVarArgs) {
      if (!pVarArgs) {
        if (pParents.length != pChildren.length) {
          return Decision.Undecidable;
        }
      }
      int sup = 0;
      int sub = 0;
      int extralen = 0;
      for (int i = 0; i < pParents.length; ++i) {
        if ((i < pChildren.length) && pParents[i].isAssignableFrom(pChildren[i])) {
          if (!pParents[i].equals(pChildren[i])) {
            ++sup;
          }
        } else {
          extralen = -1;
          if (pVarArgs && ((i + 1) == pParents.length)) {
            if (i == pChildren.length) {
              extralen = -1;
            } else {

              final TypeRef<?> varArgType = ((ArrayType) pParents[i].getReferredType()).getElementType();
              for (int j = i; j < pChildren.length; ++j) {
                if (varArgType.isAssignableFrom(pChildren[j])) {
                  if (!varArgType.equals(pChildren[j])) {
                    ++sup;
                  }
                  ++extralen;
                } else {
                  return Decision.Undecidable;
                }
              }
            }
          } else {
            ++sub;
          }
        }
      }
      if (pVarArgs) {
        if (pParents.length != (pChildren.length - extralen)) {
          return Decision.Undecidable;
        }
      }

      if ((sup == 0) && (sub > 0)) {
        return Decision.False;
      }
      if (sub == 0) {
        return Decision.True;
      }
      return Decision.Undecidable;
    }

    private static Decision superClasses(final Class<?>[] pParents, final Class<?>[] pChildren, final boolean pVarArgs) {
      if (!pVarArgs) {
        if (pParents.length != pChildren.length) {
          return Decision.Undecidable;
        }
      }
      int sup = 0;
      int sub = 0;
      int extralen = 0;
      for (int i = 0; i < pParents.length; ++i) {
        if ((i < pChildren.length) && pParents[i].isAssignableFrom(pChildren[i])) {
          if (!pParents[i].equals(pChildren[i])) {
            ++sup;
          }
        } else {
          if (pVarArgs && ((i + 1) == pParents.length)) {
            if (i == pChildren.length) {
              extralen = -1;
            } else {
              final Class<?> varArgType = pParents[i].getComponentType();
              for (int j = i; j < pChildren.length; ++j) {
                if (varArgType.isAssignableFrom(pChildren[j])) {
                  if (!varArgType.equals(pChildren[j])) {
                    ++sup;
                  }
                  ++extralen;
                } else {
                  return Decision.Undecidable;
                }
              }
            }
          } else {
            ++sub;
          }
        }
      }
      if (pVarArgs) {
        if (pParents.length != (pChildren.length - extralen)) {
          return Decision.Undecidable;
        }
      }

      if ((sup == 0) && (sub > 0)) {
        return Decision.False;
      }
      if (sub == 0) {
        return Decision.True;
      }
      return Decision.Undecidable;
    }

    @Override
    public FieldRef resolveField(final Symbol pField, final Scope pScope) {
      final String name = pField.getName();
      Field field;
      try {
        field = aClass.getField(name);
      } catch (final NoSuchFieldException ex) {
        return null; // TODO do not rely on exceptions
      }

      final TypeRef<?> varType = TypeRef.create(null, field.getType());
      return new FieldRef(AttributeFlags.fromModifiers(field.getModifiers()), getRef(), pField, varType);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != ClassWrapper.class) {
        return false;
      }
      return aClass.equals(((ClassWrapper<?>) pObj).aClass);
    }

    @Override
    public int hashCode() {
      return aClass.hashCode();
    }

    @Override
    public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().classWrapperCompileTransform(pToken, this, pTargetType, pExpr, pScope, pCleanupStack);
    }

    @Override
    public Literal<?> evalCallStatic(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
      try {
        final Class<?>[] parameterTypes = TypeRef.getJClass(pFunction.getFunctionType().getParamTypes(pScope));
        final Method m = aClass.getMethod(pFunction.getFunctionName(), parameterTypes);
        if (!pFunction.isStatic()) {
          pScope.getContext().error(pFunction, "Callin a nonstatic method on a type");
          return null;
        }
        final Object result = m.invoke(null, Literal.getObjValue(pArgs));
        if (m.getReturnType() == void.class) {
          return null;
        } else {
          return Literal.createByInference(null, result);
        }

      } catch (final NoSuchMethodException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final IllegalAccessException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final IllegalArgumentException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final InvocationTargetException ex) {
        throw new CompilationError(pFunction, ex);
      }
    }


    @Override
    public Literal<?> evalCallDynamic(final Literal<?> pTarget, final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
      try {
        final Class<?>[] parameterTypes = TypeRef.getJClass(pFunction.getFunctionType().getParamTypes(pScope));
        final Method m = aClass.getMethod(pFunction.getFunctionName(), parameterTypes);
        final Object target = pTarget.getObjValue();
        final Object result = m.invoke(target, Literal.getObjValue(pArgs));
        if (m.getReturnType() == void.class) {
          return null;
        } else {
          return Literal.createByInference(null, result);
        }

      } catch (final NoSuchMethodException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final IllegalAccessException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final IllegalArgumentException ex) {
        throw new CompilationError(pFunction, ex);
      } catch (final InvocationTargetException ex) {
        throw new CompilationError(pFunction, ex);
      }
    }

    @Override
    public boolean hasParent(final TypeRef<? extends JavaReferenceType> pCandidate) {
      if (!(pCandidate.getReferredType() instanceof ClassWrapper)) {
        return false;
      } else {
        final Class<?> candidate = ((ClassWrapper<?>) pCandidate.getReferredType()).aClass;
        return candidate.isAssignableFrom(aClass);
      }
    }

    @Override
    public List<FunctionRef> getMethods(final List<FunctionRef> pReceiver) {
      for (final Method method : aClass.getMethods()) {
        pReceiver.add(new FunctionRef(null, method));
      }
      return pReceiver;
    }

    @Override
    public List<FieldRef> getFields(final List<FieldRef> pReceiver) throws CompilationException {
      for (final Field field : aClass.getFields()) {
        final FieldRef fieldRef = new FieldRef(AttributeFlags.fromModifiers(field.getModifiers()), getRef(), new Symbol(null, field.getName()), TypeRef.create(null, field.getType()));
        pReceiver.add(fieldRef);
      }
      return pReceiver;
    }

    public boolean isAnnotation() {
      return aClass.isAnnotation();
    }

    public boolean isArrayType() {
      return aClass.isArray();
    }

  }

  private static final TypeRef<?>[] EMPTYLIST = new TypeRef<?>[0];

  public static final TypeRef<?> ANY = new TypeRef<>(null, null);

  private final T aType;

  private final TypeRef<? extends JavaReferenceType>[] aGenericParams;

  @SafeVarargs
  private TypeRef(final LinePosition pPosition, final T pType, final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    super(pPosition);
    if (pType != null) {
      aType = pType;
      GenericType.verifyCompatible(pType.getGenericParams(), pGenericParams);
    } else {
      aType = null;
    }
    aGenericParams = pGenericParams != null ? ((TypeRef<? extends JavaReferenceType>[]) pGenericParams)
        : TypeRef.<JavaReferenceType> emptyList();
  }

  public static <T extends JavaType> TypeRef<T> create(final LinePosition pPosition, final T pType) {
    return new TypeRef<>(pPosition, pType, TypeRef.<JavaReferenceType> emptyList());
  }

  @SafeVarargs
  public static <T extends JavaType> TypeRef<T> create(final LinePosition pPosition, final T pType, final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return new TypeRef<>(pPosition, pType, pGenericParams);
  }

  //  
  //  public static <U> TypeRef<?> create(Class<U> pClass) {
  //    return create(pClass, TypeRef.<ReferenceType>emptyList());
  //  }
  //  
  //  public static <U> TypeRef<?> create(Class<U> pClass, TypeRef<? extends ReferenceType>... pGenericParams) {
  //    return create(pClass, TypeRef.<ReferenceType>emptyList());
  //  }

  @SafeVarargs
  public static <U> TypeRef<?> create(final LinePosition pPosition, final Class<U> pClass, final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    if (pClass.equals(int.class)) {
      return Primitive.MInt.getRef();
    }
    if (pClass.equals(boolean.class)) {
      return Primitive.MBoolean.getRef();
    }
    if (pClass.equals(byte.class)) {
      return Primitive.MByte.getRef();
    }
    if (pClass.equals(char.class)) {
      return Primitive.MChar.getRef();
    }
    if (pClass.equals(short.class)) {
      return Primitive.MShort.getRef();
    }
    if (pClass.equals(float.class)) {
      return Primitive.MFloat.getRef();
    }
    if (pClass.equals(long.class)) {
      return Primitive.MLong.getRef();
    }
    if (pClass.equals(double.class)) {
      return Primitive.MDouble.getRef();
    }
    if (pClass.isArray()) {
      final ArrayType arrayType = new ArrayType(create(pPosition, pClass.getComponentType()));
      return arrayType.getRef();

    }

    return new TypeRef<>(pPosition, new ClassWrapper<>(pClass), pGenericParams);
  }

  public static TypeRef<?> create(final LinePosition pPosition, final java.lang.reflect.Type pType) {
    return create(pPosition, pType, TypeRef.<JavaReferenceType> emptyList());
  }


  @SafeVarargs
  public static TypeRef<?> create(final LinePosition pPosition, final java.lang.reflect.Type pType, final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    if (pType instanceof Class) {
      return create(pPosition, (Class<?>) pType, pGenericParams);
    } else if (pType instanceof ParameterizedType) {
      final ParameterizedType type = (ParameterizedType) pType;
      return create(pPosition, (Class<?>) type.getRawType(), asReferenceType(createList(type.getActualTypeArguments())));
    } else if (pType instanceof WildcardType) {
      //      WildcardType type = (WildcardType) pType;
      //      java.lang.reflect.Type[] lowerbounds = type.getLowerBounds();
      //      java.lang.reflect.Type[] upperbounds = type.getUpperBounds();
      return ANY; // TODO fix this to work properly
    } else if (pType instanceof GenericArrayType) {
      final ArrayType arrayType = new ArrayType(create(pPosition, ((GenericArrayType) pType).getGenericComponentType()));
      return arrayType.getRef();
    } else if (pType instanceof TypeVariable<?>) {
      final TypeVariable<?> var = (TypeVariable<?>) pType;
      // TODO don't just erase
      return create(pPosition, var.getBounds()[0]);
    }
    throw new IllegalArgumentException("Creating references to " + (pType == null ? "null" : pType.getClass().toString())
        + " is not implemented");
  }

  @SuppressWarnings("unchecked")
  private static TypeRef<? extends JavaReferenceType>[] asReferenceType(final TypeRef<? extends JavaType>... pCreateList) {
    final TypeRef<? extends JavaReferenceType>[] result = new TypeRef[pCreateList.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = pCreateList[i].asReferenceType();
    }
    return result;
  }

  public static Class<?>[] getJClass(final TypeRef<?>[] pParamTypes) {
    final Class<?>[] result = new Class<?>[pParamTypes.length];
    for (int i = 0; i < result.length; ++i) {
      result[i] = getJClass(pParamTypes[i]);
    }
    return result;
  }

  private static Class<?> getJClass(final TypeRef<?> pTypeRef) {
    if (pTypeRef.aType instanceof ClassWrapper<?>) {
      return ((ClassWrapper<?>) pTypeRef.aType).getJClass();
    } else if (pTypeRef.aType instanceof ArrayType) {
      final Class<?> elemType = getJClass(((ArrayType) pTypeRef.aType).getElementType());
      return Array.newInstance(elemType, 0).getClass();
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  /**
   * Is the object pointed to an interface?
   * 
   * @return true if pointing to an interface
   */
  public boolean isInterface() {
    if (aType instanceof ClassWrapper<?>) {
      return ((ClassWrapper<?>) aType).aClass.isInterface();
    }
    if (!(aType instanceof MClass)) {
      return false;
    }
    return ((MClass) aType).isInterface();
  }

  public String getSignature() {
    if ((aGenericParams == null) || (aGenericParams.length == 0)) {
      return aType.getDescriptor();
    } else if (!(aType instanceof JavaReferenceType)) {
      throw new IllegalStateException("Nonreference types can't have generic parameters");
    }
    final StringBuilder result = new StringBuilder().append('L').append(aType.getInternalName());
    result.append('<');
    for (final TypeRef<? extends JavaReferenceType> param : aGenericParams) {
      result.append(param.getSignature());
    }
    result.append(">;");
    return result.toString();
  }

  public String getDescriptor() {
    return aType.getDescriptor();
  }

  public T getReferredType() {
    return aType;
  }

  public String getInternalName() {
    return aType.getInternalName();
  }

  @SuppressWarnings("unchecked")
  public static TypeRef<? extends JavaType>[] createList(final java.lang.reflect.Type[] pTypes) {
    final TypeRef<? extends JavaType>[] result = new TypeRef[pTypes.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = create(null, pTypes[i]);
    }
    return result;
  }

  @SafeVarargs
  public static <T extends Type> TypeRef<? extends T>[] createList(final TypeRef<? extends T>... pList) {
    if ((pList == null) || (pList.length == 0)) {
      return TypeRef.<T> emptyList();
    }
    return pList;
  }

  @SuppressWarnings("unchecked")
  public static <T extends Type> TypeRef<? extends T>[] emptyList() {
    return (TypeRef<? extends T>[]) EMPTYLIST;
  }

  public boolean isAssignableFrom(final TypeRef<?> pOther) {
    if (pOther == null) {
      return false;
    }
    if (pOther.aType == null) {
      return true;
    }
    final boolean result = aType.isAssignableFrom(pOther.aType);
    if (!result) {
      return false;
    }
    if ((aGenericParams.length != 0) && (pOther.aGenericParams.length != 0)) {
      if (aGenericParams.length != pOther.aGenericParams.length) {
        return false;
      }
      for (int i = aGenericParams.length - 1; i >= 0; --i) {
        if (!(aGenericParams[i].isAssignableFrom(pOther.aGenericParams[i]))) {
          return false;
        }
      }
    }
    return true;
  }

  @Override
  public boolean equals(final Object pObj) {
    if (pObj == null) {
      return false;
    }
    if (pObj.getClass() != TypeRef.class) {
      return false;
    }
    final TypeRef<?> other = (TypeRef<?>) pObj;
    if (aType == null) {
      return other.aType == null;
    }
    final String myDesc = aType.getDescriptor();
    final String otherDesc = other.aType.getDescriptor();
    if (!myDesc.equals(otherDesc)) {
      return false;
    }
    return Arrays.equals(aGenericParams, other.aGenericParams);
  }

  @Override
  public int hashCode() {
    int result = aType.hashCode();
    for (final TypeRef<? extends JavaReferenceType> param : aGenericParams) {
      result = (result * 31) + param.hashCode();
    }
    return result;
  }

  public TypeRef<? extends JavaReferenceType> asReferenceType() {
    if (!((aType instanceof JavaReferenceType) || (this == ANY))) {
      return null;
      //      throw new ClassCastException("The type referred to is not a reference type");
    }

    @SuppressWarnings("unchecked")
    final TypeRef<? extends JavaReferenceType> result = (TypeRef<? extends JavaReferenceType>) this;

    return result;
  }

  /**
   * Get the parent type for the referred type.
   * 
   * @return a reference to the parent.
   */
  public TypeRef<? extends JavaReferenceType> getParent() {
    return aType.getParent(aGenericParams);
  }

  public List<TypeRef<? extends JavaReferenceType>> getInterfaces() {
    return aType.getInterfaces(aGenericParams);
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    return aType.resolveFunction(pScope, pName, pParamTypes);
  }

  public static TypeRef<? extends Type> createArray(final TypeRef<?> pElementType) {
    return create(null, new ArrayType(pElementType));
  }

  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return aType.compileTransform(pToken, pTargetType, pExpr, pScope, pCleanupStack);
  }

  @Override
  public String toString() {
    if (aType == null) {
      return "TypeRef<ANY>";
    }

    return "TypeRef<" + aType.toString() + ((aGenericParams.length > 0) ? ("<" + aGenericParams.toString() + ">>") : ">");
  }

  @Override
  public String toMetaCode(final int pIndent) {
    if (aType == null) {
      return "_";
    }
    ;
    final StringBuilder result = new StringBuilder();
    result.append(aType.getInternalName().replace('/', '.'));
    if ((aGenericParams != null) && (aGenericParams.length > 0)) {
      result.append('<');
      boolean first = true;
      for (final TypeRef<? extends JavaReferenceType> gparam : aGenericParams) {
        if (!first) {
          result.append(", ");
        }
        first = false;
        result.append(gparam.toMetaCode(0));
      }
      result.append('<');
    }
    return result.toString();
  }

  @Override
  public MLang getTokenType() {
    return MLang.TYPEREF;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public boolean isAnnotation() {
    if (aType instanceof ClassWrapper) {
      final ClassWrapper<?> type = (ClassWrapper<?>) aType;
      return type.isAnnotation();
    } else if (aType instanceof MClass) {
      return ((MClass) aType).isAnnotation();
    } else {
      return false;
    }
  }

  public boolean isArrayType() {
    return ((aType instanceof ArrayType) || ((aType instanceof ClassWrapper) && ((ClassWrapper<?>) aType).isArrayType()));
  }

  public TypeRef<?> getElementType() {
    if (aType instanceof ArrayType) {
      return ((ArrayType) aType).getElementType();
    }
    if (aType instanceof ClassWrapper<?>) {
      return TypeRef.create(null, ((ClassWrapper<?>) aType).aClass.getComponentType());
    }
    throw new UnsupportedOperationException("The referred type is not an array, so has not elementType");
  }

  public static boolean isWide(final TypeRef<?> pType) {
    final Object referredType = pType.getReferredType();
    return ((referredType == Primitive.MLong) || (referredType == Primitive.MDouble));
  }

  public boolean isSubTypeOf(final Class<ClassInstance> pClass) {
    return create(null, pClass).isAssignableFrom(this);
  }

}
