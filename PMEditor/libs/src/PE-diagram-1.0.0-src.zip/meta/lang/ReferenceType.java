package meta.lang;

import java.util.ArrayList;
import java.util.List;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;


public abstract class ReferenceType implements Type {

  /**
   * Check whether the given type ref is a parent of this type
   * 
   * @param pCandidate The candidate type to check
   * @return true if a parent (class or interface)
   */
  public abstract boolean hasParent(TypeRef<? extends JavaReferenceType> pCandidate);

  @Override
  public Literal<?> getDefaultValue() {
    return Literal.createByInference(null, null);
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException(getClass().getName() + " - Not yet implemented");
  }

  /**
   * Resolve a field
   * 
   * @param pField the name of the field to resolve
   * @param pScope TODO
   * @return the resulting field, or <code>null</code> if it doesn't exist
   * @throws CompilationException
   */
  public FieldRef resolveField(final Symbol pField, final Scope pScope) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException(getClass().getName() + " - Not yet implemented");
  }

  @Override
  public TypeRef<?> compileCallStatic(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    pScope.getContext().error(pFunction, "Most types do not have methods (yet)");
    return null;
  }

  @Override
  public Literal<?> evalCallStatic(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    pScope.getContext().error(pFunction, "Most types do not have methods (yet)");
    return null;
  }

  @Override
  public Literal<?> evalCallDynamic(final Literal<?> pTarget, final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    pScope.getContext().error(TypeRef.create(null, (JavaType) this), "Most types do not have methods (yet)");
    return null;
  }

  public abstract String getClassName();

  public abstract List<FunctionRef> getMethods(List<FunctionRef> pReceiver);

  @Override
  public List<FunctionRef> getMethods() {
    return getMethods(new ArrayList<FunctionRef>());
  }

  public abstract List<FieldRef> getFields(List<FieldRef> pReceiver) throws CompilationException;

  @Override
  public List<FieldRef> getFields() throws CompilationException {
    return getFields(new ArrayList<FieldRef>());
  }

}
