package meta.lang;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class FunctionType extends ReferenceType implements Expression {


  public enum MatchType {
    PERFECT,
    PARTIAL,
    NONE;
  }

  public static final List<AnnotateToken> _PUBLICSTATIC = AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.STATIC);

  public static final List<AnnotateToken> _PUBLIC = AnnotateToken.fromFlags(FunctionFlags.PUBLIC);

  private TypeRef<?> aOwner;

  private final VarAssign[] aParams;

  private Expression aReturnType;

  private final GenericType[] aGenericParams;

  private final List<AnnotateToken> aFlags;

  private final LinePosition aPosition;

  public FunctionType(final LinePosition pPosition, final List<AnnotateToken> pFlags, final TypeRef<?> pOwner, final Expression pReturnType, final TypeRef<?>... pParams) {
    this(pPosition, pFlags, pOwner, pReturnType, toVarAssigns(pParams));
  }

  private static VarAssign[] toVarAssigns(final TypeRef<?>[] pParams) {
    final VarAssign[] result = new VarAssign[pParams.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = toVarAssign(pParams[i]);
    }
    return result;
  }

  private static VarAssign toVarAssign(final TypeRef<?> pTypeRef) {
    return new VarAssign(pTypeRef.getPos(), null, null, pTypeRef, null);
  }

  public FunctionType(final LinePosition pPosition, final List<AnnotateToken> pFlags, final TypeRef<?> pOwner, final Expression pReturnType, final VarAssign... pParams) {
    aPosition = pPosition;
    aFlags = pFlags != null ? pFlags : new ArrayList<AnnotateToken>(0);
    aOwner = pOwner;
    aReturnType = pReturnType;
    aParams = pParams != null ? pParams : new VarAssign[0];
    aGenericParams = new GenericType[0];
  }

  public FunctionType(final Method pMethod) {
    aPosition = null;
    aFlags = AnnotateToken.fromFlags(FunctionFlags.fromModifiers(pMethod.getModifiers()));
    aFlags.addAll(AnnotateToken.fromAnnotations(pMethod.getAnnotations()));
    aOwner = TypeRef.create(null, pMethod.getDeclaringClass());
    final TypeRef<?> returnType = TypeRef.create(null, pMethod.getReturnType());
    aReturnType = returnType.equals(TypeRef.create(null, void.class)) ? null : returnType;
    final java.lang.reflect.Type[] parameterTypes = pMethod.getGenericParameterTypes();
    aParams = new VarAssign[parameterTypes.length];
    for (int i = aParams.length - 1; i >= 0; --i) {
      aParams[i] = toVarAssign(TypeRef.create(null, parameterTypes[i]));
    }
    final TypeVariable<Method>[] typeParams = pMethod.getTypeParameters();
    aGenericParams = new GenericType[typeParams.length];
    for (int i = aGenericParams.length - 1; i >= 0; --i) {
      aGenericParams[i] = new GenericType(typeParams[i]);
    }
  }

  public FunctionType(final Constructor<?> pConstructor) {
    aPosition = null;
    aFlags = AnnotateToken.fromFlags(FunctionFlags.fromModifiers(pConstructor.getModifiers()));
    aOwner = TypeRef.create(null, pConstructor.getDeclaringClass());
    aReturnType = null;
    final java.lang.reflect.Type[] parameterTypes = pConstructor.getGenericParameterTypes();
    aParams = new VarAssign[parameterTypes.length];
    for (int i = aParams.length - 1; i >= 0; --i) {
      aParams[i] = toVarAssign(TypeRef.create(null, parameterTypes[i]));
    }
    aGenericParams = new GenericType[0];
  }

  public String getDescriptor(final Scope pScope) throws CompilationException {
    final StringBuilder result = new StringBuilder();
    result.append('(');
    for (final VarAssign param : getParams()) {
      result.append(getParamType(param, pScope).getDescriptor());
    }
    result.append(')');
    if ((getReturnType(pScope) == null) || getReturnType(pScope).equals(TypeRef.create(null, void.class))) {
      result.append('V');
    } else {
      result.append(getReturnType(pScope).getDescriptor());
    }
    return result.toString();
  }

  public String getSignature() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public GenericType[] getGenericParams() {
    return aGenericParams;
  }

  @Override
  public String getInternalName() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public String getClassName() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public void setOwner(final MClass pOwner) {
    if (aOwner != null) {
      throw new IllegalStateException("Changing owners of functions is not allowed");
    }
    aOwner = pOwner.getRef(TypeRef.<JavaReferenceType> emptyList());
  }

  public TypeRef<?> getOwner() {
    return aOwner;
  }

  public Expression getReturnType() {
    return aReturnType;
  }

  public TypeRef<?> getReturnType(final Scope pScope) throws CompilationException {
    if ((aReturnType != null) && (!(aReturnType instanceof TypeRef))) {
      aReturnType = MEvaluator.toTypeRef(aReturnType, pScope);
    }
    return (TypeRef<?>) aReturnType;
  }

  public boolean hasFlag(final FunctionFlags pFlag) {
    return aFlags.contains(new AnnotateToken(null, pFlag.getRepr()));
  }

  public boolean isStatic() {
    return hasFlag(FunctionFlags.STATIC);
  }

  public boolean isPublic() {
    return hasFlag(FunctionFlags.PUBLIC);
  }

  public boolean isAbstract() {
    return hasFlag(FunctionFlags.ABSTRACT);
  }

  public boolean isVarArgs() {
    return hasFlag(FunctionFlags.VARARGS);
  }

  public VarAssign[] getParams() {
    return aParams;
  }

  public TypeRef<?>[] getParamTypes(final Scope pScope) throws CompilationException {
    final TypeRef<?>[] result = new TypeRef<?>[aParams.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = getParamType(aParams[i], pScope);
    }
    return result;
  }

  public MatchType match(final TypeRef<?>[] pParamTypes, final Scope pScope) throws CompilationException {
    if (pParamTypes.length != aParams.length) {
      return MatchType.NONE;
    }
    MatchType result = MatchType.PERFECT;
    for (int i = aParams.length - 1; i >= 0; --i) {
      final TypeRef<?> paramType = getParamType(aParams[i], pScope);
      if (paramType.equals(pParamTypes[i])) {
        continue;
      } else if (paramType.isAssignableFrom(pParamTypes[i])) {
        result = MatchType.PARTIAL;
      } else {
        return MatchType.NONE;
      }
    }

    return result;
  }

  @Override
  public boolean isAssignableFrom(final Type pOther) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public TypeRef<? extends JavaReferenceType> getParent(@SuppressWarnings("unchecked") final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @SafeVarargs
  @Override
  public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public EnumSet<FunctionFlags> getFlags(final Scope pScope) throws CompilationException {
    final List<FunctionFlags> result = new ArrayList<>(0);
    for (final AnnotateToken f : aFlags) {
      final FunctionFlags flag = FunctionFlags.fromString(f.getName());
      if (flag != null) {
        if ((f.getParams(pScope) != null) && (f.getParams(pScope).length > 0)) {
          pScope.getContext().error(f, "Builtin annotations do not have parameters");
        }
        result.add(flag);
      }
    }
    if (result.size() == 0) {
      return EnumSet.noneOf(FunctionFlags.class);
    }
    return EnumSet.copyOf(result);
  }

  public List<AnnotateToken> getFlags() {
    return aFlags;
  }

  public FunctionType newWithFlags(final List<AnnotateToken> pNewFlags) {
    return new FunctionType(aPosition, pNewFlags, null, aReturnType, aParams);
  }

  @Override
  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    final boolean first = true;
    result.append('(');
    if (aParams != null) {
      for (final VarAssign param : aParams) {
        if (!first) {
          result.append(',');
        }
        result.append(param.getLValue()).append(':').append(param.toString());
      }
    }
    result.append("):");
    result.append(aReturnType == null ? "void" : aReturnType.toString());
    return result.toString();
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    boolean first = true;
    result.append("[(");
    for (final VarAssign param : aParams) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      result.append(getParamName(param)).append(':').append(param.getValueType().toMetaCode(pIndent + 2));
    }
    result.append("):");
    result.append(aReturnType == null ? "()" : aReturnType.toMetaCode(0));
    result.append(']');
    return result.toString();
  }

  private static String getParamName(final VarAssign pParam) {
    final Expression lValue = pParam.getLValue();
    return lValue == null ? null : MEvaluator.toSymbol(lValue).getName();
  }

  private static TypeRef<?> getParamType(final VarAssign pParam, final Scope pScope) throws CompilationException {
    return MEvaluator.toTypeRef(pParam.getValueType(), pScope);
  }

  @Override
  public boolean hasParent(final TypeRef<? extends JavaReferenceType> pCandidate) {
    return false; // TODO Function types don't have parent types
  }

  @Override
  public Literal<?> eval(final Scope pScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public MLang getTokenType() {
    return MLang.FUNCTYPE;
  }

  @Override
  public LinePosition getPos() {
    return aPosition;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pEvalScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public List<FunctionRef> getMethods(final List<FunctionRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public List<FieldRef> getFields(final List<FieldRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public AnnotateToken getAnnotation(final Class<compiletime> pClass) {
    for (final AnnotateToken flag : aFlags) {
      if (flag.isAnnotation(pClass)) {
        return flag;
      }
    }
    return null;
  }

  @Override
  public Literal<?> evalFieldRef(final Object pInstance, final Symbol pName, final Scope pScope) throws CompilationException {
    pScope.getContext().error(pName, "Function types have no fields");
    return null;
  }

  @Override
  public boolean equals(final Object pObj) {
    if (pObj == this) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != FunctionType.class)) {
      return false;
    }
    final FunctionType other = (FunctionType) pObj;
    boolean equals = aFlags.equals(other.aFlags);
    equals = equals && (((aOwner == null) && (other.aOwner == null)) || aOwner.equals(other.aOwner));
    equals = equals && Arrays.equals(aParams, other.aParams);
    equals = equals && aReturnType.equals(other.aReturnType);
    equals = equals && Arrays.equals(aGenericParams, other.aGenericParams);
    return equals;
    //    
    //    return aFlags.equals(other.aFlags) && 
    //           ((aOwner == null && other.aOwner == null) || aOwner.equals(other.aOwner)) && 
    //           aParams.equals(other.aParams) &&
    //           aReturnType.equals(other.aReturnType) &&
    //           aGenericParams.equals(other.aGenericParams);
  }

  @Override
  public int hashCode() {
    int result = aParams.hashCode();
    result = (result * 31) + aReturnType.hashCode();
    return result;
  }

  public boolean isSame(final FunctionType pOther, final Scope pScope) throws CompilationException {
    if (pOther == this) {
      return true;
    }
    if ((pOther == null) || (pOther.getClass() != FunctionType.class)) {
      return false;
    }
    final FunctionType other = pOther;
    final boolean paramsEqual = Arrays.equals(getParamTypes(pScope), other.getParamTypes(pScope));
    return paramsEqual && aReturnType.equals(other.aReturnType);
  }

}
