package meta.lang;

import java.util.List;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvaluationException;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


/**
 * Represents a type in M
 * 
 * @author Paul de Vrieze TODO evaluate whether a type really isn't a value
 */
public interface Type extends NamedObject /* Expression */{

  public String getInternalName();

  /**
   * Get the generic parameters for this type
   * 
   * @return the generic parameters
   */
  public GenericType[] getGenericParams();

  /**
   * Is this type a supertype of the other type?
   * 
   * @param pOther The type to compare with
   * @return true if this is a superclass of the other type
   */
  public boolean isAssignableFrom(Type pOther);

  /**
   * Get a reference to the parent type when the generic params for this type
   * are given
   * 
   * @param pGenericParams The generic params for this type.
   * @return a reference to the parent
   */
  public TypeRef<? extends JavaReferenceType> getParent(@SuppressWarnings("unchecked") TypeRef<? extends JavaReferenceType>... pGenericParams);

  /**
   * Get references to the interfaces when the generic params for this type are
   * given
   * 
   * @param pGenericParams The generic params for this type.
   * @return a reference to the parent
   */
  public List<TypeRef<? extends JavaReferenceType>> getInterfaces(@SuppressWarnings("unchecked") TypeRef<? extends JavaReferenceType>... pGenericParams);

  /**
   * Resolve a function on the type
   * 
   * @param pScope The scope to use for errors
   * @param pParamTypes The parameter types
   * @param pSymbol
   * @return
   * @throws CompilationException
   */
  public FunctionRef resolveFunction(Scope pScope, Symbol pName, TypeRef<?>... pParamTypes) throws CompilationException;

  /**
   * Get the list of functions provided by this type.
   * 
   * @return
   */
  public List<FunctionRef> getMethods();

  /**
   * Return the list of fields in this type.
   * 
   * @return The list. Private fields may not be returned
   * @throws CompilationException
   */
  public List<FieldRef> getFields() throws CompilationException;

  /**
   * Compile calling the given static function on the type
   * 
   * @param pFunction The function to call
   * @param pScope TODO
   * @param pCleanupStack TODO
   * @return the return type of the function
   * @throws CompilationException When compilation encounters errors
   */
  public TypeRef<?> compileCallStatic(FunctionRef pFunction, Scope pScope, boolean pCleanupStack) throws CompilationException;

  /**
   * Compile the transformation of an instance of this type to the target type.
   * 
   * @param pToken A token for errors
   * @param pTargetType The target type
   * @param pExpr The expression to be transformed
   * @param pScope The compilation scope
   * @param pCleanupStack Should a value be left on the stack afterwards
   * @return
   * @throws CompilationException
   */
  public TypeRef<?> compileTransform(LinedToken<MLang> pToken, TypeRef<?> pTargetType, Expression pExpr, Scope pScope, boolean pCleanupStack) throws CompilationException;

  /**
   * Evaluate calling the given static function on the type.
   * 
   * @param pFunction The function to call
   * @param pScope TODO
   * @param pArgs TODO
   * @param pCleanupStack TODO
   * @return the return type of the function
   * @throws EvaluationException When evaluating encounters errors
   * @throws CompilationException When evaluating encounters errors
   */
  public Literal<?> evalCallStatic(FunctionRef pFunction, Scope pScope, Literal<?>... pArgs) throws CompilationException;

  /**
   * Evaluate calling the given dynamic function on the type.
   * 
   * @param pFunction The function to call
   * @param pScope TODO
   * @param pArgs TODO
   * @param pCleanupStack TODO
   * @return the return type of the function
   * @throws EvaluationException When evaluating encounters errors
   * @throws CompilationException When evaluating encounters errors
   */
  public Literal<?> evalCallDynamic(Literal<?> pTarget, FunctionRef pFunction, Scope pScope, Literal<?>... pArgs) throws CompilationException;

  /**
   * Look up a field on the type
   * 
   * @param pInstance instance to look up on
   * @param pName The name of the field
   * @param pScope The scope to use
   * @return
   * @throws EvaluationException
   * @throws CompilationException
   */
  public abstract Literal<?> evalFieldRef(Object pInstance, Symbol pName, Scope pScope) throws CompilationException;

  /**
   * Get a literal representing the default value of this type
   * 
   * @return the default value
   */
  public Literal<?> getDefaultValue();

  /**
   * {@inheritDoc}
   */
  public String toMetaCode(int pIndent);
}
