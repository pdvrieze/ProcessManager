package meta.lang;

import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class GenericType extends JavaReferenceType {

  private final TypeRef<? extends JavaReferenceType> aParent;

  private final List<TypeRef<? extends JavaReferenceType>> aInterfaces;

  private final String aName;

  @SafeVarargs
  public GenericType(final String pName, final TypeRef<? extends JavaReferenceType> pSuperClass, final TypeRef<? extends JavaReferenceType>... pInterfaces) {
    aName = pName;
    aParent = pSuperClass;
    aInterfaces = Arrays.asList(pInterfaces);
  }

  public GenericType(final TypeVariable<?> pTypeVariable) {
    final ArrayList<TypeRef<? extends JavaReferenceType>> interfaces = new ArrayList<>(pTypeVariable.getBounds().length);
    aName = pTypeVariable.getName();
    aParent = TypeRef.create(null, Object.class).asReferenceType();
    for (final java.lang.reflect.Type t : pTypeVariable.getBounds()) {
      interfaces.add(TypeRef.create(null, t).asReferenceType());
    }
    pTypeVariable.getBounds();
    aInterfaces = Arrays.asList(TypeRef.<JavaReferenceType> emptyList());
  }

  @Override
  public String getDescriptor() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public GenericType[] getGenericParams() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public String getInternalName() {
    return aName;
  }

  @Override
  public String getClassName() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @SafeVarargs
  @Override
  public final TypeRef<GenericType> getRef(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return TypeRef.create(null, this, pGenericParams);
  }

  @Override
  public String getSignature() {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public CharSequence getFormalTypeParameter() {
    final StringBuilder result = new StringBuilder();
    result.append(getInternalName()).append(':');
    if (aParent.isInterface()) {
      result.append(':');
    }
    result.append(aParent.getSignature());

    for (final TypeRef<? extends JavaReferenceType> mInterface : aInterfaces) {
      result.append(':').append(mInterface.getSignature());
    }

    return result;
  }

  /**
   * Verify that the parameters are compatible.
   * 
   * @param pExpected
   * @param pGenericParams
   * @param pParams
   */
  public static void verifyCompatible(final GenericType[] pExpected, final TypeRef<?>[] pFound) {
    for (final TypeRef<?> i : pFound) {
      if (i == null) {
        throw new NullPointerException();
      }
    }
    // TODO Auto-generated method stub
    // 
    //    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public boolean isAssignableFrom(final Type pOther) {
    // TODO Auto-generated method stub
    // return false;
    throw new UnsupportedOperationException("Not yet implemented");

  }

  @Override
  public boolean equals(final Object pObj) {
    // TODO Auto-generated method stub
    // return super.equals(pObj);
    throw new UnsupportedOperationException("Not yet implemented");

  }

  @Override
  public int hashCode() {
    // TODO Auto-generated method stub
    // return super.hashCode();
    throw new UnsupportedOperationException("Not yet implemented");

  }

  @SafeVarargs
  @Override
  public final TypeRef<? extends JavaReferenceType> getParent(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return aParent;
  }

  @SafeVarargs
  @Override
  public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return aInterfaces;
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    FunctionRef result = aParent.resolveFunction(pScope, pName, pParamTypes);
    if (result != null) {
      return result;
    }
    for (final TypeRef<? extends JavaReferenceType> iface : aInterfaces) {
      result = iface.resolveFunction(pScope, pName, pParamTypes);
      if (result != null) {
        return result;
      }
    }
    return null;
  }

  @Override
  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return aParent.compileTransform(pToken, pTargetType, pExpr, pScope, pCleanupStack);
  }

  @Override
  public boolean hasParent(final TypeRef<? extends JavaReferenceType> pCandidate) {
    if ((!pCandidate.isInterface()) && pCandidate.getReferredType().equals(this)) {
      return true;
    }
    if (pCandidate.isInterface()) {
      for (final TypeRef<? extends JavaReferenceType> iface : aInterfaces) {
        if (iface.getReferredType().hasParent(pCandidate)) {
          return true;
        }
      }
    }
    return aParent.getReferredType().hasParent(pCandidate);
  }

  @Override
  public TypeRef<?> compileCallStatic(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public List<FunctionRef> getMethods(final List<FunctionRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public List<FieldRef> getFields(final List<FieldRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

}
