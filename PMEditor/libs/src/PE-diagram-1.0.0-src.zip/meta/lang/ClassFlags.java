package meta.lang;

import java.lang.reflect.Modifier;
import java.util.EnumSet;

import static org.objectweb.asm.Opcodes.*;

import net.devrieze.meta.compile.MFlags;


public enum ClassFlags implements MFlags {
  PUBLIC(ACC_PUBLIC, "public"),
  PROTECTED(ACC_PROTECTED, "protected"),
  PRIVATE(ACC_PRIVATE, "private"),
  ABSTRACT(ACC_ABSTRACT, "abstract"),
  INTERFACE(ACC_INTERFACE, "interface"),
  STATIC(ACC_STATIC, "static"),
  FINAL(ACC_FINAL, "final"),
  STRICTFP(ACC_STRICT, "strictfp"),
  SYNTHETIC(ACC_SYNTHETIC, "synthetic"),
  ANNOTATION(ACC_ANNOTATION, "annotation"),
  ENUM(ACC_ENUM, "enum");

  final int aFlagValue;

  final String aMetaRepr;

  ClassFlags(final int pFlagValue, final String pMetaRepr) {
    aFlagValue = pFlagValue;
    aMetaRepr = pMetaRepr;
  }

  @Override
  public int getFlagValue() {
    return aFlagValue;
  }

  public static ClassFlags fromString(final String pName) {
    for (final ClassFlags flag : values()) {
      if (flag.name().equals(pName) || flag.aMetaRepr.equals(pName)) {
        return flag;
      }
    }
    return null;
  }

  public static EnumSet<ClassFlags> fromModifiers(final int pModifiers) {
    final EnumSet<ClassFlags> result = EnumSet.noneOf(ClassFlags.class);
    if (Modifier.isPublic(pModifiers)) {
      result.add(PUBLIC);
    }
    if (Modifier.isProtected(pModifiers)) {
      result.add(PROTECTED);
    }
    if (Modifier.isPrivate(pModifiers)) {
      result.add(PRIVATE);
    }
    if (Modifier.isAbstract(pModifiers)) {
      result.add(ABSTRACT);
    }
    if (Modifier.isInterface(pModifiers)) {
      result.add(INTERFACE);
    }
    if (Modifier.isStatic(pModifiers)) {
      result.add(STATIC);
    }
    if (Modifier.isFinal(pModifiers)) {
      result.add(FINAL);
    }
    if (Modifier.isStrict(pModifiers)) {
      result.add(STRICTFP);
    }
    if ((pModifiers & 0x1000) != 0) {
      result.add(SYNTHETIC);
    }
    if ((pModifiers & 0x2000) != 0) {
      result.add(ANNOTATION);
    }
    if ((pModifiers & 0x4000) != 0) {
      result.add(ENUM);
    }
    return result;
  }

  @Override
  public String toMetaCode() {
    return '@' + aMetaRepr;
  }

  @Override
  public String getRepr() {
    return aMetaRepr;
  }

}
