package meta.lang;

import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.ClassInstance;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;
import net.devrieze.util.StringUtil;


public class Function extends AbstractExpression {

  private final FunctionType aFunctionType;

  private final String aName;

  private final Expression[] aImplementation;

  public Function(final LinePosition pPosition, final String pName, final FunctionType pType, final Expression... pImlementation) {
    super(pPosition);
    aName = pName;
    aFunctionType = pType;
    aImplementation = pImlementation;
  }

  public Function(final LinePosition pPosition, final List<AnnotateToken> pFlags, final String pName, final TypeRef<?> pReturnType, final VarAssign[] pParams, final Expression... pImplementation) {
    this(pPosition, pName, new FunctionType(pPosition, pFlags, null, pReturnType, pParams), pImplementation);
  }

  public Function newWithName(final String pName) {
    return new Function(getPos(), pName, aFunctionType, aImplementation);
  }

  @SuppressWarnings("unchecked")
  public TypeRef<MClass> getOwner() {
    return (TypeRef<MClass>) aFunctionType.getOwner();
  }

  public FunctionType getFunctionType() {
    return aFunctionType;
  }

  public String getName() {
    return aName;
  }

  public void setOwner(final MClass pOwner) {
    aFunctionType.setOwner(pOwner);
  }

  public FunctionRef getRef() {
    return new FunctionRef(null, aName, aFunctionType);
  }

  /**
   * Compile the function
   * 
   * @category Function
   */
  public void function_compile(final Scope pScope) throws CompilationException {
    pScope.getCompiler().compileFunction(pScope, this);
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  public Literal<?> evalCall(final Scope pScope, final LinePosition pPos, final ClassInstance pTarget, final Literal<?>[] pArgs) throws CompilationException {
    // TODO see what to do with static functions
    ClassInstance target = pTarget;
    if (isConstructor(pScope)) {
      target = new ClassInstance(getOwner());
      target.evalFunction(this, pArgs);
      return Literal.create(pPos, target);
    } else if (getFunctionType().isStatic()) {
      final MClass owner = getOwner().getReferredType();
      return owner.evalStaticFunction(this, pArgs);
    } else if (pTarget == null) {
      pScope.getContext().error(this, "Null target for non-constructor function");
    }
    return target.evalFunction(this, pArgs);
  }


  public boolean isConstructor(final Scope pScope) throws CompilationException {
    return (aFunctionType.getReturnType(pScope) == null)
        && (aName.equals("<init>") || aName.equals(getOwner().getReferredType().getClassName()));
  }

  @Override
  public boolean equals(final Object pObj) {
    if (pObj == this) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != Function.class)) {
      return false;
    }
    final Function other = (Function) pObj;
    boolean equals = aName.equals(other.aName) && aFunctionType.equals(other.aFunctionType);
    equals = equals && Arrays.equals(aImplementation, other.aImplementation);
    return equals;
  }

  @Override
  public int hashCode() {
    return (((aName.hashCode() * 31) + aFunctionType.hashCode()) * 31) + aImplementation.hashCode();
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append(aName).append(aFunctionType).append("(\n");
    boolean first = true;
    for (final Expression val : aImplementation) {
      if (!first) {
        result.append(",\n");
      }
      first = false;
      result.append("  ").append(val);
    }
    result.append(")\n");
    return result.toString();
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    StringUtil.addChars(result, pIndent, ' ');
    for (final AnnotateToken flag : aFunctionType.getFlags()) {
      result.append(flag.toMetaCode()).append(' ');
    }

    result.append(aName);
    result.append(" : ");
    result.append(aFunctionType.toMetaCode(0));
    if (!getFunctionType().isAbstract()) {
      result.append(" = (\n");
      StringUtil.addChars(result, pIndent + 2, ' ');
      boolean first = true;
      for (final Expression val : aImplementation) {
        if (!first) {
          result.append(",\n");
          StringUtil.addChars(result, pIndent + 2, ' ');
        }
        first = false;
        result.append(val.toMetaCode(pIndent + 2));
      }
      result.append('\n');
      StringUtil.addChars(result, pIndent, ' ');
      result.append(")\n");
    }
    return result.toString();
  }

  public Expression[] getImplementation() {
    return aImplementation;
  }

  @Override
  public MLang getTokenType() {
    return MLang.FUNCDEF;
  }

}
