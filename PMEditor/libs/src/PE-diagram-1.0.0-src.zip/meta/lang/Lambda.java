package meta.lang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;


// TODO verify that it should extend AbstractValue
public abstract class Lambda<T> /* extends AbstractExpression */{

  private static final String PARAMSNAME = "pParams";

  private static int _anonLambdaCnt = 1;

  private static Expression[] toParamValues(final LinePosition pPosition, final VarAssign[] pParams, final Scope pScope) throws CompilationException {
    final Expression[] result = new Expression[pParams.length];
    final Symbol pvar = new Symbol(pPosition, PARAMSNAME);
    final FunctionRef operator = new FunctionRef(pPosition, "operator[", new FunctionType(pPosition, Arrays.<AnnotateToken> asList(), null, TypeRef.create(pPosition, Object.class), TypeRef.create(pPosition, Primitive.MInt)));
    for (int i = result.length - 1; i >= 0; --i) {
      final TypeRef<?> param = MEvaluator.toTypeRef(pParams[i].getValueType(), pScope);
      if (param.getReferredType() instanceof Primitive) {
        final Primitive paramType = (Primitive) param.getReferredType();
        result[i] = new TypeCast(pPosition, param, new TypeCast(pPosition, paramType.getWrappedType(), FuncCall.create(pPosition, pvar, operator, new Expression[] { Literal.createInt(pPosition, i) })));
      } else {
        result[i] = new TypeCast(pPosition, param, FuncCall.create(pPosition, pvar, operator, new Expression[] { Literal.createInt(pPosition, i) }));
      }
    }
    return result;
  }

  /**
   * Determine whether the function type is actually a straight lambda method,
   * no synthetic is needed.
   * 
   * @param pType
   * @return
   */
  private static boolean isPureLambda(final Expression pType) {
    // TODO Auto-generated method stub
    return false;
    //    throw new UnsupportedOperationException("Not yet implemented");
  }

  private static StringBuilder generateName(final FunctionType pType, final Scope pScope) throws CompilationException {
    final StringBuilder result = new StringBuilder();
    result.append('(');
    boolean first = true;
    for (final VarAssign param : pType.getParams()) {
      if (!first) {
        result.append('#');
      }
      first = false;
      result.append(MEvaluator.toTypeRef(param.getValueType(), pScope).getDescriptor());
    }
    result.append(')').append(pType.getReturnType(pScope).getDescriptor());
    return result;
  }

  private static Expression[] asVarRefs(final VarAssign[] pParams) {
    final Expression[] result = new Expression[pParams.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = MEvaluator.toSymbol(pParams[i].getLValue());
    }
    return result;
  }

  private static VarAssign[] ensureNames(final VarAssign[] pParams) {
    int count = 1;
    final VarAssign[] result = new VarAssign[pParams.length];
    for (int i = result.length - 1; i >= 0; --i) {
      final VarAssign tupple = pParams[i];
      if (tupple.getLValue() == null/* TODO || tupple.getElem1().equals("") */) {
        final String name = "p" + (count++);
        result[i] = new VarAssign(tupple.getPos(), tupple.getFlags(), new Symbol(null, name), tupple.getValueType(), tupple.getRValue());
      } else {
        result[i] = tupple;
      }
    }
    return result;
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  public static Class<? extends Lambda<?>> generate(final LinePosition pPosition, final FunctionType pType, final Scope pScope) throws CompilationException {
    if (isPureLambda(pType)) {
      return (Class) Lambda.class;
    }
    final String name = "meta/lang/gen/Lambda$$" + generateName(pType, pScope);
    {
      try {
        final Class<?> result = pScope.getContext().getClassLoader().loadClass(name);
        return (Class) result.asSubclass(Lambda.class);
      } catch (final ClassNotFoundException ex) {
        // Just fall through when this class does not exist yet.
      }
    }

    final ArrayList<VarAssign> attributes = new ArrayList<>(0);

    final FunctionType newType = pType.newWithFlags(AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.ABSTRACT, FunctionFlags.SYNTHETIC));
    final Function lambda = new Function(pPosition, "lambda", newType);

    final FunctionType bridge1Type = new FunctionType(pPosition, AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.BRIDGE, FunctionFlags.VARARGS, FunctionFlags.SYNTHETIC), null, TypeRef.create(pPosition, Object.class).asReferenceType(), new VarAssign[] { new VarAssign(null, null, new Symbol(pPosition, PARAMSNAME), TypeRef.createArray(TypeRef.create(pPosition, Object.class)), null) });

    final Function bridge1 = new Function(pPosition, "lambda", bridge1Type, new Return(pPosition, new TypeCast(pPosition, TypeRef.create(pPosition, Object.class), FuncCall.create(pPosition, new Symbol(pPosition, "this"), lambda.getRef(), toParamValues(pPosition, lambda.getFunctionType().getParams(), pScope)))));

    final FunctionType bridge2Type = new FunctionType(pPosition, AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.BRIDGE, FunctionFlags.VARARGS, FunctionFlags.SYNTHETIC), null, TypeRef.create(pPosition, Integer.class).asReferenceType(), new VarAssign[] { new VarAssign(null, null, new Symbol(pPosition, PARAMSNAME), TypeRef.createArray(TypeRef.create(pPosition, Object.class)), null) });

    final Function bridge2 = new Function(pPosition, "lambda", bridge2Type, new Return(pPosition, new TypeCast(pPosition, TypeRef.create(pPosition, Integer.class), FuncCall.create(pPosition, new Symbol(pPosition, "this"), lambda.getRef(), toParamValues(pPosition, lambda.getFunctionType().getParams(), pScope)))));

    final List<Function> methods = Arrays.asList(bridge1, bridge2, lambda);
    final MClass result = new MClass(pPosition, AnnotateToken.fromFlags(ClassFlags.PUBLIC, ClassFlags.SYNTHETIC, ClassFlags.ABSTRACT), name, TypeRef.create(pPosition, Lambda.class, TypeRef.create(pPosition, Integer.class).asReferenceType()).asReferenceType(), null, attributes, methods, pScope);
    final byte[] byteArray = result.compileClass(Scope.fileScope(pScope.getContext())).getByteArray();
    pScope.getContext().setClassWriter(null); // Ensure a new class writer for the next fool ;-)
    try {
      final Class<?> clazz = pScope.getContext().getClassLoader().define(byteArray);
      return (Class) clazz.asSubclass(Lambda.class);
    } catch (final Error e) {
      pScope.getContext().handleException(e, byteArray);
      throw e;
    } catch (final RuntimeException e) {
      pScope.getContext().handleException(e, byteArray);
      throw e;
    }
  }

  public static MClass generate(final LinePosition pPosition, final FunctionRef pFunctionRef, final Scope pScope) throws CompilationException {
    final Class<? extends Lambda<?>> parent = generate(pPosition, pFunctionRef.getFunctionType(), pScope);

    final String functionName = pFunctionRef.getFunctionName();
    final String className = "meta/lang/gen/Lambda$%" + (functionName != null ? functionName : Integer.toString(_anonLambdaCnt++));

    final VarAssign[] params = ensureNames(pFunctionRef.getFunctionType().getParams());

    final FunctionType ft = new FunctionType(pPosition, AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.SYNTHETIC), null, pFunctionRef.getReturnType(pScope), params);
    final Function function = new Function(pPosition, "lambda", ft, FuncCall.create(pPosition, null, pFunctionRef, asVarRefs(params)));

    final ArrayList<VarAssign> attributes = new ArrayList<>(0);
    final List<Function> methods = Arrays.asList(function);

    return new MClass(pPosition, AnnotateToken.fromFlags(ClassFlags.PUBLIC, ClassFlags.SYNTHETIC), className, TypeRef.create(pPosition, parent).asReferenceType(), null, attributes, methods, pScope);
  }

  public static MClass generate(final LinePosition pPosition, final FunctionType pFunctionType, final Expression pExpr, final Scope pScope) throws CompilationException {
    final Class<? extends Lambda<?>> parent = generate(pPosition, pFunctionType, pScope);

    final String className = "meta/lang/gen/Lambda$" + Integer.toString(_anonLambdaCnt++);

    final Function function = new Function(pPosition, "lambda", pFunctionType, pExpr);

    final List<Function> methods = Arrays.asList(function);

    return new MClass(pPosition, AnnotateToken.fromFlags(ClassFlags.PUBLIC, ClassFlags.SYNTHETIC), className, TypeRef.create(pPosition, parent).asReferenceType(), null, null, methods, pScope);
  }

  public abstract T lambda(Object... pParams);

}
