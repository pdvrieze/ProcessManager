package meta.lang;


import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationContext;
import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.EvaluationErrors;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class FuncCall extends AbstractExpression {

  private final Expression aTarget;

  private final Symbol aFunctionSymbol;

  private final Expression[] aArgs;

  private final Expression aReturnType;

  public static FuncCall create(final LinePosition pPosition, final Expression pTarget, final Symbol pFunctionSymbol, final List<Expression> pArgs) {
    return new FuncCall(pPosition, pTarget, pFunctionSymbol, TypeRef.ANY, pArgs.toArray(new Expression[pArgs.size()]));
  }

  public static FuncCall create(final LinePosition pPosition, final Expression pTarget, final Symbol pFunctionSymbol, final TypeRef<?> pReturnType, final List<Expression> pArgs) {
    return new FuncCall(pPosition, pTarget, pFunctionSymbol, pReturnType, pArgs.toArray(new Expression[pArgs.size()]));
  }

  public static FuncCall create(final LinePosition pPosition, final Expression pTarget, final FunctionRef pFunctionRef, final Expression[] pArgs) {
    return new FuncCall(pPosition, pTarget, new Symbol(pFunctionRef.getPos(), pFunctionRef.getFunctionName()), pFunctionRef.getReturnType(), pArgs);
  }

  public static FuncCall create(final LinePosition pPosition, final Expression pTarget, final Symbol pFunctionSymbol, final Expression pReturnType, final Expression[] pArgs) {
    return new FuncCall(pPosition, pTarget, pFunctionSymbol, pReturnType, pArgs);
  }

  private FuncCall(final LinePosition pPosition, final Expression pTarget, final Symbol pFunctionSymbol, final Expression pReturnType, final Expression[] pArgs) {
    super(pPosition);
    if ((pTarget == null) && pFunctionSymbol.getName().equals("super")) {
      aTarget = new Symbol(pFunctionSymbol.getPos(), "super");
      aFunctionSymbol = new Symbol(pFunctionSymbol.getPos(), "<init>");
    } else {
      aTarget = pTarget;
      aFunctionSymbol = pFunctionSymbol;
    }
    aReturnType = pReturnType;
    aArgs = pArgs;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileFuncCall(this, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    if ((aReturnType != TypeRef.ANY) && (aReturnType instanceof TypeRef)) {
      return (TypeRef<?>) aReturnType;
    }
    final FunctionRef function = resolveFunction(pScope);
    if (function == null) {
      pScope.getContext().error(this, CompilationErrors.FUNCTION_NOT_RESOLVED);
      return null;
    }
    if (function.isConstructor()) {
      return function.getOwner();
    } else {
      return function.getReturnType(pScope);
    }
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    final CompilationContext context = pScope.getContext();
    Literal<?>[] args = new Literal<?>[aArgs.length];
    final TypeRef<?>[] argTypes = new TypeRef<?>[aArgs.length];
    for (int i = args.length - 1; i >= 0; --i) {
      final Literal<?> val = pScope.expectLiteral(aArgs[i].eval(pScope));
      args[i] = val;
      argTypes[i] = val == null ? null : val.getReferredType();
    }
    final FunctionRef function = resolveFunction(pScope, argTypes);
    if (function == null) {
      context.error(aFunctionSymbol, "Function not found");
      return null;
    }
    {
      final AnnotateToken an = function.getFunctionType().getAnnotation(compiletime.class);
      if (an != null) {
        boolean addScope = false;
        for (final Expression param : MEvaluator.toTupple(an.getParam("value", pScope))) {
          if (MEvaluator.toLiteral(param, pScope).getObjValue() == compiletime.CompilerDirectives.SCOPE) {
            addScope = true;
          } else {
            throw new UnsupportedOperationException("Other annotations than SCOPE are not yet supported");
          }
        }
        if (addScope) {
          final TypeRef<?>[] paramTypes = function.getFunctionType().getParamTypes(pScope);
          final Literal<?>[] newArgs = new Literal<?>[paramTypes.length];
          final TypeRef<?> scopeRef = TypeRef.create(null, Scope.class);
          for (int i = 0, j = 0; (i < paramTypes.length) && (j < aArgs.length); ++i) {
            if (scopeRef.isAssignableFrom(paramTypes[i])) {
              newArgs[i] = Literal.createObj(null, scopeRef, pScope);
            } else {
              newArgs[i] = args[j];
              ++j;
            }
          }
          args = newArgs;
        }

      }
    }

    Literal<?> result;
    if (aTarget != null) {
      result = function.evalCall(pScope, aTarget, args);
    } else {
      result = context.evalGlobal(function, pScope, args);
    }
    if (result == null) {
      if (function.getReturnType() != null) {
        pScope.getContext().error(this, EvaluationErrors.TYPE_ERROR, "Expected: " + function.getReturnType(), "Got: void");
      }
      return null;
    } else {
      if (function.getReturnType(pScope).isAssignableFrom(result.getReferredType())) {
        return result;
      } else {
        pScope.getContext().error(this, EvaluationErrors.TYPE_ERROR, "Expected: " + function.getReturnType(), "Got: "
            + result.getReferredType());
        throw new IllegalStateException("Should be unreachable");
      }
    }
  }

  private FunctionRef resolveFunction(final Scope pScope, final TypeRef<?>[] argTypes) throws CompilationException {
    if (aTarget != null) {
      final TypeRef<?> evalType = aTarget.getEvalType(pScope);
      return evalType == null ? null : evalType.resolveFunction(pScope, aFunctionSymbol, argTypes);
    } else {
      return pScope.resolveFunction(aFunctionSymbol, argTypes);
    }
  }

  private FunctionRef resolveFunction(final Scope pScope) throws CompilationException {
    final TypeRef<?>[] argTypes = new TypeRef<?>[aArgs.length];
    for (int i = argTypes.length - 1; i >= 0; --i) {
      argTypes[i] = aArgs[i].getEvalType(pScope);
    }
    if (aTarget != null) {
      final TypeRef<?> targetType = aTarget.getEvalType(pScope);
      return targetType.resolveFunction(pScope, aFunctionSymbol, argTypes);
    } else {
      return pScope.resolveFunction(new Symbol(getPos(), aFunctionSymbol.getName()), argTypes);
    }
  }

  public Expression getTarget() {
    return aTarget;
  }

  public String getFunctionName() {
    return aFunctionSymbol.getName();
  }

  public Symbol getFunctionSymbol() {
    return aFunctionSymbol;
  }

  public Expression[] getArgs() {
    return aArgs;
  }


  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    if (aTarget != null) {
      final String target = aTarget.toString();
      if (!target.equals("this")) {
        result.append(target).append('.');
      }
    }
    result.append(aFunctionSymbol.getName()).append('(');
    boolean first = true;
    for (final Expression arg : aArgs) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      result.append(arg);
    }
    result.append(')');

    return result.toString();
  }


  @Override
  public String toMetaCode(final int pIndent) {
    if (aFunctionSymbol.getName().startsWith("operator")) {
      return operatorMetaCode(pIndent);
    }
    final StringBuilder result = new StringBuilder();
    if (aTarget != null) {
      final String target = aTarget.toMetaCode(pIndent);
      if (!"this".equals(target)) {
        result.append(target).append('.');
      }
    }
    result.append(aFunctionSymbol.getName()).append('(');
    final int indent = result.length();
    boolean first = true;
    for (final Expression arg : aArgs) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      // TODO check why this can be null
      result.append(arg == null ? "<NULL>" : arg.toMetaCode(indent));
    }
    result.append(')');

    return result.toString();
  }

  private String operatorMetaCode(final int pIndent) {
    String operator = aFunctionSymbol.getName().substring("operator".length());
    boolean prefix = false;
    if (operator.charAt(0) == '_') {
      operator = operator.substring(1);
    } else if (operator.charAt(operator.length() - 1) == '_') {
      operator = operator.substring(0, operator.length() - 1);
      prefix = true;
    }
    final StringBuilder result = new StringBuilder();

    if (prefix) {
      result.append(operator);
    }
    result.append(aTarget.toMetaCode(pIndent));
    if (!prefix) {
      if (aArgs.length == 1) {
        result.append(' ');
        result.append(operator).append(' ');
        result.append(aArgs[0].toMetaCode(pIndent));
      } else {
        result.append(operator);
      }
    }
    return result.toString();
  }

  @Override
  public MLang getTokenType() {
    return MLang.FUNCCALL;
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FuncCall other = (FuncCall) obj;
    if (!Arrays.equals(aArgs, other.aArgs)) {
      return false;
    }
    if (aFunctionSymbol == null) {
      if (other.aFunctionSymbol != null) {
        return false;
      }
    } else if (!aFunctionSymbol.equals(other.aFunctionSymbol)) {
      return false;
    }
    if (aReturnType == null) {
      if (other.aReturnType != null) {
        return false;
      }
    } else if (!aReturnType.equals(other.aReturnType)) {
      return false;
    }
    if (aTarget == null) {
      if (other.aTarget != null) {
        return false;
      }
    } else if (!aTarget.equals(other.aTarget)) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + Arrays.hashCode(aArgs);
    result = (prime * result) + ((aFunctionSymbol == null) ? 0 : aFunctionSymbol.hashCode());
    result = (prime * result) + ((aReturnType == null) ? 0 : aReturnType.hashCode());
    result = (prime * result) + ((aTarget == null) ? 0 : aTarget.hashCode());
    return result;
  }

}
