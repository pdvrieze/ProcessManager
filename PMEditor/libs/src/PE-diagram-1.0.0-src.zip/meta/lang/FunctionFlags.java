package meta.lang;

import java.lang.reflect.Modifier;
import java.util.EnumSet;

import static org.objectweb.asm.Opcodes.*;

import net.devrieze.meta.compile.MFlags;


public enum FunctionFlags implements MFlags {
  PUBLIC(ACC_PUBLIC, "public"),
  PRIVATE(ACC_PRIVATE, "private"),
  PROTECTED(ACC_PROTECTED, "protected"),
  ABSTRACT(ACC_ABSTRACT, "abstract"),
  STATIC(ACC_STATIC, "static"),
  FINAL(ACC_FINAL, "final"),
  SYNCHRONIZED(ACC_SYNCHRONIZED, "synchronized"),
  BRIDGE(ACC_BRIDGE, "bridge"),
  VARARGS(ACC_VARARGS, "varargs"),
  NATIVE(ACC_NATIVE, "native"),
  STRICTFP(ACC_STRICT, "strictfp"),
  SYNTHETIC(ACC_SYNTHETIC, "synthetic");

  final int aFlagValue;

  final String aMetaRepr;

  FunctionFlags(final int pFlagValue, final String pMetaRepr) {
    aFlagValue = pFlagValue;
    aMetaRepr = pMetaRepr;
  }

  @Override
  public int getFlagValue() {
    return aFlagValue;
  }

  public static FunctionFlags fromString(final String pName) {
    for (final FunctionFlags flag : values()) {
      if (flag.name().equals(pName) || flag.aMetaRepr.equals(pName)) {
        return flag;
      }
    }
    return null;
  }

  public static EnumSet<FunctionFlags> fromModifiers(final int pModifiers) {
    final EnumSet<FunctionFlags> result = EnumSet.noneOf(FunctionFlags.class);
    if (Modifier.isPublic(pModifiers)) {
      result.add(PUBLIC);
    }
    if (Modifier.isPrivate(pModifiers)) {
      result.add(PRIVATE);
    }
    if (Modifier.isProtected(pModifiers)) {
      result.add(PROTECTED);
    }
    if (Modifier.isAbstract(pModifiers)) {
      result.add(ABSTRACT);
    }
    if (Modifier.isStatic(pModifiers)) {
      result.add(STATIC);
    }
    if (Modifier.isFinal(pModifiers)) {
      result.add(FINAL);
    }
    if (Modifier.isSynchronized(pModifiers)) {
      result.add(SYNCHRONIZED);
    }
    if ((pModifiers & 0x40) != 0) {
      result.add(BRIDGE);
    }
    if ((pModifiers & 0x80) != 0) {
      result.add(VARARGS);
    }
    if (Modifier.isNative(pModifiers)) {
      result.add(NATIVE);
    }
    if (Modifier.isStrict(pModifiers)) {
      result.add(STRICTFP);
    }
    if ((pModifiers & 0x1000) != 0) {
      result.add(SYNTHETIC);
    }
    return result;
  }

  @Override
  public String toMetaCode() {
    return '@' + aMetaRepr;
  }

  @Override
  public String getRepr() {
    return aMetaRepr;
  }

}
