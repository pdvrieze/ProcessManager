package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class Conditional extends AbstractExpression {

  private final Expression aCondition;

  private final Expression aThen;

  private final Expression aElse;

  public Conditional(final LinePosition pPos, final Expression pCondition, final Expression pThen, final Expression pElse) {
    super(pPos);
    aCondition = pCondition;
    aThen = pThen;
    aElse = pElse;
  }

  public Conditional(final LinePosition pPos, final Expression pCondition, final Expression pThen) {
    super(pPos);
    aCondition = pCondition;
    aThen = pThen;
    aElse = null;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO somehow optimize depending on the condition
    return pScope.getCompiler().compileIf(this, pScope, pCleanupStack);
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    final Literal<?> condition = pScope.expectLiteral(aCondition.eval(pScope));
    if (!(condition instanceof Literal.BoolLiteral)) {
      pScope.getContext().error(aCondition, "Condition must evaluate to boolean value");
    }
    if (((Literal.BoolLiteral) condition).getValue()) {
      final EvalResult result = aThen.eval(pScope);
      if (result instanceof ReturnValue) {
        return result;
      }
      return aElse == null ? null : result.toLiteral();
    } else {
      if (aElse == null) {
        return null;
      }

      final EvalResult result = aElse.eval(pScope);
      if (result instanceof ReturnValue) {
        return result;
      }
      return aElse == null ? null : result.toLiteral();
    }
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return aElse == null ? null : aThen.getEvalType(pScope); // XXX take the union of then and else
  }

  @Override
  public String toMetaCode(final int pIndent) {
    if (aElse == null) {
      return "if (" + aCondition.toMetaCode(pIndent + 4) + ") then " + aThen.toMetaCode(pIndent);
    }
    return "if (" + aCondition.toMetaCode(pIndent + 4) + ") then " + aThen.toMetaCode(pIndent) + " else " + aElse.toMetaCode(pIndent);
  }

  @Override
  public String toString() {
    if (aElse == null) {
      return "if (" + aCondition + ") then " + aThen;
    }
    return "if (" + aCondition + ") then " + aThen + " else " + aElse;
  }

  @Override
  public MLang getTokenType() {
    return MLang.IF;
  }

  public Expression getCondition() {
    return aCondition;
  }

  public Expression getThen() {
    return aThen;
  }

  public Expression getElse() {
    return aElse;
  }

}
