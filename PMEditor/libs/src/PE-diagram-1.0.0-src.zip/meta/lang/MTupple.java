package meta.lang;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class MTupple extends AbstractExpression implements Iterable<Expression> {

  private final Expression[] aBody;

  public MTupple(final LinePosition pPosition, final Expression... pBody) {
    super(pPosition);
    aBody = pBody.clone();
  }

  public MTupple(final LinePosition pPosition, final List<Expression> pBody) {
    super(pPosition);
    aBody = pBody.toArray(new Expression[0]);
  }

  public Expression get(final int pIndex) {
    return aBody[pIndex];
  }

  public boolean isEmpty() {
    return aBody.length == 0;
  }

  @Override
  public Iterator<Expression> iterator() {
    return Arrays.asList(aBody).iterator();
  }

  public int size() {
    return aBody.length;
  }

  @Override
  public MLang getTokenType() {
    return MLang.TUPPLE;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileTupple(this, pScope, pCleanupStack);
  }

  @Override
  public Literal<?> eval(final Scope pScope) throws CompilationException {
    EvalResult result = null;
    for (final Expression expr : aBody) {
      result = expr.eval(pScope);
      if (result instanceof ReturnValue) {
        return result.toLiteral();
      }
    }
    return result == null ? null : result.toLiteral();
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    if (aBody.length == 0) {
      return null;
    } else {
      return aBody[aBody.length - 1].getEvalType(pScope);
    }
  }

  public List<Expression> asList() {
    return Arrays.asList(aBody);
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append("MTupple(");
    boolean first = true;
    for (final Expression expr : aBody) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      result.append(expr.toString());
    }
    result.append(')');
    return result.toString();
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append('(');
    boolean first = true;
    for (final Expression expr : aBody) {
      if (!first) {
        result.append(", ");
      }
      first = false;
      result.append(expr.toMetaCode(pIndent + 2));
    }
    result.append(')');
    return result.toString();
  }

  public Expression[] toArray() {
    return aBody;
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != MTupple.class)) {
      return false;
    }
    final MTupple other = (MTupple) pObj;
    return Arrays.equals(aBody, other.aBody);
  }

  @Override
  public int hashCode() {
    return aBody.hashCode() + 34693;
  }

}
