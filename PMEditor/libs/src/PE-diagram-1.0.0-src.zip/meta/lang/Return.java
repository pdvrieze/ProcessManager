package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class Return extends AbstractExpression {

  private final Expression aExpr;

  /**
   * Create a return statement
   * 
   * @param pExpression The expression to return
   */
  public Return(final LinePosition pPosition, final Expression pExpression) {
    super(pPosition);
    aExpr = pExpression;
  }

  public Return(final LinePosition pPosition) {
    super(pPosition);
    aExpr = null;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileReturn(this, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return aExpr == null ? null : aExpr.getEvalType(pScope);
  }

  public Expression getExpr() {
    return aExpr;
  }

  @Override
  public ReturnValue eval(final Scope pScope) throws CompilationException {
    if (aExpr == null) {
      return new ReturnValue(null);
    }
    final Literal<?> expr = pScope.expectLiteral(aExpr.eval(pScope));
    return new ReturnValue(expr);
  }

  @Override
  public String toString() {
    return "return " + aExpr;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    if (aExpr == null) {
      result.append("return");
    } else {
      result.append("return ").append(aExpr.toMetaCode(pIndent + 2));
    }
    return result.toString();
  }

  @Override
  public MLang getTokenType() {
    return MLang.RETURN;
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != Return.class)) {
      return false;
    }
    final Return other = (Return) pObj;
    return aExpr.equals(other.aExpr);
  }

  @Override
  public int hashCode() {
    return aExpr.hashCode() * 3134895;
  }

}
