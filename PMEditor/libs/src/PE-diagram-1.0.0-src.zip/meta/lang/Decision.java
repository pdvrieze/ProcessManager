package meta.lang;


public enum Decision {
  True,
  False,
  Undecidable;
}
