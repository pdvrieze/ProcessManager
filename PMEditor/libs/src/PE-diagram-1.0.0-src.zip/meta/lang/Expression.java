package meta.lang;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.EvaluationException;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


/**
 * Class that represents first class things in M
 * 
 * @author Paul de Vrieze
 */
public abstract interface Expression extends LinedToken<MLang> {

  /**
   * @param pScope the scope to use
   * @param pName the name of the function to resolve
   * @param pParamTypes the parameters to use
   * @category Compile Eval
   */
  FunctionRef resolveFunction(Scope pScope, Symbol pName, TypeRef<?>... pParamTypes) throws CompilationException;

  /**
   * Compile the token to expressions for class files. This is to compile the
   * token as a value.
   * 
   * @param pCleanupStack Indicates whether the stack should be contain a result
   *          value after the compilation.
   * @return The type of the expression.
   * @throws CompilationException When compilation fails
   * @category Compile
   */
  abstract TypeRef<?> compile(Scope pScope, boolean pCleanupStack) throws CompilationException;

  /**
   * Evaluate the token
   * 
   * @param pScope The scope to evaluate within
   * @return The result of evaluation
   * @throws EvaluationException When evaluation fails
   * @throws CompilationException
   * @category Eval
   */
  abstract EvalResult eval(Scope pScope) throws CompilationException;

  /**
   * Get the type that evaluating this token will result in. This will typically
   * be the same as {@link #compile(Scope, boolean)} returns.
   * 
   * @param pScope The scope to evaluate within.
   * @return <code>null</code> when void, otherwise a reference to the type.
   * @throws CompilationException
   * @category Compile Eval
   */
  abstract TypeRef<?> getEvalType(Scope pScope) throws CompilationException;

  /**
   * Write a metacode representation of the expression.
   * 
   * @param pIndent The current indentation level.
   * @return A string representation.
   * @category Output
   */
  String toMetaCode(int pIndent);

  /**
   * Get the token type of this token
   * 
   * @category Meta
   */
  @Override
  abstract MLang getTokenType();
}
