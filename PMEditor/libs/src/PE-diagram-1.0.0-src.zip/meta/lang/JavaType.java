package meta.lang;


/**
 * Represents a type in M that is also a type in java
 * 
 * @author Paul de Vrieze
 */
public interface JavaType extends Type {

  /** Describes the type without generics */
  public String getDescriptor();

  /** Describes the type with generics */
  public String getSignature();

  /**
   * Get a reference to the type.
   * 
   * @return A reference to the type
   */
  public TypeRef<? extends Type> getRef();

  /**
   * Get a reference to the type.
   * 
   * @param pGenericParams The generic params. When null is passed, the
   *          "default" params are used.
   * @return A reference to the type
   */
  public TypeRef<? extends Type> getRef(@SuppressWarnings("unchecked") TypeRef<? extends JavaReferenceType>... pGenericParams);
}
