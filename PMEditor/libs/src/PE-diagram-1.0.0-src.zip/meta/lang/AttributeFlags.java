package meta.lang;

import java.lang.reflect.Modifier;
import java.util.EnumSet;

import static org.objectweb.asm.Opcodes.*;

import net.devrieze.meta.compile.MFlags;


public enum AttributeFlags implements MFlags {
  PUBLIC(ACC_PUBLIC, "public"),
  PRIVATE(ACC_PRIVATE, "private"),
  PROTECTED(ACC_PROTECTED, "protected"),
  STATIC(ACC_STATIC, "static"),
  FINAL(ACC_FINAL, "final"),
  VOLATILE(ACC_VOLATILE, "volatile"),
  TRANSIENT(ACC_TRANSIENT, "transient"),
  SYNTHETIC(ACC_SYNTHETIC, "synthetic"),
  ENUM(ACC_ENUM, "enum");

  final int aFlagValue;

  final String aMetaRepr;

  AttributeFlags(final int pFlagValue, final String pMetaRepr) {
    aFlagValue = pFlagValue;
    aMetaRepr = pMetaRepr;
  }

  @Override
  public int getFlagValue() {
    return aFlagValue;
  }

  public static AttributeFlags fromString(final String pName) {
    for (final AttributeFlags flag : values()) {
      if (flag.name().equals(pName) || flag.aMetaRepr.equals(pName)) {
        return flag;
      }
    }
    return null;
  }

  public static EnumSet<AttributeFlags> fromModifiers(final int pModifiers) {
    final EnumSet<AttributeFlags> result = EnumSet.noneOf(AttributeFlags.class);
    if (Modifier.isPublic(pModifiers)) {
      result.add(PUBLIC);
    }
    if (Modifier.isPrivate(pModifiers)) {
      result.add(PRIVATE);
    }
    if (Modifier.isProtected(pModifiers)) {
      result.add(PROTECTED);
    }
    if (Modifier.isStatic(pModifiers)) {
      result.add(STATIC);
    }
    if (Modifier.isFinal(pModifiers)) {
      result.add(FINAL);
    }
    if (Modifier.isVolatile(pModifiers)) {
      result.add(VOLATILE);
    }
    if (Modifier.isTransient(pModifiers)) {
      result.add(TRANSIENT);
    }
    if ((pModifiers & 0x1000) != 0) {
      result.add(SYNTHETIC);
    }
    if ((pModifiers & 0x4000) != 0) {
      result.add(ENUM);
    }
    return result;
  }

  @Override
  public String toMetaCode() {
    return '@' + aMetaRepr;
  }

  @Override
  public String getRepr() {
    return aMetaRepr;
  }

}
