package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.JavaCompiler;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;


public class BinaryExpression extends AbstractExpression {

  private final BinaryOperatorTokens aOperator;

  private final Expression aLeft;

  private final Expression aRight;

  public BinaryExpression(final LinePosition pPosition, final BinaryOperatorTokens pOperator, final Expression pLeft, final Expression pRight) {
    super(pPosition);
    aOperator = pOperator;
    aLeft = pLeft;
    aRight = pRight;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO support operator.
    if (aOperator == BinaryOperatorTokens.MEMBERACCESS) {
      final TypeRef<?> leftType = aLeft.compile(pScope, false);
      final Symbol rightSymbol = (Symbol) aRight; // Evaluate this cast
      final FieldRef field = leftType.asReferenceType().getReferredType().resolveField(rightSymbol, pScope);
      return field.compileRef(rightSymbol, pScope, pCleanupStack);
    } else {

      final Symbol functionSymbol = new Symbol(getPos(), "operator" + aOperator.toString());
      final FuncCall fc = FuncCall.create(getPos(), aLeft, functionSymbol, TypeRef.ANY, new Expression[] { aRight });
      return fc.compile(pScope, pCleanupStack);
      //      throw new UnsupportedOperationException("This code is broken");
    }
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    final Literal<?> left = pScope.expectLiteral(aLeft.eval(pScope));
    switch (aOperator) {
      case MEMBERACCESS:
        return evalMemberAccess(left, MEvaluator.toSymbol(aRight), pScope);
      default:
        final Symbol functionSymbol = new Symbol(getPos(), "operator" + aOperator.toString());
        final FuncCall fc = FuncCall.create(getPos(), aLeft, functionSymbol, TypeRef.ANY, new Expression[] { aRight });
        return fc.eval(pScope);

    }
  }

  private static Literal<?> evalMemberAccess(final Literal<?> pLeft, final Symbol pSymbol, final Scope pScope) throws CompilationException {
    final Object left = pLeft.getObjValue();
    final TypeRef.ClassWrapper<?> wrapper = new TypeRef.ClassWrapper<>(left.getClass());
    final FieldRef fieldRef = wrapper.resolveField(pSymbol, pScope);
    return fieldRef.evalRef(left, pScope);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    switch (aOperator) {
      case DIV:
      case EQUALS:
      case GREATER:
      case GREATEREQ:
      case LESS:
      case LESSEQ:
      case LOGIC_AND:
      case LOGIC_OR:
      case UNEQUALS:
        return Primitive.MBoolean.getRef();
      case MEMBERACCESS: {
        final TypeRef<?> leftType = aLeft.getEvalType(pScope);
        if (aRight.getTokenType() == MLang.FUNCCALL) {
          final FuncCall funcCall = (FuncCall) aRight;
          final FunctionRef function = leftType.resolveFunction(pScope, funcCall.getFunctionSymbol(), JavaCompiler.getParamTypes(pScope, funcCall.getArgs()).toArray(TypeRef.emptyList()));
          return function.getReturnType(pScope);
        } else if (aRight.getTokenType() == MLang.SYMBOL) {
          final Symbol symbol = (Symbol) aRight;
          final FieldRef fieldRef = leftType.asReferenceType().getReferredType().resolveField(symbol, pScope);
          return fieldRef.getVarType();
        }
        break;
      }
      case MINUS:
      case MOD:
      case PLUS:
      case POWER:
      case TIMES:
    }
    return aLeft.getEvalType(pScope); // XXX Assumes that types are equal
  }

  @Override
  public MLang getTokenType() {
    return MLang.BINARYOPERATOR;
  }

  public Expression getLeft() {
    return aLeft;
  }

  public Expression getRight() {
    return aRight;
  }

  public BinaryOperatorTokens getOperator() {
    return aOperator;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    // TODO format this as operator call, but with proper parenthesizing
    appendParenMetaCode(result, aOperator, aLeft, pIndent).append(' ').append(aOperator.toString()).append(' ');
    appendParenMetaCode(result, aOperator, aRight, pIndent);

    return result.toString();
  }

  private static StringBuilder appendParenMetaCode(final StringBuilder pString, final BinaryOperatorTokens pParent, final Expression pExpression, final int pIndent) {
    if (pExpression.getTokenType() != MLang.BINARYOPERATOR) {
      return pString.append(pExpression.toMetaCode(pIndent));
    }
    final BinaryExpression expr = (BinaryExpression) pExpression;
    if (pParent.getOrder() < expr.getOperator().getOrder()) {
      return pString.append('(').append(expr.toMetaCode(pIndent)).append(')');
    }
    return pString.append(expr.toMetaCode(pIndent));
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append("BinaryExpression: ").append(aLeft.toString()).append(".operator").append(aOperator.toString()).append('(').append(aRight.toString()).append(')');

    return result.toString();
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != BinaryExpression.class)) {
      return false;
    }
    final BinaryExpression other = (BinaryExpression) pObj;
    return (aOperator == other.aOperator) && aLeft.equals(other.aLeft) && aRight.equals(other.aRight);
  }

  @Override
  public int hashCode() {
    return aOperator.hashCode() + (aLeft.hashCode() * 31) + (aRight.hashCode() * 57);
  }

}
