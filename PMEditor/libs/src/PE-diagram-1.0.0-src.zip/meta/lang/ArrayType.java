package meta.lang;


import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class ArrayType extends JavaReferenceType {


  private class ArrayLengthField extends FieldRef {

    public ArrayLengthField(final ArrayType pArrayType, final Symbol pSymbol) {
      super(EnumSet.of(AttributeFlags.PUBLIC, AttributeFlags.FINAL), pArrayType.getRef(), pSymbol, Primitive.MInt.getRef());
    }

    @Override
    public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) throws CompilationException {
      pScope.getContext().error(pToken, CompilationErrors.ASSIGN_TO_CONST);
      return null;
    }

    @Override
    public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().compileGetArrayLength(pScope, pToken, pCleanupStack);
    }

    @Override
    public boolean isStatic() {
      return false;
    }

  }

  private static boolean _isJavaCompatible = true;

  private final TypeRef<?> aElementType;

  public ArrayType(final TypeRef<?> pElementType) {
    aElementType = pElementType;
  }

  @Override
  public String getDescriptor() {
    final CharSequence elemDescriptor = aElementType.getDescriptor();
    return new StringBuilder(elemDescriptor.length() + 1).append('[').append(elemDescriptor).toString();
  }

  @Override
  public GenericType[] getGenericParams() {
    return new GenericType[0];
  }

  @Override
  public String getInternalName() {
    return "[" + aElementType.getInternalName();
  }

  @Override
  public String getClassName() {
    // TODO this actually breaks for primitives
    return aElementType.asReferenceType().getReferredType().getClassName();
  }

  @Override
  @SafeVarargs
  public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return Arrays.asList(TypeRef.<JavaReferenceType> emptyList());
  }

  @Override
  @SafeVarargs
  public final TypeRef<? extends JavaReferenceType> getParent(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    if ((pGenericParams != null) && (pGenericParams.length > 0)) {
      throw new IllegalArgumentException("Array type has no generic params");
    }
    return null; // No parent type for now
  }

  @Override
  @SafeVarargs
  public final TypeRef<? extends Type> getRef(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    if ((pGenericParams != null) && (pGenericParams.length > 0)) {
      throw new IllegalArgumentException("Array type has no generic params");
    }
    return TypeRef.create(null, this);
  }

  @Override
  public TypeRef<ArrayType> getRef() {
    return TypeRef.create(null, this);
  }

  @Override
  public String getSignature() {
    return "[" + aElementType.getSignature();
  }

  @Override
  public boolean hasParent(final TypeRef<? extends JavaReferenceType> pCandidate) {
    return (isJavaCompatible() && (pCandidate.getReferredType().getClass() == ArrayType.class) && ((ArrayType) pCandidate.getReferredType()).aElementType.equals(TypeRef.create(null, Object.class)));

  }

  @Override
  public boolean isAssignableFrom(final Type pOther) {
    if (pOther.getClass() != ArrayType.class) {
      return false;
    }
    if (isJavaCompatible()) {
      return aElementType.isAssignableFrom(((ArrayType) pOther).aElementType);
    } else {
      return aElementType.equals(((ArrayType) pOther).aElementType);
    }
  }

  private static boolean isJavaCompatible() {
    return _isJavaCompatible;
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) {
    final String name = pName.getName();
    if (name.equals("operator[")) {
      if ((pParamTypes.length == 1) && pParamTypes[0].equals(Primitive.MInt.getRef())) {
        final FunctionType ft = new FunctionType(pName.getPos(), AnnotateToken.fromFlags(FunctionFlags.PUBLIC), getRef(), aElementType, Primitive.MInt.getRef());
        return new FunctionRef(pName.getPos(), "operator[", ft);
      } else if ((pParamTypes.length == 2) && pParamTypes[0].equals(Primitive.MInt.getRef())
          && aElementType.isAssignableFrom(pParamTypes[1])) {
        final FunctionType ft = new FunctionType(pName.getPos(), AnnotateToken.fromFlags(FunctionFlags.PUBLIC), getRef(), null, Primitive.MInt.getRef(), aElementType);
        return new FunctionRef(pName.getPos(), "operator[", ft);
      }
    } else if (name.equals("<init>")) {
      final FunctionType ft = new FunctionType(pName.getPos(), AnnotateToken.fromFlags(FunctionFlags.PUBLIC), getRef(), null, Primitive.MInt.getRef());
      return new FunctionRef(pName.getPos(), "<init>", ft);
    }
    return null;
  }

  @Override
  public FieldRef resolveField(final Symbol pField, final Scope pScope) {
    if (pField.getName().equals("length")) {
      return new ArrayLengthField(this, pField);
    }
    return null;
  }

  @Override
  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> compileCallStatic(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (pFunction.getFunctionName().equals("operator[")) {
      final int paramCount = pFunction.getFunctionType().getParams().length;
      if (paramCount == 1) {
        return compileArrayRead(pFunction, pScope, pCleanupStack);
      } else if (paramCount == 2) {
        return compileArrayWrite(pFunction, pScope, pCleanupStack);
      }
    }
    pScope.getContext().error(null, "Arrays do not support operations with name: " + pFunction.getFunctionName());
    return pFunction.getReturnType(pScope);
  }

  private TypeRef<?> compileArrayRead(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    return pScope.getCompiler().compileArrayRead(this, pScope, pToken, pCleanupStack);
  }

  private TypeRef<?> compileArrayWrite(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    return pScope.getCompiler().compileArrayWrite(this, pScope, pToken, pCleanupStack);
  }

  public TypeRef<?> getElementType() {
    return aElementType;
  }

  @Override
  public List<FunctionRef> getMethods(final List<FunctionRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public List<FieldRef> getFields(final List<FieldRef> pReceiver) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public String toMetaCode(final int pIndent) {
    return aElementType.toMetaCode(pIndent) + "[]";
  }

  @Override
  public String toString() {
    return "Array<" + aElementType + ">";
  }

  @Override
  public boolean equals(final Object pThat) {
    if (this == pThat) {
      return true;
    }
    if (pThat.getClass() != ArrayType.class) {
      return false;
    }
    return aElementType.equals(((ArrayType) pThat).aElementType);
  }

  @Override
  public int hashCode() {
    return (aElementType.hashCode() * 31) + 5478;
  }

}
