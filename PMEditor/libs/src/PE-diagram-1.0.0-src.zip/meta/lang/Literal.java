package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.ClassInstance;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


/**
 * A literal value is first-class
 * 
 * @author Paul de Vrieze
 */
public abstract class Literal<T extends JavaType> extends AbstractExpression implements EvalResult {


  public static final class ObjectLiteral<T> extends Literal<JavaType> {

    private final T aValue;

    public ObjectLiteral(final LinePosition pPosition, final TypeRef<? extends JavaType> pTypeRef, final T pValue) {
      super(pPosition, pTypeRef);
      aValue = pValue;
    }

    @Override
    public T getObjValue() {
      return aValue;
    }

    @SuppressWarnings("unchecked")
    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      if (aValue == null) {
        return pScope.getCompiler().compileNull(this, pScope, pCleanupStack);
      } else if (aValue instanceof String) {
        return pScope.getCompiler().compileStringConstant((Literal.ObjectLiteral<String>) this, pScope, pCleanupStack);
      }
      throw new UnsupportedOperationException("Object instances can not be compiled");
    }

    @Override
    public MLang getTokenType() {
      return MLang.OBJLITERAL;
    }

    @Override
    public String toMetaCode(final int pIndent) {
      if (aValue instanceof String) {
        return '"' + aValue.toString() + '"'; // XXX Properly escape
      } else {
        return aValue == null ? "null" : aValue.toString();
      }
    }

  }

  public static final class IntLiteral extends Literal<Primitive> {

    private final int aValue;

    private IntLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final int pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getIntCompiler().compileIntLiteral(this, pScope, pCleanupStack);
    }

    public int getValue() {
      return aValue;
    }

    @Override
    public Integer getObjValue() {
      return Integer.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != IntLiteral.class) {
        return false;
      }
      return aValue == ((IntLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Integer.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.INTLITERAL;
    }

  }

  public static final class BoolLiteral extends Literal<Primitive> {

    private final boolean aValue;

    private BoolLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final boolean pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getIntCompiler().compileBoolLiteral(this, pScope, pCleanupStack);
    }

    public boolean getValue() {
      return aValue;
    }

    @Override
    public Boolean getObjValue() {
      return Boolean.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != BoolLiteral.class) {
        return false;
      }
      return aValue == ((BoolLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Boolean.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.BOOLLITERAL;
    }

  }

  public static final class ByteLiteral extends Literal<Primitive> {

    private final byte aValue;

    private ByteLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final byte pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getIntCompiler().compileByteLiteral(this, pScope, pCleanupStack);
    }

    public byte getValue() {
      return aValue;
    }

    @Override
    public Byte getObjValue() {
      return Byte.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != ByteLiteral.class) {
        return false;
      }
      return aValue == ((ByteLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Byte.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.BYTELITERAL;
    }

  }

  public static final class CharLiteral extends Literal<Primitive> {

    private final char aValue;

    private CharLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final char pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getIntCompiler().compileCharLiteral(this, pScope, pCleanupStack);
    }

    public char getValue() {
      return aValue;
    }

    @Override
    public Character getObjValue() {
      return Character.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != CharLiteral.class) {
        return false;
      }
      return aValue == ((CharLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Character.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.CHARLITERAL;
    }

  }

  public static final class ShortLiteral extends Literal<Primitive> {

    private final short aValue;

    private ShortLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final short pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getIntCompiler().compileShortLiteral(this, pScope, pCleanupStack);
    }

    public short getValue() {
      return aValue;
    }

    @Override
    public Short getObjValue() {
      return Short.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != ShortLiteral.class) {
        return false;
      }
      return aValue == ((ShortLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Short.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.SHORTLITERAL;
    }

  }

  public static final class LongLiteral extends Literal<Primitive> {

    private final long aValue;

    private LongLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final long pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getLongCompiler().compileLongLiteral(this, pScope, pCleanupStack);
    }

    public long getValue() {
      return aValue;
    }

    @Override
    public Long getObjValue() {
      return Long.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != LongLiteral.class) {
        return false;
      }
      return aValue == ((LongLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Long.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.LONGLITERAL;
    }

  }

  public static final class FloatLiteral extends Literal<Primitive> {

    private final float aValue;

    private FloatLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final float pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getFloatCompiler().compileFloatLiteral(this, pScope, pCleanupStack);
    }

    public float getValue() {
      return aValue;
    }

    @Override
    public Float getObjValue() {
      return Float.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != FloatLiteral.class) {
        return false;
      }
      return aValue == ((FloatLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Float.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.FLOATLITERAL;
    }

  }

  public static final class DoubleLiteral extends Literal<Primitive> {

    private final double aValue;

    private DoubleLiteral(final LinePosition pPosition, final TypeRef<Primitive> pType, final double pValue) {
      super(pPosition, pType);
      aValue = pValue;
    }

    @Override
    public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
      return pScope.getCompiler().getDoublePrimitveCompiler().compileDoubleLiteral(this, pScope, pCleanupStack);
    }

    public double getValue() {
      return aValue;
    }

    @Override
    public Double getObjValue() {
      return Double.valueOf(aValue);
    }

    @Override
    public boolean equals(final Object pObj) {
      if (pObj.getClass() != DoubleLiteral.class) {
        return false;
      }
      return aValue == ((DoubleLiteral) pObj).aValue;
    }

    @Override
    public int hashCode() {
      return Double.valueOf(aValue).hashCode();
    }

    @Override
    public MLang getTokenType() {
      return MLang.DOUBLELITERAL;
    }

  }

  private final TypeRef<? extends T> aValueType;

  Literal(final LinePosition pPosition, final TypeRef<? extends T> pValueType) {
    super(pPosition);
    aValueType = pValueType;
  }

  public TypeRef<?> getValueType() {
    return aValueType;
  }

  // TODO make these functions use positions
  public static Literal<Primitive> createInt(final LinePosition pPos, final int pInt) {
    return new IntLiteral(pPos, Primitive.MInt.getRef(), pInt);
  }

  public static Literal<Primitive> createBool(final LinePosition pPos, final boolean pBool) {
    return new BoolLiteral(pPos, Primitive.MBoolean.getRef(), pBool);
  }

  public static Literal<Primitive> createByte(final LinePosition pPos, final byte pByte) {
    return new ByteLiteral(pPos, Primitive.MByte.getRef(), pByte);
  }

  public static Literal<Primitive> createChar(final LinePosition pPos, final char pChar) {
    return new CharLiteral(pPos, Primitive.MChar.getRef(), pChar);
  }

  public static Literal<Primitive> createShort(final LinePosition pPos, final short pShort) {
    return new ShortLiteral(pPos, Primitive.MShort.getRef(), pShort);
  }

  public static Literal<Primitive> createLong(final LinePosition pPos, final long pLong) {
    return new LongLiteral(pPos, Primitive.MLong.getRef(), pLong);
  }

  public static Literal<Primitive> createFloat(final LinePosition pPos, final float pFloat) {
    return new FloatLiteral(pPos, Primitive.MFloat.getRef(), pFloat);
  }

  public static Literal<Primitive> createDouble(final LinePosition pPos, final double pDouble) {
    return new DoubleLiteral(pPos, Primitive.MDouble.getRef(), pDouble);
  }

  public static <T extends Expression> Literal<?> create(final LinePosition pPos, final T pValue) {
    return new ObjectLiteral<>(pPos, TypeRef.create(pPos, pValue.getClass()), pValue);
  }

  public static Literal<?> create(final LinePosition pPos, final ClassInstance pValue) {
    return new ObjectLiteral<>(pPos, pValue.getReferredType(), pValue);
  }

  public static <T extends Object> Literal<?> createObj(final LinePosition pPos, final TypeRef<?> pType, final T pValue) {
    return new ObjectLiteral<>(pPos, pType, pValue);
  }

  /**
   * Get the value that is contained in this object
   * 
   * @return The value
   */
  public abstract Object getObjValue();

  public static Object[] getObjValue(final Literal<?>... pArgs) {
    final Object[] result = new Object[pArgs.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = pArgs[i].getObjValue();
    }
    return result;
  }

  @Override
  public Literal<?> eval(final Scope pScope) {
    return this;
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return aValueType;
  }

  //  @Override
  public TypeRef<?> getReferredType() {
    return aValueType;
  }

  @Override
  public String toString() {
    final Object objValue = getObjValue();
    final String className = getClass().getName();
    final String strValue = objValue == null ? "null" : objValue.toString();
    return className + "(" + strValue + ")";
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final Object objValue = getObjValue();
    return objValue == null ? "null" : objValue.toString();
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    return getValueType().resolveFunction(pScope, pName, pParamTypes);
  }

  /**
   * @deprecated This function does not need to be directly called on know
   *             literals as they are just the identity.
   */
  @Deprecated
  @Override
  public Literal<?> toLiteral() {
    return this;
  }


  /**
   * @deprecated This function does not need to be directly called on know
   *             literals as they are just the identity.
   */
  @Deprecated
  @Override
  public Literal<?> expectLiteral(final Scope pScope) {
    return this;
  }

  /**
   * Create a literal depending on the object passed. This is for use by the
   * compiler. It is important to know that this
   * 
   * @param pPos
   * @param pValue
   */
  public static Literal<?> createByInference(final LinePosition pPos, final Object pValue) {
    if (pValue == null) {
      return new ObjectLiteral<>(pPos, TypeRef.ANY, null);
    }
    if (pValue instanceof Integer) {
      return createInt(pPos, ((Integer) pValue).intValue());
    } else if (pValue instanceof Boolean) {
      return createBool(pPos, ((Boolean) pValue).booleanValue());
    } else if (pValue instanceof Character) {
      return createChar(pPos, ((Character) pValue).charValue());
    } else if (pValue instanceof Double) {
      return createDouble(pPos, ((Double) pValue).doubleValue());
    } else if (pValue instanceof Byte) {
      return createByte(pPos, ((Byte) pValue).byteValue());
    } else if (pValue instanceof Short) {
      return createShort(pPos, ((Short) pValue).shortValue());
    } else if (pValue instanceof Long) {
      return createLong(pPos, ((Long) pValue).longValue());
    } else if (pValue instanceof Float) {
      return createFloat(pPos, ((Float) pValue).floatValue());
    } else {
      return createObj(pPos, TypeRef.create(pPos, pValue.getClass()), pValue);
    }
  }

  public static Literal<?>[] createListByInference(final LinePosition pPos, final Object... pValues) {
    final Literal<?>[] result = new Literal<?>[pValues.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = createByInference(pPos, pValues[i]);
    }
    return result;
  }

}
