package meta.lang;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.BinaryOperatorTokens;


public class BinaryPrimitiveOperator extends FunctionRef {

  private final Primitive aPrimitive;

  private final BinaryOperatorTokens aOperator;

  public BinaryPrimitiveOperator(final LinePosition pPos, final Primitive pPrimitive, final BinaryOperatorTokens pOperator) {
    super(pPos, "operator" + pOperator.toString(), getFuncType(pOperator, pPrimitive));
    aPrimitive = pPrimitive;
    aOperator = pOperator;
  }

  private static FunctionType getFuncType(final BinaryOperatorTokens pOperator, final Primitive pPrimitive) {
    final TypeRef<Primitive> primitive = pPrimitive.getRef();
    final Primitive returnType;
    {
      switch (pOperator) {
        case DIV:
        case MINUS:
        case MOD:
        case PLUS:
        case TIMES: {
          switch (pPrimitive) {
            case MBoolean:
              throw new IllegalArgumentException("The operator is not supported for the type");
            case MByte:
            case MChar:
            case MShort:
            case MInt:
              returnType = Primitive.MInt;
              break;
            case MDouble:
              returnType = Primitive.MDouble;
              break;
            case MFloat:
              returnType = Primitive.MFloat;
              break;
            case MLong:
              returnType = Primitive.MLong;
              break;
            default:
              throw new IllegalStateException("Code should be unreachable");
          }
          break;
        }
        case POWER:
          switch (pPrimitive) {
            case MBoolean:
              throw new IllegalArgumentException("The operator is not supported for the type");
            case MByte:
            case MChar:
            case MShort:
            case MInt:
            case MFloat:
            case MLong:
            case MDouble:
              returnType = Primitive.MDouble;
              break;
            default:
              throw new IllegalStateException("Code should be unreachable");
          }
          break;
        case LOGIC_AND:
        case LOGIC_OR:
          if (pPrimitive == Primitive.MBoolean) {
            returnType = Primitive.MBoolean;
            break;
          } else {
            throw new IllegalArgumentException("The operator is not supported for the type");
          }
        case EQUALS:
        case GREATER:
        case GREATEREQ:
        case LESS:
        case LESSEQ:
        case UNEQUALS:
          returnType = Primitive.MBoolean;
          break;
        default:
          throw new IllegalStateException("Code should be unreachable");
      }
    }


    return new FunctionType(null, FunctionType._PUBLIC, primitive, returnType.getRef(), primitive);
  }

  public Literal<?> evalCall(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    final Literal<?> target = pLeft;
    switch (aOperator) {
      case PLUS:
        return evalPlus(target, pRight, pScope);
      case MINUS:
        return evalMinus(target, pRight, pScope);
      case DIV:
        return evalDiv(target, pRight, pScope);
      case MOD:
        return evalMod(target, pRight, pScope);
      case POWER:
        return evalPower(target, pRight, pScope);
      case TIMES:
        return evalTimes(target, pRight, pScope);
      case LESSEQ:
        return evalLessEq(target, pRight, pScope);
      case LESS:
        return evalLess(target, pRight, pScope);
      case GREATER:
        return evalGreater(target, pRight, pScope);
      case GREATEREQ:
        return evalGreaterEq(target, pRight, pScope);
      case EQUALS:
        return evalEq(target, pRight, pScope);
      case UNEQUALS:
        return evalNe(target, pRight, pScope);
      case LOGIC_AND:
        return evalLogicAnd(target, pRight, pScope);
      case LOGIC_OR:
        return evalLogicOr(target, pRight, pScope);
      case MEMBERACCESS:
        throw new UnsupportedOperationException("Member access is not supported on primitives");

    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough: " + aOperator);
  }

  private Literal<?> evalPlus(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Adding booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createInt(null, MEvaluator.getInt(pLeft, pScope.getContext()) + MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createDouble(null, MEvaluator.getDouble(pLeft, pScope.getContext())
            + MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createFloat(null, MEvaluator.getFloat(pLeft, pScope.getContext()) + MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createLong(null, MEvaluator.getLong(pLeft, pScope.getContext()) + MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalMinus(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Subtracting booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createInt(null, MEvaluator.getInt(pLeft, pScope.getContext()) - MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createDouble(null, MEvaluator.getDouble(pLeft, pScope.getContext())
            - MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createFloat(null, MEvaluator.getFloat(pLeft, pScope.getContext()) - MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createLong(null, MEvaluator.getLong(pLeft, pScope.getContext()) - MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalDiv(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Dividing booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createInt(null, MEvaluator.getInt(pLeft, pScope.getContext()) / MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createDouble(null, MEvaluator.getDouble(pLeft, pScope.getContext())
            / MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createFloat(null, MEvaluator.getFloat(pLeft, pScope.getContext()) / MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createLong(null, MEvaluator.getLong(pLeft, pScope.getContext()) / MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalMod(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Dividing booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createInt(null, MEvaluator.getInt(pLeft, pScope.getContext()) % MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createDouble(null, MEvaluator.getDouble(pLeft, pScope.getContext())
            % MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createFloat(null, MEvaluator.getFloat(pLeft, pScope.getContext()) % MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createLong(null, MEvaluator.getLong(pLeft, pScope.getContext()) % MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalTimes(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Multiplying booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createInt(null, MEvaluator.getInt(pLeft, pScope.getContext()) * MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createDouble(null, MEvaluator.getDouble(pLeft, pScope.getContext())
            * MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createFloat(null, MEvaluator.getFloat(pLeft, pScope.getContext()) * MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createLong(null, MEvaluator.getLong(pLeft, pScope.getContext()) * MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<?> evalPower(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Exponentiating booleans makes no sense");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createDouble(null, Math.pow(MEvaluator.getInt(pLeft, pScope.getContext()), MEvaluator.getInt(pRight, pScope.getContext())));
      case MDouble:
        return Literal.createDouble(null, Math.pow(MEvaluator.getDouble(pLeft, pScope.getContext()), MEvaluator.getDouble(pRight, pScope.getContext())));
      case MFloat:
        return Literal.createDouble(null, Math.pow(MEvaluator.getFloat(pLeft, pScope.getContext()), MEvaluator.getFloat(pRight, pScope.getContext())));
      case MLong:
        return Literal.createDouble(null, Math.pow(MEvaluator.getLong(pLeft, pScope.getContext()), MEvaluator.getLong(pRight, pScope.getContext())));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalLessEq(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) <= MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) <= MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) <= MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) <= MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalLess(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) < MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) < MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) < MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) < MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalGreaterEq(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) >= MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) >= MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) >= MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) >= MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalGreater(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) > MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) > MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) > MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) > MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalEq(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) == MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) == MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) == MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) == MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalNe(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        pScope.getContext().error(this, "Booleans are not ordered");
        return null;
      case MByte:
      case MShort:
      case MChar:
      case MInt:
        return Literal.createBool(null, MEvaluator.getInt(pLeft, pScope.getContext()) != MEvaluator.getInt(pRight, pScope.getContext()));
      case MDouble:
        return Literal.createBool(null, MEvaluator.getDouble(pLeft, pScope.getContext()) != MEvaluator.getDouble(pRight, pScope.getContext()));
      case MFloat:
        return Literal.createBool(null, MEvaluator.getFloat(pLeft, pScope.getContext()) != MEvaluator.getFloat(pRight, pScope.getContext()));
      case MLong:
        return Literal.createBool(null, MEvaluator.getLong(pLeft, pScope.getContext()) != MEvaluator.getLong(pRight, pScope.getContext()));
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalLogicAnd(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        return Literal.createBool(null, MEvaluator.getBool(pLeft, pScope) && MEvaluator.getBool(pRight, pScope));
      case MByte:
      case MShort:
      case MChar:
      case MInt:
      case MDouble:
      case MFloat:
      case MLong:
        pScope.getContext().error(this, "Logical and is only defined on boolean values");
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  private Literal<Primitive> evalLogicOr(final Literal<?> pLeft, final Literal<?> pRight, final Scope pScope) throws CompilationException {
    switch (aPrimitive) {
      case MBoolean:
        return Literal.createBool(null, MEvaluator.getBool(pLeft, pScope) || MEvaluator.getBool(pRight, pScope));
      case MByte:
      case MShort:
      case MChar:
      case MInt:
      case MDouble:
      case MFloat:
      case MLong:
        pScope.getContext().error(this, "Logical or is only defined on boolean values");
    }
    throw new UnsupportedOperationException("Unexpected unsupported operation, case fallthrough");
  }

  @Override
  public TypeRef<?> compileCall(final Expression pTarget, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression[] pArgs) throws CompilationException {
    if (((aOperator == BinaryOperatorTokens.LOGIC_AND) || (aOperator == BinaryOperatorTokens.LOGIC_OR)) && (pArgs.length == 1)) {
      final Expression condition = new BinaryExpression(getPos(), aOperator, pTarget, pArgs[0]);
      final Conditional ifToken = new Conditional(getPos(), condition, Literal.createBool(null, true), Literal.createBool(null, false));
      return ifToken.compile(pScope, pCleanupStack);
    }

    pTarget.compile(pScope, false);
    for (final Expression expr : pArgs) {
      expr.compile(pScope, false);
    }
    return compileCall(pScope, pCleanupStack);
  }

  public TypeRef<?> compileCall(final Scope pScope, final boolean pCleanupStack) {
    switch (aPrimitive) {
      case MBoolean: {
        switch (aOperator) {
          case EQUALS:
            pScope.getCompiler().getIntCompiler().compileBuiltinEqualsInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in bool
          case UNEQUALS:
            pScope.getCompiler().getIntCompiler().compileBuiltinUnequalsInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in bool
          case LOGIC_AND:
            pScope.getCompiler().getIntCompiler().compileBuiltinLogicAnd(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in bool
          case LOGIC_OR:
            pScope.getCompiler().getIntCompiler().compileBuiltinLogicOr(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in bool
          default:
            break;
        }
        break;
      }
      case MByte:
      case MChar:
      case MShort:
      case MInt:
        switch (aOperator) {
          case PLUS:
            pScope.getCompiler().getIntCompiler().compileBuiltinAddInt(this, pScope, pCleanupStack);
            return Primitive.MInt.getRef(); // Always results in int
          case DIV:
            pScope.getCompiler().getIntCompiler().compileBuiltinDivInt(this, pScope, pCleanupStack);
            return Primitive.MInt.getRef(); // Always results in int
          case LOGIC_AND:
            break;
          case LOGIC_OR:
            break;
          case MEMBERACCESS:
            break;
          case MINUS:
            pScope.getCompiler().getIntCompiler().compileBuiltinMinusInt(this, pScope, pCleanupStack);
            return Primitive.MInt.getRef(); // Always results in int
          case MOD:
            pScope.getCompiler().getIntCompiler().compileBuiltinModInt(this, pScope, pCleanupStack);
            return Primitive.MInt.getRef(); // Always results in int
          case POWER:
            break;
          case TIMES:
            pScope.getCompiler().getIntCompiler().compileBuiltinMultInt(this, pScope, pCleanupStack);
            return Primitive.MInt.getRef(); // Always results in int
          case EQUALS:
            pScope.getCompiler().getIntCompiler().compileBuiltinEqualsInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
          case GREATER:
            pScope.getCompiler().getIntCompiler().compileBuiltinGreaterInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
          case GREATEREQ:
            pScope.getCompiler().getIntCompiler().compileBuiltinGreaterEqInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
          case LESS:
            pScope.getCompiler().getIntCompiler().compileBuiltinLessInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
          case LESSEQ:
            pScope.getCompiler().getIntCompiler().compileBuiltinLessEqInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
          case UNEQUALS:
            pScope.getCompiler().getIntCompiler().compileBuiltinUnequalsInt(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef(); // Always results in int
        }
        break;
      case MDouble:
        switch (aOperator) {
          case PLUS:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinAddDouble(this, pScope, pCleanupStack);
            return Primitive.MDouble.getRef();
          case DIV:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinDivDouble(this, pScope, pCleanupStack);
            return Primitive.MDouble.getRef();
          case LOGIC_AND:
            break;
          case LOGIC_OR:
            break;
          case MEMBERACCESS:
            break;
          case MINUS:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinMinusDouble(this, pScope, pCleanupStack);
            return Primitive.MDouble.getRef();
          case MOD:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinModDouble(this, pScope, pCleanupStack);
            return Primitive.MDouble.getRef();
          case POWER:
            break;
          case TIMES:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinMultDouble(this, pScope, pCleanupStack);
            return Primitive.MDouble.getRef();
          case EQUALS:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinEqualsDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATER:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinGreaterDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATEREQ:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinGreaterEqDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESS:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinLessDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESSEQ:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinLessEqDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case UNEQUALS:
            pScope.getCompiler().getDoublePrimitveCompiler().compileBuiltinUnequalsDouble(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
        }
        break;
      case MFloat:
        switch (aOperator) {
          case PLUS: {
            pScope.getCompiler().getFloatCompiler().compileBuiltinAddFloat(this, pScope, pCleanupStack);
            return aPrimitive.getRef();
          }
          case DIV:
            pScope.getCompiler().getFloatCompiler().compileBuiltinDivFloat(this, pScope, pCleanupStack);
            return Primitive.MFloat.getRef();
          case LOGIC_AND:
            break;
          case LOGIC_OR:
            break;
          case MEMBERACCESS:
            break;
          case MINUS:
            pScope.getCompiler().getFloatCompiler().compileBuiltinMinusFloat(this, pScope, pCleanupStack);
            return Primitive.MFloat.getRef();
          case MOD:
            pScope.getCompiler().getFloatCompiler().compileBuiltinModFloat(this, pScope, pCleanupStack);
            return Primitive.MFloat.getRef();
          case POWER:
            break;
          case TIMES:
            pScope.getCompiler().getFloatCompiler().compileBuiltinMultFloat(this, pScope, pCleanupStack);
            return Primitive.MFloat.getRef();
          case EQUALS:
            pScope.getCompiler().getFloatCompiler().compileBuiltinEqualsFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATER:
            pScope.getCompiler().getFloatCompiler().compileBuiltinGreaterFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATEREQ:
            pScope.getCompiler().getFloatCompiler().compileBuiltinGreaterEqFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESS:
            pScope.getCompiler().getFloatCompiler().compileBuiltinLessFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESSEQ:
            pScope.getCompiler().getFloatCompiler().compileBuiltinLessEqFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case UNEQUALS:
            pScope.getCompiler().getFloatCompiler().compileBuiltinUnequalsFloat(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
        }
        break;
      case MLong:
        switch (aOperator) {
          case PLUS:
            pScope.getCompiler().getLongCompiler().compileBuiltinAddLong(this, pScope, pCleanupStack);
            return aPrimitive.getRef();
          case DIV:
            pScope.getCompiler().getLongCompiler().compileBuiltinDivLong(this, pScope, pCleanupStack);
            return Primitive.MLong.getRef();
          case LOGIC_AND:
            break;
          case LOGIC_OR:
            break;
          case MEMBERACCESS:
            break;
          case MINUS:
            pScope.getCompiler().getLongCompiler().compileBuiltinMinusLong(this, pScope, pCleanupStack);
            return Primitive.MLong.getRef();
          case MOD:
            pScope.getCompiler().getLongCompiler().compileBuiltinModLong(this, pScope, pCleanupStack);
            return Primitive.MLong.getRef();
          case POWER:
            break;
          case TIMES:
            pScope.getCompiler().getLongCompiler().compileBuiltinMultLong(this, pScope, pCleanupStack);
            return Primitive.MLong.getRef();
          case EQUALS:
            pScope.getCompiler().getLongCompiler().compileBuiltinEqualsLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATER:
            pScope.getCompiler().getLongCompiler().compileBuiltinGreaterLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case GREATEREQ:
            pScope.getCompiler().getLongCompiler().compileBuiltinGreaterEqLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESS:
            pScope.getCompiler().getLongCompiler().compileBuiltinLessLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case LESSEQ:
            pScope.getCompiler().getLongCompiler().compileBuiltinLessEqLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
          case UNEQUALS:
            pScope.getCompiler().getLongCompiler().compileBuiltinUnequalsLong(this, pScope, pCleanupStack);
            return Primitive.MBoolean.getRef();
        }
        break;
    }

    throw new IllegalArgumentException("operator" + aOperator.toString() + ": unsupported builtin");
  }

}
