package meta.lang;


import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.LocalVariable;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class VarAssign extends AbstractExpression {

  private final Expression aLValue;

  private final Expression aType;

  private final Expression aRValue;

  private final List<AnnotateToken> aFlags;

  public VarAssign(final LinePosition pPosition, final List<AnnotateToken> pFlags, final Expression pLValue, final Expression pTypeToken, final Expression pValue) {
    super(pPosition);
    aFlags = pFlags;
    aLValue = pLValue;
    aType = pTypeToken;
    aRValue = pValue;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    Symbol variable;
    if (aLValue.getTokenType() == MLang.SYMBOL) {
      variable = (Symbol) aLValue;
    } else {
      final TypeRef<?> lValType = aLValue.getEvalType(pScope);
      if (TypeRef.create(null, Symbol.class).isAssignableFrom(lValType)) {
        variable = MEvaluator.toSymbol(aLValue);
      } else {
        final FuncCall fc = FuncCall.create(getPos(), aLValue, new Symbol(getPos(), "operator="), TypeRef.ANY, new Expression[] { aRValue });
        return fc.compile(pScope, pCleanupStack);
      }
    }
    if (isShortOperator(variable, pScope)) {
      return compileShortOperator(variable, pScope, pCleanupStack);
    }
    NamedObject target = pScope.resolveSymbol(variable.getName());
    if (target instanceof FieldRef) {
      if (!((FieldRef) target).isStatic()) {
        pScope.resolveSymbol("this").compileRef(this, pScope, false);
      }
    }
    if (aRValue != null) {
      final TypeRef<?> result = aRValue.compile(pScope, false);
      TypeRef<?> type;
      if ((aType == null) || (aType == TypeRef.ANY)) {
        type = result;
      } else {
        type = MEvaluator.toTypeRef(aType, pScope);
        if (!type.isAssignableFrom(result)) {
          pScope.getContext().error(this, "Declared type is not assignable from the expression");
        }
      }
      if (target == null) {
        target = pScope.addLocal(variable, type);
      }
      target.compileAssign(pScope, aRValue, pCleanupStack);
      return result;
    } else {
      pScope.addLocal(variable, MEvaluator.toTypeRef(aType, pScope));
      return null; //Declaration of a variable
    }
  }

  private boolean isShortOperator(final Symbol pVariable, final Scope pScope) throws CompilationException {
    if ((aRValue != null) && (aRValue.getTokenType() == MLang.BINARYOPERATOR)) {
      final BinaryExpression bOperator = (BinaryExpression) aRValue;
      if (pVariable.equals(bOperator.getLeft()) || pVariable.equals(bOperator.getRight())) {
        final Type targetType = aRValue.getEvalType(pScope).getReferredType();
        if (targetType instanceof Primitive) {
          switch ((Primitive) targetType) {
            case MByte:
            case MChar:
            case MInt:
            case MLong:
            case MShort:
              return true;
            case MDouble:
            case MFloat:
            case MBoolean:
              return false; // For now
          }
        }
      }
    }
    return false;
  }

  private TypeRef<?> compileShortOperator(final Symbol pVariable, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    boolean leftVal = false;
    assert (aRValue.getTokenType() != MLang.BINARYOPERATOR);

    final BinaryExpression bOperator = (BinaryExpression) aRValue;
    if (pVariable.equals(bOperator.getRight())) {
      leftVal = true;
    }

    final NamedObject target = pScope.resolveSymbol(pVariable.getName());

    if (target instanceof FieldRef) {
      return pScope.getCompiler().compileShortAssign(this, (FieldRef) target, bOperator.getOperator(), leftVal ? bOperator.getLeft()
          : bOperator.getRight(), pScope, pCleanupStack);
    } else {
      return pScope.getCompiler().compileShortAssign(this, (LocalVariable) target, bOperator.getOperator(), leftVal ? bOperator.getLeft()
          : bOperator.getRight(), pScope, pCleanupStack);
    }
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public MLang getTokenType() {
    return MLang.VARASSIGN;
  }

  @Override
  public Literal<?> eval(final Scope pScope) throws CompilationException {
    if (aRValue != null) {
      final Literal<?> result = MEvaluator.toLiteral(aRValue, pScope);
      pScope.setVar(MEvaluator.toSymbol(aLValue), result);
      return result;
    } else {
      if ((aType == null) || (aType == TypeRef.ANY)) {
        pScope.getContext().error(this, "The type of the variable could not be determined");
        return null;
      }
      final Literal<?> result = MEvaluator.toTypeRef(aType, pScope).getReferredType().getDefaultValue();
      pScope.setVar(MEvaluator.toSymbol(aLValue), result);
      return result;
    }
  }

  public Expression getLValue() {
    return aLValue;
  }


  public Expression getValueType() {
    return aType;
  }


  public Expression getRValue() {
    return aRValue;
  }


  // TODO share this with other flag receivers
  public EnumSet<AttributeFlags> getFlags(final Scope pScope) throws CompilationException {
    final List<AttributeFlags> result = new ArrayList<>(0);
    for (final AnnotateToken f : aFlags) {
      final AttributeFlags flag = AttributeFlags.fromString(f.getName());
      if (flag != null) {
        if ((f.getParams(pScope) != null) && (f.getParams(pScope).length > 0)) {
          pScope.getContext().error(f, "Builtin annotations do not have parameters");
        }
        result.add(flag);
      }
    }
    if (result.size() == 0) {
      return EnumSet.noneOf(AttributeFlags.class);
    }
    return EnumSet.copyOf(result);
  }

  public List<AnnotateToken> getFlags() {
    return aFlags;
  }

  @Override
  public boolean equals(final Object pObj) {
    if (pObj == this) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != VarAssign.class)) {
      return false;
    }
    final VarAssign other = (VarAssign) pObj;
    return aLValue.equals(other.aLValue) && aType.equals(other.aType)
        && (((aRValue == null) && (other.aRValue == null)) || ((aRValue != null) && aRValue.equals(other.aRValue)))
        && aFlags.equals(other.aFlags);
  }

  @Override
  public int hashCode() {
    return (((((aLValue.hashCode() * 31) + aType.hashCode()) * 31) + aRValue.hashCode()) * 31) + aFlags.hashCode();
  }

  @Override
  public String toString() {
    return getClass().getName() + "[ " + aFlags + ' ' + aLValue + ": " + aType + " = " + aRValue + " ]";
  }

  @Override
  public String toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    for (final AnnotateToken flag : aFlags) {
      result.append('@').append(flag.getName()).append(' ');
    }
    result.append(aLValue.toMetaCode(pIndent + 2));
    if (aType != TypeRef.ANY) {
      result.append(" : ").append(aType.toMetaCode(pIndent + 2));
    }
    if (aRValue != null) {
      result.append(" = ").append(aRValue.toMetaCode(pIndent + 2));
    }
    return result.toString();
  }

}
