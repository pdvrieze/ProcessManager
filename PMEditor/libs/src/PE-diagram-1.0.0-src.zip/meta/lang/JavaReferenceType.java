package meta.lang;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public abstract class JavaReferenceType extends ReferenceType implements JavaType {

  /**
   * Check whether the given type ref is a parent of this type
   * 
   * @param pCandidate The candidate type to check
   * @return true if a parent (class or interface)
   */
  @Override
  public abstract boolean hasParent(TypeRef<? extends JavaReferenceType> pCandidate);

  @Override
  public TypeRef<?> compileCallStatic(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Verify existence of the function on this type first.
    return pScope.getCompiler().compileCall(this, pFunction, pScope, pCleanupStack);
  }

  @Override
  public Literal<?> evalCallStatic(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException(getClass().getName() + ": Not yet implemented");
  }

  @Override
  public String toMetaCode(final int pIndent) {
    // TODO Auto-generated method stub
    // return null;
    return toString();
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return getRef();
    // TODO Auto-generated method stub
    // return null;
    //    throw new UnsupportedOperationException(getClass().getName()+": Not yet implemented");
  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pEvalScope) {
    return TypeRef.create(null, this);
  }

  @Override
  public TypeRef<? extends Type> getRef() {
    return getRef(TypeRef.<JavaReferenceType> emptyList());
  }

  @Override
  public Literal<?> evalFieldRef(final Object pInstance, final Symbol pName, final Scope pScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented: " + getClass().getName());
  }

}
