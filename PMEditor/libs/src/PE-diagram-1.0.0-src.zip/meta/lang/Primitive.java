package meta.lang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.FieldRef;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.languages.UnaryOperatorTokens;


/**
 * Primitive types
 * 
 * @author Paul de Vrieze
 */
public enum Primitive implements JavaType {
  MInt("int", "I", int.class, Integer.class),
  MDouble("double", "D", double.class, Double.class),
  MFloat("float", "F", float.class, Float.class),
  MBoolean("boolean", "Z", boolean.class, Boolean.class),
  MChar("char", "C", char.class, Character.class),
  MByte("byte", "B", byte.class, Byte.class),
  MLong("long", "J", long.class, Long.class),
  MShort("short", "S", short.class, Short.class);


  private final String aDescriptor;

  private final String aFQName;

  private final Class<?> aWrappedType;

  private final Class<?> aJClass;

  private List<FunctionRef> aMethods;

  Primitive(final String pFQName, final String pDescriptor, final Class<?> pJClass, final Class<?> pWrappedType) {
    aDescriptor = pDescriptor;
    aFQName = pFQName;
    aJClass = pJClass;
    aWrappedType = pWrappedType;
  }

  @Override
  public String getDescriptor() {
    return aDescriptor;
  }

  @Override
  public String getInternalName() {
    return aFQName;
  }

  @Override
  public GenericType[] getGenericParams() {
    return new GenericType[0];
  }

  @Override
  public TypeRef<Primitive> getRef() {
    return TypeRef.create(null, this);
  }

  @SafeVarargs
  @Override
  public final TypeRef<Primitive> getRef(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    assert (pGenericParams == null) || (pGenericParams.length == 0);
    return TypeRef.create(null, this);
  }

  @Override
  public String getSignature() {
    // Primitives are not generic by definition
    return aDescriptor;
  }

  @Override
  public boolean isAssignableFrom(final Type pOther) {
    return this.equals(pOther);
  }

  @SafeVarargs
  @Override
  public final TypeRef<? extends JavaReferenceType> getParent(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return null; // primitives have no parent class
  }

  @SafeVarargs
  @Override
  public final List<TypeRef<? extends JavaReferenceType>> getInterfaces(final TypeRef<? extends JavaReferenceType>... pGenericParams) {
    return Arrays.asList(TypeRef.<JavaReferenceType> emptyList());
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) {
    final String name = pName.getName();
    if (name.startsWith("operator")) {
      final String operatorToken = name.substring(8);
      final LinePosition pos = pName.getPos();
      for (final BinaryOperatorTokens operator : BinaryOperatorTokens.values()) {
        if (operator.isRepr(operatorToken) && isOperator(this, operator)) {
          return new BinaryPrimitiveOperator(pos, this, operator);
        }
      }
      for (final UnaryOperatorTokens operator : UnaryOperatorTokens.values()) {
        if (operator.isRepr(operatorToken) && isOperator(this, operator)) {
          return new UnaryPrimitiveOperator(pos, this, operator);
        }
      }
    }
    return null; // No other functions yet 
    // TODO Add wrapper statics
  }

  private static boolean isOperator(final Primitive pPrimitive, final UnaryOperatorTokens pOperator) {
    switch (pOperator) {
      case NOT: {
        switch (pPrimitive) {
          case MBoolean:
          case MByte:
          case MChar:
          case MShort:
          case MInt:
            return true;
          case MDouble:
          case MFloat:
          case MLong:
            return false;
          default:
            throw new IllegalStateException("Code should be unreachable");
        }
      }
      case PREINC:
      case POSTINC:
      case PREDEC:
      case POSTDEC:
        switch (pPrimitive) {
          case MDouble:
          case MFloat:
          case MBoolean:
            return false;
          case MByte:
          case MChar:
          case MInt:
          case MLong:
          case MShort:
            return true;
          default:
            throw new IllegalStateException("Code should be unreachable");
        }
      case PARENOPEN:
      case PARENCLOSE:
        return false;
      default:
        throw new IllegalStateException("Code should be unreachable");
    }
  }

  private static boolean isOperator(final Primitive pPrimitive, final BinaryOperatorTokens pOperator) {
    switch (pOperator) {
      case GREATER:
      case GREATEREQ:
      case LESS:
      case LESSEQ:
      case DIV:
      case MINUS:
      case MOD:
      case PLUS:
      case POWER:
      case TIMES: {
        switch (pPrimitive) {
          case MBoolean:
            return false;
          case MByte:
          case MChar:
          case MShort:
          case MInt:
          case MDouble:
          case MFloat:
          case MLong:
            return true;
          default:
            throw new IllegalStateException("Code should be unreachable");
        }
      }

      case LOGIC_AND:
        return pPrimitive == MBoolean;
      case LOGIC_OR:
        return pPrimitive == MBoolean;
      case EQUALS:
      case UNEQUALS:
        return true;
      default:
        throw new IllegalStateException("Code should be unreachable");
    }
  }

  @Override
  public List<FunctionRef> getMethods() {
    if (aMethods == null) {
      aMethods = new ArrayList<>(BinaryOperatorTokens.values().length);
      for (final BinaryOperatorTokens operator : BinaryOperatorTokens.values()) {
        if (isOperator(this, operator)) {
          aMethods.add(new BinaryPrimitiveOperator(null, this, operator));
        }
      }
    }
    return aMethods;
  }

  @Override
  public List<FieldRef> getFields() throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public FuncCall unWrap(final LinePosition pPosition, final Class<?> aSourceType, final Expression pExpr) {
    if (!aWrappedType.isAssignableFrom(aSourceType)) {
      throw new ClassCastException("The object " + aSourceType.getName() + " can not be converted to a primitive");
    }
    final FunctionType ft = new FunctionType(null, Arrays.<AnnotateToken> asList(), TypeRef.create(pPosition, aWrappedType), getRef(), TypeRef.emptyList());
    final FuncCall result = FuncCall.create(null, pExpr, new FunctionRef(null, getUnWrapName(), ft), new Expression[0]);
    return result;
  }

  private String getUnWrapName() {
    return aFQName + "Value";
  }

  private FuncCall wrap(final LinePosition pPosition, final Expression pExpr) {
    final FunctionType ft = new FunctionType(null, AnnotateToken.fromFlags(FunctionFlags.STATIC), TypeRef.create(pPosition, aWrappedType), TypeRef.create(pPosition, aWrappedType), getRef());
    final FuncCall result = FuncCall.create(null, getWrappedType(), new FunctionRef(null, "valueOf", ft), new Expression[] { pExpr });
    return result;
  }

  @Override
  public TypeRef<?> compileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (!pTargetType.isAssignableFrom(TypeRef.create(null, aWrappedType))) {
      throw new ClassCastException("The object can not be converted from a primitive to an unrelated type");
    }
    final FuncCall wrap = wrap(pToken.getPos(), pExpr);
    return wrap.compile(pScope, pCleanupStack);
  }


  public TypeRef<? extends JavaReferenceType> getWrappedType() {
    // We know that this must be a reference, but the compiler doesn't.
    return TypeRef.create(null, aWrappedType).asReferenceType();
  }

  @Override
  public TypeRef<?> compileCallStatic(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (pFunction instanceof BinaryPrimitiveOperator) {
      return ((BinaryPrimitiveOperator) pFunction).compileCall(pScope, pCleanupStack);
    }
    //    if (pFunction instanceof UnaryPrimitiveOperator) {
    //      return ((UnaryPrimitiveOperator) pFunction).compileCall(pScope, pCleanupStack);
    //    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  // TODO Make the evaluation stuff also go through FunctionRef when not complete yet
  @Override
  public Literal<?> evalCallStatic(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    if (pFunction instanceof BinaryPrimitiveOperator) {
      if (pArgs.length != 2) {
        pScope.getContext().error(pFunction, CompilationErrors.INVALID_ARGUMENT_COUNT);
      }
      return ((BinaryPrimitiveOperator) pFunction).evalCall(pArgs[0], pArgs[1], pScope);
    }
    if (pFunction instanceof UnaryPrimitiveOperator) {
      if (pArgs.length != 1) {
        pScope.getContext().error(pFunction, CompilationErrors.INVALID_ARGUMENT_COUNT);
      }
      return ((UnaryPrimitiveOperator) pFunction).evalCall(pScope, pArgs[0]);
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public Literal<?> evalCallDynamic(final Literal<?> pTarget, final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    if (pFunction instanceof BinaryPrimitiveOperator) {
      if (pArgs.length != 1) {
        pScope.getContext().error(pFunction, CompilationErrors.INVALID_ARGUMENT_COUNT);
      }
      return ((BinaryPrimitiveOperator) pFunction).evalCall(pTarget, pArgs[0], pScope);
    }
    if (pFunction instanceof UnaryPrimitiveOperator) {
      if ((pArgs != null) && (pArgs.length != 0)) {
        pScope.getContext().error(pFunction, CompilationErrors.INVALID_ARGUMENT_COUNT);
      }
      return ((UnaryPrimitiveOperator) pFunction).evalCall(pScope, pTarget);
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public String toMetaCode(final int pIndent) {
    return aDescriptor;
  }

  @Override
  public Literal<?> getDefaultValue() {
    // TODO implement more than just integer defaults
    switch (this) {
      case MInt:
        return Literal.createInt(null, 0);
      case MBoolean:
        return Literal.createBool(null, false);
      case MByte:
        return Literal.createByte(null, (byte) 0);
      case MChar:
        return Literal.createChar(null, (char) 0);
      case MDouble:
        return Literal.createDouble(null, Double.NaN);
      case MFloat:
        return Literal.createFloat(null, Float.NaN);
      case MLong:
        return Literal.createLong(null, 0l);
      case MShort:
        return Literal.createShort(null, (short) 0);
    }
    return null;
  }

  public Class<?> getJClass() {
    return aJClass;
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pEvalScope) {
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public Literal<?> evalFieldRef(final Object pInstance, final Symbol pName, final Scope pScope) throws CompilationException {
    pScope.getContext().error(pName, "Function types have no fields");
    return null;
  }

}
