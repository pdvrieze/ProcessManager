package meta.lang;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;
import net.devrieze.util.StringUtil;


public class Loop extends AbstractExpression {


  private static final class ReturnException extends Exception {

    private static final long serialVersionUID = 5788436691349878469L;

    private final ReturnValue aCondition;

    public ReturnException(final ReturnValue pReturnValue) {
      aCondition = pReturnValue;
    }

    public ReturnValue getReturnValue() {
      return aCondition;
    }

  }


  /** The main loop body */
  private final Expression aBody;

  /** The postcondition for the loop */
  private final Expression aPostCondition;

  /** The precondition for the loop */
  private final Expression aPreCondition;

  /** The initialising code for the loop */
  private final Expression aInit;

  /** The code to execute when looping (between postcondition and precondition) */
  private final Expression aLoopBody;

  public Loop(final LinePosition pPosition, final Expression pInit, final Expression pPreCondition, final Expression pBody, final Expression pPostCondition, final Expression pLoopBody) {
    super(pPosition);
    aInit = pInit;
    aPreCondition = pPreCondition;
    aBody = pBody;
    aPostCondition = pPostCondition;
    aLoopBody = pLoopBody;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (!pCleanupStack) {
      pScope.getContext().error(this, "Loops do not have a result variable");
    }
    pScope.getCompiler().compileLoop(this, pScope);
    return null;
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    final Scope outerScope = pScope.newDefaultSubScope();
    if (aInit.getTokenType() == MLang.TUPPLE) {
      for (final Expression expr : ((MTupple) aInit)) {
        expr.eval(outerScope);
      }
    } else {
      aInit.eval(outerScope);
    }
    try {
      boolean preCondition = evalCondition(aPreCondition, outerScope.newInternalScope());
      boolean postCondition = true;
      while (preCondition && postCondition) {
        EvalResult returnValue = aBody.eval(outerScope.newDefaultSubScope());
        if (returnValue instanceof ReturnValue) {
          return returnValue;
        }
        postCondition = evalCondition(aPostCondition, outerScope.newInternalScope());
        if (postCondition) {
          if (aLoopBody != null) {
            returnValue = aLoopBody.eval(outerScope.newInternalScope());
            if (returnValue instanceof ReturnValue) {
              return returnValue;
            }
          }
        }
        preCondition = evalCondition(aPreCondition, outerScope.newInternalScope());
      }
    } catch (final ReturnException e) {
      return e.getReturnValue();
    }
    return null;
  }

  private static boolean evalCondition(final Expression pCondition, final Scope pScope) throws CompilationException, ReturnException {
    if (pCondition == null) {
      return true;
    }
    final EvalResult condition = pCondition.eval(pScope);
    if (condition instanceof ReturnValue) {
      pScope.getContext().warning(pCondition, "Return from within an expression");
      throw new ReturnException((ReturnValue) condition);
    }
    if (!(condition instanceof Literal.BoolLiteral)) {
      pScope.getContext().error(pCondition, "Condition must evaluate to boolean value");
    }
    return ((Literal.BoolLiteral) condition).getValue();
  }

  @Override
  public MLang getTokenType() {
    return MLang.LOOP;
  }

  public static Loop newDo(final LinePosition pPos, final MTupple pBody, final MTupple pCondition) {
    return new Loop(pPos, null, null, pBody, pCondition, null);
  }

  public static Loop newWhile(final LinePosition pPos, final MTupple pCondition, final MTupple pBody) {
    return new Loop(pPos, null, pCondition, pBody, null, null);
  }

  public static Loop newFor(final LinePosition pPos, final Expression pInit, final Expression pCondition, final Expression pControl, final MTupple pBody) {
    return new Loop(pPos, pInit, pCondition, pBody, null, pControl);
  }

  public static Loop newForEach(final LinePosition pPos, final Expression pReceiver, final Expression pCollection, final MTupple pBody, final Scope pScope) throws CompilationException {
    Expression init;
    Expression preCondition;
    Expression loopBody;
    // Support proper anonymous variables
    final Symbol iterVar = new Symbol(pPos, "$it");
    Expression body1;

    final TypeRef<?> sourceType = pCollection.getEvalType(pScope);
    if (sourceType.getReferredType() instanceof ArrayType) {
      final Symbol endVar = new Symbol(pPos, "$itend");
      final ArrayType at = (ArrayType) sourceType.getReferredType();
      final VarAssign init1 = new VarAssign(pReceiver.getPos(), null, iterVar, Primitive.MInt.getRef(), Literal.createInt(pPos, 0));
      final VarAssign init2 = new VarAssign(pReceiver.getPos(), null, endVar, Primitive.MInt.getRef(), new BinaryExpression(pPos, BinaryOperatorTokens.MEMBERACCESS, pCollection, new Symbol(pPos, "length")));
      final FuncCall fc = FuncCall.create(pPos, pCollection, new Symbol(pCollection.getPos(), "operator["), TypeRef.ANY, new Expression[] { iterVar });
      body1 = new VarAssign(pReceiver.getPos(), null, pReceiver, at.getElementType(), fc);
      init = new MTupple(pPos, init1, init2);
      preCondition = new BinaryExpression(pPos, BinaryOperatorTokens.LESS, iterVar, endVar);
      loopBody = FuncCall.create(pPos, iterVar, new Symbol(pPos, "operator++_"), TypeRef.ANY, new Expression[0]);
    } else if (TypeRef.create(null, Iterable.class).isAssignableFrom(sourceType)) {
      final FunctionRef iter = sourceType.resolveFunction(pScope, new Symbol(pPos, "iterator"));
      init = new VarAssign(pReceiver.getPos(), null, iterVar, iter.getReturnType(pScope), FuncCall.create(pPos, pCollection, iter, new Expression[0]));
      final FunctionRef next = iter.getReturnType(pScope).resolveFunction(pScope, new Symbol(pPos, "next"));
      final FuncCall fc = FuncCall.create(pPos, iterVar, next, new Expression[0]);
      final TypeCast cast = new TypeCast(pPos, next.getReturnType(pScope), fc);
      body1 = new VarAssign(pReceiver.getPos(), null, pReceiver, null, cast);
      final FunctionRef hasNext = iter.getReturnType(pScope).resolveFunction(pScope, new Symbol(pPos, "hasNext"));
      preCondition = FuncCall.create(pPos, iterVar, hasNext, new Expression[0]);
      loopBody = null;
    } else {
      pScope.getContext().error(pCollection, "The result of the expression is not iterable");
      return null;
    }
    final MTupple body = new MTupple(pPos, body1, pBody);

    return new Loop(pPos, init, preCondition, body, null, loopBody);
  }


  public Expression getBody() {
    return aBody;
  }


  public Expression getPostCondition() {
    return aPostCondition;
  }


  public Expression getPrecondition() {
    return aPreCondition;
  }


  public Expression getInit() {
    return aInit;
  }


  public Expression getLoopBody() {
    return aLoopBody;
  }

  @Override
  public String toMetaCode(final int pIndent) {
    if ((aLoopBody == null) && (aInit == null)) {
      if (aPostCondition == null) {
        return whileToMetaCode(pIndent);
      }
      if (aPreCondition == null) {
        return doToMetaCode(pIndent);
      }
    } else if (aPostCondition == null) {
      return forMetaCode(pIndent);
    }
    // TODO Auto-generated method stub
    // return super.toMetaCode(pIndent);
    throw new UnsupportedOperationException("Not yet implemented");
  }

  private String forMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("for(").append(aInit == null ? "()" : aInit.toMetaCode(pIndent + 4));
    result.append(", ").append(aPreCondition.toMetaCode(pIndent + 4));
    result.append(", ").append(aLoopBody == null ? "()" : aLoopBody.toMetaCode(pIndent + 4));
    if (aBody.getTokenType() == MLang.TUPPLE) {
      result.append(")(\n");
      for (final Expression expr : (MTupple) aBody) {
        result.append(StringUtil.charRepeat(pIndent + 2, ' '));
        result.append(expr.toMetaCode(pIndent + 2)).append('\n');
      }
      result.append(StringUtil.charRepeat(pIndent, ' ')).append(')');
    } else {
      result.append(")\n").append(StringUtil.charRepeat(pIndent + 2, ' '));
      result.append(aBody.toMetaCode(pIndent + 2));
    }
    return result.toString();
  }

  private String whileToMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("while (").append(aPreCondition.toMetaCode(pIndent + 4));
    if (aBody.getTokenType() == MLang.TUPPLE) {
      result.append(") (\n");
      for (final Expression expr : (MTupple) aBody) {
        result.append(StringUtil.charRepeat(pIndent + 2, ' '));
        result.append(expr.toMetaCode(pIndent + 2)).append('\n');
      }
      result.append(StringUtil.charRepeat(pIndent, ' ')).append(')');
    } else {
      result.append(")\n").append(StringUtil.charRepeat(pIndent + 2, ' '));
      result.append(aBody.toMetaCode(pIndent + 2));
    }
    return result.toString();
  }

  private String doToMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("do (").append(aPreCondition.toMetaCode(pIndent + 4));
    if (aBody.getTokenType() == MLang.TUPPLE) {
      result.append("do (\n");
      for (final Expression expr : (MTupple) aBody) {
        result.append(StringUtil.charRepeat(pIndent + 2, ' '));
        result.append(expr.toMetaCode(pIndent + 2)).append('\n');
      }
      result.append(StringUtil.charRepeat(pIndent, ' ')).append(" while (");
    } else {
      result.append("do\n").append(StringUtil.charRepeat(pIndent + 2, ' '));
      result.append(aBody.toMetaCode(pIndent + 2));
      result.append(StringUtil.charRepeat(pIndent, ' ')).append("while (");
    }
    result.append(aPostCondition.toMetaCode(pIndent + 4));
    result.append(")\n");
    return result.toString();
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append("loop ( init = ");
    result.append(aInit).append(", preCondition = ");
    result.append(aPreCondition).append(", body = ");
    result.append(aBody).append(", postCondition = ");
    result.append(aPostCondition).append(", loopBody = ");
    result.append(aLoopBody).append(")");
    return result.toString();
  }

  @Override
  public boolean equals(final Object pObj) {
    if (this == pObj) {
      return true;
    }
    if ((pObj == null) || (pObj.getClass() != Loop.class)) {
      return false;
    }
    final Loop other = (Loop) pObj;
    boolean equals = aBody.equals(other.aBody);
    equals = equals && (((aPostCondition == null) && (other.aPostCondition == null)) || aPostCondition.equals(other.aPostCondition));
    equals = equals && (((aPreCondition == null) && (other.aPreCondition == null)) || aPreCondition.equals(other.aPreCondition));
    equals = equals && (((aInit == null) && (other.aInit == null)) || aInit.equals(other.aInit));
    equals = equals && (((aLoopBody == null) && (other.aLoopBody == null)) || aLoopBody.equals(other.aLoopBody));
    return equals;
  }

  @Override
  public int hashCode() {
    // TODO Auto-generated method stub
    return super.hashCode();
  }
}
