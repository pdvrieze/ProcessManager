package nl.adaptivity.diagram;


public interface Diagram extends Drawable {

}
