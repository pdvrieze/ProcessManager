package nl.adaptivity.diagram;


public interface Color {

}
