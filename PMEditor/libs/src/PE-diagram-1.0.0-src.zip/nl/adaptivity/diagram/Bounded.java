package nl.adaptivity.diagram;


public interface Bounded {

  public Rectangle getBounds();

}