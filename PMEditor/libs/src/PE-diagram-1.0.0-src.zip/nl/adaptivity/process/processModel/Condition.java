package nl.adaptivity.process.processModel;


public interface Condition {

  public String getCondition();

}