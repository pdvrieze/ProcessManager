/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.compiler.typedTokens;

import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.tokens.ExprToken;
import net.devrieze.parser.tokens.LiteralToken;
import net.devrieze.parser.tokens.UnaryExprToken;


/**
 * Transform untyped expressions into typed ones.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class ExpressionTyper {

  private ExpressionTyper() {
    // Empty
  }

  @SuppressWarnings({ "unchecked", "incomplete-switch" })
  public static TypedExpressionToken<ExpressionTokens> type(final ExprToken<ExpressionTokens> pExpr) throws CompilationException {
    // TODO Actually implement everything
    switch (pExpr.getTokenType()) {
      case LITERAL:
        return new TypedLiteral<>((LiteralToken<ExpressionTokens, Object>) pExpr);
      case PAREN:
        return type(((UnaryExprToken<ExpressionTokens>) pExpr).getSubToken());
      case NOT:
        return handleNot((UnaryExprToken<ExpressionTokens>) pExpr);
    }
    return null;
  }

  private static TypedExpressionToken<ExpressionTokens> handleNot(final UnaryExprToken<ExpressionTokens> pExpr) throws CompilationException {
    final TypedExpressionToken<ExpressionTokens> sub = type(pExpr.getSubToken());
    if (sub instanceof TypedLiteral) {
      if (sub.getReferredType() != Boolean.class) {
        throw new CompilationException(sub, "the type of the expression is not boolean");
      }
      final Object value = ((TypedLiteral<?,?>) sub).getValue();
      return new TypedLiteral<>(sub.getTokenType(), pExpr.getPos(), Boolean.valueOf(!((Boolean) value).booleanValue()));
    }
    return new TypedUnary<>(pExpr, sub);
  }

}
