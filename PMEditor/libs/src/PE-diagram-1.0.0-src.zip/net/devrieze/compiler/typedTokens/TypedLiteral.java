/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.compiler.typedTokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.LiteralToken;


/**
 * A typed literal.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The language.
 * @param <V> The type of the value.
 */
public class TypedLiteral<T extends Enum<T> & Language<T>, V> extends LiteralToken<T, V> implements TypedExpressionToken<T> {

  public TypedLiteral(final T pTokenType, final LinePosition pPos, final V pValue) {
    super(pTokenType, pPos, pValue);
  }

  public TypedLiteral(final LiteralToken<T, V> pExpr) {
    super(pExpr.getTokenType(), pExpr.getPos(), pExpr.getValue());
  }

  @Override
  public Class<?> getReferredType() {
    return getValue().getClass();
  }

}
