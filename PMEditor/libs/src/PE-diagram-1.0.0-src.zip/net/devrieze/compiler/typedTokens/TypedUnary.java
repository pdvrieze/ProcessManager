/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.compiler.typedTokens;

import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.UnaryExprToken;


/**
 * A typed unary.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The language used
 */
public class TypedUnary<T extends Enum<T> & Language<T>> extends UnaryExprToken<T> implements TypedExpressionToken<T> {

  public TypedUnary(final UnaryExprToken<T> pExpr, final TypedExpressionToken<T> pSub) {
    super(pExpr.getTokenType(), pExpr.getPos(), pSub);
  }

  @Override
  public TypedExpressionToken<T> getSubToken() {
    return (TypedExpressionToken<T>) super.getSubToken();
  }

  /**
   * Get the type of the expression.
   * 
   * @return The type.
   * @see net.devrieze.compiler.typedTokens.TypedExpressionToken#getReferredType()
   */
  @Override
  public Class<?> getReferredType() {
    final Object tokenType = getTokenType();
    if (tokenType == ExpressionTokens.NOT) {
      return Boolean.class;
    }
    return getSubToken().getReferredType();
  }

}
