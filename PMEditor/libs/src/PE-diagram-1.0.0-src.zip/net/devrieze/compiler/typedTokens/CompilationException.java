/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.compiler.typedTokens;

import net.devrieze.parser.Token;
import net.devrieze.parser.TokenException;


/**
 * An exception for errors found in compilation.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class CompilationException extends TokenException {

  private static final long serialVersionUID = -4402903211684034312L;

  public CompilationException(final Token<?> pToken, final String pMessage) {
    super(pToken, pMessage);
  }

  public CompilationException(final Token<?> pToken, final Throwable pCause, final String pMessage) {
    super(pToken, pCause, pMessage);
  }

  public CompilationException(final Token<?> pToken, final Throwable pCause) {
    super(pToken, pCause);
  }

}
