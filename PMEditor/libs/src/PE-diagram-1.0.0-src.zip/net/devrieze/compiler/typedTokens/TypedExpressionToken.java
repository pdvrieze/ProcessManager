/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.compiler.typedTokens;

import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.ExprToken;


/**
 * A type of expression tokens that has types.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The language used.
 */
public interface TypedExpressionToken<T extends Enum<T> & Language<T>> extends ExprToken<T> {

  /**
   * Get the type of the token.
   * 
   * @return The type.
   */
  Class<?> getReferredType();
}
