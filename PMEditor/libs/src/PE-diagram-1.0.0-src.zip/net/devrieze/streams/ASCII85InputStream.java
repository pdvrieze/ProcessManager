/*
 * Created on Feb 13, 2004
 *
 */
package net.devrieze.streams;

import java.io.IOException;
import java.io.InputStream;

import net.devrieze.util.StringUtil;


/**
 * An input stream for parsing the ASCII85 format as defined in the PDF
 * standard.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class ASCII85InputStream extends InputStream {

  private static final int _IMMEDIATE_EOS = 122;

  private static final int _ENDOFSTREAM = 126;

  private static final int _OFFSET = 33;

  private static final int _BASE = 85;

  private static final int _MAX_BYTE = 0xff;

  private static final int _BITS_PER_BYTE = 8;

  private static final int _BUFFERSIZE = 4;

  private static final int _OUTBUFFERSIZE = 5;

  private final InputStream aIn;

  private final int[] aBuffer;

  private int aBufferPos;

  private int aBufferLength;

  public ASCII85InputStream(final InputStream pIn) {
    aIn = pIn;
    aBuffer = new int[_BUFFERSIZE];
    aBufferPos = _BUFFERSIZE;
    aBufferLength = _BUFFERSIZE;
  }

  private int[] readBuf() throws IOException {
    final int[] result = new int[_OUTBUFFERSIZE];
    do {
      result[0] = aIn.read();
    } while (StringUtil.isWhite((char) result[0]));
    if (result[0] == _IMMEDIATE_EOS) {
      result[0] = 0;
      return result;
    }
    for (int i = 1; i < _OUTBUFFERSIZE; i++) {
      do {
        result[i] = (byte) aIn.read();
      } while (StringUtil.isWhite((char) result[i]));
    }
    return result;
  }

  @Override
  public int read() throws IOException {
    if (aBufferLength < 0) {
      return -1;
    }
    if (aBufferPos >= aBufferLength) {
      if (aBufferLength < _BUFFERSIZE) {
        return -1;
      }
      final int[] buf = readBuf();
      long val = 0;
      aBufferLength = _BUFFERSIZE;
      for (int i = 0; i < _OUTBUFFERSIZE; i++) {
        if (buf[i] == _ENDOFSTREAM) {
          if (i == 0) {
            aBufferLength = 0;
            return -1;
          }

          aBufferLength = i - 1;
          // break;
        }
        val = (val * _BASE) + (buf[i] - _OFFSET);
      }
      for (int i = _BUFFERSIZE - 1; i >= 0; i--) {
        aBuffer[i] = (int) (val & _MAX_BYTE);
        val = val >> _BITS_PER_BYTE; // shift right 8 bits
      }
      for (int i = aBufferLength; i < aBuffer.length; i++) {
        aBuffer[i] = -1;
      }
      aBufferPos = 0;
    }
    aBufferPos++;
    return aBuffer[aBufferPos - 1];
  }

  @Override
  public void close() throws IOException {
    aIn.close();
  }

  /**
   * Restart to the beginning of the stream.
   */
  @Override
  public synchronized void reset() throws IOException {
    aIn.reset();
    aBufferPos = _BUFFERSIZE;
    aBufferLength = _BUFFERSIZE;
  }

  @Override
  public boolean markSupported() {
    return false;
  }

}
