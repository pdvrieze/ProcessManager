/*
 * Created on Feb 13, 2004
 *
 */
package net.devrieze.streams;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import net.devrieze.lang.Const;


/**
 * An output stream that encodes to the ASCII85 format as defined by the pdf
 * standard.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class ASCII85OutputStream extends OutputStream {


  private static final int _OFFSET = 33;

  private static final int _BASE = 85;

  private static final int _MAX_BYTE = 0xff;

  private static final int _BITS_PER_BYTE = 8;

  private static final int _BUFFERSIZE = 4;

  private static final int _OUTBUFFERSIZE = 5;

  private static final int _MAX_LINE_LENGTH = 80;

  private final OutputStream aOut;

  private final int[] aWaiting;

  private int aWaitingCount;

  private int aCharsOnLine;

  public ASCII85OutputStream(final OutputStream pOut) {
    aOut = pOut;
    aWaiting = new int[_BUFFERSIZE];
    aWaitingCount = 0;
    aCharsOnLine = 0;
  }

  @Override
  public void write(final int pB) throws IOException {
    aWaiting[aWaitingCount] = pB;
    aWaitingCount++;
    if (aWaitingCount >= aWaiting.length) {
      final byte[] encoded = encode(aWaiting, true);
      aOut.write(encoded);
      aCharsOnLine += encoded.length;
      if (aCharsOnLine > _MAX_LINE_LENGTH) {
        aOut.write(Const._CR);
        aOut.write(Const._LF);
      }
      aWaitingCount = 0;
    }
  }

  private static byte[] encode(final int[] pWaiting, final boolean pZeroRule) {
    final byte[] result = new byte[_OUTBUFFERSIZE];
    long total = 0;
    for (final int waiting : pWaiting) {
      total = (total << _BITS_PER_BYTE) | waiting;
    }
    if ((total == 0) && pZeroRule) {
      return new byte[] { 'z' };
    }
    for (int i = result.length - 1; i >= 0; i--) {
      result[i] = (byte) ((total % _BASE) + _OFFSET);
      total /= _BASE;
    }
    return result;
  }

  /**
   * Close the stream, but not the parent.
   * 
   * @throws IOException When something goes wrong.
   */
  @Override
  public void close() throws IOException {
    for (int i = aWaitingCount; i < aWaiting.length; i++) {
      aWaiting[i] = 0;
    }
    if (aWaitingCount > 0) {
      final byte[] encoded = encode(aWaiting, false);
      for (int i = 0; i < (aWaitingCount + 1); i++) {
        aOut.write(encoded[i]);
      }
    }
    aOut.write('~');
    aOut.write('>');

    super.close();
  }

  public static String encode(final int[] pCharacters) {
    try {
      final ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
      try(final ASCII85OutputStream out = new ASCII85OutputStream(byteArray)) {
        for (final int i : pCharacters) {
          if ((i > _MAX_BYTE) || (i < 0)) {
            throw new IllegalArgumentException("The characters to encode must range from 0 to 255");
          }
          out.write(i);
        }
      }
      return byteArray.toString();
    } catch (final IOException e) {
      throw new RuntimeException(e);
    }
  }


}
