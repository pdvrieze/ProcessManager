/*
 * Created on 24-May-2005
 */
package net.devrieze.php;

import java.util.Collection;
import java.util.Map;


/**
 * A class that can perform php serialization.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public final class Serializer {

  private Serializer() {
    // Don't create instances. It's a utility class.
  }

  public static String serialize(final String pString) {
    return "s:" + pString.length() + ":\"" + pString + "\";";
  }

  public static String serialize(final int pInt) {
    return "i:" + pInt + ";";
  }

  public static String serialize(final Integer pInt) {
    return serialize(pInt.intValue());
  }

  public static String serialize(final double pDouble) {
    return "d:" + pDouble + ";";
  }

  public static String serialize(final Double pDouble) {
    return serialize(pDouble.doubleValue());
  }

  public static String serialize(final boolean pBool) {
    return "b:" + (pBool ? '1' : '0') + ";";
  }

  public static String serialize(final Boolean pBool) {
    return serialize(pBool.booleanValue());
  }

  public static String serialize(final Object[] pArray) {
    final StringBuilder result = new StringBuilder();
    result.append("a:").append(pArray.length).append(":{");
    for (int i = 0; i < pArray.length; i++) {
      result.append(serialize(i)).append(serialize(pArray[i]));
    }
    result.append("}");
    return result.toString();
  }

  public static String serialize(final Collection<?> pList) {
    return serialize(pList.toArray());
  }

  public static String serialize(final Map<?, ?> pMap) {
    final StringBuilder result = new StringBuilder();
    result.append("a:").append(pMap.size()).append(":{");
    for (final Map.Entry<?, ?> e : pMap.entrySet()) {
      result.append(serialize(e.getKey())).append(serialize(e.getValue()));
    }
    result.append("}");
    return result.toString();
  }

  public static String serialize(final Object pObject) {
    String result;
    if (pObject instanceof Object[]) {
      result = serialize((Object[]) pObject);
    } else if (pObject instanceof Double) {
      result = serialize((Double) pObject);
    } else if (pObject instanceof Integer) {
      result = serialize((Integer) pObject);
    } else if (pObject instanceof Collection) {
      result = serialize((Collection<?>) pObject);
    } else if (pObject instanceof Map) {
      result = serialize((Map<?, ?>) pObject);
    } else if (pObject instanceof String) {
      result = serialize((String) pObject);
    } else if (pObject instanceof Boolean) {
      result = serialize((Boolean) pObject);
    } else {
      throw new RuntimeException("Trying to serialize an unsupported object: " + pObject.getClass().getName());
    }
    return result;
  }

  public static Object deSerialize(final CharSequence pSequence) {
    final char type = pSequence.charAt(0);
    switch (type) {
      case 'i': {
        return deSerializeInteger(pSequence);
      }
      case 'd': {
        return deSerializeDouble(pSequence);
      }
      case 's': {
        return deSerializeString(pSequence);
      }
      default:
        return null;
    }
  }

  private static Object deSerializeString(final CharSequence pSequence) {
    assert pSequence.charAt(1) == ':';
    int i = 2;
    while ((pSequence.charAt(i) >= '0') && (pSequence.charAt(i) <= '9')) {
      i++;
    }
    assert pSequence.charAt(i) == ':';
    assert pSequence.charAt(i + 1) == '"';
    final int size = Integer.parseInt(pSequence.subSequence(2, i).toString());
    final StringBuilder result = new StringBuilder(size);
    for (int j = 0; j < size; j++) {
      result.append(pSequence.charAt(i + 1 + j));
    }
    assert pSequence.charAt(i + size + 1) == '"';
    assert pSequence.charAt(i + size + 2) == ';';
    return result.toString();
  }

  private static Object deSerializeDouble(final CharSequence pSequence) {
    assert pSequence.charAt(1) == ':';
    int i = 2;
    while (((pSequence.charAt(i) >= '0') && (pSequence.charAt(i) <= '9')) || (pSequence.charAt(i) == '.')) {
      i++;
    }
    assert pSequence.charAt(i) == ';';
    return Double.valueOf(pSequence.subSequence(2, i).toString());
  }

  private static Object deSerializeInteger(final CharSequence pSequence) {
    assert pSequence.charAt(1) == ':';
    int i = 2;
    while ((pSequence.charAt(i) >= '0') && (pSequence.charAt(i) <= '9')) {
      i++;
    }
    assert pSequence.charAt(i) == ';';
    return Integer.valueOf(pSequence.subSequence(2, i).toString());
  }

}
