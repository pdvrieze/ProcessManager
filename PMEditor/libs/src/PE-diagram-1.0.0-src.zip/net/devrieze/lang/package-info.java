/**
 * The net.devrieze.lang package contains extensions upon {@link java.lang}
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.lang;

