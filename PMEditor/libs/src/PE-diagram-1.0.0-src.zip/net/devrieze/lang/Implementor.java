/*
 * Created on Dec 19, 2004
 *
 */
package net.devrieze.lang;

import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import static net.devrieze.util.Annotations.*;

import net.devrieze.annotation.Published;
import net.devrieze.annotations.NotNull;
import net.devrieze.annotations.Nullable;


/**
 * The implementor class allows wrappers to be defined that provide interfaces
 * for types that do not implement them natively.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@Published({ "net.devrieze.experimental" })
public final class Implementor {

  private Implementor() {
    // Do nothing, it is a utility class.
  }

  /**
   * The _Implementors variable contains the map that records all implementors.
   */
  @NotNull
  private static final HashMap<Class<?>, HashMap<Class<?>, Class<?>>> __Implementors = defaultImplementors();

  /**
   * Create a new Implementor with the specified properties.
   *
   * @param pMapper The class that provides a wrapper that implements an
   *          interface for the pSource class.
   * @param pSource The source type for which the wrapper works.
   * @param pTarget The target interface.
   * @param pTargetList A list of other targets. This is aditional to pTarget as
   *          there must be at least one target.
   */
  protected static void registerImplementor(@NotNull final Class<?> pMapper, @NotNull final Class<?> pSource, @NotNull final Class<?> pTarget, @NotNull final Class<?>... pTargetList) {
    if (!__Implementors.containsKey(pSource)) {
      __Implementors.put(pSource, new HashMap<Class<?>, Class<?>>());
    }
    __Implementors.get(pSource).put(pTarget, pMapper);
    for (final Class<?> target : pTargetList) {
      __Implementors.get(pSource).put(target, pMapper);
    }
  }

  /**
   * Checks whether there is a class that will implement the pClass for the
   * given source type.
   *
   * @param pSource The object that might be &quot;cast&quot;
   * @param pTarget The class to which the object should cast.
   * @return <code>true</code> if there is a wrapper or pSource is an instance
   *         <code>false</code> if not.
   */
  public static boolean hasImplementorClass(@NotNull final Class<?> pSource, @NotNull final Class<?> pTarget) {
    if (pTarget.isAssignableFrom(pSource)) {
      return true;
    }
    if (__Implementors.containsKey(pSource)) {
      for (final Class<?> r : __Implementors.get(pSource).keySet()) {
        if (pTarget.isAssignableFrom(r)) {
          return true;
        }
      }
      return false;
    }
    for (final Class<?> c : new ParentIterator(pSource)) {
      if (hasImplementor(notNull(c), pTarget)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Checks whether there is a class that will implement the pClass for the
   * given object.
   *
   * @param pSource The object that might be &quot;cast&quot;
   * @param pClass The class to which the object should cast.
   * @return <code>true</code> if there is a wrapper or pSource is an instance
   *         <code>false</code> if not.
   */
  public static boolean hasImplementor(@NotNull final Object pSource, @NotNull final Class<?> pClass) {
    return hasImplementor(notNull(pSource.getClass()), pClass);
  }

  /**
   * Get a class that implements a wrapper for the given source type to the
   * target type. If the source type is a subtype of the target type, the source
   * type is returned.
   *
   * @param <T> Get's the type of the target type, so casts are not needed.
   * @param pSource The source type to search from.
   * @param pTarget The type that must be cast to.
   * @return <code>null</code> if there is no class, else a wrapper class.
   */
  @Nullable
  public static <T> Class<? extends T> implementorClass(@NotNull final Class<?> pSource, @NotNull final Class<T> pTarget) {
    if (pTarget.isAssignableFrom(pSource)) {
      return pSource.asSubclass(pTarget);
    }

    final Map<? extends Class<?>, ? extends Class<?>> map = __Implementors.get(pSource);
    if (map == null) {
      for (final Class<?> c : new ParentIterator(pSource)) {
        final Class<? extends T> r = implementorClass(notNull(c), pTarget);
        if (r != null) {
          return r;
        }
      }
      return null;
    } /* The map is not null */
    for (final Map.Entry<? extends Class<?>, ? extends Class<?>> entry : map.entrySet()) {
      if (pTarget.isAssignableFrom(entry.getKey())) {
        return entry.getValue().asSubclass(pTarget);
      }
    }

    return null;
  }

  /**
   * Get an implementor for a given interface, given the source object. This
   * works like a cast except that it alleviates the problems caused by third
   * party libraries and final classes.
   *
   * @param <T> The type of the interface, to avoid casts.
   * @param pSource The source object to get a wrapper for
   * @param pTarget The target class that must be implemented
   * @return An instance of a wrapper to the given interface. <code>null</code>
   *         if there is no wrapper.
   */
  @Nullable
  public static <T> T implementor(@NotNull final Object pSource, @NotNull final Class<T> pTarget) {
    if (pTarget.isInstance(pSource)) {
      return pTarget.cast(pSource);
    }
    try {
      @Nullable final Class<? extends T> c = implementorClass(notNull(pSource.getClass()), pTarget);
      if (c == null) {
        return null;
      }
      for (final Constructor<?> constr : c.getConstructors()) {
        if ((constr.getParameterTypes().length == 1) && constr.getParameterTypes()[0].isInstance(pSource)) {
          return pTarget.cast(constr.newInstance(new Object[] { pSource }));
        }
      }
    } catch (final IllegalArgumentException e) {
      e.printStackTrace();
      throw new RuntimeException("Something went wrong in the implementor function", e);
    } catch (final InstantiationException e) {
      e.printStackTrace();
      throw new RuntimeException("Something went wrong in the implementor function", e);
    } catch (final IllegalAccessException e) {
      e.printStackTrace();
      throw new RuntimeException("Something went wrong in the implementor function", e);
    } catch (final InvocationTargetException e) {
      e.printStackTrace();
      throw new RuntimeException("Something went wrong in the implementor function", e);
    }
    throw new RuntimeException("An implementor did not fullfill it's contract");
  }

  @NotNull
  private static HashMap<Class<?>, HashMap<Class<?>, Class<?>>> defaultImplementors() {
    final HashMap<Class<?>, HashMap<Class<?>, Class<?>>> map = new HashMap<>();
    final HashMap<Class<?>, Class<?>> m2 = new HashMap<>();
    m2.put(Readable.class, StringReader.class);
    map.put(String.class, m2);
    return map;
  }

}
