/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.lang;

/**
 * A class representing a lambda function with one argument.
 * 
 * @param <T> The return type of the function
 * @param <U> The type of the first parameter to the function
 * @param <V> The type of the second parameter to the function
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface LambdaN<T, U, V> {

  /**
   * The function that should be executed. These lambda functions should not
   * have sideeffects.
   * 
   * @param pArg The parameter.
   * @return The return value.
   */
  T lambda(U arg1, V arg2, Object... pArgs);
}
