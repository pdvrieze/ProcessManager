/*
 * Created on Dec 19, 2004
 *
 */
package net.devrieze.lang;

import java.util.Iterator;

import net.devrieze.annotations.NotNull;
import net.devrieze.collections.Sequence;
import net.devrieze.util.Annotations;


/**
 * An iterator over all the parent classes for a given class. It is an iterator,
 * but in itself it is also iterable.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ParentIterator implements Sequence<Class<?>> {

  @NotNull
  private final Class<?>[] aParents;

  private int aPos = 0;

  private ParentIterator(@NotNull final Class<?>[] pParents, int pPos) {
    aParents = pParents;
    aPos = pPos;
  }

  /**
   * Create a new iterator that iterates over all the parent classes for the
   * given class.
   *
   * @param pClass The class over which parents (and interfaces) should be
   *          iterated.
   */
  public ParentIterator(@NotNull final Class<?> pClass) {
    final Class<?>[] interfaces = pClass.getInterfaces();
    if (pClass.getSuperclass() == null) {
      aParents = new Class<?>[interfaces.length];
      for (int i = 0; i < interfaces.length; i++) {
        aParents[i] = interfaces[i];
      }
    } else {
      aParents = new Class<?>[interfaces.length + 1];
      aParents[0] = pClass.getSuperclass();
      for (int i = 0; i < interfaces.length; i++) {
        aParents[i + 1] = interfaces[i];
      }
    }
  }

  /**
   * Create this iterator, but with a reset position. Allows the use in
   * simplified for loops.
   *
   * @return A new iterator with a reset position.
   */
  @Override
  @NotNull
  public Iterator<Class<?>> iterator() {
    return new ParentIterator(aParents, 0);
  }

  /**
   * Check wheter a next item exists.
   *
   * @see Iterator#hasNext()
   */
  @Override
  public boolean hasNext() {
    return aPos < aParents.length;
  }

  /**
   * @return The next parent or interface.
   * @see Iterator#next()
   */
  @Override
  @NotNull
  public Class<?> next() {
    final Class<?> result = aParents[aPos];
    aPos++;
    return Annotations.notNull(result);
  }

  /**
   * Not supported, it doesn't make sense as class objects are readonly.
   *
   * @see Iterator#remove()
   */
  @Override
  public void remove() {
    throw new UnsupportedOperationException("ClassesDon't Change");
  }

  /**
   * ParentIterators are guaranteed to be finite.
   *
   * @return <code>true</code>
   * @see net.devrieze.collections.Sequence#isFinite()
   */
  @Override
  public boolean isFinite() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  @NotNull
  public ParentIterator clone() {
    return new ParentIterator(aParents, aPos);
  }

  /** {@inheritDoc} */
  @Override
  @NotNull
  public ParentIterator reset() {
    aPos = 0;
    return this;
  }
}
