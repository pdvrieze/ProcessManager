/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import java.util.Iterator;
import java.util.NoSuchElementException;

import net.devrieze.annotations.NotNull;
import net.devrieze.annotations.Nullable;
import net.devrieze.util.Annotations;


/**
 * An iterator representing a range of integers.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class IntRange extends AbstractRange<Integer> {

  private final int aStart;

  private final int aStep;

  private final int aEnd;

  private int aCurrent;

  /**
   * Create a new integer range. The stepping is <code>1</code>
   *
   * @param pStart The starting digit
   * @param pEnd The pEnd of the sequence
   */
  public IntRange(final int pStart, final int pEnd) {
    this(pStart, 1, pEnd);
  }

  /**
   * Create a new integer range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   */
  public IntRange(final int pStart, final int pStep, final int pEnd) {
    this(pStart, pStep, pEnd, true);
  }

  /**
   * Create a new int range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   * @param pFinite If this value is <code>false</code>, then the sequence is
   *          infinite and pEnd will not be used
   */
  public IntRange(final int pStart, final int pStep, final int pEnd, final boolean pFinite) {
    super(pFinite);
    aStart = pStart;
    aCurrent = pStart;
    aStep = pStep;
    aEnd = pEnd;
  }

  public IntRange(@NotNull IntRange pOther) {
    super(pOther.isFinite());
    aStart = pOther.aStart;
    aCurrent = pOther.aCurrent;
    aStep = pOther.aStep;
    aEnd = pOther.aEnd;
  }

  /**
   * Reset the position of the object to the start position.
   *
   * @return this object.
   * @see net.devrieze.collections.ResetableIterator#reset()
   */
  @Override
  @NotNull
  public IntRange reset() {
    aCurrent = aStart;
    return this;
  }

  /**
   * Check whether the end of the range has been reached.
   *
   * @return the position in the range.
   * @see Iterator#hasNext()
   */
  @Override
  public boolean hasNext() {
    return (!isFinite()) || (aCurrent > aEnd);
  }

  /**
   * Get the next element in the sequence.
   *
   * @return The next element in the range.
   * @see Iterator#next()
   */
  @Override
  @Nullable
  public Integer next() {
    if (isFinite() && (aCurrent > aEnd)) {
      throw new NoSuchElementException("Last element in the range (" + aStart + ", " + aStep + ", " + aEnd + ") allready reached");
    }

    final int result = aCurrent;
    aCurrent++;
    return Annotations.notNull(Integer.valueOf(result));
  }

  /**
   * Create a new iterator for this range. Starting at the initial position. The
   * difference with reset is that this operator creates a clone.
   *
   * @return A new Range with a resetted position.
   * @see Iterable#iterator()
   */
  @Override
  public IntRange iterator() {
    return clone().reset();
  }

  /**
   * Create a copy of this range. With the same position.
   *
   * @return A copy of this range.
   * @see Object#clone()
   */
  @Override
  public IntRange clone() {
    return new IntRange(this);
  }
}
