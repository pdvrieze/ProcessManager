/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import java.util.Iterator;

import net.devrieze.annotations.NotNull;


/**
 * An iterator interface that allows the iterator to be reset to it's starting
 * position.
 *
 * @param <T> The type that is iterated over
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface ResetableIterator<T> extends Iterator<T> {

  /**
   * Reset the iterator to the initial position.
   *
   * @return A pointer to itself. For easy chaining.
   */
  @NotNull
  ResetableIterator<T> reset();
}
