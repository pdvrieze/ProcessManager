/**
 * This package contains classes in my improved collection framework.
 * @see java.util
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.collections;

