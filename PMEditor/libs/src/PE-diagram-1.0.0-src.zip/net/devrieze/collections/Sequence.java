/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import net.devrieze.annotations.NotNull;


/**
 * Represents in the most abstract way a sequence of things.
 *
 * @param <T> The type of the element in the sequence.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */

public interface Sequence<T> extends Iterable<T>, ResetableIterator<T>, Cloneable {

  /**
   * Is the sequence infinite or does it have an end.
   *
   * @return <code>true</code> if it has an end, <code>false</code> if not.
   */
  boolean isFinite();

  /**
   * Sequences must implement the clone interface.
   *
   * @return A copy of this sequence.
   */
  @NotNull
  Sequence<T> clone();
}
