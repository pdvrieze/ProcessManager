/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import net.devrieze.annotations.NotNull;
import net.devrieze.annotations.Nullable;
import net.devrieze.lang.Lambda1;


/**
 * The {@link Sequences} class is a utility class for functions on sequence
 * objects. It is not instanciatable. Creating instances also does not make
 * sense.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class Sequences {

  /**
   * The ApplySequence object implements the result of the apply method.
   *
   * @author Paul de Vrieze
   */
  private static class ApplySequence<T, U> implements Sequence<T> {

    @NotNull
    private final Lambda1<T, U> aFunc;

    @NotNull
    private final Sequence<? extends U> aSequence;

    /**
     * Create a new ApplySequence object.
     *
     * @param pFunc
     * @param pSequence
     */
    public ApplySequence(@NotNull final Lambda1<T, U> pFunc, @NotNull final Sequence<? extends U> pSequence) {
      aFunc = pFunc;
      aSequence = pSequence;
    }

    /** {@inheritDoc} */
    @Override
    public boolean isFinite() {
      return aSequence.isFinite();
    }

    /** {@inheritDoc} */
    @Override
    @NotNull
    public Sequence<T> iterator() {
      return clone().reset();
    }

    /** {@inheritDoc} */
    @Override
    @NotNull
    public ApplySequence<T, U> clone() {
      return new ApplySequence<>(aFunc, aSequence.clone());
    }

    /** {@inheritDoc} */
    @Override
    @NotNull
    public ApplySequence<T, U> reset() {
      aSequence.reset();
      return this;
    }

    /** {@inheritDoc} */
    @Override
    public boolean hasNext() {
      return aSequence.hasNext();
    }

    /** {@inheritDoc} */
    @Override
    @Nullable
    public T next() {
      return aFunc.lambda(aSequence.next());
    }

    /** Do nothing as sequences are immutable. */
    @Override
    public void remove() {
      throw new UnsupportedOperationException("Sequences are immutable");
    }

  }

  /**
   * The <code>Sequences</code> class is a utility class, that for now does not
   * need any initializing. It's functions are static.
   */
  private Sequences() {
    // Just do nothing
  }

  /**
   * Apply a function to a sequence and return a resulting sequence. As the
   * sequence is evaluated lazilly, the function may not have sideeffects.
   *
   * @param <T> The type of the parameter to the function.
   * @param <U> The type of the elements of the resulting sequence.
   * @param pFunc The function to apply to the elements of the sequence.
   * @param pSequence The sequence to apply the function to.
   * @return The resulting sequence.
   */
  @NotNull
  public static <T, U> Sequence<U> apply(@NotNull final Lambda1<U, T> pFunc, @NotNull final Sequence<? extends T> pSequence) {
    return new ApplySequence<>(pFunc, pSequence);
  }
}
