/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import java.util.NoSuchElementException;

import net.devrieze.annotations.NotNull;
import net.devrieze.util.Annotations;


/**
 * An iterator representing a range of doubles.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class DoubleRange extends AbstractRange<Double> {

  private final double aStart;

  private final double aStep;

  private final double aEnd;

  private double aCurrent;

  /**
   * Create a new double range. The stepping is <code>1</code>
   *
   * @param pStart The starting digit
   * @param pEnd The pEnd of the sequence
   */
  public DoubleRange(final double pStart, final double pEnd) {
    this(pStart, 1, pEnd);
  }

  /**
   * Create a new double range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   */
  public DoubleRange(final double pStart, final double pStep, final double pEnd) {
    this(pStart, pStep, pEnd, true);
  }

  /**
   * Create a new double range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   * @param pFinite If this value is <code>false</code>, then the sequence is
   *          infinite and pEnd will not be used
   */
  public DoubleRange(final double pStart, final double pStep, final double pEnd, final boolean pFinite) {
    super(pFinite);
    aStart = pStart;
    aCurrent = pStart;
    aStep = pStep;
    aEnd = pEnd;
  }

  public DoubleRange(@NotNull DoubleRange pOther) {
    super(pOther.isFinite());
    aStart = pOther.aStart;
    aCurrent = pOther.aCurrent;
    aStep = pOther.aStep;
    aEnd = pOther.aEnd;
  }

  /**
   * Reset the position in the range to the initial position.
   *
   * @return The range itself.
   * @see net.devrieze.collections.ResetableIterator#reset()
   */
  @Override
  @NotNull
  public DoubleRange reset() {
    aCurrent = aStart;
    return this;
  }

  /**
   * Find whether there is still another digit in the range.
   *
   * @return <code>true</code> if so, <code>false</code> if not.
   * @see java.util.Iterator#hasNext()
   */
  @Override
  public boolean hasNext() {
    return (!isFinite()) || (aCurrent > aEnd);
  }

  /**
   * Get the next element in the range. Note that this changes the object.
   *
   * @return The next element in the range.
   * @see java.util.Iterator#next()
   */
  @Override
  @NotNull
  public Double next() {
    if (isFinite() && (aCurrent > aEnd)) {
      throw new NoSuchElementException("Last element in the range (" + aStart + ", " + aStep + ", " + aEnd + ") allready reached");
    }

    final Double result = Double.valueOf(aCurrent);
    aCurrent++;
    return Annotations.notNull(result);
  }

  @Override
  @NotNull
  public DoubleRange clone() {
    return new DoubleRange(this);
  }

  /**
   * Get a new {@link java.util.Iterator} for this range. This will create a
   * clone that is reset to the initial position.
   *
   * @return A new iterator for the range.
   * @see java.lang.Iterable#iterator()
   */
  @Override
  @NotNull
  public DoubleRange iterator() {
    return clone().reset();
  }

}
