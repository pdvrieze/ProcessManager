/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import java.util.Iterator;
import java.util.NoSuchElementException;

import net.devrieze.annotations.NotNull;
import net.devrieze.util.Annotations;


/**
 * An iterator representing a range of longs.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class LongRange extends AbstractRange<Long> {

  private final long aStart;

  private final long aStep;

  private final long aEnd;

  private long aCurrent;

  /**
   * Create a new double range. The stepping is <code>1</code>
   *
   * @param pStart The starting digit
   * @param pEnd The pEnd of the sequence
   */
  public LongRange(final long pStart, final long pEnd) {
    this(pStart, 1, pEnd);
  }

  /**
   * Create a new long range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   */
  public LongRange(final long pStart, final long pStep, final long pEnd) {
    this(pStart, pStep, pEnd, true);
  }

  /**
   * Create a new long range.
   *
   * @param pStart The starting digit.
   * @param pStep the stepping between the ranges.
   * @param pEnd The pEnd of the sequence.
   * @param pFinite If this value is <code>false</code>, then the sequence is
   *          infinite and pEnd will not be used
   */
  public LongRange(final long pStart, final long pStep, final long pEnd, final boolean pFinite) {
    super(pFinite);
    aStart = pStart;
    aCurrent = pStart;
    aStep = pStep;
    aEnd = pEnd;
  }

  public LongRange(@NotNull LongRange pOther) {
    super(pOther.isFinite());
    aStart = pOther.aStart;
    aCurrent = pOther.aCurrent;
    aStep = pOther.aStep;
    aEnd = pOther.aEnd;
  }

  /**
   * Reset the position of the object to the start position.
   *
   * @return this object.
   * @see net.devrieze.collections.ResetableIterator#reset()
   */
  @Override
  @NotNull
  public LongRange reset() {
    aCurrent = aStart;
    return this;
  }

  /**
   * Check whether the end of the range has been reached.
   *
   * @return the position in the range.
   * @see Iterator#hasNext()
   */
  @Override
  public boolean hasNext() {
    return (!isFinite()) || (aCurrent > aEnd);
  }

  /**
   * Get the next element in the sequence.
   *
   * @return The next element in the range.
   * @see Iterator#next()
   */
  @Override
  @NotNull
  public Long next() {
    if (isFinite() && (aCurrent > aEnd)) {
      throw new NoSuchElementException("Last element in the range (" + aStart + ", " + aStep + ", " + aEnd + ") allready reached");
    }

    final long result = aCurrent;
    aCurrent++;
    return Annotations.notNull(Long.valueOf(result));
  }

  @Override
  @NotNull
  public LongRange clone() {
    return new LongRange(this);
  }

  /**
   * Create a new iterator for this range. Starting at the initial position. The
   * difference with reset is that this operator creates a clone.
   *
   * @return A new Range with a resetted position.
   * @see Iterable#iterator()
   */
  @Override
  @NotNull
  public LongRange iterator() {
    return clone().reset();
  }


}
