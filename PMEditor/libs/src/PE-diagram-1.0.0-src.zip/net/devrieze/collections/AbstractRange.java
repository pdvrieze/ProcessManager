/*
 * Created on Apr 10, 2005
 *
 */
package net.devrieze.collections;

import static net.devrieze.util.Annotations.notNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.Objects;

import net.devrieze.annotations.NotNull;


/**
 * An abstract baseclass for range types.
 *
 * @param <E> The element types for the range
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractRange<E> implements Sequence<E> {

  private final boolean aFinite;

  /**
   * Create a new range.
   *
   * @param pFinite <code>true</code> if the range is finite, <code>false</code>
   *          if not.
   */
  protected AbstractRange(final boolean pFinite) {
    aFinite = pFinite;
  }

  /**
   * Clone the range.
   *
   * @return A copy of the range.
   */
  @Override
  @SuppressWarnings({ "unchecked" })
  @NotNull
  public AbstractRange<E> clone() {
    try {
      @SuppressWarnings("rawtypes")
      Constructor<? extends AbstractRange> c = this.getClass().getConstructor(this.getClass());
      if (c!=null) {
        return notNull(c.newInstance(this));
      } else
        return (AbstractRange<E>) Objects.requireNonNull(super.clone());
    } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | CloneNotSupportedException ex) {
      throw new RuntimeException(ex);
    }
  }

  /**
   * Specifies whether the range is finite.
   *
   * @see net.devrieze.collections.Sequence#isFinite()
   */
  @Override
  public boolean isFinite() {
    return aFinite;
  }


  /**
   * The remove operation is not supported for Ranges.
   *
   * @see Iterator#remove()
   */
  @Override
  public final void remove() {
    throw new UnsupportedOperationException("Ranges are immutable");
  }

}
