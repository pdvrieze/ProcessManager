package net.devrieze.meta.tokens;

import meta.lang.Literal;
import meta.lang.TypeRef;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class PackageDecl extends AbstractExpression {

  private final String aPackage;

  public PackageDecl(final LinePosition pPosition, final String pPackage) {
    super(pPosition);
    aPackage = pPackage;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    pScope.setPackage(aPackage);
    return null;
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return null;
  }

  @Override
  public MLang getTokenType() {
    return MLang.PACKAGEDECL;
  }

  public String getPackage() {
    return aPackage;
  }

  @Override
  public Literal<?> eval(final Scope pScope) throws CompilationException {
    return Literal.createObj(getPos(), getEvalType(pScope), this);
  }

}
