package net.devrieze.meta.tokens;

import meta.lang.Expression;
import meta.lang.Primitive;
import meta.lang.ReferenceType;
import meta.lang.TypeRef;

import net.devrieze.meta.AbstractExpression;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;


public class InstanceofToken extends AbstractExpression {

  private final Expression aExpression;

  private final Expression aType;

  public InstanceofToken(final LinePosition pPos, final Expression pExpression, final Expression pType) {
    super(pPos);
    aExpression = pExpression;
    aType = pType;
  }

  @Override
  public TypeRef<?> compile(final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final TypeRef<? extends ReferenceType> origType = aExpression.compile(pScope, false).asReferenceType();
    final TypeRef<? extends ReferenceType> newType = MEvaluator.toTypeRef(aType, pScope).asReferenceType();
    if (newType.isAssignableFrom(origType)) {
      pScope.getContext().warning(this, "Unneeded instanceof from " + origType + " to " + newType);
      return origType;
    }
    if (!(newType.isInterface() || origType.isAssignableFrom(newType))) {
      pScope.getContext().error(this, "incompatible types for instanceof " + origType + " and " + newType);
    }
    return pScope.getCompiler().compileInstanceof(this, newType, pScope, pCleanupStack);
  }

  @Override
  public TypeRef<?> getEvalType(final Scope pScope) throws CompilationException {
    return Primitive.MBoolean.getRef();
  }

  @Override
  public MLang getTokenType() {
    return MLang.INSTANCEOF;
  }

}
