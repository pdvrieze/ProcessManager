package net.devrieze.meta.tokens;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

import meta.lang.*;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.MFlags;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.tokens.AbstractLinedToken;


public class AnnotateToken extends AbstractLinedToken<MLang> {

  private final String aName;

  private Expression[] aParams;

  public AnnotateToken(final LinePosition pPos, final CharSequence pName, final MTupple pParams) {
    super(MLang.ANNOTATE, pPos);
    aParams = pParams == null ? new Expression[0] : pParams.toArray(); // TODO Perhaps validate the parameters 
    aName = pName.toString();
  }

  private static VarAssign[] toVarAssigns(final Expression[] pParams, final Scope pScope) throws CompilationException {
    if ((pParams != null) && (pParams.length == 1)) {
      final Expression elem = pParams[0];
      if (!(elem instanceof VarAssign)) {
        return new VarAssign[] { new VarAssign(null, null, new Symbol(null, "value"), TypeRef.ANY, elem) };
      } else {
        return new VarAssign[] { (VarAssign) elem };
      }
    }
    return MEvaluator.toVarAssigns(pParams, pScope);
  }

  public AnnotateToken(final LinePosition pPos, final CharSequence pName, final VarAssign... pParams) {
    super(MLang.ANNOTATE, pPos);
    aParams = pParams.clone(); // TODO Perhaps validate the parameters 
    aName = pName.toString();
  }

  public String getName() {
    return aName;
  }

  public VarAssign[] getParams(final Scope pScope) throws CompilationException {
    if (aParams instanceof VarAssign[]) {
      return (VarAssign[]) aParams;
    }
    final VarAssign[] params = toVarAssigns(aParams, pScope);
    aParams = params;
    return params;
  }

  public static <T extends Enum<T> & MFlags> List<AnnotateToken> fromFlags(final EnumSet<T> pFlags) {
    final ArrayList<AnnotateToken> result = new ArrayList<>(pFlags.size());
    for (final T flag : pFlags) {
      result.add(new AnnotateToken(null, flag.getRepr(), new MTupple(null)));
    }
    return result;
  }

  @SafeVarargs
  public static <T extends Enum<T> & MFlags> List<AnnotateToken> fromFlags(final T... pFlags) {
    final ArrayList<AnnotateToken> result = new ArrayList<>(pFlags.length);
    for (final T flag : pFlags) {
      result.add(new AnnotateToken(null, flag.getRepr(), new MTupple(null)));
    }
    return result;
  }

  public static <T extends Enum<T> & MFlags> AnnotateToken fromFlag(final T pFlag) {
    return new AnnotateToken(null, pFlag.getRepr(), new MTupple(null));
  }

  @Override
  public String toString() {
    // TODO do not add types to the output
    if ((aParams == null) || (aParams.length == 0)) {
      return '@' + aName;
    } else {
      return '@' + aName + aParams.toString();
    }
  }

  public String toMetaCode() {
    // TODO do not add types to the output
    if ((aParams == null) || (aParams.length == 0)) {
      return '@' + aName;
    } else {
      return '@' + aName + toMetaCode(aParams, 0);
    }
  }

  private static CharSequence toMetaCode(final Expression[] pParams, final int pIndent) {
    if (pParams.length == 1) {
      if (pParams[0] instanceof VarAssign) {
        final VarAssign va = (VarAssign) pParams[0];
        if (MEvaluator.toSymbol(va.getLValue()).getName().equals("value")) {
          return pParams[0].toMetaCode(pIndent + 4);
        }
      }
    }
    final StringBuilder result = new StringBuilder();
    result.append('(');
    for (final Expression a : pParams) {
      result.append(a.toMetaCode(pIndent + 4));
    }
    result.append(')');
    return result;
  }

  @Override
  public boolean equals(final Object pObj) {
    if ((getClass() != AnnotateToken.class) || (pObj == null) || (pObj.getClass() != AnnotateToken.class)) {
      return false;
    }
    if (this == pObj) {
      return true;
    }
    final AnnotateToken other = (AnnotateToken) pObj;
    if (!aName.equals(other.aName)) {
      return false;
    }
    if (((aParams == null) || (aParams.length == 0)) && ((other.aParams == null) || (other.aParams.length == 0))) {
      return true;
    }
    return (aParams != null) && aParams.equals(other.aParams);
  }

  @Override
  public int hashCode() {
    int result = aName.hashCode() + 23147;
    if ((aParams == null) || (aParams.length == 0)) {
      result += 78503;
    } else {
      result = (result * 31) + aParams.hashCode();
    }
    return result;
  }

  public boolean isAnnotation(final Class<compiletime> pClass) {
    return (pClass.getName().equals(aName));
  }

  public static Collection<? extends AnnotateToken> fromAnnotations(final Annotation[] pAnnotations) {
    final AnnotateToken[] result = new AnnotateToken[pAnnotations.length];
    for (int i = 0; i < result.length; ++i) {
      result[i] = fromAnnotation(pAnnotations[i]);
    }
    return Arrays.asList(result);
  }

  private static AnnotateToken fromAnnotation(final Annotation pAnnotation) {
    try {
      final Class<? extends Annotation> type = pAnnotation.annotationType();
      final List<Expression> params = new ArrayList<>();
      for (final Method m : type.getDeclaredMethods()) {
        if (m.getParameterTypes().length > 0) {
          throw new UnsupportedOperationException("Annotation methods with arguments not supported");
        }
        final String name = m.getName();
        Object value = m.invoke(pAnnotation);
        if (value.getClass().isArray()) {
          value = new MTupple(null, Literal.createListByInference(null, ((Object[]) value)));
        } else {
          value = Literal.createByInference(null, value);
        }
        final VarAssign a = new VarAssign(null, null, new Symbol(null, name), TypeRef.ANY, (Expression) value);
        params.add(a);
      }
      return new AnnotateToken(null, type.getName(), params.toArray(new VarAssign[0]));

    } catch (final IllegalArgumentException ex) {
      throw new RuntimeException(ex);
    } catch (final IllegalAccessException ex) {
      throw new RuntimeException(ex);
    } catch (final InvocationTargetException ex) {
      throw new RuntimeException(ex);
    }
  }

  public Expression getParam(final String pString, final Scope pScope) throws CompilationException {
    for (final Expression ex : aParams) {
      final VarAssign va = MEvaluator.toVarAssign(ex, pScope);

      if ((va != null) && MEvaluator.toSymbol(va.getLValue()).getName().equals(pString)) {
        return va.getRValue();
      }
    }
    return null;
  }

}
