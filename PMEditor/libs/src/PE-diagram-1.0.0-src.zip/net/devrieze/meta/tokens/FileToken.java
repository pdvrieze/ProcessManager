package net.devrieze.meta.tokens;

import meta.lang.Expression;
import meta.lang.MTupple;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.tokens.AbstractLinedToken;
import net.devrieze.util.StringUtil;


public class FileToken extends AbstractLinedToken<MLang> {

  private final MTupple aBody;

  public FileToken(final LinePosition pPos, final MTupple pBody) {
    super(MLang.FILE, pPos);
    aBody = pBody;
  }

  public MTupple getBody() {
    return aBody;
  }

  public CharSequence toMetaCode(final int pIndent) {
    final StringBuilder result = new StringBuilder();
    result.append("meta(0.1)(\n");
    StringUtil.addChars(result, pIndent + 2, ' ');
    boolean first = true;
    for (final Expression elem : aBody) {
      if (!first) {
        StringUtil.addChars(result.append(",\n"), pIndent + 2, ' ');
      }
      first = false;
      result.append(elem.toMetaCode(pIndent + 2));
    }
    StringUtil.addChars(result.append('\n'), pIndent, ' ').append(')');
    return result;
  }

}
