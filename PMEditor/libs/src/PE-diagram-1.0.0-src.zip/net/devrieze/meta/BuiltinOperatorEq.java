package net.devrieze.meta;

import meta.lang.*;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.parser.LinePosition;


public class BuiltinOperatorEq extends FunctionRef {

  private final boolean aEquals;

  public BuiltinOperatorEq(final LinePosition pPosition, final boolean pEquals) {
    super(pPosition, "operator==", new FunctionType(null, FunctionType._PUBLIC, TypeRef.create(null, Object.class), Primitive.MBoolean.getRef(), TypeRef.create(null, Object.class)));
    aEquals = pEquals;
  }

  @Override
  public TypeRef<?> compileCall(final Expression pTarget, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression[] pArgs) throws CompilationException {
    if (pArgs.length != 1) {
      pScope.getContext().error(this, "Invalid argument count");
    }
    pTarget.compile(pScope, false);
    pArgs[0].compile(pScope, false);
    if (aEquals) {
      pScope.getCompiler().compileObjEquals(this, pScope);
    } else {
      pScope.getCompiler().compileObjNEquals(this, pScope);
    }
    return Primitive.MBoolean.getRef();
  }

  @Override
  public Literal<?> evalCall(final Scope pScope, final Expression pTarget, final Expression... pArgs) throws CompilationException {
    if (pArgs.length != 1) {
      pScope.getContext().error(this, "Invalid argument count");
    }
    final Literal<?> left = pScope.expectLiteral(pTarget.eval(pScope));
    final Literal<?> right = pScope.expectLiteral(pArgs[0].eval(pScope));
    return Literal.createBool(null, (left.getObjValue() == right.getObjValue()) && left.getValueType().equals(right));
  }

}
