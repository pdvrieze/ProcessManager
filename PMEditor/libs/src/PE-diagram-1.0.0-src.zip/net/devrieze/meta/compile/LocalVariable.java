package net.devrieze.meta.compile;

import meta.lang.Symbol;
import meta.lang.TypeRef;

import net.devrieze.meta.NamedObject;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class LocalVariable implements NamedObject/*
                                                  * extends AbstractExpression
                                                  * implements Expression
                                                  */{

  private final TypeRef<?> aVarType;

  private final Symbol aName;

  private final int aPos;

  public LocalVariable(final Symbol pName, final int pPos, final TypeRef<?> pType) {
    aName = pName;
    aPos = pPos;
    aVarType = pType;
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileGetLocalVariable(this, pScope, pToken, pCleanupStack);
  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    return pScope.getCompiler().compileSetLocalVariable(this, pScope, pToken, pCleanupStack);
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pScope) {
    return getVarType();
  }

  @Override
  public String toString() {
    return "LocalVariable(" + getPos() + ", " + getVarType().toString() + ')';
  }

  public TypeRef<?> getVarType() {
    return aVarType;
  }

  public int getPos() {
    return aPos;
  }

  public String getName() {
    return aName.getName();
  }

  public Symbol getSymbol() {
    return aName;
  }
}
