package net.devrieze.meta.compile;


import org.objectweb.asm.ClassWriter;

import meta.lang.*;

import net.devrieze.meta.eval.EvalContext;
import net.devrieze.parser.Token;


/**
 * Class for containing the compilation context.
 * 
 * @author Paul de Vrieze
 */
public class CompilationContext extends EvalContext {


  public static interface ContextListener {

    void handleException(Throwable pE, byte[] pClassBytes);

    void saveClass(String pName, byte[] pByteCode);

  }

  private MyClassWriter aClassWriter = null;

  private MyMethodVisitor aMethodVisitor;

  private ContextListener aContextListener;

  private final CompilerClassLoader aClassLoader;

  private final JavaCompiler aCompiler;

  public CompilationContext() {
    aClassLoader = new CompilerClassLoader(getClass().getClassLoader()) {

      @Override
      protected void saveClass(final String pName, final byte[] pByteCode) {
        CompilationContext.this.saveClass(pName, pByteCode);
      }

    };
    aCompiler = new JavaCompiler();
  }

  private void saveClass(final String pName, final byte[] pByteCode) {
    if (aContextListener != null) {
      aContextListener.saveClass(pName, pByteCode);
    }
  }

  private CompilationContext(final CompilerClassLoader pClassLoader, final ContextListener pExceptionListener) {
    aClassLoader = pClassLoader;
    aContextListener = pExceptionListener;
    aCompiler = new JavaCompiler();
  }

  public MyClassWriter getClassWriter() {
    if (aClassWriter == null) {
      setClassWriter(new MyClassWriter(new ClassWriter(ClassWriter.COMPUTE_FRAMES)));
    }
    return aClassWriter;
  }

  public void setClassWriter(final MyClassWriter pClassWriter) {
    aClassWriter = pClassWriter;
    aMethodVisitor = null;
  }

  public JavaCompiler getCompiler() {
    return aCompiler;
  }

  MyMethodVisitor getMethodVisitor() {
    return aMethodVisitor;
  }


  public void setMethodVisitor(final MyMethodVisitor pMethodVisitor) {
    aMethodVisitor = pMethodVisitor;
  }

  public CompilationContext split() {
    return new CompilationContext(aClassLoader, aContextListener);
  }

  public CompilerClassLoader getClassLoader() {
    return aClassLoader;
  }

  public void handleException(final Throwable pE, final byte[] pClassBytes) {
    if (aContextListener != null) {
      aContextListener.handleException(pE, pClassBytes);
    }
  }


  public ContextListener getExceptionListener() {
    return aContextListener;
  }


  public void setExceptionListener(final ContextListener pExceptionListener) {
    aContextListener = pExceptionListener;
  }

  @Override
  public void setCurrentClass(final MClass pClass) {
    if ((getCurrentClass() != null) && (getCurrentClass() != pClass)) {
      aClassWriter = null;
    }
    super.setCurrentClass(pClass);
  }

  public TypeRef<?> compileCallGlobal(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (pFunction.isStatic()) {
      final TypeRef<? extends ReferenceType> owner = pFunction.getOwner().asReferenceType();
      if (owner != null) {
        final ReferenceType o2 = owner.getReferredType();
        return pScope.getCompiler().compileCall(o2, pFunction, pScope, pCleanupStack);
      }
    }
    error(pFunction, "Function is not a global function");
    return null;
  }

  public void warning(final Token<?> pToken, final String pString) {
    System.err.println("Warning: " + pString);
    if (pToken != null) {
      System.err.println(pToken.toString());
    }
  }

  public void error(final Token<?> pToken, final CompilationErrors pError) throws CompilationException {
    throw stripLastStackTraceElem(new CompilationError(pToken, pError.getMessage()));
  }

  public void error(final Token<?> pToken, final String pMessage) throws CompilationException {
    throw stripLastStackTraceElem(new CompilationError(pToken, pMessage));
  }

  public void fatalError(final Token<?> pToken, final String pMessage) throws CompilationException {
    throw stripLastStackTraceElem(new FatalCompilationError(pToken, pMessage));
  }

  // TODO make static and refactor into TypeRef or other callers
  public Literal<?> evalGlobal(final FunctionRef pFunctionRef, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    if (pFunctionRef.isStatic() || pFunctionRef.isConstructor()) {
      final TypeRef<? extends ReferenceType> owner = pFunctionRef.getOwner().asReferenceType();
      if (owner != null) {
        return pFunctionRef.evalCall(pScope, owner, pArgs);
      }
    }
    error(pFunctionRef, "The function could not be resolved");
    return null;
  }

}
