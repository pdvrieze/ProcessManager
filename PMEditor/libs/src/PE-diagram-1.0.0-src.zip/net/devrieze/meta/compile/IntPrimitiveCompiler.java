package net.devrieze.meta.compile;

import org.objectweb.asm.Label;

import meta.lang.*;
import meta.lang.Literal.BoolLiteral;
import meta.lang.Literal.ByteLiteral;
import meta.lang.Literal.CharLiteral;
import meta.lang.Literal.IntLiteral;
import meta.lang.Literal.ShortLiteral;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;


public class IntPrimitiveCompiler {

  private final JavaCompiler aJavaCompiler;

  public IntPrimitiveCompiler(final JavaCompiler pJavaCompiler) {
    aJavaCompiler = pJavaCompiler;
  }

  public TypeRef<?> compileIntLiteral(final IntLiteral pIntLiteral, final Scope pScope, final boolean pCleanupStack) {
    final int value = pIntLiteral.getValue();
    return compileIntHelper(pIntLiteral, pScope, value, pCleanupStack);
  }

  public TypeRef<?> compileBoolLiteral(final BoolLiteral pBoolLiteral, final Scope pScope, final boolean pCleanupStack) {
    return compileIntHelper(pBoolLiteral, pScope, pBoolLiteral.getValue() ? 1 : 0, pCleanupStack);
  }

  public TypeRef<?> compileByteLiteral(final ByteLiteral pByteLiteral, final Scope pScope, final boolean pCleanupStack) {
    return compileIntHelper(pByteLiteral, pScope, pByteLiteral.getValue(), pCleanupStack);
  }

  public TypeRef<?> compileCharLiteral(final CharLiteral pCharLiteral, final Scope pScope, final boolean pCleanupStack) {
    return compileIntHelper(pCharLiteral, pScope, pCharLiteral.getValue(), pCleanupStack);
  }

  public TypeRef<?> compileShortLiteral(final ShortLiteral pShortLiteral, final Scope pScope, final boolean pCleanupStack) {
    return compileIntHelper(pShortLiteral, pScope, pShortLiteral.getValue(), pCleanupStack);
  }

  private TypeRef<?> compileIntHelper(final Literal<?> pLiteral, final Scope pScope, final int value, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pLiteral);
    mv.visitLdc(value);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pLiteral, "Discarding the value of a literal makes no sense");
    }
    return pLiteral.getValueType();
  }

  public void compileBuiltinAddInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIAdd();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinDivInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIDiv();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMinusInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitISub();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinModInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIRem();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMultInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIMul();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLogicAnd(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIAnd();

    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLogicOr(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIOr();

    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  /**
   * Compile a comparison for use within conditional jumps.
   * 
   * @param pOperator
   * @param pTrueTarget
   * @param pFalseTarget
   * @param pScope
   */
  public void compileBuiltinCompareJump(final LinedToken<MLang> pToken, final BinaryOperatorTokens pOperator, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    switch (pOperator) {
      case EQUALS:
        compileBuiltinEqualsJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      case UNEQUALS:
        compileBuiltinUnequalsJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      case GREATER:
        compileBuiltinGreaterJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      case GREATEREQ:
        compileBuiltinGreaterEqJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      case LESS:
        compileBuiltinLessJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      case LESSEQ:
        compileBuiltinLessEqJump(pToken, pTrueTarget, pFalseTarget, pScope);
        return;
      default:
        throw new IllegalArgumentException("Compare jump optimization only possible for comparison operators");
    }
  }

  public void compileBuiltinEqualsJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpNe(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpEq(pTrueTarget);
    }
  }

  public void compileBuiltinEqualsInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinEqualsJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinGreaterJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpLe(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpGt(pTrueTarget);
    }
  }

  public void compileBuiltinGreaterInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinGreaterJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinGreaterEqJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpLt(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpGe(pTrueTarget);
    }
  }

  public void compileBuiltinGreaterEqInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinGreaterEqJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinUnequalsJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpEq(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpNe(pTrueTarget);
    }
  }

  public void compileBuiltinUnequalsInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinUnequalsJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinLessJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpGe(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpLt(pTrueTarget);
    }
  }

  public void compileBuiltinLessInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinLessJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinLessEqJump(final LinedToken<MLang> pToken, final Label pTrueTarget, final Label pFalseTarget, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (pFalseTarget != null) {
      mv.visitIfIcmpGt(pFalseTarget);
      if (pTrueTarget != null) {
        mv.visitGoto(pTrueTarget);
      }
    } else {
      mv.visitIfIcmpLe(pTrueTarget);
    }
  }

  public void compileBuiltinLessEqInt(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pCleanupStack) {
      aJavaCompiler.debugLine(mv, pToken);
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
      return;
    }
    final Label elseLabel = new Label();

    compileBuiltinLessEqJump(pToken, null, elseLabel, pScope);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
  }

  public void compileBuiltinNot(final UnaryPrimitiveOperator pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    // Hack that should be better than if statements
    switch (pToken.getPrimitive()) {
      case MBoolean:
        mv.visitLdc(1);
        break;
      case MByte:
        mv.visitLdc(0xff);
        break;
      case MShort:
      case MChar:
        mv.visitLdc(0xffff);
        break;
      case MInt:
        mv.visitLdc(0xffffffff);
        break;
      case MFloat:
      case MLong:
      case MDouble:
        throw new IllegalArgumentException("Expected an int primitive");
    }
    mv.visitIXor();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinPostAdd(final UnaryPrimitiveOperator pToken, final LocalVariable pLocalVariable, final int pIncrement, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    if (!pCleanupStack) {
      mv.visitILoad(pLocalVariable.getPos());
    }
    mv.visitIincInsn(pLocalVariable.getPos(), pIncrement);
  }

  public void compileBuiltinPreAdd(final UnaryPrimitiveOperator pToken, final LocalVariable pLocalVariable, final int pIncrement, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitIincInsn(pLocalVariable.getPos(), pIncrement);
    if (!pCleanupStack) {
      mv.visitILoad(pLocalVariable.getPos());
    }
  }

}
