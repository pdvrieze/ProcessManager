package net.devrieze.meta.compile;

import net.devrieze.parser.Token;
import net.devrieze.parser.languages.MLang;


public class FatalCompilationError extends CompilationException {

  private static final long serialVersionUID = 6253970830405004838L;

  public FatalCompilationError(final Token<MLang> pToken, final String pMessage, final Throwable pCause) {
    super(pToken, pCause, pMessage);
  }

  public FatalCompilationError(final Token<?> pToken, final String pMessage) {
    super(pToken, pMessage);
  }

  public FatalCompilationError(final Token<MLang> pToken, final Throwable pCause) {
    super(pToken, pCause);
  }

}
