package net.devrieze.meta.compile;

import meta.lang.ReferenceType;
import meta.lang.TypeRef;


public class MangledClassName {

  private final String aName;

  public MangledClassName(final TypeRef<?> pType) {
    //    aName = JavaCompiler.mangleCompleteName(pType.getInternalName());
    aName = pType.getInternalName();
  }

  public MangledClassName(final ReferenceType pType) {
    //    aName = JavaCompiler.mangleCompleteName(pType.getInternalName());
    aName = pType.getInternalName();
  }

  @Override
  public String toString() {
    return aName;
  }
}
