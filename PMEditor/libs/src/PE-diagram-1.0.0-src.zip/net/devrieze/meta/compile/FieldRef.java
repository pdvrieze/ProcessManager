package net.devrieze.meta.compile;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import meta.lang.*;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class FieldRef implements NamedObject {

  private final EnumSet<AttributeFlags> aFlags;

  private final TypeRef<?> aOwner;

  private final Symbol aName;

  private final TypeRef<?> aVarType;

  public FieldRef(final EnumSet<AttributeFlags> pFlags, final TypeRef<?> pOwner, final Symbol pName, final TypeRef<?> pVarType) {
    aFlags = pFlags;
    aOwner = pOwner;
    aName = pName;
    aVarType = pVarType;
  }

  public FieldRef(final TypeRef<?> pOwner, final VarAssign pAttribute, final Scope pScope) throws CompilationException {
    final List<AnnotateToken> pFlags = pAttribute.getFlags();
    final TypeRef<?> varType = MEvaluator.toTypeRef(pAttribute.getValueType(), pScope);

    final List<AttributeFlags> flags2 = new ArrayList<>(pFlags.size());
    for (final AnnotateToken flag : pFlags) {
      final AttributeFlags newFlag = AttributeFlags.fromString(flag.getName());
      if (newFlag != null) {
        flags2.add(newFlag);
      }
    }

    EnumSet<AttributeFlags> flags;
    if (flags2.size() == 0) {
      flags = EnumSet.noneOf(AttributeFlags.class);
    } else {
      flags = EnumSet.copyOf(flags2);
    }

    aFlags = flags;
    aOwner = pOwner;
    aName = MEvaluator.toSymbol(pAttribute.getLValue());
    aVarType = varType;

  }

  @Override
  public TypeRef<?> compileAssign(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) throws CompilationException {
    if (aFlags.contains(AttributeFlags.FINAL) && (!pScope.inConstructor())) {
      pScope.getContext().error(pToken, CompilationErrors.ASSIGN_TO_CONST);
    }
    return pScope.getCompiler().compileSetField(this, pScope, pToken, pCleanupStack);
  }

  @Override
  public TypeRef<?> compileRef(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    return pScope.getCompiler().compileGetField(this, pScope, pToken, pCleanupStack);
  }

  public Literal<?> evalRef(final Object pInstance, final Scope pScope) throws CompilationException {
    return ((Type) aOwner.getReferredType()).evalFieldRef(pInstance, aName, pScope);
  }

  @Override
  public TypeRef<?> getReferredType(final Scope pEvalScope) {
    return getVarType();
  }

  public TypeRef<?> getVarType() {
    return aVarType;
  }

  public TypeRef<?> getOwner() {
    return aOwner;
  }

  public EnumSet<AttributeFlags> getFlags() {
    return aFlags;
  }

  public boolean isPublic() {
    return aFlags.contains(AttributeFlags.STATIC);
  }

  public boolean isStatic() {
    return aFlags.contains(AttributeFlags.STATIC);
  }

  public String getName() {
    return aName.getName();
  }

  public Symbol getSymbol() {
    return aName;
  }

}
