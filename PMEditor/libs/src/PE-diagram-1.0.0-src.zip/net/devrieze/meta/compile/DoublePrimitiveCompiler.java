package net.devrieze.meta.compile;

import org.objectweb.asm.Label;

import meta.lang.Literal.DoubleLiteral;
import meta.lang.TypeRef;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class DoublePrimitiveCompiler {

  private final JavaCompiler aJavaCompiler;

  public DoublePrimitiveCompiler(final JavaCompiler pJavaCompiler) {
    aJavaCompiler = pJavaCompiler;
  }

  public TypeRef<?> compileDoubleLiteral(final DoubleLiteral pDoubleLiteral, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pDoubleLiteral);
    mv.visitLdc(pDoubleLiteral.getValue());
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pDoubleLiteral, "Discarding the value of a literal makes no sense");
    }
    return pDoubleLiteral.getValueType();
  }

  public void compileBuiltinAddDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDAdd();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinDivDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDDiv();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMinusDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDSub();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinModDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDRem();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMultDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDMul();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinEqualsDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDCmp();
    final Label elseLabel = new Label();
    mv.visitIfNe(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    final Label elseLabel = new Label();
    mv.visitDCmp();
    mv.visitIfGt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterEqDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDCmp();
    final Label elseLabel = new Label();
    mv.visitIfGe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinUnequalsDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDCmp();
    final Label elseLabel = new Label();
    mv.visitIfEq(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDCmp();
    final Label elseLabel = new Label();
    mv.visitIfLt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessEqDouble(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitDCmp();
    final Label elseLabel = new Label();
    mv.visitIfLe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

}
