package net.devrieze.meta.compile;

import org.objectweb.asm.Label;

import meta.lang.Literal.LongLiteral;
import meta.lang.TypeRef;
import meta.lang.UnaryPrimitiveOperator;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class LongPrimitiveCompiler {

  private final JavaCompiler aJavaCompiler;

  public LongPrimitiveCompiler(final JavaCompiler pJavaCompiler) {
    aJavaCompiler = pJavaCompiler;
  }

  public TypeRef<?> compileLongLiteral(final LongLiteral pLongLiteral, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pLongLiteral);
    mv.visitLdc(pLongLiteral.getValue());
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pLongLiteral, "Discarding the value of a literal makes no sense");
    }
    return pLongLiteral.getValueType();
  }

  public void compileBuiltinAddLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLAdd();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinDivLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLDiv();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMinusLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLSub();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinModLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLRem();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMultLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLMul();
    if (pCleanupStack) {
      mv.visitPop2();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinEqualsLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLCmp();
    final Label elseLabel = new Label();
    mv.visitIfNe(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    final Label elseLabel = new Label();
    mv.visitLCmp();
    mv.visitIfGt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterEqLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLCmp();
    final Label elseLabel = new Label();
    mv.visitIfGe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinUnequalsLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLCmp();
    final Label elseLabel = new Label();
    mv.visitIfEq(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLCmp();
    final Label elseLabel = new Label();
    mv.visitIfLt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessEqLong(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitLCmp();
    final Label elseLabel = new Label();
    mv.visitIfLe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinPostAdd(final UnaryPrimitiveOperator pToken, final LocalVariable pLocalVariable, final long pIncrement, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    final int pos = pLocalVariable.getPos();

    mv.visitLLoad(pos);
    if (!pCleanupStack) {
      mv.visitDup2();
    }
    mv.visitLdc(pIncrement);
    mv.visitLAdd();
    mv.visitLStore(pos);
  }

  public void compileBuiltinPreAdd(final UnaryPrimitiveOperator pToken, final LocalVariable pLocalVariable, final int pIncrement, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    final int pos = pLocalVariable.getPos();

    mv.visitLLoad(pos);
    mv.visitLdc(pIncrement);
    mv.visitLAdd();
    if (!pCleanupStack) {
      mv.visitDup2();
    }
    mv.visitLStore(pos);
  }

}
