package net.devrieze.meta.compile;

import java.lang.reflect.Type;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.Attribute;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

import static org.objectweb.asm.Opcodes.*;

import meta.lang.JavaType;
import meta.lang.Primitive;
import meta.lang.ReferenceType;
import meta.lang.TypeRef;

import net.devrieze.parser.LinePosition;


public class MyMethodVisitor {

  private final MethodVisitor aMethodVisitor;

  private int aLine;

  public MyMethodVisitor(final MethodVisitor pMethodVisitor) {
    aMethodVisitor = pMethodVisitor;
    aLine = -1;

  }

  public void visitInvokeSpecial(final MangledClassName pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitMethodInsn(INVOKESPECIAL, pOwner.toString(), pName, pDesc);
  }

  public void visitInvokeInterface(final MangledClassName pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitMethodInsn(INVOKEINTERFACE, pOwner.toString(), pName, pDesc);
  }

  public void visitInvokeVirtual(final MangledClassName pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitMethodInsn(INVOKEVIRTUAL, pOwner.toString(), pName, pDesc);
  }

  public void visitInvokeStatic(final MangledClassName pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitMethodInsn(INVOKESTATIC, pOwner.toString(), pName, pDesc);
  }

  public Label visitLabel() {
    final Label result = new Label();
    aMethodVisitor.visitLabel(result);
    return result;
  }

  public void visitLabel(final Label pLabel) {
    aMethodVisitor.visitLabel(pLabel);
  }

  public void visitEnd() {
    // Set the stack size (is automatically calculated, so negative numbers)
    aMethodVisitor.visitMaxs(-13, -17);
    aMethodVisitor.visitEnd();
  }

  public void visitLocalVariable(final String pName, final String pDesc, final String pSignature, final Label pStartLabel, final Label pEndLabel, final int pIndex) {
    aMethodVisitor.visitLocalVariable(pName, pDesc, pSignature, pStartLabel, pEndLabel, pIndex);
  }

  public void visitPop(final TypeRef<? extends JavaType> pType) {
    final JavaType type = pType.getReferredType();
    if ((type == Primitive.MDouble) || (type == Primitive.MLong)) {
      visitPop2();
    } else {
      visitPop();
    }
  }

  public void visitPop() {
    aMethodVisitor.visitInsn(POP);
  }

  public void visitPop2() {
    aMethodVisitor.visitInsn(POP2);
  }

  public void visitDup() {
    aMethodVisitor.visitInsn(DUP);
  }

  public void visitDup_x1() {
    aMethodVisitor.visitInsn(DUP_X1);
  }

  public void visitDup_x2() {
    aMethodVisitor.visitInsn(DUP_X2);
  }

  public void visitDup2() {
    aMethodVisitor.visitInsn(DUP2);
  }

  public void visitDup2_x1() {
    aMethodVisitor.visitInsn(DUP2_X1);
  }

  public void visitDup2_x2() {
    aMethodVisitor.visitInsn(DUP2_X2);
  }

  public void visitVoidReturn() {
    aMethodVisitor.visitInsn(RETURN);
  }

  public void visitIReturn() {
    aMethodVisitor.visitInsn(IRETURN);
  }

  public void visitFReturn() {
    aMethodVisitor.visitInsn(FRETURN);
  }

  public void visitDReturn() {
    aMethodVisitor.visitInsn(DRETURN);
  }

  public void visitLReturn() {
    aMethodVisitor.visitInsn(LRETURN);
  }

  public void visitRefReturn() {
    aMethodVisitor.visitInsn(ARETURN);
  }

  public void visitILoad(final int pIndex) {
    aMethodVisitor.visitVarInsn(ILOAD, pIndex);
  }

  public void visitDLoad(final int pIndex) {
    aMethodVisitor.visitVarInsn(DLOAD, pIndex);
  }

  public void visitFLoad(final int pIndex) {
    aMethodVisitor.visitVarInsn(FLOAD, pIndex);
  }

  public void visitALoad(final int pIndex) {
    aMethodVisitor.visitVarInsn(ALOAD, pIndex);
  }

  public void visitLLoad(final int pIndex) {
    aMethodVisitor.visitVarInsn(LLOAD, pIndex);
  }

  public void visitIStore(final int pIndex) {
    aMethodVisitor.visitVarInsn(ISTORE, pIndex);
  }

  public void visitFStore(final int pIndex) {
    aMethodVisitor.visitVarInsn(FSTORE, pIndex);
  }

  public void visitAStore(final int pIndex) {
    aMethodVisitor.visitVarInsn(ASTORE, pIndex);
  }

  public void visitLStore(final int pIndex) {
    aMethodVisitor.visitVarInsn(LSTORE, pIndex);
  }

  public void visitDStore(final int pIndex) {
    aMethodVisitor.visitVarInsn(DSTORE, pIndex);
  }

  public void visitGetStatic(final String pOwner, final String pName, final String pDescriptor) {
    aMethodVisitor.visitFieldInsn(GETSTATIC, pOwner, pName, pDescriptor);
  }

  public void visitGetField(final String pOwner, final String pName, final String pDescriptor) {
    aMethodVisitor.visitFieldInsn(GETFIELD, pOwner, pName, pDescriptor);
  }

  public void visitPutStatic(final String pOwner, final String pName, final String pDescriptor) {
    aMethodVisitor.visitFieldInsn(PUTSTATIC, pOwner, pName, pDescriptor);
  }

  public void visitPutField(final String pOwner, final String pName, final String pDescriptor) {
    aMethodVisitor.visitFieldInsn(PUTFIELD, pOwner, pName, pDescriptor);
  }

  public void visitBALoad() {
    aMethodVisitor.visitInsn(BALOAD);
  }

  public void visitCALoad() {
    aMethodVisitor.visitInsn(CALOAD);
  }

  public void visitSALoad() {
    aMethodVisitor.visitInsn(SALOAD);
  }

  public void visitIALoad() {
    aMethodVisitor.visitInsn(IALOAD);
  }

  public void visitLALoad() {
    aMethodVisitor.visitInsn(LALOAD);
  }

  public void visitFALoad() {
    aMethodVisitor.visitInsn(FALOAD);
  }

  public void visitDALoad() {
    aMethodVisitor.visitInsn(DALOAD);
  }

  public void visitAALoad() {
    aMethodVisitor.visitInsn(AALOAD);
  }

  public void visitBAStore() {
    aMethodVisitor.visitInsn(BASTORE);
  }

  public void visitCAStore() {
    aMethodVisitor.visitInsn(CASTORE);
  }

  public void visitSAStore() {
    aMethodVisitor.visitInsn(SASTORE);
  }

  public void visitIAStore() {
    aMethodVisitor.visitInsn(IASTORE);
  }

  public void visitLAStore() {
    aMethodVisitor.visitInsn(LASTORE);
  }

  public void visitFAStore() {
    aMethodVisitor.visitInsn(FASTORE);
  }

  public void visitDAStore() {
    aMethodVisitor.visitInsn(DASTORE);
  }

  public void visitAAStore() {
    aMethodVisitor.visitInsn(AASTORE);
  }

  public void visitCheckCast(final String pType) {
    aMethodVisitor.visitTypeInsn(CHECKCAST, pType);
  }

  public void visitNew(final MangledClassName pMangledCompleteName) {
    aMethodVisitor.visitTypeInsn(NEW, pMangledCompleteName.toString());
  }

  public void visitNewArray(final Primitive pType) {
    aMethodVisitor.visitTypeInsn(NEWARRAY, pType.getInternalName());
  }

  public void visitANewArray(final TypeRef<? extends ReferenceType> pType) {
    aMethodVisitor.visitTypeInsn(ANEWARRAY, pType.getInternalName());
  }

  public void visitInstanceOf(final TypeRef<? extends ReferenceType> pType) {
    aMethodVisitor.visitTypeInsn(INSTANCEOF, pType.getInternalName());
  }

  public void visitNull() {
    aMethodVisitor.visitInsn(ACONST_NULL);
  }

  public AnnotationVisitor visitAnnotation(final String pDesc, final boolean pVisible) {
    return aMethodVisitor.visitAnnotation(pDesc, pVisible);
  }

  @Deprecated
  public AnnotationVisitor visitAnnotationDefault() {
    return aMethodVisitor.visitAnnotationDefault();
  }

  @Deprecated
  public void visitAttribute(final Attribute pAttr) {
    aMethodVisitor.visitAttribute(pAttr);
  }

  @Deprecated
  public void visitCode() {
    aMethodVisitor.visitCode();
  }

  @Deprecated
  public void visitFieldInsn(final int pOpcode, final String pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitFieldInsn(pOpcode, pOwner, pName, pDesc);
  }

  @Deprecated
  public void visitFrame(final int pType, final int pLocal, final Object[] pLocal2, final int pStack, final Object[] pStack2) {
    aMethodVisitor.visitFrame(pType, pLocal, pLocal2, pStack, pStack2);
  }

  public void visitIincInsn(final int pVar, final int pIncrement) {
    aMethodVisitor.visitIincInsn(pVar, pIncrement);
  }

  @Deprecated
  public void visitInsn(final int pOpcode) {
    aMethodVisitor.visitInsn(pOpcode);
  }

  @Deprecated
  public void visitIntInsn(final int pOpcode, final int pOperand) {
    aMethodVisitor.visitIntInsn(pOpcode, pOperand);
  }

  @Deprecated
  public void visitJumpInsn(final int pOpcode, final Label pLabel) {
    aMethodVisitor.visitJumpInsn(pOpcode, pLabel);
  }

  public void visitLdcInsn(final Integer pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  public void visitLdcInsn(final Float pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  public void visitLdcInsn(final Long pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  public void visitLdcInsn(final Double pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  public void visitLdcInsn(final String pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  public void visitLdcInsn(final java.lang.reflect.Type pObj) {
    aMethodVisitor.visitLdcInsn(pObj);
  }

  @Deprecated
  public void visitLineNumber(final int pLine, final Label pStart) {
    aMethodVisitor.visitLineNumber(pLine, pStart);
  }

  @Deprecated
  public void visitLookupSwitchInsn(final Label pDflt, final int[] pKeys, final Label[] pLabels) {
    aMethodVisitor.visitLookupSwitchInsn(pDflt, pKeys, pLabels);
  }

  @Deprecated
  public void visitMethodInsn(final int pOpcode, final String pOwner, final String pName, final String pDesc) {
    aMethodVisitor.visitMethodInsn(pOpcode, pOwner, pName, pDesc);
  }

  @Deprecated
  public void visitMultiANewArrayInsn(final String pDesc, final int pDims) {
    aMethodVisitor.visitMultiANewArrayInsn(pDesc, pDims);
  }

  @Deprecated
  public AnnotationVisitor visitParameterAnnotation(final int pParameter, final String pDesc, final boolean pVisible) {
    return aMethodVisitor.visitParameterAnnotation(pParameter, pDesc, pVisible);
  }

  @Deprecated
  public void visitTableSwitchInsn(final int pMin, final int pMax, final Label pDflt, final Label[] pLabels) {
    aMethodVisitor.visitTableSwitchInsn(pMin, pMax, pDflt, pLabels);
  }

  @Deprecated
  public void visitTryCatchBlock(final Label pStart, final Label pEnd, final Label pHandler, final String pType) {
    aMethodVisitor.visitTryCatchBlock(pStart, pEnd, pHandler, pType);
  }

  @Deprecated
  public void visitTypeInsn(final int pOpcode, final String pType) {
    aMethodVisitor.visitTypeInsn(pOpcode, pType);
  }

  @Deprecated
  public void visitVarInsn(final int pOpcode, final int pVar) {
    aMethodVisitor.visitVarInsn(pOpcode, pVar);
  }

  public void visitLdc(final int pValue) {
    if ((pValue >= -1) && (pValue <= 5)) {
      if (pValue == -1) {
        aMethodVisitor.visitInsn(ICONST_M1);
      } else if (pValue == 0) {
        aMethodVisitor.visitInsn(ICONST_0);
      } else if (pValue == 1) {
        aMethodVisitor.visitInsn(ICONST_1);
      } else if (pValue == 2) {
        aMethodVisitor.visitInsn(ICONST_2);
      } else if (pValue == 3) {
        aMethodVisitor.visitInsn(ICONST_3);
      } else if (pValue == 4) {
        aMethodVisitor.visitInsn(ICONST_4);
      } else if (pValue == 5) {
        aMethodVisitor.visitInsn(ICONST_5);
      }
    } else {
      if ((pValue >= Byte.MIN_VALUE) && (pValue <= Byte.MAX_VALUE)) {
        aMethodVisitor.visitIntInsn(BIPUSH, pValue);
      } else if ((pValue >= Short.MIN_VALUE) && (pValue <= Short.MAX_VALUE)) {
        aMethodVisitor.visitIntInsn(SIPUSH, pValue);
      } else {
        aMethodVisitor.visitLdcInsn(Integer.valueOf(pValue));
      }
    }
  }

  public void visitLdc(final boolean pValue) {
    visitLdc(pValue ? 1 : 0);
  }

  public void visitLdc(final long pValue) {
    aMethodVisitor.visitLdcInsn(Long.valueOf(pValue));
  }

  public void visitLdc(final float pValue) {
    aMethodVisitor.visitLdcInsn(Float.valueOf(pValue));
  }

  public void visitLdc(final double pValue) {
    aMethodVisitor.visitLdcInsn(Double.valueOf(pValue));
  }

  public void visitLdc(final Type pValue) {
    aMethodVisitor.visitLdcInsn(pValue);
  }


  public void visitIAdd() {
    aMethodVisitor.visitInsn(IADD);
  }

  public void visitIDiv() {
    aMethodVisitor.visitInsn(IDIV);
  }

  public void visitISub() {
    aMethodVisitor.visitInsn(ISUB);
  }

  public void visitIRem() {
    aMethodVisitor.visitInsn(IREM);
  }

  public void visitIMul() {
    aMethodVisitor.visitInsn(IMUL);
  }

  public void visitDAdd() {
    aMethodVisitor.visitInsn(DADD);
  }

  public void visitDDiv() {
    aMethodVisitor.visitInsn(DDIV);
  }

  public void visitDSub() {
    aMethodVisitor.visitInsn(DSUB);
  }

  public void visitDRem() {
    aMethodVisitor.visitInsn(DREM);
  }

  public void visitDMul() {
    aMethodVisitor.visitInsn(DMUL);
  }

  public void visitFAdd() {
    aMethodVisitor.visitInsn(FADD);
  }

  public void visitFDiv() {
    aMethodVisitor.visitInsn(FDIV);
  }

  public void visitFSub() {
    aMethodVisitor.visitInsn(FSUB);
  }

  public void visitFRem() {
    aMethodVisitor.visitInsn(FREM);
  }

  public void visitFMul() {
    aMethodVisitor.visitInsn(FMUL);
  }

  public void visitLAdd() {
    aMethodVisitor.visitInsn(LADD);
  }

  public void visitLDiv() {
    aMethodVisitor.visitInsn(LDIV);
  }

  public void visitLSub() {
    aMethodVisitor.visitInsn(LSUB);
  }

  public void visitLRem() {
    aMethodVisitor.visitInsn(LREM);
  }

  public void visitLMul() {
    aMethodVisitor.visitInsn(LMUL);
  }

  public void visitLCmp() {
    aMethodVisitor.visitInsn(LCMP);
  }

  public void visitDCmp() {
    aMethodVisitor.visitInsn(DCMPL);
  }

  public void visitFCmp() {
    aMethodVisitor.visitInsn(FCMPL);
  }

  public void visitGoto(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(GOTO, pTarget);
  }

  public void visitIfEq(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFEQ, pTarget);
  }

  public void visitIfNe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFNE, pTarget);
  }

  public void visitIfLt(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFLT, pTarget);
  }

  public void visitIfLe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFLE, pTarget);
  }

  public void visitIfGt(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFGT, pTarget);
  }

  public void visitIfGe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IFGE, pTarget);
  }

  public void visitIfIcmpEq(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPEQ, pTarget);
  }

  public void visitIfIcmpNe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPNE, pTarget);
  }

  public void visitIfIcmpLt(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPLT, pTarget);
  }

  public void visitIfIcmpLe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPLE, pTarget);
  }

  public void visitIfIcmpGt(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPGT, pTarget);
  }

  public void visitIfIcmpGe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ICMPGE, pTarget);
  }

  public void visitPos(final LinePosition pPos) {
    if (pPos == null) {
      return;
    }
    final int line = pPos.getLineNo();
    if (line < 0) {
      return; // When an invalid line is there, or the line is not known
    }
    if (aLine != line) {
      aMethodVisitor.visitLineNumber(line, visitLabel());
    }
    aLine = line;
  }

  public void visitReturn(final TypeRef<?> pReturnType) {
    if (pReturnType.getReferredType() instanceof Primitive) {
      final Primitive returnType = (Primitive) pReturnType.getReferredType();
      switch (returnType) {
        case MBoolean:
        case MByte:
        case MChar:
        case MShort:
        case MInt:
          visitIReturn();
          break;
        case MDouble:
          visitDReturn();
          break;
        case MFloat:
          visitFReturn();
          break;
        case MLong:
          visitLReturn();
          break;
      }

    } else {
      visitRefReturn();
    }
  }

  public void visitThrow() {
    aMethodVisitor.visitInsn(ATHROW);
  }

  public void visitArrayLength() {
    aMethodVisitor.visitInsn(ARRAYLENGTH);
  }

  public void visitIXor() {
    aMethodVisitor.visitInsn(IXOR);
  }

  public void visitIAnd() {
    aMethodVisitor.visitInsn(IAND);
  }

  public void visitIOr() {
    aMethodVisitor.visitInsn(IOR);
  }

  public void visitIfAcmpEq(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ACMPEQ, pTarget);
  }

  public void visitIfAcmpNe(final Label pTarget) {
    aMethodVisitor.visitJumpInsn(IF_ACMPNE, pTarget);
  }

}
