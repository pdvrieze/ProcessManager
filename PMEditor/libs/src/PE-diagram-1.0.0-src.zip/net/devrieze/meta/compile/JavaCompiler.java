package net.devrieze.meta.compile;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Label;

import meta.lang.*;
import meta.lang.Literal.BoolLiteral;
import meta.lang.TypeRef.ClassWrapper;

import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;


/**
 * Class that encapsulates the compilation of M to java bytecode
 * 
 * @author Paul de Vrieze
 */
public class JavaCompiler {

  public enum DebugStyles {
    SOURCE,
    LINES,
    LOCALS;
  }

  private final EnumSet<DebugStyles> aDebugLevel;

  private final IntPrimitiveCompiler aIntPrimitveCompiler;

  private final LongPrimitiveCompiler aLongPrimitveCompiler;

  private final DoublePrimitiveCompiler aDoublePrimitveCompiler;

  private final FloatPrimitiveCompiler aFloatPrimitveCompiler;

  private boolean isDebugLocals() {
    return aDebugLevel.contains(DebugStyles.LOCALS);
  }

  private boolean isDebugLines() {
    return aDebugLevel.contains(DebugStyles.LINES);
  }

  @Deprecated
  public static String mangleName(final String pName) {
    return mangleName(pName, false);
  }

  @Deprecated
  public static String mangleCompleteName(final String pName) {
    return mangleName(pName, true);
  }

  @Deprecated
  public static String mangleName(final String pName, final boolean pSkipPackageSeparator) {
    final StringBuilder result = new StringBuilder(pName.length() + Math.max(10, pName.length() / 10));
    for (int i = 0; i < pName.length(); ++i) {
      final char c = pName.charAt(i);
      switch (c) {
        case ';':
          result.append('%').append("?");
          break;
        case '$':
          result.append('%').append("#");
          break;
        case '<':
          result.append('%').append("^");
          break;
        case '>':
          result.append('%').append("_");
          break;
        case '[':
          result.append('%').append("{");
          break;
        case ']':
          result.append('%').append("}");
          break;
        case ':':
          result.append('%').append("!");
          break;
        case '%':
          result.append('%').append("%");
          break;
        case '/':
          if (!pSkipPackageSeparator) {
            result.append('%').append("|");
            break;
          } else {
            result.append(c);
            break;
          }
        case '.':
          result.append('%').append(",");
          break;
        default:
          result.append(c);
      }
    }
    if ((result.length() != pName.length()) || (result.length() == 0)) {
      result.insert(0, "%-");
    }

    return result.toString();
  }

  public void debugLine(final MyMethodVisitor mv, final LinedToken<MLang> pToken) {
    if (isDebugLines() && (pToken != null)) {
      mv.visitPos(pToken.getPos());
    }
  }

  public JavaCompiler() {
    //    aDebugLevel = EnumSet.noneOf(DebugStyles.class);
    aDebugLevel = EnumSet.allOf(DebugStyles.class);
    aIntPrimitveCompiler = new IntPrimitiveCompiler(this);
    aDoublePrimitveCompiler = new DoublePrimitiveCompiler(this);
    aFloatPrimitveCompiler = new FloatPrimitiveCompiler(this);
    aLongPrimitveCompiler = new LongPrimitiveCompiler(this);
  }

  public IntPrimitiveCompiler getIntCompiler() {
    return aIntPrimitveCompiler;
  }

  public LongPrimitiveCompiler getLongCompiler() {
    return aLongPrimitveCompiler;
  }

  public FloatPrimitiveCompiler getFloatCompiler() {
    return aFloatPrimitveCompiler;
  }

  public DoublePrimitiveCompiler getDoublePrimitveCompiler() {
    return aDoublePrimitveCompiler;
  }

  public TypeRef<?> compileCall(final ReferenceType pTarget, final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pFunction);
    if (pFunction.isConstructor()) {
      mv.visitInvokeSpecial(new MangledClassName(pTarget), pFunction.getFunctionName(), pFunction.getFunctionType().getDescriptor(pScope));
      return pFunction.getOwner();
    }
    if (pFunction.isInterfaceMethod()) {
      mv.visitInvokeInterface(new MangledClassName(pTarget), pFunction.getFunctionName(), pFunction.getFunctionType().getDescriptor(pScope));
    } else if (pFunction.isStatic()) {
      mv.visitInvokeStatic(new MangledClassName(pTarget), pFunction.getFunctionName(), pFunction.getFunctionType().getDescriptor(pScope));
    } else {
      mv.visitInvokeVirtual(new MangledClassName(pTarget), pFunction.getFunctionName(), pFunction.getFunctionType().getDescriptor(pScope));
    }
    final TypeRef<?> returnType = pFunction.getReturnType(pScope);
    if ((returnType == null) && (!pCleanupStack)) {
      pScope.getContext().error(pFunction, "Expected function return value, but found void");
    } else if (pCleanupStack && (returnType != null)) {
      mv.visitPop(returnType);
    }
    return returnType;
  }

  public TypeRef<?> compileFuncCall(final FuncCall pFuncCall, final Scope pScope, final boolean pCleanupStack) throws CompilationError, CompilationException {
    final Symbol functionSymbol = pFuncCall.getFunctionSymbol();
    Expression target = pFuncCall.getTarget();
    final Expression[] args = pFuncCall.getArgs();

    final boolean isSuperCall = ((target != null) && (target.getTokenType() == MLang.SYMBOL) && "super".equals(((Symbol) target).getName()));
    final TypeRef<?> targetType;
    if (isSuperCall) {
      target = new Symbol(pFuncCall.getPos(), "this");
      targetType = target.getEvalType(pScope).getParent();
    } else {
      targetType = getTargetType(pScope, target);
    }
    FunctionRef function;

    final ArrayList<TypeRef<?>> paramTypes = getParamTypes(pScope, args);

    if (target != null) {
      function = targetType.resolveFunction(pScope, functionSymbol, paramTypes.toArray(new TypeRef[0]));
    } else {
      function = pScope.resolveFunction(functionSymbol, paramTypes.toArray(new TypeRef<?>[0]));
      if ((function != null) && (!function.isStatic()) && (!function.isConstructor())) {
        // The function must be unqualified, so start by putting a reference to the current context on the stack.
        target = new Symbol(pFuncCall.getPos(), "this");
      }
    }
    if (function == null) {
      final StringBuilder functionRepr = functionPrototype(functionSymbol, paramTypes);
      pScope.getContext().error(pFuncCall, "The function \"" + functionRepr + "\" could not be resolved on type " + targetType);
      return null;
    }

    // TODO move this to ArrayType so literals can be created for instances
    final Expression[] newArgs;
    if (function.getFunctionType().isVarArgs()) {
      final TypeRef<?>[] declParamTypes = function.getFunctionType().getParamTypes(pScope);
      final int lastArg = declParamTypes.length - 1;
      final LinePosition pos = pFuncCall.getPos();
      if (!(((paramTypes.size() - 1) == lastArg) && declParamTypes[lastArg].isAssignableFrom(paramTypes.get(lastArg)))) {
        newArgs = new Expression[declParamTypes.length];
        System.arraycopy(args, 0, newArgs, 0, lastArg);
        final TypeRef<?> arrayType = declParamTypes[lastArg];
        final FunctionRef constructor = arrayType.resolveFunction(pScope, new Symbol(pos, "<init>"), Primitive.MInt.getRef());
        final FuncCall constructorCall = FuncCall.create(pos, arrayType, constructor, new Expression[] { Literal.createInt(pos, args.length
            - lastArg) });
        final Expression[] body = new Expression[(args.length - lastArg) + 2];
        final Symbol array = new Symbol(pos, "$array");
        body[0] = new VarAssign(pos, null, array, TypeRef.ANY, constructorCall);
        final FunctionRef assignment = arrayType.resolveFunction(pScope, new Symbol(null, "operator["), Primitive.MInt.getRef(), arrayType.getElementType());
        for (int i = 0; (i + lastArg) < args.length; ++i) {
          final LinePosition pos2 = args[i + lastArg].getPos();
          body[i + 1] = FuncCall.create(pos2, array, assignment, new Expression[] { Literal.createInt(null, i), args[i + lastArg] });
        }
        body[body.length - 1] = array;
        final MTupple arg = new MTupple(pos, body);
        newArgs[lastArg] = arg;
      } else {
        newArgs = args;
      }
    } else {
      newArgs = args;
    }

    return function.compileCall(target, pScope, pCleanupStack, isSuperCall, newArgs);
  }

  private static StringBuilder functionPrototype(final Symbol functionSymbol, final ArrayList<TypeRef<?>> paramTypes) {
    final StringBuilder functionRepr = new StringBuilder();
    functionRepr.append(functionSymbol.getName()).append("( ");
    for (final TypeRef<?> paramType : paramTypes) {
      functionRepr.append(" _ : ").append(paramType.toMetaCode(0)).append(',');
    }
    functionRepr.deleteCharAt(functionRepr.length() - 1);
    functionRepr.append(')');
    return functionRepr;
  }

  public TypeRef<?> compileFuncCall(final FunctionRef pFunction, final Expression pTarget, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression... pArgs) throws CompilationException {
    if (pTarget != null) {
      final TypeRef<?> targetType = compileTarget(pScope, pTarget);
      if (!pFunction.getOwner().isAssignableFrom(targetType)) {
        pScope.getContext().error(pFunction, "The type of the called object is incompatible with the function");
      }
    }
    return compileFuncCallWithArgs(pFunction, pScope, pCleanupStack, pIsSuperCall, pArgs);
  }

  public TypeRef<?> compileFuncCallWithArgs(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final Expression... pArgs) throws CompilationError, CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if ((!pIsSuperCall) && pFunction.isConstructor()) {
      final TypeRef<?> resultType = pFunction.getOwner();
      if (resultType.isArrayType()) {
        for (final Expression arg : pArgs) {
          arg.compile(pScope, false);
        }
        return compileCreateArray(pFunction, pScope, (ArrayType) resultType.getReferredType(), pCleanupStack);
      } else {
        final MangledClassName mangledCompleteName = new MangledClassName(resultType);
        mv.visitNew(mangledCompleteName);
        mv.visitDup(); // one dup for the constructor
        if (!pCleanupStack) {
          mv.visitDup(); // one dup for the resulting object
        }
      }
    }

    // Add arguments
    for (final Expression arg : pArgs) {
      arg.compile(pScope, false);
    }

    return compileFuncCallNoArgs(pFunction, pScope, pCleanupStack, pIsSuperCall, mv);
  }

  private TypeRef<?> compileFuncCallNoArgs(final FunctionRef pFunction, final Scope pScope, final boolean pCleanupStack, final boolean pIsSuperCall, final MyMethodVisitor mv) throws CompilationException {
    if (pFunction instanceof BinaryPrimitiveOperator) {
      return ((BinaryPrimitiveOperator) pFunction).compileCall(pScope, pCleanupStack);
    }

    if (pFunction.getOwner() != null) {
      if (pIsSuperCall) {
        debugLine(mv, pFunction);
        mv.visitInvokeSpecial(new MangledClassName(pFunction.getOwner()), pFunction.getFunctionName(), pFunction.getFunctionType().getDescriptor(pScope));
        final TypeRef<?> returnType = pFunction.getReturnType(pScope);
        if (pCleanupStack) {
          if ((returnType != null) && (!pFunction.isConstructor())) {
            mv.visitPop(returnType);
          }
        } else {
          if (returnType == null) {
            pScope.getContext().error(pFunction, "Expected function return value, but not found");
          }
        }
        return returnType;
      } else {
        return pFunction.getOwner().getReferredType().compileCallStatic(pFunction, pScope, pCleanupStack);
      }

    } // no target type, so global
    if (pFunction.isConstructor()) {
      debugLine(mv, pFunction);
      final TypeRef<?> resultType = pFunction.getOwner();
      final MangledClassName mangledCompleteName = new MangledClassName(resultType);
      mv.visitInvokeSpecial(mangledCompleteName, "<init>", pFunction.getFunctionType().getDescriptor(pScope));
      return resultType;
    } else {
      return pScope.getContext().compileCallGlobal(pFunction, pScope, pCleanupStack);
    }
  }

  private static TypeRef<?> compileTarget(final Scope pScope, final Expression pTarget) throws CompilationException {
    if (pTarget == null) {
      return null;
    }
    if (pTarget instanceof TypeRef<?>) {
      return ((TypeRef<?>) pTarget).asReferenceType(); // A static call
    } else {
      // Push the target on the stack (for nonstatic / nonglobal methods)
      return pTarget.compile(pScope, false);// The object is the first param
    }
  }

  private static TypeRef<?> getTargetType(final Scope pScope, final Expression target) throws CompilationException {
    if (target == null) {
      return null;
    }
    if (target instanceof TypeRef<?>) {
      return ((TypeRef<?>) target).asReferenceType(); // A static call
    } else {
      // Push the target on the stack (for nonstatic / nonglobal methods)
      return target.getEvalType(pScope);// The object is the first param
    }
  }

  // XXX move to FuncCall
  public static ArrayList<TypeRef<?>> getParamTypes(final Scope pScope, final Expression[] args) throws CompilationException {
    final ArrayList<TypeRef<?>> paramTypes = new ArrayList<>();
    // Push the arguments on the stack
    for (final Expression arg : args) {
      final TypeRef<?> evalType = arg.getEvalType(pScope);
      if (evalType == null) {
        pScope.getContext().error(arg, "The return type of the expression could not be determined");
        continue;
      }
      paramTypes.add(evalType);
    }
    return paramTypes;
  }

  public void compileBuiltinThis(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "The result of the this operator is not used");
      return;
    }
    mv.visitALoad(0);
  }

  public CompilationResult compileClass(final MClass pClass, final Scope pScope) throws CompilationException {
    final MyClassWriter cw = pScope.getContext().getClassWriter();
    pScope.getContext().setCurrentClass(pClass);

    cw.visit(MyClassWriter.ClassVersion.V16, pClass.getFlagSet(), new MangledClassName(pClass), pClass.getClassSignature().toString(), pClass.getParent().getInternalName(), getInterfaceNames(pClass.getInterfaces()));
    debugClassSource(cw, pClass);

    final Scope scope = pScope.newClassScope(pClass);

    // TODO Visit attributes
    for (final VarAssign attribute : pClass.getAttributes()) {
      final String name = MEvaluator.toSymbol(attribute.getLValue()).getName();
      TypeRef<?> type = MEvaluator.toTypeRef(attribute.getValueType(), pScope);
      if (type == null) {
        if (attribute.getRValue() == null) {
          pScope.getContext().error(attribute, CompilationErrors.PSYCHIC_ASSIGN);
        }
        type = attribute.getRValue().getEvalType(pScope);
      }
      Object value;
      final Expression value2 = attribute.getRValue();
      if (value2 == null) {
        value = null;
      } else {
        value = value2.eval(pScope);
      }
      final String desc = type.getDescriptor();
      final String signature = type.getSignature();
      final FieldVisitor fv = cw.visitField(attribute.getFlags(pScope), name, desc, signature, value);
      fv.visitEnd();

    }

    boolean constructed = false;
    final String className = pClass.getClassName();
    for (final Function m : pClass.getLocalMethods()) {
      Function m2 = m;
      if (m.getName().equals("<init>")) {
        constructed = true;
      } else if (m.getName().equals(className)) {
        m2 = m.newWithName("<init>");
        constructed = true;
      }
      compileFunction(scope, m2);
    }
    if (!constructed) {
      // Default constructor.
      final LinePosition pos = pClass.getPos();
      final Function ast = new Function(pos, "<init>", new FunctionType(pos, FunctionType._PUBLIC, pClass.getRef(TypeRef.<JavaReferenceType> emptyList()), null, TypeRef.emptyList()), new Expression[] {
                                                                                                                                                                                                         FuncCall.create(pos, new Symbol(pos, "super"), new FunctionRef(pos, "<init>", new FunctionType(pos, FunctionType._PUBLIC, pClass.getParent(), null, TypeRef.emptyList())), new Expression[0]),
                                                                                                                                                                                                         new Return(pos) });
      compileFunction(scope, ast);
    }
    cw.visitEnd();
    final byte[] byteArray = pScope.getContext().getClassWriter().toByteArray();
    pScope.getContext().setCurrentClass(null);
    return new CompilationResult(pClass, byteArray);
  }

  private void debugClassSource(final MyClassWriter pCw, final MClass pClass) {
    if (aDebugLevel.contains(DebugStyles.SOURCE)) {
      final LinePosition pos = pClass.getPos();
      if (pos != null) {
        final String filename = pos.getFile().getName();
        pCw.visitSource(filename);
      }
    }
  }

  private static String[] getInterfaceNames(final List<TypeRef<? extends JavaReferenceType>> pList) {
    final String[] result = new String[pList.size()];
    for (int i = 0; i < pList.size(); ++i) {
      result[i] = pList.get(i).getInternalName();
    }
    return result;
  }

  private static MyMethodVisitor getMethodVisitor(final Function pFunction, final Scope pScope) throws CompilationException {
    final EnumSet<FunctionFlags> flags = pFunction.getFunctionType().getFlags(pScope);
    final MyMethodVisitor result = pScope.getContext().getClassWriter().visitMethod(flags, pFunction.getName(), pFunction.getFunctionType().getDescriptor(pScope), null, null);
    pScope.getContext().setMethodVisitor(result);
    return result;
  }

  public void compileFunction(final Scope pOldScope, final Function pFunction) throws CompilationException {
    final MyMethodVisitor mv = getMethodVisitor(pFunction, pOldScope);
    compileFunctionAnnotations(pFunction.getFunctionType().getFlags(), mv, pOldScope);

    final Scope scope = pOldScope.newFunctionScope(pFunction);

    Label localStartLabel = null;
    if (isDebugLocals()) {
      localStartLabel = mv.visitLabel();
    }

    final Expression[] implementation = pFunction.getImplementation();

    if (pFunction.isConstructor(scope) && (!doesConstruct(implementation))) {
      invokeSuperConstructor(pFunction, scope);
    }

    boolean implementsReturn = false;

    final TypeRef<?> returnType = pFunction.getFunctionType().getReturnType(pOldScope);

    // The actual compilation of the body
    for (int i = 0; i < implementation.length; ++i) {
      final Expression token = implementation[i];
      if (implementsReturn) {
        pOldScope.getContext().error(token, CompilationErrors.UNREACHABLE_CODE);
      } else {
        // TODO perhaps optimize this
        implementsReturn = doesReturn(token);
      }
      if ((returnType != null) && (!implementsReturn) && ((i + 1) == implementation.length)) {
        final TypeRef<?> resultType = token.compile(scope, false);
        if (returnType.isAssignableFrom(resultType)) { // implicit return
          mv.visitReturn(returnType);
        } else {
          pOldScope.getContext().error(token, CompilationErrors.MISMATCHING_RETURN_TYPES);
        }
      } else {
        token.compile(scope, true);
      }
    }

    if (!implementsReturn && (returnType == null)) {
      mv.visitVoidReturn();
    }

    final Label localEndLabel = new Label();
    if (isDebugLocals()) {
      mv.visitLabel(localEndLabel);
      addScopeDebugInfo(mv, localStartLabel, localEndLabel, scope);
    }

    mv.visitEnd();
    pOldScope.getContext().setMethodVisitor(null); // Just to make sure

    if (returnType != null) {
      // Find if this function has overridden an existing function
      final FunctionRef overridden = findOverridden(pFunction, scope);

      if (overridden != null) {
        // If we have overridden, but not the same return type, then create a synthetic accessor
        if (!pFunction.getFunctionType().getReturnType(pOldScope).equals(overridden.getReturnType())) {
          for (final Function declaredFunction : pFunction.getOwner().getReferredType().getLocalMethods()) {
            if (declaredFunction.getRef().isSame(overridden, scope)) {
              return; // Skip generation if the class defines the overridden function as well
            }
          }

          createAndCompileBridge(pOldScope, pFunction, overridden);
        }
      }
    }

    return;
  }

  private static void compileFunctionAnnotations(final List<AnnotateToken> pFlags, final MyMethodVisitor pMv, final Scope pScope) throws CompilationException {
    for (final AnnotateToken flag : pFlags) {
      if (FunctionFlags.fromString(flag.getName()) == null) {
        // Not Builtin into the java language (and as such a flag, not annotation)
        compileFunctionAnnotation(pMv, flag, pScope);
      }
    }
  }

  private static void compileFunctionAnnotation(final MyMethodVisitor pMv, final AnnotateToken pFlag, final Scope pScope) throws CompilationException {
    final TypeRef<?> annotation = pScope.resolveType(pFlag.getName());
    if (!annotation.isAnnotation()) {
      pScope.getContext().error(pFlag, "The type represented by this token is not an annotation");
    }
    // TODO base visibility on actual type
    final AnnotationVisitor av = pMv.visitAnnotation(annotation.getDescriptor(), true);
    final List<FunctionRef> preElems = annotation.getReferredType().getMethods();
    final List<FunctionRef> elems = new ArrayList<>(preElems.size());
    for (final FunctionRef fr : preElems) {
      if (fr.getFunctionType().isAbstract() && fr.getFunctionType().getOwner().equals(annotation)) {
        elems.add(fr);
      }
    }

    VarAssign[] parms = pFlag.getParams(pScope);
    if (elems.size() == 0) {
      if ((parms != null) && (parms.length > 0)) {
        pScope.getContext().error(pFlag, CompilationErrors.INVALID_ARGUMENT_COUNT);
        return;
      }
      parms = new VarAssign[0];
    } else if ((parms == null) || (parms.length != elems.size())) {
      pScope.getContext().error(pFlag, CompilationErrors.INVALID_ARGUMENT_COUNT);
      return;
    }

    int pos = 0;
    for (final FunctionRef fr : elems) {
      final VarAssign parm = parms[pos];

      final FunctionType ft = fr.getFunctionType();
      final TypeRef<?>[] paramTypes = ft.getParamTypes(pScope);
      if ((paramTypes.length > 0) || (!ft.isAbstract())) {
        pScope.getContext().error(pFlag, "Illegal annotation member");
      }
      final TypeRef<?> annotationType = ft.getReturnType(pScope);
      if (annotationType.isArrayType()) {
        final MTupple aParm = MEvaluator.toTupple(parm.getRValue());
        final AnnotationVisitor av2 = av.visitArray(fr.getFunctionName());
        final TypeRef<?> memberType = annotationType.getElementType();
        if (memberType.getReferredType() instanceof ArrayType) {
          throw new UnsupportedOperationException("Recursion without recursion");
        } else if (TypeRef.create(null, Enum.class).isAssignableFrom(memberType)) {
          for (final Expression p : aParm) {
            final Symbol s = MEvaluator.toSymbol(p);
            av2.visitEnum(null, memberType.getDescriptor(), s.getName());
          }
        } else if (memberType.getReferredType() instanceof Primitive) {
          throw new UnsupportedOperationException("not yet implemented");
        }
        av2.visitEnd();
      } else if (TypeRef.create(null, Enum.class).isAssignableFrom(annotationType)) {
        final Symbol s = MEvaluator.toSymbol(parm);
        av.visitEnum(null, annotationType.getDescriptor(), s.getName());
      } else if (annotationType.getReferredType() instanceof Primitive) {
        throw new UnsupportedOperationException("not yet implemented");
      }
      ++pos;
    }

    av.visitEnd();
    return;
  }


  private static void createAndCompileBridge(final Scope pScope, final Function pNewFunc, final FunctionRef pOverridden) throws CompilationException {
    final Expression target = new Symbol(null, "this");
    final Expression[] args = new Expression[pNewFunc.getFunctionType().getParams().length];
    for (int i = 0; i < args.length; ++i) {
      // TODO seems overly complicated
      args[i] = new Symbol(null, MEvaluator.toSymbol(pNewFunc.getFunctionType().getParams()[i].getLValue()).getName());
    }
    // Generate syntethic acessor
    final Function f = new Function(null, pNewFunc.getName(), new FunctionType(null, AnnotateToken.fromFlags(FunctionFlags.PUBLIC, FunctionFlags.BRIDGE, FunctionFlags.SYNTHETIC), pNewFunc.getFunctionType().getOwner(), pOverridden.getReturnType(), pNewFunc.getFunctionType().getParams()), new Return(null, FuncCall.create(null, target, new Symbol(null, pNewFunc.getName()), pNewFunc.getFunctionType().getReturnType(pScope), args)));
    f.function_compile(pScope);// Invoke the compiler on the new tokens
  }

  private static FunctionRef findOverridden(final Function pFunction, final Scope pScope) throws CompilationException {
    final Symbol functionName = new Symbol(null, pFunction.getName());
    FunctionRef overridden = pFunction.getOwner().getParent().resolveFunction(pScope, functionName, pFunction.getFunctionType().getParamTypes(pScope));
    if (overridden == null) {
      for (final TypeRef<? extends JavaReferenceType> iface : pFunction.getOwner().getInterfaces()) {
        overridden = iface.resolveFunction(pScope, functionName, pFunction.getFunctionType().getParamTypes(pScope));
      }
    }
    return overridden;
  }

  private void addScopeDebugInfo(final MyMethodVisitor mv, final Label localStartLabel, final Label localEndLabel, final Scope pScope) {
    if (isDebugLocals()) {
      for (final LocalVariable local : pScope.getLocals()) {
        mv.visitLocalVariable(local.getName(), local.getVarType().getDescriptor(), local.getVarType().getSignature(), localStartLabel, localEndLabel, local.getPos());
      }
    }
  }

  private void invokeSuperConstructor(final Function pFunction, final Scope pScope) throws CompilationException {
    final TypeRef<? extends JavaReferenceType> target = pFunction.getOwner().getParent();

    final Symbol thisSymbol = new Symbol(pFunction.getPos(), "this");
    thisSymbol.compile(pScope, false);
    final FunctionRef superConstructor = target.resolveFunction(pScope, new Symbol(pFunction.getPos(), "<init>"));
    compileFuncCallWithArgs(superConstructor, pScope, true, true);
  }

  private static boolean doesConstruct(final Expression[] pExpressions) {
    for (final Expression expression : pExpressions) {
      if (doesConstruct(expression)) {
        return true;
      }
    }
    return false;
  }

  private static boolean doesConstruct(final Expression pExpression) {
    if (pExpression.getTokenType() == MLang.FUNCCALL) {
      final FuncCall fc = (FuncCall) pExpression;
      final String fname = fc.getFunctionName();
      // TODO improve
      if (fname.equals("super") || fname.equals("<init>") || fname.equals("this")) {
        return true;
      }
    }
    return false;
  }

  // TODO refactor this whole stuff
  private boolean doesReturn(final Expression pToken) {
    if (pToken == null) {
      return false;
    }
    switch (pToken.getTokenType()) {
      case RETURN:
        return true;
      case THROW:
        return true;
      case IF: {
        final Conditional c = (Conditional) pToken;
        return doesReturn(c.getThen()) && doesReturn(c.getElse());
      }
      case TUPPLE: {
        final MTupple m = (MTupple) pToken;
        for (final Expression expr : m) {
          if (doesReturn(expr)) {
            return true;
          }
        }
        return false;
      }
      default:
        return false;
    }
  }

  public TypeRef<?> compileReturn(final Return pReturn, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (!pCleanupStack) {
      pScope.getContext().error(pReturn, "Expecting a result value from a return token");
    }
    final Expression expr = pReturn.getExpr();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pReturn);
    if (expr == null) {
      mv.visitVoidReturn();
      return null;
    } else {
      final TypeRef<?> resultType = expr.compile(pScope, false);
      mv.visitReturn(resultType);
      return resultType;
    }
  }

  public TypeRef<?> compileThrow(final Throw pThrow, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    if (!pCleanupStack) {
      pScope.getContext().error(pThrow, "Expecting a result value from a throw token");
    }
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pThrow);
    final Expression expr = pThrow.getExpr();
    if (expr == null) {
      pScope.getContext().error(pThrow, CompilationErrors.THROW_MUST_RETURN_THROWABLE);
      return null;
    }
    final TypeRef<?> resultType = expr.compile(pScope, false);
    if (!TypeRef.create(null, Throwable.class).isAssignableFrom(resultType)) {
      pScope.getContext().error(pThrow, CompilationErrors.THROW_MUST_RETURN_THROWABLE);
      return null;
    }
    mv.visitThrow();
    return null;
  }

  public TypeRef<?> compileIf(final Conditional pConditional, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final Label thenLabel = new Label();
    final Label elseLabel = new Label();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pConditional);
    compileCondition(pConditional, pConditional.getCondition(), thenLabel, elseLabel, true, pScope);

    //    pConditional.getCondition().compile(pScope, false);

    //mv.visitIfEq(elseLabel);

    mv.visitLabel(thenLabel);
    final TypeRef<?> thenResult = pConditional.getThen().compile(pScope, pCleanupStack);
    final boolean thenReturns = doesReturn(pConditional.getThen());

    TypeRef<?> elseResult = null;

    final Expression _else = pConditional.getElse();
    if (_else == null) {
      mv.visitLabel(elseLabel);
    } else {
      final Label endLabel = new Label();
      if (!thenReturns) {
        mv.visitGoto(endLabel);
      }
      mv.visitLabel(elseLabel);
      elseResult = _else.compile(pScope, pCleanupStack);
      if (!thenReturns) {
        mv.visitLabel(endLabel);
      }
    }
    if (elseResult == null) {
      if (!pCleanupStack) {
        pScope.getContext().error(pConditional, "Conditionals without else part cannot result in a value");
      }
      return null; // Partial if statements do not return anything
    } else if (thenResult.isAssignableFrom(elseResult)) {
      return thenResult;
    } else if (elseResult.isAssignableFrom(thenResult)) {
      return elseResult;
    }
    throw new UnsupportedOperationException("No support yet for finding common super classes");
  }

  private void compileCondition(final LinedToken<MLang> pParentToken, final Expression pCondition, final Label pTrueTarget, final Label pFalseTarget, final boolean pFallthroughValue, final Scope pScope) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    switch (pCondition.getTokenType()) {
      case TUPPLE: {
        final MTupple tupple = (MTupple) pCondition; // Compile all but the last
        if (tupple.size() == 0) {
          pScope.getContext().error(pCondition, "Empty tupple does not evaluate to boolean");
        }
        for (int i = 0; i < (tupple.size() - 1); ++i) {
          tupple.get(i).compile(pScope, true);
        }
        compileCondition(pParentToken, tupple.get(tupple.size() - 1), pTrueTarget, pFalseTarget, pFallthroughValue, pScope);
        return;
      }
      case BOOLLITERAL: {
        final Literal.BoolLiteral literal = (BoolLiteral) pCondition;
        if (literal.getObjValue().booleanValue()) {
          if (!pFallthroughValue) {
            mv.visitGoto(pTrueTarget);
          }
        } else {
          if (pFallthroughValue) {
            mv.visitGoto(pFalseTarget);
          }
        }
        return;
      }
      case BINARYOPERATOR: {
        final BinaryExpression expr = (BinaryExpression) pCondition;
        switch (expr.getOperator()) {
          case LOGIC_AND: {
            final Label nextLabel = new Label();
            compileCondition(expr, expr.getLeft(), nextLabel, pFalseTarget, true, pScope);
            mv.visitLabel(nextLabel);
            compileCondition(pParentToken, expr.getRight(), pTrueTarget, pFalseTarget, pFallthroughValue, pScope);
            return;
          }
          case LOGIC_OR: {
            final Label nextLabel = new Label();
            compileCondition(expr, expr.getLeft(), pTrueTarget, nextLabel, false, pScope);
            mv.visitLabel(nextLabel);
            compileCondition(pParentToken, expr.getRight(), pTrueTarget, pFalseTarget, pFallthroughValue, pScope);
            return;
          }
          case EQUALS:
          case GREATER:
          case GREATEREQ:
          case LESS:
          case LESSEQ:
          case UNEQUALS: {
            final Type leftType = expr.getLeft().getEvalType(pScope).getReferredType();
            if (leftType instanceof Primitive) {
              switch ((Primitive) leftType) {
                case MByte:
                case MChar:
                case MShort:
                case MInt: {
                  expr.getLeft().compile(pScope, false);
                  expr.getRight().compile(pScope, false);
                  getIntCompiler().compileBuiltinCompareJump(expr, expr.getOperator(), pFallthroughValue ? null : pTrueTarget, pFallthroughValue ? pFalseTarget
                      : null, pScope);
                  return;
                }


                default:
                  break;
              }
            }// TODO Support comparison of objects
            break;
          }
          default:
            break;
        }
        break;
      }
      case FUNCCALL: {
        final FuncCall fc = (FuncCall) pCondition;
        final Expression[] args = fc.getArgs();
        if (fc.getFunctionName().equals("operator!") && ((args == null) || (args.length == 0))
            && (fc.getTarget().getEvalType(pScope).getReferredType() == Primitive.MBoolean)) {
          // A boolean not operator just reverses the conditions
          compileCondition(fc, fc.getTarget(), pFalseTarget, pTrueTarget, !pFallthroughValue, pScope);
          return;
        }
        break;
      }
      default:
        break;
    }
    final TypeRef<?> conditionType = pCondition.compile(pScope, false);
    if (!conditionType.equals(Primitive.MBoolean.getRef())) {
      pScope.getContext().error(pCondition, CompilationErrors.CONDITION_MUST_RETURN_BOOL);
    }
    debugLine(mv, pParentToken);
    if (pFallthroughValue) {
      mv.visitIfEq(pFalseTarget);
    } else {
      mv.visitIfNe(pTrueTarget);
    }
  }

  public void compileLoop(final Loop pLoop, final Scope pScope) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pLoop);
    final Scope scope = pScope.newInternalScope();
    final Label outerScopeStartLabel = mv.visitLabel();

    {
      // init
      final Expression init = pLoop.getInit();
      if (init.getTokenType() == MLang.TUPPLE) {
        for (final Expression e : ((MTupple) init)) {
          e.compile(scope, true);
        }
      } else {
        init.compile(scope, true);
      }
    }

    final Expression preCondition = pLoop.getPrecondition();
    Label preCondStart = null;

    if (preCondition != null) {
      preCondStart = new Label();
      mv.visitGoto(preCondStart);
    }

    final Label loopStart = mv.visitLabel();
    final Label loopEnd = new Label();

    // Body

    pLoop.getBody().compile(scope.newInternalScope(), true);

    // Postcondition
    {
      final Expression postCondition = pLoop.getPostCondition();
      if (postCondition != null) {
        final Scope postConditionScope = scope.newInternalScope();
        final Label postConditionStart = mv.visitLabel();

        final Label postConditionEnd = new Label();
        compileCondition(pLoop, postCondition, postConditionEnd, loopEnd, true, postConditionScope);

        mv.visitLabel(postConditionEnd);
        addScopeDebugInfo(mv, postConditionStart, postConditionEnd, postConditionScope);
      } else if (preCondition == null) {
        pScope.getContext().error(pLoop, "A loop must have at least a precondition or a postcondition");
      }
    }

    {
      final Expression loopBody = pLoop.getLoopBody();
      if (loopBody != null) {
        final Scope bodyScope = scope.newInternalScope();
        final Label bodyStartLable = mv.visitLabel();
        loopBody.compile(bodyScope, true);
        addScopeDebugInfo(mv, bodyStartLable, mv.visitLabel(), bodyScope);
      }
    }

    if (preCondition != null) {
      mv.visitLabel(preCondStart);
      final Label preCondEnd = new Label();
      final Scope preConditionScope = scope.newInternalScope();

      compileCondition(pLoop, preCondition, loopStart, preCondEnd, false, preConditionScope);
      mv.visitLabel(preCondEnd);
      addScopeDebugInfo(mv, preCondStart, preCondEnd, preConditionScope);
    }

    mv.visitLabel(loopEnd);
    addScopeDebugInfo(mv, outerScopeStartLabel, loopEnd, scope);

  }

  public TypeRef<?> compileTupple(final MTupple pTupple, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    final Label startLabel = mv.visitLabel();
    final Scope newScope = pScope.newInternalScope();
    TypeRef<?> result = null;
    for (int i = 0; i < pTupple.size(); ++i) {
      final Expression elem = pTupple.get(i);
      result = elem.compile(newScope, pCleanupStack || ((i + 1) < pTupple.size()));
    }
    if (isDebugLocals()) {
      addScopeDebugInfo(mv, startLabel, mv.visitLabel(), newScope);
    }
    return result;
  }

  public TypeRef<?> compileGetLocalVariable(final LocalVariable pLocalVariable, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final int pos = pLocalVariable.getPos();
    final TypeRef<?> varType = pLocalVariable.getVarType();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the value of a local variable");
      return varType;
    }

    if (varType.getReferredType() instanceof Primitive) {
      switch ((Primitive) varType.getReferredType()) {
        case MBoolean:
        case MChar:
        case MByte:
        case MShort:
        case MInt:
          mv.visitILoad(pos);
          break;
        case MLong:
          mv.visitLLoad(pos);
          break;
        case MFloat:
          mv.visitFLoad(pos);
          break;
        case MDouble:
          mv.visitDLoad(pos);
          break;
      }
    } else { // Reference
      mv.visitALoad(pos);
    }

    return varType;
  }

  public TypeRef<?> compileSetLocalVariable(final LocalVariable pLocalVariable, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final int pos = pLocalVariable.getPos();
    final TypeRef<?> varType = pLocalVariable.getVarType();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);

    if (varType.getReferredType() instanceof Primitive) {
      switch ((Primitive) varType.getReferredType()) {
        case MBoolean:
        case MChar:
        case MByte:
        case MShort:
        case MInt:
          if (!pCleanupStack) {
            mv.visitDup();
          }
          mv.visitIStore(pos);
          break;
        case MLong:
          if (!pCleanupStack) {
            mv.visitDup2();
          }
          mv.visitLStore(pos);
          break;
        case MFloat:
          if (!pCleanupStack) {
            mv.visitDup();
          }
          mv.visitFStore(pos);
          break;
        case MDouble:
          if (!pCleanupStack) {
            mv.visitDup2();
          }
          mv.visitDStore(pos);
          break;
      }
    } else { // Reference
      mv.visitAStore(pos);
    }
    return varType;
  }

  public TypeRef<?> compileGetField(final FieldRef pFieldRef, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final String classDescriptor = pFieldRef.getOwner().getInternalName();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the value of a field");
      return pFieldRef.getVarType();
    }

    if (pFieldRef.isStatic()) {
      mv.visitGetStatic(classDescriptor, pFieldRef.getName(), pFieldRef.getVarType().getDescriptor());
    } else {
      // TODO ensure that we are actually in a nonstatic context
      mv.visitALoad(0);
      mv.visitGetField(classDescriptor, pFieldRef.getName(), pFieldRef.getVarType().getDescriptor());
    }
    return pFieldRef.getVarType();
  }

  public TypeRef<?> compileSetField(final FieldRef pFieldRef, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final String classDescriptor = pFieldRef.getOwner().getInternalName();
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (!pCleanupStack) {
      mv.visitDup_x1();
    }

    if (pFieldRef.isStatic()) {
      mv.visitPutStatic(classDescriptor, pFieldRef.getName(), pFieldRef.getVarType().getDescriptor());
    } else {
      mv.visitPutField(classDescriptor, pFieldRef.getName(), pFieldRef.getVarType().getDescriptor());
    }
    return pFieldRef.getVarType();
  }

  public TypeRef<?> compileCreateArray(final LinedToken<MLang> pToken, final Scope pScope, final ArrayType pArrayType, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the creation of an array. Skipping instruction");
      return pArrayType.getRef();
    }
    if (pArrayType.getElementType().getReferredType() instanceof Primitive) {
      mv.visitNewArray((Primitive) pArrayType.getElementType().getReferredType());
    } else {
      mv.visitANewArray(pArrayType.getElementType().asReferenceType());
    }
    return pArrayType.getRef();
  }

  public TypeRef<?> compileArrayRead(final ArrayType pArrayType, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final TypeRef<?> elementType = pArrayType.getElementType();
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the value of an array element");
      return elementType;
    }

    if (elementType.getReferredType() instanceof Primitive) {
      final Primitive et = (Primitive) elementType.getReferredType();
      switch (et) {
        case MBoolean:
        case MByte:
          mv.visitBALoad();
          return elementType;
        case MChar:
          mv.visitCALoad();
          return elementType;
        case MShort:
          mv.visitSALoad();
          return elementType;
        case MInt:
          mv.visitIALoad();
          return elementType;
        case MLong:
          mv.visitLALoad();
          return elementType;
        case MFloat:
          mv.visitFALoad();
          return elementType;
        case MDouble:
          mv.visitDALoad();
          return elementType;
      }
      throw new IllegalStateException("Should be unreachable");
    } else {
      // otherwise it must be a reference type and loaded with ref load
      mv.visitAALoad();
      return elementType;
    }
  }

  public TypeRef<?> compileArrayWrite(final ArrayType pArrayType, final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final TypeRef<?> elementType = pArrayType.getElementType();
    if (!pCleanupStack) {
      final Type et = elementType.getReferredType();
      final boolean doublesize = ((et == Primitive.MDouble) || (et == Primitive.MLong));
      if (doublesize) {
        mv.visitDup_x1();
      } else {
        mv.visitDup2_x1();
      }
    }

    if (elementType.getReferredType() instanceof Primitive) {
      final Primitive et = (Primitive) elementType.getReferredType();
      switch (et) {
        case MBoolean:
        case MByte:
          mv.visitBAStore();
          return elementType;
        case MChar:
          mv.visitCAStore();
          return elementType;
        case MShort:
          mv.visitSAStore();
          return elementType;
        case MInt:
          mv.visitIAStore();
          return elementType;
        case MLong:
          mv.visitLAStore();
          return elementType;
        case MFloat:
          mv.visitFAStore();
          return elementType;
        case MDouble:
          mv.visitDAStore();
          return elementType;
      }
      throw new IllegalStateException("Should be unreachable");
    } else {
      // otherwise it must be a reference type and loaded with ref load
      mv.visitAAStore();
      return elementType;
    }
  }

  public TypeRef<?> compileGetArrayLength(final Scope pScope, final LinedToken<MLang> pToken, final boolean pCleanupStack) {
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the length of an array");
      return Primitive.MInt.getRef();
    }
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    mv.visitArrayLength();
    return Primitive.MInt.getRef();
  }

  public TypeRef<?> classWrapperCompileTransform(final LinedToken<MLang> pToken, final ClassWrapper<?> pSourceType, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    if (pTargetType.getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) pTargetType.getReferredType();
      final FuncCall call = primitive.unWrap(pToken.getPos(), pSourceType.getJClass(), pExpr);
      return call.compile(pScope, pCleanupStack);
    }
    pExpr.compile(pScope, false);
    debugLine(mv, pToken);

    // TODO actually check that conversion is possible at compile time
    // Can only be a regular cast as this class doesn't wrap primitive wrappers.
    mv.visitCheckCast(pTargetType.asReferenceType().getInternalName());
    if (pCleanupStack) {
      mv.visitPop();
    }
    return pTargetType;
  }

  public TypeRef<?> mClassCompileTransform(final LinedToken<MLang> pToken, final TypeRef<?> pTargetType, final Expression pExpr, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final TypeRef<?> resultType = pExpr.compile(pScope, false);
    if (!pTargetType.isAssignableFrom(resultType)) {
      pScope.getContext().error(null, CompilationErrors.ILLEGAL_CLASS_CAST);
    }
    if (!pCleanupStack) {
      mv.visitDup();
    }
    mv.visitCheckCast(pTargetType.asReferenceType().getInternalName());
    return pTargetType;
  }

  /*
   * ================================================================= /
   * Operations on primitives
   * ================================================================
   */
  public TypeRef<?> compileNull(final Literal<?> pToken, final Scope pScope, final boolean pCleanupStack) {
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding the null value");
      return TypeRef.ANY;
    }
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    mv.visitNull();
    return TypeRef.ANY;
  }

  public TypeRef<?> compileStringConstant(final Literal.ObjectLiteral<String> pToken, final Scope pScope, final boolean pCleanupStack) {
    if (pCleanupStack) {
      pScope.getContext().warning(pToken, "Directly discarding string literal");
      return TypeRef.create(null, String.class);
    }
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    mv.visitLdcInsn(pToken.getObjValue());
    return TypeRef.create(null, String.class);
  }

  public TypeRef<Primitive> compileInstanceof(final LinedToken<MLang> pToken, final TypeRef<? extends ReferenceType> pType, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    mv.visitInstanceOf(pType);
    if (pCleanupStack) {
      mv.visitPop();
    }
    return Primitive.MBoolean.getRef();
  }

  public TypeRef<?> compileShortAssign(final LinedToken<MLang> pToken, final FieldRef pTarget, final BinaryOperatorTokens pOperator, final Expression pRValue, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    if (!pTarget.isStatic()) {
      pScope.resolveSymbol("this").compileRef(pToken, pScope, false);
      mv.visitDup();
    }
    final TypeRef<?> fieldType = compileGetField(pTarget, pScope, pToken, false);
    final TypeRef<?> paramType = pRValue.compile(pScope, false);

    final FunctionRef function = fieldType.getReferredType().resolveFunction(pScope, new Symbol(pToken.getPos(), "operator"
        + pOperator.toString()), paramType);
    TypeRef<?> assignType;
    if (function instanceof BinaryPrimitiveOperator) {
      assignType = ((BinaryPrimitiveOperator) function).compileCall(pScope, false);
    } else {
      assignType = compileCall(fieldType.asReferenceType().getReferredType(), function, pScope, false);
    }
    if (!fieldType.isAssignableFrom(assignType)) {
      pScope.getContext().error(pToken, "The type of the assigned variable is not the type of the field");
    }
    return (compileSetField(pTarget, pScope, pToken, pCleanupStack));
  }

  public TypeRef<?> compileShortAssign(final LinedToken<MLang> pToken, final LocalVariable pTarget, final BinaryOperatorTokens pOperator, final Expression pRValue, final Scope pScope, final boolean pCleanupStack) throws CompilationException {
    //    if (pExpression.getTokenType()==MLang.LITERAL) {
    //      if (pOperator==BinaryOperatorTokens.PLUS || pOperator==BinaryOperatorTokens.MINUS) {
    //        return compileConstInc()
    //      }
    //    }
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final TypeRef<?> fieldType = compileGetLocalVariable(pTarget, pScope, pToken, false);
    final TypeRef<?> paramType = pRValue.compile(pScope, false);

    final FunctionRef function = fieldType.getReferredType().resolveFunction(pScope, new Symbol(pToken.getPos(), "operator"
        + pOperator.toString()), paramType);
    TypeRef<?> assignType;
    if (function instanceof BinaryPrimitiveOperator) {
      assignType = ((BinaryPrimitiveOperator) function).compileCall(pScope, false);
    } else {
      assignType = compileCall(fieldType.asReferenceType().getReferredType(), function, pScope, false);
    }
    if (!fieldType.isAssignableFrom(assignType)) {
      pScope.getContext().error(pToken, "The type of the assigned variable is not the type of the field");
    }
    return (compileSetLocalVariable(pTarget, pScope, pToken, pCleanupStack));
  }

  public void compileObjEquals(final LinedToken<MLang> pToken, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final Label eq = new Label();
    mv.visitIfAcmpEq(eq);
    mv.visitLdc(false);
    final Label ifEnd = new Label();
    mv.visitGoto(ifEnd);
    mv.visitLabel(eq);
    mv.visitLdc(true);
    mv.visitLabel(ifEnd);
  }

  public void compileObjNEquals(final LinedToken<MLang> pToken, final Scope pScope) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    debugLine(mv, pToken);
    final Label eq = new Label();
    mv.visitIfAcmpEq(eq);
    mv.visitLdc(true);
    final Label ifEnd = new Label();
    mv.visitGoto(ifEnd);
    mv.visitLabel(eq);
    mv.visitLdc(false);
    mv.visitLabel(ifEnd);
  }

}
