package net.devrieze.meta.compile;

import java.util.EnumSet;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;

import static org.objectweb.asm.Opcodes.*;

import meta.lang.AttributeFlags;
import meta.lang.ClassFlags;
import meta.lang.FunctionFlags;


public class MyClassWriter {

  public static enum ClassVersion {
    V11(V1_1),
    V12(V1_2),
    V13(V1_3),
    V14(V1_4),
    V15(V1_5),
    V16(V1_6);

    private final int aVersionCode;

    private ClassVersion(final int pVersionCode) {
      aVersionCode = pVersionCode;
    }

    public int toInt() {
      return aVersionCode;
    }
  }

  private final ClassWriter aClassWriter;

  public MyClassWriter(final ClassWriter pClassWriter) {
    aClassWriter = pClassWriter;
  }

  public MyMethodVisitor visitMethod(final EnumSet<FunctionFlags> pFlags, final String pName, final String pDescriptor, final String pSignature, final String[] pExceptions) {
    final int flags = calcFunctionFlags(pFlags);
    final MyMethodVisitor result = new MyMethodVisitor(aClassWriter.visitMethod(flags, pName, pDescriptor, pSignature, pExceptions));
    return result;
  }

  private static int calcFunctionFlags(final EnumSet<FunctionFlags> pFlags) {
    int result = 0;
    for (final FunctionFlags f : pFlags) {
      result += f.getFlagValue();
    }
    return result;
  }

  public void visit(final ClassVersion pVersion, final EnumSet<ClassFlags> pFlags, final MangledClassName pName, final String pSignature, final String pSuperName, final String[] pInterfaces) {
    aClassWriter.visit(pVersion.toInt(), calcClassFlags(pFlags) | ACC_SUPER, pName.toString(), pSignature, pSuperName, pInterfaces);
  }

  private static int calcClassFlags(final EnumSet<ClassFlags> pFlags) {
    int result = 0;
    for (final ClassFlags f : pFlags) {
      result += f.getFlagValue();
    }
    return result;
  }

  public void visitSource(final String pFilename) {
    assert pFilename.indexOf('/') < 0;
    aClassWriter.visitSource(pFilename, null);
  }

  public void visitEnd() {
    aClassWriter.visitEnd();
  }

  public byte[] toByteArray() {
    return aClassWriter.toByteArray();
  }

  public FieldVisitor visitField(final EnumSet<AttributeFlags> pFlags, final String pName, final String pDesc, final String pSignature, final Object pValue) {
    return aClassWriter.visitField(calcFieldFlags(pFlags), pName, pDesc, pSignature, pValue);
    // TODO Perhaps just close of the field here as well
  }

  private static int calcFieldFlags(final EnumSet<AttributeFlags> pFlags) {
    int result = 0;
    for (final AttributeFlags flag : pFlags) {
      result += flag.getFlagValue();
    }
    return result;
  }

}
