package net.devrieze.meta.compile;

import org.objectweb.asm.Label;

import meta.lang.Literal.FloatLiteral;
import meta.lang.TypeRef;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public class FloatPrimitiveCompiler {

  private final JavaCompiler aJavaCompiler;

  public FloatPrimitiveCompiler(final JavaCompiler pJavaCompiler) {
    aJavaCompiler = pJavaCompiler;
  }

  public TypeRef<?> compileFloatLiteral(final FloatLiteral pFloatLiteral, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pFloatLiteral);
    mv.visitLdc(pFloatLiteral.getValue());
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pFloatLiteral, "Discarding the value of a literal makes no sense");
    }
    return pFloatLiteral.getValueType();
  }

  public void compileBuiltinAddFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFAdd();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinDivFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFDiv();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMinusFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFSub();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinModFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFRem();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinMultFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFMul();
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinEqualsFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFCmp();
    final Label elseLabel = new Label();
    mv.visitIfNe(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    final Label elseLabel = new Label();
    mv.visitFCmp();
    mv.visitIfGt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinGreaterEqFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFCmp();
    final Label elseLabel = new Label();
    mv.visitIfGe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinUnequalsFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFCmp();
    final Label elseLabel = new Label();
    mv.visitIfEq(elseLabel);
    mv.visitLdc(true);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(false);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFCmp();
    final Label elseLabel = new Label();
    mv.visitIfLt(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

  public void compileBuiltinLessEqFloat(final LinedToken<MLang> pToken, final Scope pScope, final boolean pCleanupStack) {
    final MyMethodVisitor mv = pScope.getMethodVisitor();
    aJavaCompiler.debugLine(mv, pToken);
    mv.visitFCmp();
    final Label elseLabel = new Label();
    mv.visitIfLe(elseLabel);
    mv.visitLdc(false);
    final Label endLabel = new Label();
    mv.visitGoto(endLabel);
    mv.visitLabel(elseLabel);
    mv.visitLdc(true);
    mv.visitLabel(endLabel);
    if (pCleanupStack) {
      mv.visitPop();
      pScope.getContext().warning(pToken, "Discarding the result of a primitive operator makes no sense");
    }
  }

}
