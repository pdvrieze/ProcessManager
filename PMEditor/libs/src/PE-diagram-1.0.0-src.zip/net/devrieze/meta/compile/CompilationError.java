package net.devrieze.meta.compile;

import net.devrieze.parser.Token;


public class CompilationError extends CompilationException {

  private static final long serialVersionUID = 5939302181812482510L;

  public CompilationError(final Token<?> pToken, final String pMessage) {
    super(pToken, pMessage);
  }

  public CompilationError(final Token<?> pToken, final Throwable pCause, final String pMessage) {
    super(pToken, pCause, pMessage);
  }

  public CompilationError(final Token<?> pToken, final Throwable pCause) {
    super(pToken, pCause);
  }

}
