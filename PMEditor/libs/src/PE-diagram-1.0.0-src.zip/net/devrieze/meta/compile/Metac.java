package net.devrieze.meta.compile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.devrieze.meta.parser.MetaParser;
import net.devrieze.meta.tokens.FileToken;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.streams.FileTokenStream;


public class Metac {

  public static void main(final String[] args) {
    boolean usage = false;
    boolean verbose = false;
    String destdir = "";
    if (args.length < 1) {
      usage = true;
      System.out.println("Usage: metac [-d destDir] filename...");
      System.exit(1);
    }
    final List<String> files = new ArrayList<>(args.length);
    for (int i = 0; i < args.length; ++i) {
      if ("-d".equals(args[i])) {
        if (((i + 1) >= args.length) || (destdir.length() > 0)) {
          usage = true;
          break;
        }
        ++i;
        destdir = args[i];
      } else if ("-v".equals(args[i])) {
        verbose = true;
      } else {
        files.add(args[i]);
      }
    }
    if (files.size() == 0) {
      usage = true;
    }
    if (usage || (files.size() == 0)) {
      System.out.println("Usage: metac [-d destDir] filename...");
      System.exit(1);
    }

    final MCompiler compiler = new MCompiler();


    try {
      final File destDir = destdir.length() > 0 ? new File(destdir) : new File(".");
      for (final String file : files) {
        if (verbose) {
          System.out.print(file);
          System.out.print(": ");
        }
        final Scope scope = Scope.fileScope(compiler.getContext());
        final FileToken result;
        try(final FileTokenStream in = new FileTokenStream(new File(file));
            final MetaParser parser = new MetaParser(in, scope)) {
          result = parser.parseFile();
        }
        if (verbose) {
          System.out.print('.');
        }
        final List<CompilationResult> compileResults = compiler.compile(result, scope);
        if (verbose) {
          System.out.print('.');
        }
        final CompilerClassLoader classLoader = compiler.getContext().getClassLoader();
        for (final CompilationResult compileResult : compileResults) {
          classLoader.define(compileResult);
          if (verbose) {
            System.out.print('.');
          }
          saveClass(destDir, compileResult);
          if (verbose) {
            System.out.print('(' + compileResult.getMClass().getName() + ')');
          }
        }
        if (verbose) {
          System.out.println();
        }
      }
    } catch (final TokenException ex) {
      if (verbose) {
        System.out.println();
        ex.printStackTrace();
      } else {
        System.err.println("ERROR: " + ex.getMessage());
      }
      System.exit(2);
    } catch (final Exception ex) {
      if (verbose) {
        System.out.println();
      }
      ex.printStackTrace();
      System.exit(3);
    }
  }

  private static void saveClass(final File pDestdir, final CompilationResult pClass) {
    final File baseDir = pDestdir;
    if (!baseDir.isDirectory()) {
      throw new IllegalArgumentException("The destination " + baseDir + " is not a directory");
    }
    final String name = pClass.getMClass().getName().replace('.', File.separatorChar);
    final File newFile = new File(baseDir, name + ".class");
    if (newFile.getParentFile().exists() || newFile.getParentFile().mkdirs()) {
      FileOutputStream out;
      try {
        out = new FileOutputStream(newFile);
        try {
          out.write(pClass.getByteArray());
        } finally {
          out.close();
        }
      } catch (final IOException ex) {
        ex.printStackTrace();
      }
    }
  }

}
