package net.devrieze.meta.compile;


public interface MFlags {

  public String getRepr();

  public String toMetaCode();

  public int getFlagValue();
}
