package net.devrieze.meta.compile;


public enum CompilationErrors {
  ILLEGAL_CLASS_CAST("Illegal class cast"),
  TUPPLE_NO_FLAG("Tupples do not have annotations"),
  KEYWORD_NO_FLAG("Keywords do not have annotations"),
  UNKNOWN_FLAG("Unknown flag"),
  UNEXPECTED_TOKEN("The token is not expected in this place"),
  IS_NOT_EXPR("The token is not an expression"),
  PSYCHIC_ASSIGN("A variable declaration must either have a value, or a specified type"),
  UNRESOLVED_SYMBOL("The symbol could not be resolved"),
  NO_MULTIPLE_INHERITANCE("Multiple inheritance is not yet enabled"),
  INVALID_ARGUMENT_COUNT("The amount of parameters is wrong"),
  UNREACHABLE_CODE("The code is unreachable"),
  MISMATCHING_RETURN_TYPES("The return types do not match"),
  THROW_MUST_RETURN_THROWABLE("Throw must return a Throwable"),
  ILLEGAL_FUNCTION_TYPE_LITERAL("The token is not expected in a function type literal"),
  EXPECT_SYMBOL("Symbol expected but not found"),
  ASSIGN_TO_CONST("Assigning to a final variable is not allowed"),
  EXPECT_THEN("Expected \"then\""),
  FUNCTION_NOT_RESOLVED("The function could not be resolved"),
  CONDITION_MUST_RETURN_BOOL("A conditional must result in a boolean value");
  ;

  final String aMessage;

  private CompilationErrors(final String pMessage) {
    aMessage = pMessage;
  }

  public String getMessage() {
    return aMessage;
  }

}
