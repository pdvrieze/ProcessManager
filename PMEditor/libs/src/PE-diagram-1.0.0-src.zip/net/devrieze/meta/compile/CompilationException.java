package net.devrieze.meta.compile;

import net.devrieze.parser.Token;
import net.devrieze.parser.TokenException;


public abstract class CompilationException extends TokenException {

  private static final long serialVersionUID = -407860270557415846L;

  public CompilationException(final Token<?> pToken, final String pMessage) {
    super(pToken, pMessage);
  }

  public CompilationException(final Token<?> pToken, final Throwable pCause) {
    super(pToken, pCause);
  }

  public CompilationException(final Token<?> pToken, final Throwable pCause, final String pMessage) {
    super(pToken, pCause, pMessage);
  }

}
