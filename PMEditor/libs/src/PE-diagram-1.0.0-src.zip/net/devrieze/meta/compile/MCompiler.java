package net.devrieze.meta.compile;

import java.util.LinkedList;
import java.util.List;

import meta.lang.Expression;
import meta.lang.MClass;

import net.devrieze.meta.tokens.FileToken;
import net.devrieze.meta.tokens.PackageDecl;


public class MCompiler {

  private final CompilationContext aCompilationContext;

  public MCompiler() {
    aCompilationContext = new CompilationContext();
  }

  public <T> Class<? extends T> compile(final MClass pAst, /* String pClassName, */final Class<T> pSuper, final CompilationContext pContext) throws CompilationException {
    return loadClass(pSuper, compile(pAst, pContext));
  }

  private static CompilationResult compile(final MClass pAst, final CompilationContext pContext) throws CompilationException {
    final Scope scope = getDefaultScope(pContext);
    final CompilationResult result = pAst.compileClass(scope);
    return result;
  }

  private <T> Class<? extends T> loadClass(final Class<T> pSuper, final CompilationResult pCompilationResult) {
    final CompilerClassLoader newLoader = aCompilationContext.getClassLoader();
    final Class<?> pNewClass = newLoader.define(pCompilationResult);
    return pNewClass.asSubclass(pSuper);
  }

  public CompilationContext getContext() {
    return aCompilationContext;
  }

  public List<CompilationResult> compile(final FileToken pFile, final Scope pScope) throws CompilationException {
    final LinkedList<CompilationResult> result = new LinkedList<>();
    final List<Expression> body = pFile.getBody().asList();
    for (final Expression elem : body) {
      switch (elem.getTokenType()) {
        case CLASS:
          final MClass clazz = (MClass) elem;
          result.add(clazz.compileClass(pScope));
          break;
        case PACKAGEDECL:
          pScope.setPackage(((PackageDecl) elem).getPackage()); // XXX This is double
          break;
        default:
          aCompilationContext.error(elem, "Unexpected token as toplevel of a file");
      }
    }
    return result;
  }

  private static Scope getDefaultScope(final CompilationContext pContext) throws CompilationException {
    final Scope result = Scope.fileScope(pContext);
    return result;
  }

}
