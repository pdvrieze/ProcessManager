package net.devrieze.meta.compile;

import java.util.*;

import meta.lang.*;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.eval.ClassInstance;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.EvaluationException;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.LinePosition;


public class Scope {


  private static class FunctionScope extends Scope {

    private final boolean aInConstructor;

    public FunctionScope(final Scope pParent, final int pNextLocalPos, final boolean pInConstructor) {
      super(pParent, pNextLocalPos);
      aInConstructor = pInConstructor;
    }

    @Override
    public boolean inConstructor() {
      return aInConstructor;
    }


  }

  public static abstract class Node {

    public abstract NamedObject getObject();

  }

  public static abstract class VarNode extends Node {

    public abstract void setValue(Literal<?> pValue, Scope pScope) throws CompilationException;

    // no use yet. 

    public abstract Literal<?> getValue();
  }

  public static final class LocalVarNode extends VarNode {

    private final LocalVariable aLocal;

    private Literal<?> aValue;

    public LocalVarNode(final LocalVariable pLocal) {
      aLocal = pLocal;
    }

    @Override
    public LocalVariable getObject() {
      return aLocal;
    }

    @Override
    public void setValue(final Literal<?> pValue, final Scope pScope) throws CompilationException {
      if (aValue != null) {
        if (!aValue.getValueType().isAssignableFrom(pValue.getValueType())) {
          pScope.getContext().error(pValue, "Assigning incompatible type to variable");
        }
      }
      aValue = pValue;
    }

    @Override
    public Literal<?> getValue() {
      return aValue;
    }

    @Override
    public String toString() {
      return aLocal.getPos() + " : " + aLocal.getVarType().toMetaCode(0) + (aValue == null ? "" : aValue.getObjValue().toString());
    }

  }

  public static final class FieldInstanceNode extends FieldNode {

    private Literal<?> aValue;

    public FieldInstanceNode(final FieldRef pFieldRef, final Literal<?> pValue) {
      super(pFieldRef);
      aValue = pValue;
    }

    @Override
    public Literal<?> getValue() {
      return aValue;
    }

    @Override
    public void setValue(final Literal<?> pValue, final Scope pScope) throws CompilationException {
      if (aValue != null) {
        if (!aValue.getValueType().isAssignableFrom(pValue.getValueType())) {
          pScope.getContext().error(pValue, "Assigning incompatible type to variable");
        }
      }
      aValue = pValue;
    }

    @Override
    public String toString() {
      return super.toString() + " = " + aValue.getObjValue().toString();
    }

  }

  public static class FieldNode extends VarNode {

    private final FieldRef aFieldRef;

    public FieldNode(final FieldRef pFieldRef) {
      aFieldRef = pFieldRef;
    }

    @Override
    public FieldRef getObject() {
      return aFieldRef;
    }

    @Override
    public void setValue(final Literal<?> pValue, final Scope pScope) throws CompilationException {
      // TODO Auto-generated method stub
      // 
      throw new UnsupportedOperationException("Seting static field values in evaluation mode not yet implemented");
    }

    @Override
    public Literal<?> getValue() {
      // TODO Auto-generated method stub
      // return null;
      throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public String toString() {
      return aFieldRef.getName() + " : " + aFieldRef.getVarType().toMetaCode(0);
    }

  }

  public static final class FunctionNode extends Node {

    private final FunctionRef aFunctionRef;

    public FunctionNode(final FunctionRef pFunctionRef) {
      aFunctionRef = pFunctionRef;
    }

    @Override
    public FunctionRef getObject() {
      return aFunctionRef;
    }

    @Override
    public String toString() {
      return aFunctionRef.toString();
    }
  }

  public static final class TypeNode extends Node {

    private final Type aType;

    public TypeNode(final Type pType) {
      aType = pType;
    }

    @Override
    public Type getObject() {
      return aType;
    }

    @Override
    public String toString() {
      return "type " + aType.toString();
    }
  }

  private static class ClassScope extends Scope {

    public final MClass aClass;

    public ClassScope(final Scope pParent, final MClass pClass) {
      super(pParent, 0);
      aClass = pClass;
    }

    @Override
    protected FieldNode localFieldNameHook(final String pName) throws CompilationException {
      return node(aClass.resolveField(new Symbol(null, pName), this));
    }

    @Override
    protected NamedObject localFunctionNameHook(final LinePosition pPos, final Symbol pFunctionName, final TypeRef<?>[] pParamTypes) throws CompilationException {
      return aClass.resolveFunction(this, pFunctionName, pParamTypes);
    }

  }

  public static final class ClassInstanceScope extends ClassScope {

    private final ClassInstance aClassInstance;

    public ClassInstanceScope(final Scope pParent, final ClassInstance pClassInstance) {
      super(pParent, pClassInstance.getReferredType().getReferredType());
      aClassInstance = pClassInstance;
    }

    @Override
    protected FieldNode localFieldNameHook(final String pName) throws CompilationException {
      final FieldRef result = aClass.resolveField(new Symbol(null, pName), this);
      if (result.isStatic()) {
        return node(result);
      } else {
        return null;
      }
    }

    public void addInstanceField(final EnumSet<AttributeFlags> pFlags, final String pName, final TypeRef<?> pType, final Literal<?> pValue) {
      final FieldRef fieldRef = new FieldRef(pFlags, aClassInstance.getReferredType(), new Symbol(null, pName), pType);
      final FieldInstanceNode fn = new FieldInstanceNode(fieldRef, pValue);
      putName(pName, fn);
    }

  }

  private final Scope aParent;

  private final Map<String, Node> aNames;

  private int aNextLocalPos;

  private final List<String> aImports;

  private final CompilationContext aContext;

  private String aPackage;

  private Map<String, TypeRef<?>> aTypeCache = null;

  private Set<String> aMissingTypes = null;

  protected Scope(final CompilationContext pContext) {
    if (pContext == null) {
      throw new NullPointerException();
    }
    aParent = null;
    aNextLocalPos = 0;
    aNames = new HashMap<>();
    aImports = new ArrayList<>();
    aPackage = null;
    aContext = pContext;
  }

  protected Scope(final Scope pParent, final int pNextLocalPos) {
    aParent = pParent;
    aNextLocalPos = pNextLocalPos;
    aNames = new HashMap<>();
    aImports = new ArrayList<>();
    aPackage = null;
    if ((pParent == null) || (pParent.getContext() == null)) {
      throw new NullPointerException();
    }
    aContext = pParent.getContext();
  }

  public static Scope fileScope(final CompilationContext pContext) throws CompilationException {
    final Scope result = new Scope(pContext);
    result.addPackageImport("meta.lang");
    result.addPackageImport("meta.lang.lib");
    result.addPackageImport("java.lang");
    for (final Primitive primitive : Primitive.values()) {
      result.addType(primitive);
    }
    return new Scope(result, 0);
  }

  public Scope newFunctionScope(final Function pFunction) throws CompilationException {
    final Scope result = new FunctionScope(this, 0, pFunction.isConstructor(this));
    // Add this object to the scope (if not a static method)
    if (!pFunction.getFunctionType().isStatic()) {
      result.addParam(new Symbol(pFunction.getPos(), "this"), pFunction.getFunctionType().getOwner());
    }
    // Add parameters to the scope
    for (final VarAssign param : pFunction.getFunctionType().getParams()) {
      result.addParam(MEvaluator.toSymbol(param.getLValue()), MEvaluator.toTypeRef(param.getValueType(), this));
    }
    return result;
  }

  public Scope newClassScope(final MClass pClass) {
    return new ClassScope(this, pClass);
  }

  public Scope.ClassInstanceScope newClassInstanceScope(final ClassInstance pClassInstance) {
    return new ClassInstanceScope(this, pClassInstance);
  }

  public Scope newInternalScope() {
    return new Scope(this, aNextLocalPos);
  }

  public Scope newDefaultSubScope() {
    return new Scope(this, aNextLocalPos);
  }

  private static LocalVarNode node(final LocalVariable pLocal) {
    if (pLocal == null) {
      return null;
    }
    return new LocalVarNode(pLocal);
  }

  private static FieldNode node(final FieldRef pFieldRef) {
    if (pFieldRef == null) {
      return null;
    }
    return new FieldNode(pFieldRef);
  }

  private static Node node(final FunctionRef pFunctionRef) {
    if (pFunctionRef == null) {
      return null;
    }
    return new FunctionNode(pFunctionRef);
  }

  private static Node node(final Type pType) {
    if (pType == null) {
      return null;
    }
    return new TypeNode(pType);
  }

  protected void putName(final String pName, final Node pNode) {
    aNames.put(pName, pNode);
  }

  public void addParam(final Symbol pSymbolName, final TypeRef<?> pType) {
    aNames.put(pSymbolName.getName(), node(new LocalVariable(pSymbolName, aNextLocalPos++, pType)));
    if ((pType.getReferredType() == Primitive.MLong) || (pType.getReferredType() == Primitive.MDouble)) {
      ++aNextLocalPos;
    }
  }

  public NamedObject addLocal(final Symbol pSymbolName, final TypeRef<?> pType) {
    final LocalVariable result = new LocalVariable(pSymbolName, aNextLocalPos++, pType);
    aNames.put(pSymbolName.getName(), node(result));
    return result;
  }

  public void addField(final List<AnnotateToken> pFlags, final String pName, final TypeRef<?> pOwner, final TypeRef<?> pFieldType) {
    final List<AttributeFlags> flags2 = new ArrayList<>(pFlags.size());
    for (final AnnotateToken flag : pFlags) {
      final AttributeFlags newFlag = AttributeFlags.fromString(flag.getName());
      if (newFlag != null) {
        flags2.add(newFlag);
      }
    }

    EnumSet<AttributeFlags> flags;
    if (flags2.size() == 0) {
      flags = EnumSet.noneOf(AttributeFlags.class);
    } else {
      flags = EnumSet.copyOf(flags2);
    }
    addField(new FieldRef(flags, pOwner, new Symbol(null, pName), pFieldType));
  }

  public void addField(final FieldRef pFieldRef) {
    aNames.put(pFieldRef.getName(), node(pFieldRef));
  }

  public void addFunction(final FunctionRef pFunctionRef) {
    aNames.put(pFunctionRef.getFunctionName(), node(pFunctionRef));
  }

  public void addType(final Type pType) {
    aNames.put(pType.getInternalName(), node(pType));

  }

  public void addTypeImport(final String pString) {
    aImports.add(pString);
  }

  public void addStaticImport(final String pString) throws EvaluationException, CompilationException {
    final int periodIndex = pString.lastIndexOf('.');
    if (periodIndex <= 0) {
      getContext().error("Adding static import to scope without context");
    }
    final TypeRef<? extends JavaReferenceType> type = resolveType(pString.substring(0, periodIndex)).asReferenceType();
    final String method = pString.substring(periodIndex + 1);
    if (method.equals("*")) {
      addStaticMembers(type);
    } else {
      addStaticMembers(type, method);
    }
    // TODO Auto-generated method stub
    // 
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public void addPackageImport(final String pString) throws CompilationException {
    aImports.add(pString + ".*");
    final TypeRef<?> globals = resolveType(pString + ".Globals");
    if (globals != null) {
      final TypeRef<? extends JavaReferenceType> rtglobals = globals.asReferenceType();
      addStaticMembers(rtglobals);
    }
  }

  private void addStaticMembers(final TypeRef<? extends ReferenceType> pType) throws CompilationException {
    addStaticMembers(pType, null);
  }

  private void addStaticMembers(final TypeRef<? extends ReferenceType> pType, final String pName) throws CompilationException {
    {
      final List<FunctionRef> methods = pType.getReferredType().getMethods(new ArrayList<FunctionRef>());
      for (final FunctionRef method : methods) {
        if ((pName == null) || pName.equals(method.getFunctionName())) {
          if (method.isStatic() && method.isPublic()) {
            addFunction(method);
          }
        }
      }
    }
    {
      final List<FieldRef> fields = pType.getReferredType().getFields(new ArrayList<FieldRef>());
      for (final FieldRef field : fields) {
        if ((pName == null) || pName.equals(field.getName())) {
          if (field.isStatic() && field.isPublic()) {
            addField(field);
          }
        }
      }
    }
  }

  public NamedObject resolveSymbol(final String pName) throws CompilationException {
    final Node result = resolveSymbolNode(pName);
    return result == null ? null : result.getObject();
  }

  public Node resolveSymbolNode(final String pName) throws CompilationException {
    Node result = aNames.get(pName);
    if (result != null) {
      return result;
    }
    result = localFieldNameHook(pName);
    if (result != null) {
      return result;
    }

    if (aParent != null) {
      result = aParent.resolveSymbolNode(pName);
      if (result != null) {
        return result;
      }
    }
    final TypeRef<?> resultRef = resolveTypeLocal(pName);
    return resultRef == null ? null : node(resultRef.getReferredType());
  }

  /**
   * A hook that subclasses can implement to add symbols
   * 
   * @param pName The name to look for.
   * @throws CompilationException
   */
  protected FieldNode localFieldNameHook(final String pName) throws CompilationException {
    return null;
  }

  public TypeRef<?> resolveType(final String pName) {
    if (pName.indexOf('.') >= 0) {
      return tryResolve(pName);
    }
    final Node node = aNames.get(pName);
    final NamedObject result = node == null ? null : node.getObject();
    /*
     * Can never be true as TypeRef is not a NamedObject if (result instanceof
     * TypeRef) { return (TypeRef<?>) result; } else
     */
    if (result instanceof JavaType) {
      return TypeRef.create(null, (JavaType) result);

    }
    if (aParent != null) {
      final TypeRef<?> result2 = aParent.resolveType(pName);
      if (result2 != null) {
        return result2;
      }
    }
    return resolveTypeLocal(pName);
  }

  /**
   * A nonrecursive version of resolveType
   * 
   * @param pName the name to resolve
   * @return
   */
  private TypeRef<?> resolveTypeLocal(final String pName) {
    {
      final TypeRef<?> result = getTypeCache().get(pName);
      if (result != null) {
        return result;
      }
      if (getMissingTypes().contains(pName)) {
        return null;
      }
    }
    if (aPackage != null) {
      final TypeRef<?> result = tryResolve(aPackage + '.' + pName);
      if (result != null) {
        getTypeCache().put(pName, result);
        return result;
      }
    } else {
      final TypeRef<?> result = tryResolve(pName);
      if (result != null) {
        getTypeCache().put(pName, result);
        return result;
      }
    }
    for (final String im : aImports) {
      String name;
      if (im.charAt(im.length() - 1) == '*') {
        name = new StringBuilder((im.length() - 1) + pName.length()).append(im).deleteCharAt(im.length() - 1).append(pName).toString();
      } else if (!im.endsWith('.' + pName)) {
        continue;
      } else {
        name = im;
      }
      final TypeRef<?> result = tryResolve(name);
      if (result != null) {
        getTypeCache().put(pName, result);
        return result;
      }
    }
    getMissingTypes().add(pName);
    return null;
  }

  private TypeRef<?> tryResolve(final String pName) {
    // TODO Search without relying on exceptions
    try {
      final Class<?> result = Class.forName(pName, false, getClass().getClassLoader());
      return TypeRef.create(null, result);
    } catch (final ClassNotFoundException e) {
      if (pName.startsWith("meta.lang.lib.Globals")) {
        e.printStackTrace();
      }
      return null;
    }
  }

  public FunctionRef resolveFunction(final Symbol pFunctionName, final TypeRef<?>[] pParamTypes) throws CompilationException {
    final LinePosition pos = pFunctionName.getPos();
    // TODO support overloading
    {
      final Node result = aNames.get(pFunctionName.getName());
      if (result != null) {
        if (!(result instanceof FunctionNode)) {
          getContext().error(pFunctionName, "The name " + pFunctionName + " does not resolve to a function but to a " + result.getClass());
          return null;
        }
        return ((FunctionNode) result).getObject();
      }
    }
    NamedObject result2 = localFunctionNameHook(pos, pFunctionName, pParamTypes);
    if (result2 != null) {
      return (FunctionRef) result2;
    }
    if (aParent != null) {
      result2 = aParent.resolveFunction(pFunctionName, pParamTypes);
      if (result2 != null) {
        return (FunctionRef) result2;
      }
    }
    final TypeRef<?> clazz = resolveTypeLocal(pFunctionName.getName());
    return clazz == null ? null : clazz.resolveFunction(this, new Symbol(pFunctionName.getPos(), "<init>"), pParamTypes);
  }

  /**
   * @param pPos
   * @param pFunctionName
   * @param pParamTypes
   * @throws CompilationException
   */
  protected NamedObject localFunctionNameHook(final LinePosition pPos, final Symbol pFunctionName, final TypeRef<?>[] pParamTypes) throws CompilationException {
    return null;
  }

  public List<LocalVariable> getLocals() {
    final ArrayList<LocalVariable> result = new ArrayList<>();
    for (final Node name : aNames.values()) {
      if (name instanceof LocalVarNode) {
        result.add(((LocalVarNode) name).getObject());
      }
    }
    return result;
  }

  public String getPackage() {
    if ((aPackage == null) && (aParent != null)) {
      return aParent.getPackage();
    }
    return aPackage;
  }

  public void setPackage(final String pPackage) {
    aPackage = pPackage.replace('.', '/');
  }

  public CompilationContext getContext() {
    return aContext;
  }

  public JavaCompiler getCompiler() {
    return aContext.getCompiler();
  }

  public MyMethodVisitor getMethodVisitor() {
    return aContext.getMethodVisitor();
  }

  /**
   * Get the value of the symbol with that name
   * 
   * @category dynamic
   * @param pName
   * @return
   * @throws EvaluationException
   * @throws CompilationException
   */
  public Literal<?> getValue(final Symbol pName) throws CompilationException {
    final String name = pName.getName();
    final Node node = resolveSymbolNode(name);
    VarNode var;
    if (node == null) {
      getContext().error(pName, "Symbol " + name + " not found");
      return null;
    } else if (!(node instanceof VarNode)) {
      getContext().error(pName, "Type mismatch when setting a variable");
      return null;
    }
    var = (VarNode) node;
    final Literal<?> result = var.getValue();
    if (result == null) {
      getContext().error(pName, "The symbol " + name + " has not been initialised");
    }
    return result;
  }

  public void setVar(final NamedObject pObject, final Literal<?> pNewValue) throws CompilationException {
    if (pObject instanceof LocalVariable) {
      final LocalVariable local = (LocalVariable) pObject;
      setVar(local.getSymbol(), pNewValue);
      return;
    } else if (pObject instanceof FieldRef) {
      final FieldRef fr = (FieldRef) pObject;
      final Node node = resolveSymbolNode(fr.getName());
      if (node instanceof FieldNode) {
        ((FieldNode) node).setValue(pNewValue, this);
        return;
      }
    }
    // TODO Auto-generated method stub
    // 
    throw new UnsupportedOperationException("Not yet implemented");
  }

  /**
   * @category dynamic
   * @param pName
   * @param pResult
   * @param pContext
   * @throws CompilationException
   * @throws EvaluationException
   */
  public void setVar(final Symbol pName, final Literal<?> pValue) throws CompilationException {
    final Node node = resolveSymbolNode(pName.getName());
    VarNode var;
    if (node == null) {
      var = node(new LocalVariable(pName, aNextLocalPos, pValue.getEvalType(this)));
      ++aNextLocalPos;
      aNames.put(pName.getName(), var);
    } else if (!(node instanceof VarNode)) {
      getContext().error(pValue, "Type mismatch when setting a variable");
      return;
    } else {
      var = (VarNode) node;
    }
    var.setValue(pValue, this);
  }

  private Map<String, TypeRef<?>> getTypeCache() {
    if (aTypeCache == null) {
      aTypeCache = new HashMap<>();
    }
    return aTypeCache;
  }

  private Set<String> getMissingTypes() {
    if (aMissingTypes == null) {
      aMissingTypes = new HashSet<>();
    }
    return aMissingTypes;
  }

  @Override
  public String toString() {
    return aParent == null ? aNames.toString() : (aNames.toString() + '\n' + aParent.toString());
  }

  public boolean inConstructor() {
    if (aParent == null) {
      return false;
    }
    return aParent.inConstructor();
  }

  public Literal<?> expectLiteral(final EvalResult pResult) {
    if (!(pResult instanceof Literal)) {
      getContext().warning(null, "Return from within an expression. Using the return value as simple value,discarding return.");
    }
    return pResult == null ? null : pResult.toLiteral();
  }

}
