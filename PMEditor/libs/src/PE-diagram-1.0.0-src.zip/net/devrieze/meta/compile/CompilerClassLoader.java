package net.devrieze.meta.compile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class CompilerClassLoader extends ClassLoader {

  public static boolean first = true;

  private final Map<String, Class<?>> aDefinedClasses;

  public CompilerClassLoader(final ClassLoader pParent) {
    super(pParent);
    //    if (!first) {
    //      // This is for debugging
    //      throw new IllegalStateException("The classloader should now only be instantiated once");
    //    }
    //    first = false;
    aDefinedClasses = new HashMap<>();
  }

  public Class<?> define(final byte[] pByteCode) {
    final Class<?> result;
    try {
      result = defineClass(null, pByteCode, 0, pByteCode.length);
      saveClass(result.getCanonicalName(), pByteCode);
    } catch (final Error e) {
      final StringBuilder newMessage = new StringBuilder(e.getMessage());
      newMessage.append("\nDefined classes are:\n");
      final ArrayList<String> keylist = new ArrayList<>(aDefinedClasses.keySet());
      Collections.sort(keylist);
      for (final String name : keylist) {
        newMessage.append("  ").append(name).append('\n');
      }
      newMessage.append("=====================\n");
      final NoClassDefFoundError newEx = new NoClassDefFoundError(newMessage.toString());
      newEx.setStackTrace(e.getStackTrace());
      newEx.initCause(e.getCause());
      throw newEx;
    }
    aDefinedClasses.put(result.getName(), result);
    return result;
  }

  public Class<?> define(final CompilationResult pCompilationResult) {
    final byte[] byteCode = pCompilationResult.getByteArray();
    //    final String className = pCompilationResult.getMClass().getInternalName().replace('/', '.');
    final Class<?> result;
    try {
      result = defineClass(null, byteCode, 0, byteCode.length);
      //      System.err.println("Defined class \""+result.getName()+"\" - expecting: \""+className+"\"");
      saveClass(result.getCanonicalName(), byteCode);
    } catch (final Error e) {
      final StringBuilder newMessage = new StringBuilder(e.getMessage());
      newMessage.append("\nDefined classes are:\n");
      final ArrayList<String> keylist = new ArrayList<>(aDefinedClasses.keySet());
      Collections.sort(keylist);
      for (final String name : keylist) {
        newMessage.append("  ").append(name).append('\n');
      }
      newMessage.append("=====================\n");
      final NoClassDefFoundError newEx = new NoClassDefFoundError(newMessage.toString());
      newEx.setStackTrace(e.getStackTrace());
      newEx.initCause(e.getCause());
      throw newEx;
    }
    aDefinedClasses.put(result.getName(), result);
    return result;
  }

  /**
   * Hook to allow for saving of loaded classes
   * 
   * @param pName The name of the class
   * @param pByteCode the bytecode
   */
  protected void saveClass(final String pName, final byte[] pByteCode) {
    // By default null
  }

}
