package net.devrieze.meta.compile;

import meta.lang.MClass;


public class CompilationResult {

  private final MClass aMClass;

  private final byte[] aByteArray;

  public CompilationResult(final MClass pClass, final byte[] pByteArray) {
    aMClass = pClass;
    aByteArray = pByteArray;
  }


  public MClass getMClass() {
    return aMClass;
  }


  public byte[] getByteArray() {
    return aByteArray;
  }

}
