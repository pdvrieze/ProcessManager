package net.devrieze.meta.eval;

import java.util.Arrays;

import meta.lang.FunctionRef;
import meta.lang.MClass;

import net.devrieze.meta.compile.CompilationError;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.parser.Token;
import net.devrieze.util.StringUtil;


public class EvalContext {

  MClass aCurrentClass = null;

  public void noSuchMethodError(final FunctionRef pFunction) {
    throw stripLastStackTraceElem(new NoSuchMethodError(pFunction.toString()));
  }

  protected static <T extends Throwable> T stripLastStackTraceElem(final T pE) {
    final StackTraceElement[] oldSt = pE.getStackTrace();
    final StackTraceElement[] newSt = new StackTraceElement[oldSt.length - 1];
    for (int i = newSt.length - 1; i >= 0; --i) {
      newSt[i] = oldSt[i + 1];
    }
    pE.setStackTrace(newSt);
    return pE;
  }

  public void setCurrentClass(final MClass pClass) {
    aCurrentClass = pClass;
  }


  public MClass getCurrentClass() {
    return aCurrentClass;
  }

  public void error(final String pMessage) throws EvaluationError {
    throw stripLastStackTraceElem(new EvaluationError(pMessage));
  }

  public void error(final Token<?> pToken, final EvaluationErrors pMessage, final String... pExtra) throws CompilationException {
    String message;
    if ((pExtra != null) && (pExtra.length > 0)) {
      message = pMessage.getMessage() + ": " + StringUtil.join(", ", Arrays.asList(pExtra));
    } else {
      message = pMessage.getMessage();
    }
    throw stripLastStackTraceElem(new CompilationError(pToken, message));
  }

}
