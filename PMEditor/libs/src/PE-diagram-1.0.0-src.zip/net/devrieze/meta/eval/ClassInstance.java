package net.devrieze.meta.eval;

import meta.lang.*;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.compile.Scope.ClassInstanceScope;


public class ClassInstance /* extends AbstractExpression */{

  private final TypeRef<MClass> aOwner;

  private final ClassInstanceScope aScope;

  public ClassInstance(final TypeRef<MClass> pOwner) throws CompilationException {
    //    super(null);
    aOwner = pOwner;
    aScope = pOwner.getReferredType().getClassInstanceScope(this);
    for (final VarAssign attr : pOwner.getReferredType().getAttributes()) {
      final Symbol name = MEvaluator.toSymbol(attr.getLValue());
      final TypeRef<?> type = MEvaluator.toTypeRef(attr.getValueType(), aScope);
      final Expression rValue = attr.getRValue();
      aScope.addInstanceField(attr.getFlags(aScope), name.getName(), type, rValue == null ? null : MEvaluator.toLiteral(rValue, aScope));
    }
  }

  public TypeRef<MClass> getReferredType() {
    return aOwner;
  }

  // TODO verify that the return value is of the declared type
  public Literal<?> evalFunction(final Function pFunction, final Expression... pArgs) throws CompilationException {
    final Expression[] impl = pFunction.getImplementation();
    final Scope scope = aScope.newFunctionScope(pFunction);
    final VarAssign[] paramDefs = pFunction.getFunctionType().getParams();
    for (int i = 0; i < paramDefs.length; ++i) {
      scope.setVar(MEvaluator.toSymbol(paramDefs[i].getLValue()), (Literal<?>) pArgs[i]);
    }
    EvalResult result = null;
    for (final Expression v : impl) {
      result = v.eval(scope);
      if (result instanceof ReturnValue) {
        break;
      }
    }
    if (pFunction.isConstructor(aScope)) {
      return Literal.create(null, this);
    }
    return result == null ? null : result.toLiteral();
  }

  public Literal<?> evalCall(final FunctionRef pFunction, final Scope pScope, final Literal<?>... pArgs) throws CompilationException {
    final Function f = aOwner.getReferredType().resolveFunction(pFunction);
    if (f == null) {
      pScope.getContext().error(pFunction, EvaluationErrors.NO_SUCH_METHOD, pFunction.getFunctionName());
    }
    return evalFunction(f, pArgs);
  }

}
