package net.devrieze.meta.eval;


public enum EvaluationErrors {
  ILLEGAL_CLASS_CAST("Illegal class cast"),
  NO_SUCH_METHOD("No such method exists"),
  TYPE_ERROR("The type are not compatible"),
  NO_SUCH_VARIABLE("No such variable exists"),
  INVALID_ARGUMENT_COUNT("Invalid amount of arguments"), ;

  final String aMessage;

  private EvaluationErrors(final String pMessage) {
    aMessage = pMessage;
  }

  public String getMessage() {
    return aMessage;
  }

}
