package net.devrieze.meta.eval;

import meta.lang.Throw;

import net.devrieze.meta.compile.CompilationException;


public class EvaluationThrownException extends CompilationException {

  private static final long serialVersionUID = 6331927634129656303L;

  public EvaluationThrownException(final Throw pToken, final Throwable pCause) {
    super(pToken, pCause);
  }

}
