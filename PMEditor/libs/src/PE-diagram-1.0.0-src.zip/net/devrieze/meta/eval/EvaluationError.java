package net.devrieze.meta.eval;

public class EvaluationError extends EvaluationException {

  private static final long serialVersionUID = -1587337945240177037L;

  public EvaluationError(final String pMessage) {
    super(pMessage);
  }

  public EvaluationError(final Throwable pCause, final String pMessage) {
    super(pCause, pMessage);
  }

  public EvaluationError(final Throwable pCause) {
    super(pCause);
  }

}
