package net.devrieze.meta.eval;

import meta.lang.Literal;

import net.devrieze.meta.compile.Scope;


public class ReturnValue implements EvalResult {

  private final Literal<?> aValue;

  public ReturnValue(final Literal<?> pValue) {
    aValue = pValue;
  }

  @Override
  public Literal<?> toLiteral() {
    return aValue;
  }

  @Override
  public Literal<?> expectLiteral(final Scope pScope) {
    return pScope.expectLiteral(this);
  }

}
