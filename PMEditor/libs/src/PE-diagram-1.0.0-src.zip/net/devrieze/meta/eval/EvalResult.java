package net.devrieze.meta.eval;

import meta.lang.Literal;

import net.devrieze.meta.compile.Scope;


public interface EvalResult {

  Literal<?> toLiteral();

  /**
   * Function that ensures that return values result in a warning.
   * 
   * @return the literal
   */
  @Deprecated
  Literal<?> expectLiteral(Scope pScope);

}
