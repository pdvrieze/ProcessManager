package net.devrieze.meta.eval;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import meta.lang.*;
import meta.lang.Literal.BoolLiteral;
import meta.lang.Literal.ByteLiteral;
import meta.lang.Literal.CharLiteral;
import meta.lang.Literal.DoubleLiteral;
import meta.lang.Literal.FloatLiteral;
import meta.lang.Literal.IntLiteral;
import meta.lang.Literal.LongLiteral;
import meta.lang.Literal.ShortLiteral;

import net.devrieze.meta.NamedObject;
import net.devrieze.meta.compile.*;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.MLang;


/** Evaluator for M tokens */
public class MEvaluator {

  public static boolean getBool(final Literal<?> target, final Scope pScope) throws CompilationException {
    if (target.getValueType().getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) target.getValueType().getReferredType();
      switch (primitive) {
        case MBoolean:
          // TODO warn about implicit conversion ??
          return ((BoolLiteral) target).getValue();
        case MByte:
        case MChar:
        case MShort:
        case MInt:
        case MDouble:
        case MLong:
        case MFloat:
          pScope.getContext().error(target, "The type " + primitive.getInternalName() + " can not be implictly converted to boolean");
          return false;
      }
      throw new IllegalStateException("Unreachable code");
    } else if (target.getObjValue() instanceof Boolean) {
      return ((Boolean) target.getObjValue()).booleanValue();
    } else {
      pScope.getContext().error(target, "Objects of any type including " + target.getValueType().getInternalName()
          + " can not be implictly converted to boolean");
      return false;
    }
  }

  public static int getInt(final Literal<?> target, final CompilationContext pContext) throws CompilationException {
    if (target.getValueType().getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) target.getValueType().getReferredType();
      switch (primitive) {
        case MBoolean:
          // TODO warn about implicit conversion ??
          return ((BoolLiteral) target).getValue() ? 1 : 0;
        case MByte:
          return ((ByteLiteral) target).getValue();
        case MChar:
          return ((CharLiteral) target).getValue();
        case MShort:
          return ((ShortLiteral) target).getValue();
        case MInt:
          return ((IntLiteral) target).getValue();
        case MDouble:
        case MLong:
        case MFloat:
          pContext.error(target, "The type " + primitive.getInternalName() + " can not be implictly converted to integer");
          return 0;
      }
      throw new IllegalStateException("Unreachable code");
    } else {
      pContext.error(target, "Objects of any type including " + target.getValueType().getInternalName()
          + " can not be implictly converted to integer");
      return 0;
    }
  }

  public static float getFloat(final Literal<?> target, final CompilationContext pContext) throws CompilationException {
    if (target.getValueType().getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) target.getValueType().getReferredType();
      switch (primitive) {
        case MBoolean:
          // TODO warn about implicit conversion ??
          return ((BoolLiteral) target).getValue() ? 1f : 0f;
        case MByte:
          return ((ByteLiteral) target).getValue();
        case MChar:
          return ((CharLiteral) target).getValue();
        case MShort:
          return ((ShortLiteral) target).getValue();
        case MInt:
        case MDouble:
        case MLong:
          pContext.error(target, "The type " + primitive.getInternalName() + " can not be implictly converted to float");
          return 0;

        case MFloat:
          return ((FloatLiteral) target).getValue();
      }
      throw new IllegalStateException("Unreachable code");
    } else {
      pContext.error(target, "Objects of any type including " + target.getValueType().getInternalName()
          + " can not be implictly converted to float");
      return 0;
    }
  }

  public static double getDouble(final Literal<?> target, final CompilationContext pContext) throws CompilationException {
    if (target.getValueType().getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) target.getValueType().getReferredType();
      switch (primitive) {
        case MBoolean:
          // TODO warn about implicit conversion ??
          return ((BoolLiteral) target).getValue() ? 1.0 : 0.0;
        case MByte:
          return ((ByteLiteral) target).getValue();
        case MChar:
          return ((CharLiteral) target).getValue();
        case MShort:
          return ((ShortLiteral) target).getValue();
        case MInt:
          return ((IntLiteral) target).getValue();
        case MFloat:
          return ((FloatLiteral) target).getValue();
        case MDouble:
          return ((DoubleLiteral) target).getValue();
        case MLong:
          pContext.error(target, "The type " + primitive.getInternalName() + " can not be implictly converted to double");
          return 0;
      }
      throw new IllegalStateException("Unreachable code");
    } else {
      pContext.error(target, "Objects of any type including " + target.getValueType().getInternalName()
          + " can not be implictly converted to double");
      return 0;
    }
  }

  public static long getLong(final Literal<?> target, final CompilationContext pContext) throws CompilationException {
    if (target.getValueType().getReferredType() instanceof Primitive) {
      final Primitive primitive = (Primitive) target.getValueType().getReferredType();
      switch (primitive) {
        case MBoolean:
          // TODO warn about implicit conversion ??
          return ((BoolLiteral) target).getValue() ? 1 : 0;
        case MByte:
          return ((ByteLiteral) target).getValue();
        case MChar:
          return ((CharLiteral) target).getValue();
        case MShort:
          return ((ShortLiteral) target).getValue();
        case MInt:
          return ((IntLiteral) target).getValue();
        case MLong:
          return ((LongLiteral) target).getValue();
        case MFloat:
        case MDouble:
          pContext.error(target, "The type " + primitive.getInternalName() + " can not be implictly converted to long");
          return 0;
      }
      throw new IllegalStateException("Unreachable code");
    } else {
      pContext.error(target, "Objects of any type including " + target.getValueType().getInternalName()
          + " can not be implictly converted to long");
      return 0;
    }
  }

  public static TypeRef<?> toTypeRef(final Expression pExpr, final Scope pScope) throws CompilationException {
    if (pExpr instanceof TypeRef<?>) {
      return (TypeRef<?>) pExpr;
    } else if (pExpr.getTokenType() == MLang.SYMBOL) {
      final Symbol symbol = (Symbol) pExpr;
      final TypeRef<?> result = pScope.resolveType(symbol.getName());
      if (result != null) {
        return result;
      } else {
        pScope.getContext().error(pExpr, "Type could not be determined");
      }

    } else if (pExpr.getTokenType() == MLang.BINARYOPERATOR) {
      final BinaryExpression binExpr = (BinaryExpression) pExpr;
      if (binExpr.getOperator() == BinaryOperatorTokens.MEMBERACCESS) {
        return toTypeRefHelper(binExpr, pScope);
      }
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented, found: \"" + pExpr + '"');
  }

  private static TypeRef<?> toTypeRefHelper(final BinaryExpression pExpr, final Scope pScope) throws CompilationException {
    final Object result = toTypeRefHelper2(pExpr, pScope);
    if (result instanceof TypeRef) {
      return (TypeRef<?>) result;
    } else {
      pScope.getContext().error(pExpr, "Type " + result.toString() + " not found");
      return null;
    }
  }

  private static Object toTypeRefHelper2(final BinaryExpression pExpr, final Scope pScope) throws CompilationException {
    final Expression left = pExpr.getLeft();
    final Symbol right = (Symbol) pExpr.getRight();
    if (left.getTokenType() == MLang.SYMBOL) {
      final Symbol sLeft = (Symbol) left;
      final String name = sLeft.getName() + '.' + right.getName();
      final TypeRef<?> result = pScope.resolveType(name);
      if (result != null) {
        return result;
      } else {
        return name;
      }
    } else if (left.getTokenType() == MLang.BINARYOPERATOR) {
      final BinaryExpression binExpr = (BinaryExpression) left;
      if (binExpr.getOperator() == BinaryOperatorTokens.MEMBERACCESS) {
        final Object leftResult = toTypeRefHelper2(binExpr, pScope);
        if (leftResult instanceof TypeRef) {
          pScope.getContext().error((TypeRef<?>) leftResult, "Nested types not yet supported");
        } else {
          final String name = ((String) leftResult) + '.' + right.getName();
          final TypeRef<?> result = pScope.resolveType(name);
          if (result != null) {
            return result;
          } else {
            return name;
          }
        }
      }
    }
    throw new UnsupportedOperationException("Can not resolve to type\n" + pExpr);
  }

  public static Symbol toSymbol(final Expression pExpr) {
    if (pExpr instanceof Symbol) {
      return (Symbol) pExpr;
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public static Literal<?> toLiteral(final Expression pTarget, final Scope pScope) throws CompilationException {
    if (pTarget == null) {
      return Literal.createObj(null, TypeRef.ANY, null);
    }
    return pScope.expectLiteral(pTarget.eval(pScope));
  }

  public static EnumSet<ClassFlags> toClassFlags(final List<AnnotateToken> pFlags) {
    final List<ClassFlags> result = new ArrayList<>(pFlags.size());
    for (final AnnotateToken flag : pFlags) {
      final ClassFlags flag2 = ClassFlags.fromString(flag.getName().toString());
      if (flag2 != null) {
        result.add(flag2);
      }
    }
    if (result.size() == 0) {
      return EnumSet.noneOf(ClassFlags.class);
    }
    return EnumSet.copyOf(result);
  }

  public static EnumSet<FunctionFlags> toMethodFlags(final List<AnnotateToken> pFlags) {
    final List<FunctionFlags> result = new ArrayList<>(pFlags.size());
    for (final AnnotateToken flag : pFlags) {
      final FunctionFlags flag2 = FunctionFlags.fromString(flag.getName());
      if (flag2 != null) {
        result.add(flag2);
      }
    }
    if (result.size() == 0) {
      return EnumSet.noneOf(FunctionFlags.class);
    }
    return EnumSet.copyOf(result);
  }

  public static MTupple toTupple(final Expression pExpression) {
    if (pExpression.getTokenType() == MLang.TUPPLE) {
      return (MTupple) pExpression;
    }
    return new MTupple(pExpression.getPos(), pExpression);
    // TODO Auto-generated method stub
    // return null;
    //    throw new UnsupportedOperationException("Not yet implemented, found: \""+pExpression+'"');
  }

  public static VarAssign toVarAssign(final Expression pExpr, final Scope pScope) throws CompilationException {
    if (pExpr.getTokenType() == MLang.VARASSIGN) {
      return (VarAssign) pExpr;
    }
    if (pScope != null) {
      final Literal<?> val = pScope.expectLiteral(pExpr.eval(pScope));
      final Object obj = val == null ? null : val.getObjValue();
      if (obj instanceof VarAssign) {
        return (VarAssign) obj;
      }
      pScope.getContext().error(pExpr, "The expresion does not evaluate to a variable assignment");
      return null;
    }
    return null;
  }

  /**
   * @param pScope XXX go to implement
   */
  public static FunctionType toFunctionType(final Expression pExpr, final Scope pScope) {
    if (pExpr.getTokenType() == MLang.FUNCTYPE) {
      return (FunctionType) pExpr;
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public static TypeRef<?> commonSuperType(final TypeRef<?> pThenReturn, final TypeRef<?> pElseReturn, final Scope pScope) throws CompilationException {
    if (pThenReturn.getReferredType() instanceof Primitive) {
      if (!pThenReturn.equals(pElseReturn)) {
        if (pScope == null) {
          throw new CompilationError(null, "Incompatible return types :" + pThenReturn + " and " + pElseReturn);
        } else {
          pScope.getContext().error(pElseReturn, "Incompatible return types :" + pThenReturn + " and " + pElseReturn);
        }
      }
    }
    // TODO Auto-generated method stub
    // return null;
    throw new UnsupportedOperationException("Not yet implemented");
  }

  public static VarAssign[] toVarAssigns(final Expression[] pParams, final Scope pScope) throws CompilationException {
    if (pParams == null) {
      return new VarAssign[0];
    }
    final VarAssign[] result = new VarAssign[pParams.length];
    for (int i = 0; i < result.length; ++i) {
      result[i] = toVarAssign(pParams[i], pScope);
    }
    return result;
  }

  public static NamedObject getNamedObject(final Expression pTarget, final Scope pScope) throws CompilationException {
    if (pTarget.getTokenType() == MLang.SYMBOL) {
      return pScope.resolveSymbol(((Symbol) pTarget).getName());
    }
    if (pTarget.getTokenType() == MLang.BINARYOPERATOR) {
      final BinaryExpression be = (BinaryExpression) pTarget;
      if (be.getOperator() == BinaryOperatorTokens.MEMBERACCESS) {
        final TypeRef<?> ownerType = be.getLeft().getEvalType(pScope);
        final Symbol right = toSymbol(be.getRight());
        final FieldRef result = ownerType.asReferenceType().getReferredType().resolveField(right, pScope);
        return result;
      }
    }
    return null;
  }

  public static Literal<?>[] toLiterals(final Scope pScope, final Expression... pArgs) throws CompilationException {
    final Literal<?>[] result = new Literal<?>[pArgs.length];
    for (int i = result.length - 1; i >= 0; --i) {
      result[i] = pScope.expectLiteral(pArgs[i].eval(pScope));
      if (result[i] == null) {
        return null;
      }
    }
    return result;
  }

}
