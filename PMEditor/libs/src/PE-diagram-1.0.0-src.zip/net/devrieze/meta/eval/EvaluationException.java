package net.devrieze.meta.eval;


public class EvaluationException extends Exception {

  private static final long serialVersionUID = -947986403278455777L;

  public EvaluationException() {
    super();
  }

  public EvaluationException(final Throwable pCause, final String pMessage) {
    super(pMessage, pCause);
  }

  public EvaluationException(final String pMessage) {
    super(pMessage);
  }

  public EvaluationException(final Throwable pCause) {
    super(pCause);
  }

}
