/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.meta.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import meta.lang.*;

import net.devrieze.lang.Const;
import net.devrieze.meta.compile.CompilationError;
import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.meta.tokens.FileToken;
import net.devrieze.meta.tokens.InstanceofToken;
import net.devrieze.meta.tokens.PackageDecl;
import net.devrieze.parser.AbstractTokenStream;
import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.Token;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.UnexpectedTokenException;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.streams.BinaryOperatorParser;
import net.devrieze.parser.streams.LiteralParser;
import net.devrieze.parser.streams.SymbolParser;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LiteralToken;
import net.devrieze.parser.tokens.OperatorToken;


/**
 * A parser for statements.
 *
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @todo Make the parser provider variable
 */
public class MetaParser extends AbstractTokenStream<FileToken, MLang> implements Iterable<LinedToken<MLang>>, AutoCloseable {


  private static class SymbolFactory extends SymbolParser.SymbolTokenFactory<Symbol> {

    @Override
    protected Symbol createSymbol(final LinePosition pPosition, final String pValue) {
      return new Symbol(pPosition, pValue);
    }

  }

  private final BufferedTokenStream<? extends CharToken, CharStreamEnum> aCharStream;

  private final Scope aScope;

  private final SymbolParser<MLang, Symbol> aSymbolParser;

  private final LiteralParser<MLang> aLiteralParser;

  private final BinaryOperatorParser aBinaryOperatorParser;

  private boolean aError;

  //  private ExpressionParserProvider<MLang> aParserProvider;

  /**
   * @param pParentStream
   */
  public MetaParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream, final Scope pScope) {
    super(pParentStream.getFile());
    aCharStream = pParentStream;
    aScope = pScope;
    aSymbolParser = new SymbolParser<>(true, aCharStream, new SymbolFactory());
    aLiteralParser = new LiteralParser<>(MLang.LITERAL, aCharStream);
    aBinaryOperatorParser = new BinaryOperatorParser(aCharStream);
  }

  public static MTupple toClassBody(final MTupple pBody) {
    return pBody;
    // TODO Auto-generated method stub
    // return null;
    //    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public FileToken getNextToken() throws TokenException {
    return parseFile();
  }

  @Override
  public void close() throws IOException {
    aCharStream.close();
  }

  public MTupple simpleParse() throws TokenException {
    aError = false;
    skipWhiteSpace();
    final Symbol name = parseSymbol();
    if ((name == null) || !"meta".equals(name.getName())) {
      aScope.getContext().fatalError(name, "Only parsing meta for now");
      return null;
    }
    skipWhiteSpace();
    getChar('(');
    //    PeekBuffer<? extends CharToken,CharStreamEnum> peek = aCharStream.peek();
    try {
      final LiteralToken<MLang, ?> version = aLiteralParser.getNextToken();
      if (version == null) {
        if (aCharStream.eof()) {
          error(null, "Found end of file while looking for meta version");
        } else {
          error(aCharStream.peek().getNextToken(), "Expecting literal expressing meta version");
        }
        return null;
      }
      if (!version.getValue().toString().equals("0.1")) {
        error(version, "Supporing versions other than 0.1 is not supported");
      }
    } catch (final UnexpectedTokenException e) {
      error(e.getToken(), e.getMessage());
    }
    getChar(')');
    skipWhiteSpace();

    final MTupple tupple = parseTupple();
    skipWhiteSpace();
    if (!aCharStream.eof()) {
      error(aCharStream.peek().getNextToken(), "Expected end of file");
    }
    if (!aError) {
      return tupple;
    } else {
      return null;
    }
  }

  public FileToken parseFile() throws TokenException {
    aError = false;
    skipWhiteSpace();
    final Symbol name = peekSymbol();
    if (!"meta".equals(name.getName())) {
      aScope.getContext().fatalError(name, "Only parsing meta for now");
    }

    final MTupple tupple = simpleParse();

    if (tupple != null) {
      final MTupple body = toFileBody(tupple);

      return new FileToken(name.getPos(), body);
    } else {
      return null;
    }
  }

  private void error(final Token<?> pToken, final String pMessage) throws CompilationException {
    aError = true;
    aScope.getContext().error(pToken, pMessage);
  }

  private void error(final Token<?> pToken, final CompilationErrors pMessage) throws CompilationException {
    aError = true;
    aScope.getContext().error(pToken, pMessage);
  }

  private MTupple toFileBody(final MTupple pParseTupple) throws CompilationException {
    final List<Expression> result = new ArrayList<>(pParseTupple.size());

    for (final Expression expr : pParseTupple) {
      if (expr.getTokenType() == MLang.CLASS) {
        result.add(expr);
      } else if (expr.getTokenType() == MLang.PACKAGEDECL) {
        aScope.setPackage(((PackageDecl) expr).getPackage());
        result.add(expr); // This should not be needed, but then results must be generated differently
      } else {
        if (expr.getTokenType() == MLang.VARASSIGN) {
          final VarAssign assign = (VarAssign) expr;
          if (assign.getRValue().getTokenType() == MLang.FUNCCALL) {
            final Expression target1 = ((FuncCall) assign.getRValue()).getTarget();
            final Expression[] body = ((FuncCall) assign.getRValue()).getArgs();
            if (target1.getTokenType() == MLang.FUNCCALL) {
              final FuncCall target2 = ((FuncCall) target1);
              final Expression[] parents = ((FuncCall) target1).getArgs();
              if ("class".equals(target2.getFunctionName())) {
                result.add(getMClass(aScope.getPackage(), assign.getPos(), assign.getFlags(), assign.getLValue(), parents, body, aScope));
                continue;
              }
            }
          }
        }
        Object tmp;
        try {
          final EvalResult eval = expr.eval(aScope);
          if (eval instanceof ReturnValue) {
            error(expr, "Return in file body scope");
            continue;
          }

          tmp = eval == null ? null : eval.toLiteral().getObjValue();
        } catch (final RuntimeException ex) {
          throw new CompilationError(expr, ex);
        }
        if (tmp != null) {
          if (tmp instanceof MClass) {
            result.add((MClass) tmp);
          } else {
            error(expr, "File bodies can only consist of expressions that evaluate to classes");
          }
        }
      }
    }
    return new MTupple(pParseTupple.getPos(), result);
  }

  private MClass getMClass(final String pPackage, final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final Expression[] pParents, final Expression[] pBody, final Scope pScope) throws CompilationException {
    TypeRef<? extends JavaReferenceType> parent;
    List<TypeRef<? extends JavaReferenceType>> interfaces;
    if (pParents.length > 2) {
      error(new MTupple(pPos, pParents), CompilationErrors.INVALID_ARGUMENT_COUNT);
      return null;
    }
    if (pParents.length == 0) {
      parent = TypeRef.create(null, Object.class).asReferenceType();
    } else {
      if (pParents[0].getTokenType() == MLang.TYPEREF) {
        parent = ((TypeRef<?>) pParents[0]).asReferenceType();
      } else if (pParents[0].getTokenType() == MLang.TUPPLE) {
        final MTupple tupple = (MTupple) pParents[0];
        if (tupple.size() == 0) {
          parent = TypeRef.create(null, Object.class).asReferenceType();
        } else if (tupple.size() == 1) {
          parent = MEvaluator.toTypeRef(tupple.get(0), pScope).asReferenceType();
        } else {
          error(tupple, CompilationErrors.NO_MULTIPLE_INHERITANCE);
          return null;
        }
      } else {
        parent = MEvaluator.toTypeRef(pParents[0], pScope).asReferenceType();
      }
    }
    if (pParents.length < 2) {
      interfaces = new ArrayList<>(0);
    } else {
      interfaces = new ArrayList<>();
      final MTupple tupple = MEvaluator.toTupple(pParents[1]);
      for (final Expression elem : tupple) {
        interfaces.add(MEvaluator.toTypeRef(elem, pScope).asReferenceType());
      }
    }
    final List<VarAssign> attributes = new ArrayList<>();
    final List<Function> methods = new ArrayList<>();
    for (final Expression expr2 : pBody) {
      final VarAssign assign = MEvaluator.toVarAssign(expr2, pScope);
      if (assign.getValueType().getTokenType() == MLang.FUNCTYPE) {
        methods.add(getFunction(assign.getPos(), assign.getFlags(), assign.getLValue(), MEvaluator.toFunctionType(assign.getValueType(), pScope), MEvaluator.toTupple(assign.getRValue())));
        continue;
      } else if ((assign.getRValue() != null) && (assign.getRValue().getTokenType() == MLang.FUNCCALL)) {
        final Expression target1 = ((FuncCall) assign.getRValue()).getTarget();
        final Expression[] body = ((FuncCall) assign.getRValue()).getArgs();
        if (target1.getTokenType() == MLang.FUNCCALL) {
          final FuncCall target2 = ((FuncCall) target1);
          final Expression[] params = ((FuncCall) target1).getArgs();
          if ("function".equals(target2.getFunctionName())) {
            methods.add(getFunction(assign.getPos(), assign.getFlags(), assign.getLValue(), params, body, pScope));
            continue;
          }
        }
      }
      attributes.add(assign);
    }
    // Special case for class constructor
    // TODO replace this with generators
    final String className;
    if ((pPackage == null) || (pPackage.trim().length() == 0)) {
      className = MEvaluator.toSymbol(pName).getName();
    } else {
      className = pPackage + '/' + MEvaluator.toSymbol(pName).getName();
    }

    return new MClass(pPos, pFlags, className, parent, interfaces, attributes, methods, pScope);
  }

  private static Function getFunction(final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final FunctionType pFunctionType, final MTupple pBody) {
    final String name = MEvaluator.toSymbol(pName).getName();
    //    final EnumSet<FunctionFlags> flags = MEvaluator.toMethodFlags(pFlags);
    pFlags.addAll(pFunctionType.getFlags()); // Also use flags on the function type

    return new Function(pPos, name, pFunctionType.newWithFlags(pFlags), pBody.toArray());
  }

  private Function getFunction(final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final Expression[] pType, final Expression[] pBody, final Scope pScope) throws CompilationException {
    if (pType.length != 1) {
      error(new MTupple(pPos, pType), CompilationErrors.INVALID_ARGUMENT_COUNT);
      return null;
    }
    final VarAssign type = MEvaluator.toVarAssign(pType[0], pScope);
    if (type.getRValue() != null) {
      error(type, "Functions types can not be assigned");
      return null;
    }
    final MTupple _params = MEvaluator.toTupple(type.getLValue());
    final List<VarAssign> params2 = new ArrayList<>(_params.size());
    for (final Expression param : _params) {
      params2.add(MEvaluator.toVarAssign(param, pScope));
    }


    TypeRef<?> returnType;
    if (type.getValueType() instanceof MTupple) {
      final MTupple tupple = (MTupple) type.getValueType();
      if (tupple.size() == 0) {
        returnType = null;
      } else if (tupple.size() == 1) {
        returnType = MEvaluator.toTypeRef(tupple.get(0), pScope);
      } else {
        error(tupple, "Returning multiple values from a function is not yet supported");
        return null;
      }
    } else {
      returnType = MEvaluator.toTypeRef(type.getValueType(), pScope);
    }
    final String name = MEvaluator.toSymbol(pName).getName();

    final VarAssign[] params = params2.toArray(new VarAssign[0]);
    return new Function(pPos, pFlags, name, returnType, params, pBody);
  }

  private LinePosition getChar(final char pChar) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    final CharToken read = peek.getNextToken();
    if (read == null) {
      error(null, "Expected '" + pChar + "', found end of file");
      return null;
    }
    if (read.getChar() != pChar) {
      error(read, "Expected '" + pChar + "', found: '" + read.getChar() + "'");
    } else {
      peek.take();
    }
    return read.getPos();
  }

  private char peekChar() throws TokenException {
    return aCharStream.peek().getNextToken().getChar();
  }

  private void skipWhiteSpace() throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return;
    }

    char c = firstToken.getChar();
    while (isWhiteSpace(c)) {
      peek.take();
      if (aCharStream.eof()) {
        break;
      }
      c = peek.getNextToken().getChar();
    }
    //    announcePartition(firstToken, PartitionTypes.WHITESPACE);
    if (c == '/') {
      if (!peek.eof()) {
        char d = peek.getNextToken().getChar();
        if (d == '/') {
          final int startPos = aCharStream.getPos();
          while (d != '\n') {
            peek.take();
            if (peek.eof()) {
              d = '\n';
            } else {
              d = peek.getNextToken().getChar();
            }
          }
          announcePartition(startPos, PartitionTypes.SINGLELINECOMMENT);
          // The line end token is not part of the comment
          skipWhiteSpace(); // After comments new white space can start
        } else if (d == '*') {
          final int startPos = aCharStream.getPos();
          peek.take();
          int close = 0;
          if (!aCharStream.eof()) {
            d = aCharStream.getNextToken().getChar();
            while ((!aCharStream.eof()) && ((close != 1) || (d != '/'))) {
              if ((d == '*') && (close == 0)) {
                close = 1;
              } else {
                close = 0;
              }
              d = aCharStream.getNextToken().getChar();
            }
          }
          if ((close != 1) || (d != '/')) {
            assert aCharStream.eof();
            aScope.getContext().error(firstToken, "End of file while scanning for end of comment");
          }
          announcePartition(startPos, PartitionTypes.MULTILINECOMMENT);
          skipWhiteSpace(); // after comments new white space can start
        }
      }
    }
  }

  private Symbol parseSymbol() throws TokenException {
    return aSymbolParser.getNextToken();
  }

  private Symbol peekSymbol() throws TokenException {
    return aSymbolParser.peek().getNextToken();
  }

  private MTupple parseTupple() throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    skipWhiteSpace();
    final LinePosition startPos = getChar('(');
    skipWhiteSpace();
    {
      final CharToken nextToken = peek.getNextToken();
      if (nextToken == null) {
        error(null, "Found end of file while looking for end of tupple");
        return null;
      }
      if (nextToken.getChar() == ')') {
        peek.take();
        return new MTupple(startPos);
      } else {
        peek.reset();
      }
    }
    final List<Expression> elements = new ArrayList<>();
    char c = ',';
    while (c == ',') {
      skipWhiteSpace();

      // Allow trailing commas, just for convenience
      if (!peek.eof() && ((c = peek.getNextToken().getChar()) == ')')) {
        break;
      }
      peek.reset();

      final Expression expression = parseExpression();
      if (expression != null) {
        elements.add(expression);
      }

      skipWhiteSpace();
      {
        final CharToken nextToken = peek.getNextToken();
        if ((nextToken != null) && ((c = nextToken.getChar()) == ',')) {
          peek.take();
        } else if ((nextToken != null) && (c != ')')) {
          aScope.getContext().error(nextToken, "Expression not closed by ',' or ')'");
          peek.take();
          c = ',';
        } else {
          c = '\0';
        }

      }
    }
    getChar(')');
    return new MTupple(startPos, elements);
  }

  private Expression parseExpression(final char... pBarrier) throws TokenException {
    final List<AnnotateToken> flags = new ArrayList<>();
    boolean addedFlag = true;
    Expression expression = null;
    while (addedFlag && !aCharStream.eof()) {
      addedFlag = false;
      final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
      final char c = peek.getNextToken().getChar();
      peek.reset();
      switch (c) {
        case '@': {
          final AnnotateToken annotate = parseAnnotate();
          if (annotate != null) {
            flags.add(annotate);
          }
          skipWhiteSpace();
          addedFlag = true;
          break;
        }
        case '(': {
          expression = parseTupple();
          if (flags.size() > 0) {
            error(aCharStream.peek().getNextToken(), CompilationErrors.TUPPLE_NO_FLAG);
          }
          break;
        }
        case '[': {
          // Start of a function type literal
          expression = parseFuncTypeLiteral(flags);

          // TODO see what to do about flags
          return expression;
        }
        case '!':
        case '¬':
          if (expression != null) {
            error(peek.getNextToken(), "Not Operator found without left operand");
            break;
          }
          expression = parseNot(aCharStream.getNextToken());
          break;
        case '+': {
          peek.getNextToken();
          if ('+' == peek.getNextToken().getChar()) {
            expression = parsePreInc();
          }
          peek.reset();
          break;
        }
        case '-': {
          peek.getNextToken();
          if ('-' == peek.getNextToken().getChar()) {
            expression = parsePreDec();
          }
          peek.reset();
          break;
        }
        default: {
          final PeekBuffer<LiteralToken<MLang, ?>, MLang> literalPeek = aLiteralParser.peek();
          if (literalPeek.getNextToken() != null) {
            final LiteralToken<MLang, ?> literal = aLiteralParser.getNextToken();
            literalPeek.take();

            // TODO Literals can not actually be assigned (yet)
            final Literal<?> result = Literal.createByInference(literal.getPos(), literal.getValue());
            announceLiteralPartition(literal, result.getValueType());
            return result;
          } else {

            final Symbol tmpSymbol = parseSymbol();
            final Keywords kw = getKeyword(tmpSymbol);
            if (kw != null) {
              announcePartition(tmpSymbol, PartitionTypes.KEYWORD);
              expression = handleKeyword(kw, flags, tmpSymbol);
            } else {
              if (tmpSymbol != null) {
                announcePartition(tmpSymbol, PartitionTypes.SYMBOL);
              }
              expression = tmpSymbol;
            }
          }
        }
      }
    }
    if (expression == null) {
      if (aCharStream.eof()) {
        error(null, "Expected expression, but found end of file");
        return null;
      } else {
        error(aCharStream.peek().getNextToken(), "Expected expression, but none found");
      }
      skipWhiteSpace();
      final char peek = aCharStream.peek().getNextToken().getChar();
      boolean barrier = false;
      if (peek == ')') {
        barrier = true;
      } else {
        for (final char c : pBarrier) {
          if (peek == c) {
            barrier = true;
            break;
          }
        }
      }
      if (barrier) {
        return null;
      }
      aCharStream.getNextToken();
      return parseExpression(pBarrier);
    }
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    Expression typeToken;
    boolean hasType = false;
    {
      loop: while (!peek.eof()) {
        final char c = peek.getNextToken().getChar();
        peek.reset();
        for (final char b : pBarrier) {
          if (c == b) {
            return expression;
          }
        }
        switch (c) {
          case '(': {
            expression = parseFuncCall(expression);
            skipWhiteSpace();
            break;
          }
          case '[': {
            peek.getNextToken();
            final char d = peek.getNextToken().getChar();
            if (d == ']') {
              peek.take();
              expression = parseArrayType(expression, aScope);
            } else {
              expression = parseArrayAccess(expression);
            }
            skipWhiteSpace();
            break;
          }
          case '=': {
            peek.getNextToken();
            final char d = peek.getNextToken().getChar();
            peek.reset();
            if (d == '=') {
              expression = parseOperator(expression);
              skipWhiteSpace();
              break;
            }
            break loop;
          }
          case '.': {
            expression = parsePeriodOperator(expression);
            skipWhiteSpace();
            break;
          }
          case '+':
          case '-':
          case '*':
          case '×':
          case '!':
          case '/':
          case '%':
          case '^':
          case '&':
          case '∧':
          case '∨':
          case '≠':
          case '≤':
          case '≥':
          case '|':
          case '<':
          case '>': {
            if (expression == null) {
              error(peek.getNextToken(), "Operator found without left operand");
              break;
            } else {
              final Expression newExpression = parseOperator(expression);
              if (newExpression == null) {
                break loop;
              }
              expression = newExpression;
              skipWhiteSpace();
              break;
            }
          }
          case 'i': {
            final Symbol symbol = peekSymbol();
            if ((symbol != null) && "instanceof".equals(symbol.getName())) {
              expression = parseInstanceof(expression);
              skipWhiteSpace();
              break;
            }
            break loop;
          }
          default:
            break loop;
        }
      }
      if (peek.eof()) {
        error(expression, "End of file found while looking for end of expression");
        return expression;
      }
    }
    if ((!peek.eof()) && (peek.getNextToken().getChar() == ':')) {
      peek.take();
      hasType = true;
      skipWhiteSpace();
      typeToken = parseExpression(':', '=');
      skipWhiteSpace();
    } else {
      peek.reset();
      typeToken = TypeRef.ANY;
    }
    if ((!peek.eof()) && (peek.getNextToken().getChar() == '=')) {
      peek.take();
      skipWhiteSpace();
      final Expression value = parseExpression();
      return new VarAssign(expression.getPos(), flags, expression, typeToken, value);
    }
    if (hasType) {
      return new VarAssign(expression.getPos(), flags, expression, typeToken, null);
    }
    return expression;
  }

  private InstanceofToken parseInstanceof(final Expression pExpression) throws TokenException {
    final Symbol start = parseSymbol();
    if (!"instanceof".equals(start.getName())) {
      throw new IllegalStateException("This should not happen");
    }
    announcePartition(start, PartitionTypes.KEYWORD);
    skipWhiteSpace();
    final Expression type = parseExpression();
    return new InstanceofToken(start.getPos(), pExpression, type);
  }

  private Expression parseNot(final CharToken pToken) throws TokenException {
    announcePartition(pToken, PartitionTypes.OPERATOR);
    skipWhiteSpace();
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(pToken.getPos(), expr, new Symbol(pToken.getPos(), "operator!"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePreInc() throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('+');
    getChar('+');
    announcePartition(start.getOffset(), PartitionTypes.OPERATOR);
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(start, expr, new Symbol(start, "operator++_"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePostInc(final Expression pExpression) throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('+');
    getChar('+');
    announcePartition(start.getOffset(), PartitionTypes.OPERATOR);
    final FuncCall fc = FuncCall.create(start, pExpression, new Symbol(start, "operator_++"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePostDec(final Expression pExpression) throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('-');
    getChar('-');
    announcePartition(start.getOffset(), PartitionTypes.OPERATOR);
    final FuncCall fc = FuncCall.create(start, pExpression, new Symbol(start, "operator_--"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePreDec() throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('-');
    getChar('-');
    announcePartition(start.getOffset(), PartitionTypes.OPERATOR);
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(start, expr, new Symbol(start, "operator--_"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  // TODO rename
  private Expression parseFuncTypeLiteral(final List<AnnotateToken> pFlags) throws TokenException {
    final LinePosition startPos = getChar('[');
    if (startPos == null) {
      return null;
    }
    skipWhiteSpace();
    final Expression expression = parseExpression();
    if (expression == null) {
      // TODO improve error message
      error(aCharStream.peek().getNextToken(), "Expecting expression but not found");
      //      announcePartition(startPos.getOffset(), PartitionTypes.FUNCTYPE);
      //      return null;
    }
    skipWhiteSpace();
    if (getChar(']') == null) {
      final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();

      while (!peek.eof() && (peek.getNextToken().getChar() != ']')) {
        // Read the next char
      }
      if (!peek.eof()) {
        peek.take();
      }
      // if end of file just pretend the char was there

      announcePartition(startPos.getOffset(), PartitionTypes.FUNCTYPE);
      return null;
    }
    announcePartition(startPos.getOffset(), PartitionTypes.FUNCTYPE);
    if (expression == null) {
      return null;
    }


    if (expression.getTokenType() != MLang.VARASSIGN) {
      error(expression, CompilationErrors.ILLEGAL_FUNCTION_TYPE_LITERAL);
    }
    final VarAssign assign = (VarAssign) expression;


    final TypeRef<?> owner = null;

    final Expression valueType = assign.getValueType();
    if (valueType == null) {
      error(assign, "Expecting value type, but not found");
      return null;
    }
    Expression returnType;
    if (valueType.getTokenType() != MLang.TUPPLE) {
      returnType = valueType;
    } else {
      final MTupple tupple = (MTupple) valueType;
      if (tupple.size() == 0) {
        returnType = null; // void method
      } else if (tupple.size() == 1) {
        returnType = tupple.get(0);
      } else {
        throw new UnsupportedOperationException("No multiple return values allowed yet");
      }

    }
    VarAssign[] newParams;
    final Expression paramDecl = assign.getLValue();
    if (paramDecl instanceof MTupple) {
      final MTupple tupple = (MTupple) paramDecl;
      // XXX don't use null scope
      newParams = toVarAssigns(tupple.asList(), aScope);
    } else {
      final VarAssign x = MEvaluator.toVarAssign(paramDecl, null);
      newParams = new VarAssign[] { x };
    }
    return new FunctionType(startPos, pFlags, owner, returnType, newParams);
  }

  @Deprecated
  private static VarAssign[] toVarAssigns(final List<Expression> pAsList, final Scope pScope) throws CompilationException {
    final VarAssign[] result = new VarAssign[pAsList.size()];
    int i = 0;
    for (final Expression expr : pAsList) {
      result[i] = MEvaluator.toVarAssign(expr, pScope);
      ++i;
    }
    return result;
  }

  private static Keywords getKeyword(final Symbol pTmpSymbol) {
    if (pTmpSymbol == null) {
      return null;
    }
    final String symbol = pTmpSymbol.getName();

    if (symbol.equals("return")) {
      return Keywords.RETURN;
    }
    if (symbol.equals("throw")) {
      return Keywords.THROW;
    }
    if (symbol.equals("package")) {
      return Keywords.PACKAGE;
    }
    if (symbol.equals("if")) {
      return Keywords.IF;
    }
    if (symbol.equals("cast")) {
      return Keywords.CAST;
    }
    if (symbol.equals("for")) {
      return Keywords.FOR;
    }
    if (symbol.equals("do")) {
      return Keywords.DO;
    }
    if (symbol.equals("while")) {
      return Keywords.WHILE;
    }
    return null;
  }

  private Expression handleKeyword(final Keywords pKeyword, final List<AnnotateToken> pFlags, final Symbol pSymbol) throws TokenException, CompilationError {
    skipWhiteSpace();
    if (pFlags.size() > 0) {
      error(pFlags.get(0), CompilationErrors.KEYWORD_NO_FLAG);
    }
    switch (pKeyword) {
      case RETURN:
        return new Return(pSymbol.getPos(), parseExpression());
      case THROW:
        return new Throw(pSymbol.getPos(), parseExpression());
      case PACKAGE:
        return parsePackage(pSymbol);
      case IF:
        return parseIf(pSymbol.getPos());
      case CAST:
        return parseCast(pSymbol);
      case FOR:
        return parseFor(pSymbol.getPos());
      case DO:
        return parseDo(pSymbol.getPos());
      case WHILE:
        return parseWhile(pSymbol.getPos());
      default:
        throw new IllegalStateException("Should be unreachable " + pKeyword);
    }
  }

  private Expression parseCast(final Symbol pSymbol) throws TokenException {
    skipWhiteSpace();
    getChar('<');
    skipWhiteSpace();
    final Expression destType = parseExpression('>');
    skipWhiteSpace();
    getChar('>');
    skipWhiteSpace();
    getChar('(');
    final Expression expression = parseExpression();
    getChar(')');
    return new TypeCast(pSymbol.getPos(), destType, expression);
  }

  private Conditional parseIf(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final Expression condition = parseExpression();
    skipWhiteSpace();
    Symbol symbol = peekSymbol();
    if (symbol == null) {
      error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_THEN);
    } else if ((!symbol.getName().equals("then"))) {
      error(symbol, CompilationErrors.EXPECT_THEN);
    } else {
      parseSymbol();
    }
    announcePartition(symbol, PartitionTypes.KEYWORD);
    skipWhiteSpace();
    final Expression _then = parseExpression();
    skipWhiteSpace();
    symbol = peekSymbol();
    if ((symbol != null) && symbol.getName().equals("else")) {
      parseSymbol();
      announcePartition(symbol, PartitionTypes.KEYWORD);
      skipWhiteSpace();
      final Expression _else = parseExpression();
      return new Conditional(pPos, condition, _then, _else);
    }
    return new Conditional(pPos, condition, _then);
  }

  private Expression parseFor(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    getChar('(');
    skipWhiteSpace();
    final Expression init = parseExpression();
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    {
      final char c = peek.getNextToken().getChar();
      // TODO handle terminator
      if ((c == '←') || ((c == '<') && (peek.getNextToken().getChar() == '-'))) {
        peek.take();
        // foreach
        skipWhiteSpace();
        final Expression collection = parseExpression();
        skipWhiteSpace();
        getChar(')');
        skipWhiteSpace();
        final MTupple body = parseTupple();
        return ForEach.newForEach(pPos, init, collection, body);
      } else {
        peek.reset();
        getChar(',');
        skipWhiteSpace();
        final Expression condition = parseExpression();
        skipWhiteSpace();
        getChar(',');
        skipWhiteSpace();
        final Expression control = parseExpression();
        skipWhiteSpace();
        getChar(')');
        final MTupple body = parseTupple();
        return Loop.newFor(pPos, init, condition, control, body);
      }
    }
  }

  private Loop parseDo(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final MTupple body = parseTupple();
    skipWhiteSpace();
    final Symbol _while = parseSymbol();
    if ((_while == null) || (!_while.getName().equals("while"))) {
      error(_while, CompilationErrors.EXPECT_THEN);
      return null;
    }
    announcePartition(_while, PartitionTypes.KEYWORD);
    skipWhiteSpace();
    final MTupple condition = parseTupple();
    return Loop.newDo(pPos, body, condition);
  }

  private Loop parseWhile(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final MTupple condition = parseTupple();
    skipWhiteSpace();
    final MTupple body = parseTupple();
    return Loop.newWhile(pPos, condition, body);
  }

  private Expression parsePackage(final Symbol pSymbol) throws TokenException {
    skipWhiteSpace();
    final StringBuilder result = new StringBuilder();
    Symbol symbol = parseSymbol();
    if (symbol == null) {
      error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
      return null;
    }
    final int startPos = symbol.getPos().getOffset();
    result.append(symbol.getName());
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    while (peek.getNextToken().getChar() == '.') {
      peek.take();
      skipWhiteSpace();
      symbol = parseSymbol();
      if (symbol == null) {
        error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
        return null;
      }
      result.append('.').append(symbol.getName());
    }
    peek.reset();
    announcePartition(startPos, PartitionTypes.PACKAGEDECL);
    return new PackageDecl(pSymbol.getPos(), result.toString());
  }

  private Expression parseFuncCall(final Expression pName) throws TokenException {
    final MTupple _params = parseTupple();

    //    return new FunctionCallToken<MLang>(MLang.FUNCCALL, pName.getPos(), pName, _params.getElements());

    Expression myTarget = null;
    Expression myMethod = pName;
    // TODO make it work on reflective symbols
    while ((myMethod != null) && (myMethod.getTokenType() != MLang.SYMBOL)) {
      if (myMethod.getTokenType() == MLang.BINARYOPERATOR) {

        final BinaryExpression operator = (BinaryExpression) myMethod;
        myTarget = operator.getLeft();
        myMethod = operator.getRight();
      } else {
        // Is not named
        myTarget = myMethod;
        return FuncCall.create(pName.getPos(), myMethod, new Symbol(_params.getPos(), "operator()"), _params.asList());
      }
    }

    final Expression target = myTarget;
    if ((myMethod == null) || (myMethod.getTokenType() != MLang.SYMBOL)) {
      // TODO support more
      error(pName, "Unsupported operation");
      return null;
    }
    final List<Expression> params = _params.asList();
    //    List<TypeRef<?>> paramTypes = getTypes(params, pScope);
    final Symbol name = (Symbol) myMethod;

    return FuncCall.create(pName.getPos(), target, name, params);


  }

  // TODO make operators extensible, but not yet
  private Expression parseOperator(final Expression pLeft) throws TokenException {
    {
      final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
      {
        final char c = peek.getNextToken().getChar();
        if (((c == '+') || (c == '-')) && (peek.getNextToken().getChar() == c)) {
          // We have post and pre dec and inc
          if (c == '+') {
            return parsePostInc(pLeft);
          } else {
            return parsePostDec(pLeft);
          }
        }
      }
    }

    final OperatorToken<BinaryOperatorTokens> operatorToken = aBinaryOperatorParser.getNextToken();
    if (operatorToken == null) {
      return null;
    }
    announcePartition(operatorToken, PartitionTypes.OPERATOR);
    BinaryOperatorTokens operatorType = operatorToken.getTokenType();
    skipWhiteSpace();
    Expression left = pLeft;
    Expression right = parseExpression();
    if (right.getTokenType() == MLang.BINARYOPERATOR) {
      final BinaryExpression right2 = (BinaryExpression) right;
      if (operatorType.compare(right2.getOperator()) <= 0) {
        /* Assign to the left */
        left = new BinaryExpression(left.getPos(), operatorType, left, right2.getLeft());
        operatorType = right2.getOperator();
        right = right2.getRight();
      }

    }
    return new BinaryExpression(pLeft.getPos(), operatorType, left, right);
  }

  private Expression parsePeriodOperator(final Expression pExpression) throws TokenException {
    getChar('.');
    skipWhiteSpace();
    final Expression left = pExpression;
    final Symbol right = parseSymbol();
    if (right == null) {
      error(aCharStream.peek().getNextToken(), "Expecting member, but not found");
      return pExpression;
    }
    announcePartition(right, PartitionTypes.SYMBOL);
    return new BinaryExpression(left.getPos(), BinaryOperatorTokens.MEMBERACCESS, left, right);
  }

  private static TypeRef<ArrayType> parseArrayType(final Expression pExpression, final Scope pScope) throws CompilationException {
    final TypeRef<?> elemType = MEvaluator.toTypeRef(pExpression, pScope);
    final ArrayType arrayType = new ArrayType(elemType);

    return arrayType.getRef();
  }

  private Expression parseArrayAccess(final Expression pExpression) throws TokenException {
    final LinePosition startPos = aCharStream.peek().getNextToken().getPos();
    getChar('[');
    skipWhiteSpace();
    final Expression index = parseExpression();
    skipWhiteSpace();
    getChar(']');
    final FuncCall result = FuncCall.create(startPos, pExpression, new Symbol(startPos, "operator["), TypeRef.ANY, new Expression[] { index });
    return result;
  }

  public AnnotateToken parseAnnotate() throws TokenException {
    final LinePosition start = getChar('@');
    final CharToken next = aCharStream.peek().getNextToken();
    final Symbol symbol = parseSymbol();
    if (symbol == null) {
      error(next, "An annotation is an @ followed by an NMToken without separator.");
      return null;
    }
    announcePartition(start.getOffset(), PartitionTypes.ANNOTATION);
    MTupple pParams = null;
    if (peekChar() == '(') {
      pParams = parseTupple();
    }
    return new AnnotateToken(start, symbol.getName(), pParams);
  }

  /**
   * Parse the stream for all whitespace. Returns null if there is no
   * whitespace.
   *
   * @param pChar The character to check on being whitespace.
   * @return <code>true</code> if the character is whitespace,
   *         <code>false</code> if not.
   */
  public static boolean isWhiteSpace(final char pChar) {
    return (pChar == ' ') || (pChar == '\t') || (pChar == Const._CR) || (pChar == Const._LF);
  }

  @Override
  public boolean eof() {
    return aCharStream.eof();
  }

  @Override
  public int getPos() {
    return aCharStream.getPos();
  }

  @Override
  public Iterator<LinedToken<MLang>> iterator() {
    return new Iterator<LinedToken<MLang>>() {

      @Override
      public boolean hasNext() {
        final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
        char ch = ' ';
        while (!peek.eof() && Character.isWhitespace(ch)) {
          try {
            ch = peek.getNextToken().getChar();
          } catch (final TokenException e) {
            throw new RuntimeException("Character streams should not have unexpected tokens", e);
          }
        }
        return !peek.eof();
      }

      @Override
      public LinedToken<MLang> next() {
        try {
          return getNextToken();
        } catch (final TokenException e) {
          throw new RuntimeException(e);
        }
      }

      @Override
      public void remove() {
        throw new UnsupportedOperationException("Removing tokens out of a parsing stream makes no sense.");

      }

    };
  }

  private void announcePartition(final int pStartPos, final PartitionTypes pSinglelinecomment) {
    announcePartition(pStartPos, aCharStream.getPos() - pStartPos, pSinglelinecomment);
    // Do nothing by default
  }

  private void announcePartition(final Token<?> pFirstToken, final PartitionTypes pKind) {
    if ((pFirstToken != null) && (pFirstToken.getPos() != null)) {
      announcePartition(pFirstToken.getPos().getOffset(), pKind);
    }
  }

  private void announceLiteralPartition(final LiteralToken<MLang, ?> pLiteral, final TypeRef<?> pValueType) {
    final Type type = pValueType.getReferredType();
    if (type instanceof Primitive) {
      switch ((Primitive) type) {
        case MBoolean:
          announcePartition(pLiteral, PartitionTypes.BOOLLITERAL);
          break;
        case MByte:
        case MInt:
        case MShort:
        case MLong:
          announcePartition(pLiteral, PartitionTypes.INTLITERAL);
          break;
        case MChar:
          announcePartition(pLiteral, PartitionTypes.CHARLITERAL);
          break;
        case MFloat:
        case MDouble:
          announcePartition(pLiteral, PartitionTypes.FLOATLITERAL);
          break;
      }
      return;
    }
    if (TypeRef.create(null, String.class).isAssignableFrom(pValueType)) {
      announcePartition(pLiteral, PartitionTypes.STRINGLITERAL);
    }
  }

  /**
   * Extension method that allows for subclassing to eclipse specifics
   *
   * @param pStartPos The starting point of the partition
   * @param pLength The lenght of the partition
   * @param pType The type of the partition
   */
  protected void announcePartition(final int pStartPos, final int pLength, final PartitionTypes pType) {
    // Do nothing by default
  }

}
