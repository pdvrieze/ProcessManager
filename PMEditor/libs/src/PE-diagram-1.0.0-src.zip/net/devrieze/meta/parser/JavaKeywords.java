package net.devrieze.meta.parser;


public enum JavaKeywords {
  ABSTRACT("abstract"),
  ASSERT("assert"),
  BOOLEAN("boolean"),
  BREAK("break"),
  BYTE("byte"),
  CASE("case"),
  CATCH("catch"),
  CHAR("char"),
  CLASS("class"),
  CONST("const"),
  CONTINUE("continue"),
  DEFAULT("default"),
  DO("do"),
  DOUBLE("double"),
  ELSE("else"),
  ENUM("enum"),
  EXTENDS("extends"),
  FINAL("final"),
  FINALLY("finally"),
  FLOAT("float"),
  FOR("for"),
  GOTO("goto"),
  IF("if"),
  IMPLEMENTS("implements"),
  IMPORT("import"),
  INSTANCEOF("instanceof"),
  INT("int"),
  INTERFACE("interface"),
  LONG("long"),
  NATIVE("native"),
  NEW("new"),
  PACKAGE("package"),
  PRIVATE("private"),
  PUBLIC("public"),
  PROTECTED("protected"),
  RETURN("return"),
  SHORT("short"),
  STATIC("static"),
  STRICTFP("strictfp"),
  SUPER("super"),
  SWITCH("switch"),
  SYNCHRONIZED("synchronized"),
  THIS("this"),
  THROW("throw"),
  THROWS("throws"),
  TRANSIENT("transient"),
  TRY("try"),
  VOID("void"),
  VOLATILE("volatile"),
  WHILE("while"), ;

  private final String aRepr;

  JavaKeywords(final String pRepr) {
    aRepr = pRepr;
  }

  @Override
  public String toString() {
    return aRepr;
  }

  public static JavaKeywords fromString(final String pString) {
    if (pString == null) {
      return null;
    }
    switch (pString.length()) {
      case 2:
        return fromString2(pString);
      case 3:
        return fromString3(pString);
      case 4:
        return fromString4(pString);
      case 5:
        return fromString5(pString);
      case 6:
        return fromString6(pString);
      case 7:
        return fromString7(pString);
      case 8:
        return fromString8(pString);
      case 9:
        return fromString9(pString);
      case 10:
        return fromString10(pString);
      case 12:
        return fromString12(pString);
      default:
        return null;
    }
  }

  private static JavaKeywords fromString2(final String pString) {
    if (pString.equals("do")) {
      return DO;
    } else if (pString.equals("if")) {
      return IF;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString3(final String pString) {
    if (pString.equals("for")) {
      return FOR;
    } else if (pString.equals("int")) {
      return INT;
    } else if (pString.equals("new")) {
      return NEW;
    } else if (pString.equals("try")) {
      return TRY;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString4(final String pString) {
    if (pString.charAt(0) <= 'e') {
      if (pString.equals("byte")) {
        return BYTE;
      } else if (pString.equals("case")) {
        return CASE;
      } else if (pString.equals("char")) {
        return CHAR;
      } else if (pString.equals("else")) {
        return ELSE;
      } else if (pString.equals("enum")) {
        return ENUM;
      }
    } else {
      if (pString.equals("goto")) {
        return GOTO;
      } else if (pString.equals("long")) {
        return LONG;
      } else if (pString.equals("this")) {
        return LONG;
      } else if (pString.equals("void")) {
        return LONG;
      }
    }
    return null;
  }

  private static JavaKeywords fromString5(final String pString) {
    if (pString.charAt(0) <= 'f') {
      if (pString.equals("break")) {
        return BREAK;
      } else if (pString.equals("catch")) {
        return CATCH;
      } else if (pString.equals("class")) {
        return CLASS;
      } else if (pString.equals("const")) {
        return CONST;
      } else if (pString.equals("final")) {
        return FINAL;
      } else if (pString.equals("float")) {
        return FLOAT;
      }
    } else {
      if (pString.equals("short")) {
        return SHORT;
      } else if (pString.equals("super")) {
        return SUPER;
      } else if (pString.equals("throw")) {
        return THROW;
      } else if (pString.equals("while")) {
        return WHILE;
      }
    }
    return null;
  }

  private static JavaKeywords fromString6(final String pString) {
    if (pString.charAt(0) <= 'p') {
      if (pString.equals("assert")) {
        return ASSERT;
      } else if (pString.equals("double")) {
        return DOUBLE;
      } else if (pString.equals("import")) {
        return IMPORT;
      } else if (pString.equals("native")) {
        return NATIVE;
      } else if (pString.equals("public")) {
        return PUBLIC;
      }
    } else {
      if (pString.equals("return")) {
        return RETURN;
      } else if (pString.equals("static")) {
        return STATIC;
      } else if (pString.equals("switch")) {
        return SWITCH;
      } else if (pString.equals("throws")) {
        return THROWS;
      }
    }
    return null;
  }

  private static JavaKeywords fromString7(final String pString) {
    if (pString.equals("abstract")) {
      return ABSTRACT;
    } else if (pString.equals("boolean")) {
      return BOOLEAN;
    } else if (pString.equals("default")) {
      return DEFAULT;
    } else if (pString.equals("extends")) {
      return EXTENDS;
    } else if (pString.equals("finally")) {
      return FINALLY;
    } else if (pString.equals("package")) {
      return PACKAGE;
    } else if (pString.equals("private")) {
      return PRIVATE;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString8(final String pString) {
    if (pString.equals("continue")) {
      return CONTINUE;
    } else if (pString.equals("strictfp")) {
      return STRICTFP;
    } else if (pString.equals("volatile")) {
      return VOLATILE;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString9(final String pString) {
    if (pString.equals("interface")) {
      return INTERFACE;
    } else if (pString.equals("protected")) {
      return PROTECTED;
    } else if (pString.equals("transient")) {
      return TRANSIENT;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString10(final String pString) {
    if (pString.equals("implements")) {
      return IMPLEMENTS;
    } else if (pString.equals("instanceof")) {
      return INSTANCEOF;
    } else {
      return null;
    }
  }

  private static JavaKeywords fromString12(final String pString) {
    if (pString.equals("synchronized")) {
      return SYNCHRONIZED;
    } else if (pString.equals("instanceof")) {
      return INSTANCEOF;
    } else {
      return null;
    }
  }

}
