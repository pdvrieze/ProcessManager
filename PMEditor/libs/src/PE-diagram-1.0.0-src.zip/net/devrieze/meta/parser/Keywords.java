package net.devrieze.meta.parser;


public enum Keywords {
  RETURN,
  THROW,
  /**
   * @todo Replace by global
   */
  PACKAGE,
  IF,
  CAST,
  WHILE,
  FOR,
  DO;

}
