/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.meta.parser;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import meta.lang.*;

import net.devrieze.lang.Const;
import net.devrieze.meta.compile.CompilationError;
import net.devrieze.meta.compile.CompilationErrors;
import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.meta.eval.EvaluationException;
import net.devrieze.meta.eval.MEvaluator;
import net.devrieze.meta.eval.ReturnValue;
import net.devrieze.meta.tokens.AnnotateToken;
import net.devrieze.meta.tokens.FileToken;
import net.devrieze.meta.tokens.InstanceofToken;
import net.devrieze.meta.tokens.PackageDecl;
import net.devrieze.parser.*;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.MLang;
import net.devrieze.parser.streams.BinaryOperatorParser;
import net.devrieze.parser.streams.LiteralParser;
import net.devrieze.parser.streams.SymbolParser;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LiteralToken;
import net.devrieze.parser.tokens.OperatorToken;


/**
 * A parser for java.
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @todo Make the parser provider variable
 */
public class JavaParser extends AbstractTokenStream<FileToken, MLang> implements Iterable<LinedToken<MLang>> {


  private static class SymbolFactory extends SymbolParser.SymbolTokenFactory<Symbol> {

    @Override
    protected Symbol createSymbol(final LinePosition pPosition, final String pValue) {
      return new Symbol(pPosition, pValue);
    }

  }

  private final BufferedTokenStream<? extends CharToken, CharStreamEnum> aCharStream;

  private final Scope aScope;

  private final SymbolParser<MLang, Symbol> aSymbolParser;

  private final LiteralParser<MLang> aLiteralParser;

  private final BinaryOperatorParser aBinaryOperatorParser;

  //  private ExpressionParserProvider<MLang> aParserProvider;

  /**
   * @param pParentStream
   */
  public JavaParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream, final Scope pScope) {
    super(pParentStream.getFile());
    aCharStream = pParentStream;
    aScope = pScope;
    aSymbolParser = new SymbolParser<>(true, aCharStream, new SymbolFactory());
    aLiteralParser = new LiteralParser<>(MLang.LITERAL, aCharStream);
    aBinaryOperatorParser = new BinaryOperatorParser(aCharStream);
  }

  public static MTupple toClassBody(final MTupple pBody) {
    return pBody;
    // TODO Auto-generated method stub
    // return null;
    //    throw new UnsupportedOperationException("Not yet implemented");
  }

  @Override
  public FileToken getNextToken() throws TokenException {
    return parseFile();
  }

  public FileToken parseFile() throws TokenException {
    skipWhiteSpace();
    final List<AnnotateToken> annotations = parseAnnotations();
    Symbol symbol = parseSymbol();
    JavaKeywords keyword = getKeyword(symbol);
    final ArrayList<Expression> bodyElems = new ArrayList<>();
    if (keyword == JavaKeywords.PACKAGE) {
      skipWhiteSpace();
      bodyElems.add(parsePackage(annotations, symbol.getPos()));
      skipWhiteSpace();
      symbol = parseSymbol();
      keyword = getKeyword(symbol);
    }
    if (keyword == null) {
      aScope.getContext().error(symbol, "Expecting one of package declaration, import or class declaration");
    }
    while (keyword == JavaKeywords.IMPORT) {
      skipWhiteSpace();
      if (getKeyword(peekSymbol()) == JavaKeywords.STATIC) {
        parseSymbol();// This must be static
        skipWhiteSpace();
        parseStaticImport();
      } else {
        parseImport();
      }
      symbol = parseSymbol();
      keyword = getKeyword(symbol);
    }


    final MTupple body = toFileBody(parseTupple(), aScope);

    return new FileToken(symbol.getPos(), body);
  }

  private MTupple toFileBody(final MTupple pParseTupple, final Scope pScope) throws CompilationException {
    final List<Expression> result = new ArrayList<>(pParseTupple.size());

    for (final Expression expr : pParseTupple) {
      if (expr.getTokenType() == MLang.CLASS) {
        result.add(expr);
      } else if (expr.getTokenType() == MLang.PACKAGEDECL) {
        pScope.setPackage(((PackageDecl) expr).getPackage());
        result.add(expr); // This should not be needed, but then results must be generated differently
      } else {
        if (expr.getTokenType() == MLang.VARASSIGN) {
          final VarAssign assign = (VarAssign) expr;
          if (assign.getRValue().getTokenType() == MLang.FUNCCALL) {
            final Expression target1 = ((FuncCall) assign.getRValue()).getTarget();
            final Expression[] body = ((FuncCall) assign.getRValue()).getArgs();
            if (target1.getTokenType() == MLang.FUNCCALL) {
              final FuncCall target2 = ((FuncCall) target1);
              final Expression[] parents = ((FuncCall) target1).getArgs();
              if ("class".equals(target2.getFunctionName())) {
                result.add(getMClass(pScope.getPackage(), assign.getPos(), assign.getFlags(), assign.getLValue(), parents, body, pScope));
                continue;
              }
            }
          }
        }
        Object tmp;
        final EvalResult eval = expr.eval(pScope);
        if (eval instanceof ReturnValue) {
          pScope.getContext().error(expr, "Return in file body scope");
          continue;
        }

        tmp = eval == null ? null : eval.toLiteral().getObjValue();
        if (tmp != null) {
          if (tmp instanceof MClass) {
            result.add((MClass) tmp);
          } else {
            aScope.getContext().error(expr, "File bodies can only consist of expressions that evaluate to classes");
          }
        }
      }
    }
    return new MTupple(pParseTupple.getPos(), result);
  }

  private MClass getMClass(final String pPackage, final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final Expression[] pParents, final Expression[] pBody, final Scope pScope) throws CompilationException {
    TypeRef<? extends JavaReferenceType> parent;
    List<TypeRef<? extends JavaReferenceType>> interfaces;
    if (pParents.length > 2) {
      aScope.getContext().error(new MTupple(pPos, pParents), CompilationErrors.INVALID_ARGUMENT_COUNT);
      return null;
    }
    if (pParents.length == 0) {
      parent = TypeRef.create(null, Object.class).asReferenceType();
    } else {
      if (pParents[0].getTokenType() == MLang.TYPEREF) {
        parent = ((TypeRef<?>) pParents[0]).asReferenceType();
      } else if (pParents[0].getTokenType() == MLang.TUPPLE) {
        final MTupple tupple = (MTupple) pParents[0];
        if (tupple.size() == 0) {
          parent = TypeRef.create(null, Object.class).asReferenceType();
        } else if (tupple.size() == 1) {
          parent = MEvaluator.toTypeRef(tupple.get(0), pScope).asReferenceType();
        } else {
          aScope.getContext().error(tupple, CompilationErrors.NO_MULTIPLE_INHERITANCE);
          return null;
        }
      } else {
        parent = MEvaluator.toTypeRef(pParents[0], pScope).asReferenceType();
      }
    }
    if (pParents.length < 2) {
      interfaces = new ArrayList<>(0);
    } else {
      interfaces = new ArrayList<>();
      final MTupple tupple = MEvaluator.toTupple(pParents[1]);
      for (final Expression elem : tupple) {
        interfaces.add(MEvaluator.toTypeRef(elem, pScope).asReferenceType());
      }
    }
    final List<VarAssign> attributes = new ArrayList<>();
    final List<Function> methods = new ArrayList<>();
    for (final Expression expr2 : pBody) {
      final VarAssign assign = MEvaluator.toVarAssign(expr2, pScope);
      if (assign.getValueType().getTokenType() == MLang.FUNCTYPE) {
        methods.add(getFunction(assign.getPos(), assign.getFlags(), assign.getLValue(), MEvaluator.toFunctionType(assign.getValueType(), pScope), MEvaluator.toTupple(assign.getRValue())));
        continue;
      } else if ((assign.getRValue() != null) && (assign.getRValue().getTokenType() == MLang.FUNCCALL)) {
        final Expression target1 = ((FuncCall) assign.getRValue()).getTarget();
        final Expression[] body = ((FuncCall) assign.getRValue()).getArgs();
        if (target1.getTokenType() == MLang.FUNCCALL) {
          final FuncCall target2 = ((FuncCall) target1);
          final Expression[] params = ((FuncCall) target1).getArgs();
          if ("function".equals(target2.getFunctionName())) {
            methods.add(getFunction(assign.getPos(), assign.getFlags(), assign.getLValue(), params, body, pScope));
            continue;
          }
        }
      }
      attributes.add(assign);
    }
    // Special case for class constructor
    // TODO replace this with generators
    final String className;
    if ((pPackage == null) || (pPackage.trim().length() == 0)) {
      className = MEvaluator.toSymbol(pName).getName();
    } else {
      className = pPackage + '/' + MEvaluator.toSymbol(pName).getName();
    }

    return new MClass(pPos, pFlags, className, parent, interfaces, attributes, methods, pScope);
  }

  private static Function getFunction(final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final FunctionType pFunctionType, final MTupple pBody) {
    final String name = MEvaluator.toSymbol(pName).getName();
    //    final EnumSet<FunctionFlags> flags = MEvaluator.toMethodFlags(pFlags);
    pFlags.addAll(pFunctionType.getFlags()); // Also use flags on the function type

    return new Function(pPos, name, pFunctionType.newWithFlags(pFlags), pBody.toArray());
  }

  private Function getFunction(final LinePosition pPos, final List<AnnotateToken> pFlags, final Expression pName, final Expression[] pType, final Expression[] pBody, final Scope pScope) throws CompilationException {
    if (pType.length != 1) {
      aScope.getContext().error(new MTupple(pPos, pType), CompilationErrors.INVALID_ARGUMENT_COUNT);
      return null;
    }
    final VarAssign type = MEvaluator.toVarAssign(pType[0], pScope);
    if (type.getRValue() != null) {
      aScope.getContext().error(type, "Functions types can not be assigned");
      return null;
    }
    final MTupple _params = MEvaluator.toTupple(type.getLValue());
    final List<VarAssign> params2 = new ArrayList<>(_params.size());
    for (final Expression param : _params) {
      params2.add(MEvaluator.toVarAssign(param, pScope));
    }


    TypeRef<?> returnType;
    if (type.getValueType() instanceof MTupple) {
      final MTupple tupple = (MTupple) type.getValueType();
      if (tupple.size() == 0) {
        returnType = null;
      } else if (tupple.size() == 1) {
        returnType = MEvaluator.toTypeRef(tupple.get(0), pScope);
      } else {
        aScope.getContext().error(tupple, "Returning multiple values from a function is not yet supported");
        return null;
      }
    } else {
      returnType = MEvaluator.toTypeRef(type.getValueType(), pScope);
    }
    final String name = MEvaluator.toSymbol(pName).getName();

    final VarAssign[] params = params2.toArray(new VarAssign[0]);
    return new Function(pPos, pFlags, name, returnType, params, pBody);
  }

  private LinePosition getChar(final char pChar) throws TokenException {
    final CharToken read = aCharStream.getNextToken();
    if (read.getChar() != pChar) {
      aScope.getContext().fatalError(read, "Expected '" + pChar + "', found: '" + read.getChar() + "'");
    }
    return read.getPos();
  }

  private char peekChar() throws TokenException {
    return aCharStream.peek().getNextToken().getChar();
  }

  private void skipWhiteSpace() throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return;
    }

    char c = firstToken.getChar();
    while (isWhiteSpace(c)) {
      peek.take();
      if (aCharStream.eof()) {
        break;
      }
      c = peek.getNextToken().getChar();
    }
    if (c == '/') {
      char d = peek.getNextToken().getChar();
      if (d == '/') {
        peek.take();
        while (d != '\n') {
          d = aCharStream.getNextToken().getChar();
        }
        skipWhiteSpace(); // After comments new white space can start
      } else if (d == '*') {
        peek.take();
        int close = 0;
        d = aCharStream.getNextToken().getChar();
        while ((close != 1) || (d != '/')) {
          if ((d == '*') && (close == 0)) {
            close = 1;
          } else {
            close = 0;
          }
          d = aCharStream.getNextToken().getChar();
        }
        skipWhiteSpace(); // after comments new white space can start
      }
    }
  }

  private static VarAssign[] toVarAssigns(final List<Expression> pAsList, final Scope pScope) throws CompilationException {
    final VarAssign[] result = new VarAssign[pAsList.size()];
    int i = 0;
    for (final Expression expr : pAsList) {
      result[i] = MEvaluator.toVarAssign(expr, pScope);
      ++i;
    }
    return result;
  }

  private static JavaKeywords getKeyword(final Symbol pTmpSymbol) {
    if (pTmpSymbol == null) {
      return null;
    }
    final String symbol = pTmpSymbol.getName();
    return JavaKeywords.fromString(symbol);
  }

  private Expression handleKeyword(final JavaKeywords pKeyword, final List<AnnotateToken> pFlags, final Symbol pSymbol) throws TokenException, CompilationError {
    skipWhiteSpace();
    if (pFlags.size() > 0) {
      aScope.getContext().error(pFlags.get(0), CompilationErrors.KEYWORD_NO_FLAG);
    }
    switch (pKeyword) {
      case RETURN:
        return new Return(pSymbol.getPos(), parseExpression());
      case THROW:
        return new Throw(pSymbol.getPos(), parseExpression());
      case PACKAGE:
        break;
      case IF:
        return parseIf(pSymbol.getPos());
      case FOR:
        return parseFor(pSymbol.getPos());
      case DO:
        return parseDo(pSymbol.getPos());
      case WHILE:
        return parseWhile(pSymbol.getPos());
      case ABSTRACT:
        break;
      case ASSERT:
        break;
      case BOOLEAN:
        break;
      case BREAK:
        break;
      case BYTE:
        break;
      case CASE:
        break;
      case CATCH:
        break;
      case CHAR:
        break;
      case CLASS:
        break;
      case CONST:
        break;
      case CONTINUE:
        break;
      case DEFAULT:
        break;
      case DOUBLE:
        break;
      case ELSE:
        break;
      case ENUM:
        break;
      case EXTENDS:
        break;
      case FINAL:
        break;
      case FINALLY:
        break;
      case FLOAT:
        break;
      case GOTO:
        break;
      case IMPLEMENTS:
        break;
      case IMPORT:
        break;
      case INSTANCEOF:
        break;
      case INT:
        break;
      case INTERFACE:
        break;
      case LONG:
        break;
      case NATIVE:
        break;
      case NEW:
        break;
      case PRIVATE:
        break;
      case PROTECTED:
        break;
      case PUBLIC:
        break;
      case SHORT:
        break;
      case STATIC:
        break;
      case STRICTFP:
        break;
      case SUPER:
        break;
      case SWITCH:
        break;
      case SYNCHRONIZED:
        break;
      case THIS:
        break;
      case THROWS:
        break;
      case TRANSIENT:
        break;
      case TRY:
        break;
      case VOID:
        break;
      case VOLATILE:
        break;
    }
    throw new IllegalStateException("Should be unreachable " + pKeyword);
  }

  public AnnotateToken parseAnnotate() throws TokenException {
    final LinePosition start = getChar('@');
    final CharToken next = aCharStream.peek().getNextToken();
    final Symbol symbol = parseSymbol();
    if (symbol == null) {
      aScope.getContext().error(next, "An annotation is an @ followed by an NMToken without separator.");
      return null;
    }
    MTupple pParams = null;
    if (peekChar() == '(') {
      pParams = parseTupple();
    }
    return new AnnotateToken(start, symbol.getName(), pParams);
  }

  private List<AnnotateToken> parseAnnotations() throws TokenException {
    final List<AnnotateToken> result = new ArrayList<>();
    CharToken firstToken = aCharStream.peek().getNextToken();
    while (firstToken.getChar() == '@') {
      result.add(parseAnnotate());
      skipWhiteSpace();
      firstToken = aCharStream.peek().getNextToken();
    }
    return result;
  }

  private Expression parseArrayAccess(final Expression pExpression) throws TokenException {
    final LinePosition startPos = aCharStream.peek().getNextToken().getPos();
    getChar('[');
    skipWhiteSpace();
    final Expression index = parseExpression();
    skipWhiteSpace();
    getChar(']');
    final FuncCall result = FuncCall.create(startPos, pExpression, new Symbol(startPos, "operator["), TypeRef.ANY, new Expression[] { index });
    return result;
  }

  private static TypeRef<ArrayType> parseArrayType(final Expression pExpression, final Scope pScope) throws CompilationException {
    final TypeRef<?> elemType = MEvaluator.toTypeRef(pExpression, pScope);
    final ArrayType arrayType = new ArrayType(elemType);

    return arrayType.getRef();
  }

  private Expression parseCast(final Symbol pSymbol) throws TokenException {
    skipWhiteSpace();
    getChar('<');
    skipWhiteSpace();
    final Expression destType = parseExpression('>');
    skipWhiteSpace();
    getChar('>');
    skipWhiteSpace();
    getChar('(');
    final Expression expression = parseExpression();
    getChar(')');
    return new TypeCast(pSymbol.getPos(), destType, expression);
  }

  private Loop parseDo(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final MTupple body = parseTupple();
    skipWhiteSpace();
    final Symbol _while = parseSymbol();
    if ((_while == null) || (!_while.getName().equals("while"))) {
      aScope.getContext().error(_while, CompilationErrors.EXPECT_THEN);
      return null;
    }
    skipWhiteSpace();
    final MTupple condition = parseTupple();
    return Loop.newDo(pPos, body, condition);
  }

  private Expression parseExpression(final char... pBarrier) throws TokenException {
    final List<AnnotateToken> flags = new ArrayList<>();
    boolean addedFlag = true;
    Expression expression = null;
    while (addedFlag) {
      addedFlag = false;
      final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
      final char c = peek.getNextToken().getChar();
      peek.reset();
      switch (c) {
        case '@': {
          flags.add(parseAnnotate());
          skipWhiteSpace();
          addedFlag = true;
          break;
        }
        case '(': {
          expression = parseTupple();
          if (flags.size() > 0) {
            aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.TUPPLE_NO_FLAG);
          }
          break;
        }
        case '[': {
          // Start of a function type literal
          expression = parseFuncTypeLiteral(aScope, flags);

          // TODO see what to do about flags
          return expression;
        }
        case '!':
        case '¬':
          if (expression != null) {
            aScope.getContext().error(peek.getNextToken(), "Not Operator found without left operand");
            break;
          }
          expression = parseNot(aCharStream.getNextToken());
          break;
        case '+': {
          peek.getNextToken();
          if ('+' == peek.getNextToken().getChar()) {
            expression = parsePreInc();
          }
          peek.reset();
          break;
        }
        case '-': {
          peek.getNextToken();
          if ('-' == peek.getNextToken().getChar()) {
            expression = parsePreDec();
          }
          peek.reset();
          break;
        }
        default: {
          final PeekBuffer<LiteralToken<MLang, ?>, MLang> literalPeek = aLiteralParser.peek();
          if (literalPeek.getNextToken() != null) {
            final LiteralToken<MLang, ?> literal = aLiteralParser.getNextToken();
            literalPeek.take();
            // TODO Literals can not actually be assigned (yet)
            return Literal.createByInference(literal.getPos(), literal.getValue());
          } else {

            final Symbol tmpSymbol = parseSymbol();
            final JavaKeywords kw = getKeyword(tmpSymbol);
            if (kw != null) {
              expression = handleKeyword(kw, flags, tmpSymbol);
            } else {
              expression = tmpSymbol;
            }
          }
        }
      }
    }
    if (expression == null) {
      aScope.getContext().error(aCharStream.peek().getNextToken(), "Expected expression, but none found");
      return null;
    }
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    Expression typeToken;
    boolean hasType = false;
    {
      loop: while (!peek.eof()) {
        final char c = peek.getNextToken().getChar();
        peek.reset();
        for (final char b : pBarrier) {
          if (c == b) {
            return expression;
          }
        }
        switch (c) {
          case '(': {
            expression = parseFuncCall(expression);
            skipWhiteSpace();
            break;
          }
          case '[': {
            peek.getNextToken();
            final char d = peek.getNextToken().getChar();
            if (d == ']') {
              peek.take();
              expression = parseArrayType(expression, aScope);
            } else {
              expression = parseArrayAccess(expression);
            }
            skipWhiteSpace();
            break;
          }
          case '=': {
            peek.getNextToken();
            final char d = peek.getNextToken().getChar();
            peek.reset();
            if (d == '=') {
              expression = parseOperator(expression);
              skipWhiteSpace();
              break;
            }
            break loop;
          }
          case '.': {
            expression = parsePeriodOperator(expression);
            skipWhiteSpace();
            break;
          }
          case '+':
          case '-':
          case '*':
          case '×':
          case '!':
          case '/':
          case '%':
          case '^':
          case '&':
          case '∧':
          case '∨':
          case '≠':
          case '≤':
          case '≥':
          case '|':
          case '<':
          case '>': {
            if (expression == null) {
              aScope.getContext().error(peek.getNextToken(), "Operator found without left operand");
              break;
            } else {
              final Expression newExpression = parseOperator(expression);
              if (newExpression == null) {
                break loop;
              }
              expression = newExpression;
              skipWhiteSpace();
              break;
            }
          }
          case 'i': {
            final Symbol symbol = peekSymbol();
            if ((symbol != null) && "instanceof".equals(symbol.getName())) {
              expression = parseInstanceof(expression);
              skipWhiteSpace();
              break;
            }
            break loop;
          }
          default:
            break loop;
        }
      }
      if (peek.eof()) {
        aScope.getContext().error(expression, "End of file found while looking for end of expression");
      }
    }
    if (peek.getNextToken().getChar() == ':') {
      peek.take();
      hasType = true;
      skipWhiteSpace();
      typeToken = parseExpression(':', '=');
      skipWhiteSpace();
    } else {
      peek.reset();
      typeToken = TypeRef.ANY;
    }
    if (peek.getNextToken().getChar() == '=') {
      peek.take();
      skipWhiteSpace();
      final Expression value = parseExpression();
      return new VarAssign(expression.getPos(), flags, expression, typeToken, value);
    }
    if (hasType) {
      return new VarAssign(expression.getPos(), flags, expression, typeToken, null);
    }
    return expression;
  }

  private Expression parseFuncCall(final Expression pName) throws TokenException {
    final MTupple _params = parseTupple();

    //    return new FunctionCallToken<MLang>(MLang.FUNCCALL, pName.getPos(), pName, _params.getElements());

    Expression myTarget = null;
    Expression myMethod = pName;
    // TODO make it work on reflective symbols
    while ((myMethod != null) && (myMethod.getTokenType() != MLang.SYMBOL)) {
      if (myMethod.getTokenType() == MLang.BINARYOPERATOR) {

        final BinaryExpression operator = (BinaryExpression) myMethod;
        myTarget = operator.getLeft();
        myMethod = operator.getRight();
      } else {
        // Is not named
        myTarget = myMethod;
        return FuncCall.create(pName.getPos(), myMethod, new Symbol(_params.getPos(), "operator()"), _params.asList());
      }
    }

    final Expression target = myTarget;
    if ((myMethod == null) || (myMethod.getTokenType() != MLang.SYMBOL)) {
      // TODO support more
      aScope.getContext().error(pName, "Unsupported operation");
      return null;
    }
    final List<Expression> params = _params.asList();
    //    List<TypeRef<?>> paramTypes = getTypes(params, pScope);
    final Symbol name = (Symbol) myMethod;

    return FuncCall.create(pName.getPos(), target, name, params);


  }

  private Conditional parseIf(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final Expression condition = parseExpression();
    skipWhiteSpace();
    Symbol symbol = parseSymbol();
    if ((symbol == null) || (!symbol.getName().equals("then"))) {
      aScope.getContext().error(symbol, CompilationErrors.EXPECT_THEN);
      return null;
    }
    skipWhiteSpace();
    final Expression _then = parseExpression();
    skipWhiteSpace();
    symbol = peekSymbol();
    if ((symbol != null) && symbol.getName().equals("else")) {
      parseSymbol();
      skipWhiteSpace();
      final Expression _else = parseExpression();
      return new Conditional(pPos, condition, _then, _else);
    }
    return new Conditional(pPos, condition, _then);
  }

  private void parseImport() throws TokenException {
    final StringBuilder result = new StringBuilder();
    Symbol symbol = parseSymbol();
    if (symbol == null) {
      aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
      return;
    }
    result.append(symbol.getName());
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    while (peek.getNextToken().getChar() == '.') {
      peek.take();
      if (peek.getNextToken().getChar() != '*') {
        peek.reset();
        skipWhiteSpace();
        symbol = parseSymbol();
        if (symbol == null) {
          aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
          return;
        }
        result.append('.').append(symbol.getName());
      } else {
        result.append(".*");
        break;
      }
    }
    peek.reset();
    // This uses the internals of scope to bypass Global imports
    aScope.addTypeImport(result.toString());
  }

  private InstanceofToken parseInstanceof(final Expression pExpression) throws TokenException {
    final Symbol start = parseSymbol();
    if (!"instanceof".equals(start.getName())) {
      throw new IllegalStateException("This should not happen");
    }
    skipWhiteSpace();
    final Expression type = parseExpression();
    return new InstanceofToken(start.getPos(), pExpression, type);
  }

  private Expression parseFor(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    getChar('(');
    skipWhiteSpace();
    final Expression init = parseExpression();
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    {
      final char c = peek.getNextToken().getChar();
      // TODO handle terminator
      if ((c == '←') || ((c == '<') && (peek.getNextToken().getChar() == '-'))) {
        peek.take();
        // foreach
        skipWhiteSpace();
        final Expression collection = parseExpression();
        skipWhiteSpace();
        getChar(')');
        skipWhiteSpace();
        final MTupple body = parseTupple();
        return ForEach.newForEach(pPos, init, collection, body);
      } else {
        peek.reset();
        getChar(',');
        skipWhiteSpace();
        final Expression condition = parseExpression();
        skipWhiteSpace();
        getChar(',');
        skipWhiteSpace();
        final Expression control = parseExpression();
        skipWhiteSpace();
        getChar(')');
        final MTupple body = parseTupple();
        return Loop.newFor(pPos, init, condition, control, body);
      }
    }
  }

  // TODO rename
  private Expression parseFuncTypeLiteral(final Scope pScope, final List<AnnotateToken> pFlags) throws TokenException {
    final LinePosition startPos = getChar('[');
    skipWhiteSpace();
    final Expression expression = parseExpression();
    skipWhiteSpace();
    getChar(']');


    if (expression.getTokenType() != MLang.VARASSIGN) {
      aScope.getContext().error(expression, CompilationErrors.ILLEGAL_FUNCTION_TYPE_LITERAL);
    }
    final VarAssign assign = (VarAssign) expression;


    final TypeRef<?> owner = null;
    ;
    final Expression valueType = assign.getValueType();
    TypeRef<?> returnType;
    if (valueType.getTokenType() != MLang.TUPPLE) {
      returnType = MEvaluator.toTypeRef(valueType, pScope);
    } else {
      final MTupple tupple = (MTupple) valueType;
      if (tupple.size() == 0) {
        returnType = null; // void method
      } else if (tupple.size() == 1) {
        returnType = MEvaluator.toTypeRef(tupple.get(0), pScope);
      } else {
        throw new UnsupportedOperationException("No multiple return values allowed yet");
      }

    }
    VarAssign[] newParams;
    final Expression paramDecl = assign.getLValue();
    if (paramDecl instanceof MTupple) {
      final MTupple tupple = (MTupple) paramDecl;
      newParams = toVarAssigns(tupple.asList(), null);
    } else {
      final VarAssign x = MEvaluator.toVarAssign(paramDecl, null);
      newParams = new VarAssign[] { x };
    }
    return new FunctionType(startPos, pFlags, owner, returnType, newParams);
  }

  private Expression parseNot(final CharToken pToken) throws TokenException {
    skipWhiteSpace();
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(pToken.getPos(), expr, new Symbol(pToken.getPos(), "operator!"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  // TODO make operators extensible, but not yet
  private Expression parseOperator(final Expression pLeft) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    {
      final char c = peek.getNextToken().getChar();
      if (((c == '+') || (c == '-')) && (peek.getNextToken().getChar() == c)) {
        // We have post and pre dec and inc
        if (c == '+') {
          return parsePostInc(pLeft);
        } else {
          return parsePostDec(pLeft);
        }
      }
    }

    final OperatorToken<BinaryOperatorTokens> operatorToken = aBinaryOperatorParser.getNextToken();
    if (operatorToken == null) {
      return null;
    }
    BinaryOperatorTokens operatorType = operatorToken.getTokenType();
    skipWhiteSpace();
    Expression left = pLeft;
    Expression right = parseExpression();
    if (right.getTokenType() == MLang.BINARYOPERATOR) {
      final BinaryExpression right2 = (BinaryExpression) right;
      if (operatorType.compare(right2.getOperator()) <= 0) {
        /* Assign to the left */
        left = new BinaryExpression(left.getPos(), operatorType, left, right2.getLeft());
        operatorType = right2.getOperator();
        right = right2.getRight();
      }

    }
    return new BinaryExpression(pLeft.getPos(), operatorType, left, right);
  }

  private PackageDecl parsePackage(final List<AnnotateToken> pAnnotations, final LinePosition pTokenPos) throws TokenException {
    skipWhiteSpace();
    final StringBuilder result = new StringBuilder();
    Symbol symbol = parseSymbol();
    if (symbol == null) {
      aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
      return null;
    }
    result.append(symbol.getName());
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    while (peek.getNextToken().getChar() == '.') {
      peek.take();
      skipWhiteSpace();
      symbol = parseSymbol();
      if (symbol == null) {
        aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
        return null;
      }
      result.append('.').append(symbol.getName());
    }
    peek.reset();
    return new PackageDecl(pTokenPos, result.toString());
  }

  private Expression parsePeriodOperator(final Expression pExpression) throws TokenException {
    getChar('.');
    skipWhiteSpace();
    final Expression left = pExpression;
    final Symbol right = parseSymbol();
    return new BinaryExpression(left.getPos(), BinaryOperatorTokens.MEMBERACCESS, left, right);
  }

  private Expression parsePostDec(final Expression pExpression) throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('-');
    getChar('-');
    final FuncCall fc = FuncCall.create(start, pExpression, new Symbol(start, "operator_--"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePostInc(final Expression pExpression) throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('+');
    getChar('+');
    final FuncCall fc = FuncCall.create(start, pExpression, new Symbol(start, "operator_++"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePreDec() throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('-');
    getChar('-');
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(start, expr, new Symbol(start, "operator--_"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private Expression parsePreInc() throws TokenException {
    final LinePosition start = aCharStream.peek().getNextToken().getPos();
    getChar('+');
    getChar('+');
    final Expression expr = parseExpression();
    final FuncCall fc = FuncCall.create(start, expr, new Symbol(start, "operator++_"), TypeRef.ANY, new Expression[0]);
    return fc;
  }

  private void parseStaticImport() throws TokenException {
    final StringBuilder result = new StringBuilder();
    Symbol symbol = parseSymbol();
    if (symbol == null) {
      aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
      return;
    }
    result.append(symbol.getName());
    skipWhiteSpace();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    while (peek.getNextToken().getChar() == '.') {
      peek.take();
      if (peek.getNextToken().getChar() != '*') {
        peek.reset();
        skipWhiteSpace();
        symbol = parseSymbol();
        if (symbol == null) {
          aScope.getContext().error(aCharStream.peek().getNextToken(), CompilationErrors.EXPECT_SYMBOL);
          return;
        }
        result.append('.').append(symbol.getName());
      } else {
        result.append(".*");
        break;
      }
    }
    peek.reset();
    try {
      aScope.addStaticImport(result.toString());
    } catch (final EvaluationException ex) {
      throw new TokenException(symbol, ex);
    }
  }

  private Symbol parseSymbol() throws TokenException {
    return aSymbolParser.getNextToken();
  }

  private Symbol peekSymbol() throws TokenException {
    return aSymbolParser.peek().getNextToken();
  }

  private MTupple parseTupple() throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
    skipWhiteSpace();
    final LinePosition startPos = getChar('(');
    skipWhiteSpace();
    if (peek.getNextToken().getChar() == ')') {
      peek.take();
      return new MTupple(startPos);
    } else {
      peek.reset();
    }
    final List<Expression> elements = new ArrayList<>();
    char c = ',';
    while (c == ',') {
      skipWhiteSpace();

      // Allow trailing commas, just for convenience
      if ((c = peek.getNextToken().getChar()) == ')') {
        break;
      }
      peek.reset();

      elements.add(parseExpression());
      skipWhiteSpace();
      if ((c = peek.getNextToken().getChar()) == ',') {
        peek.take();
      }
    }
    getChar(')');
    return new MTupple(startPos, elements);
  }

  private Loop parseWhile(final LinePosition pPos) throws TokenException {
    skipWhiteSpace();
    final MTupple condition = parseTupple();
    skipWhiteSpace();
    final MTupple body = parseTupple();
    return Loop.newWhile(pPos, condition, body);
  }

  /**
   * Parse the stream for all whitespace. Returns null if there is no
   * whitespace.
   * 
   * @param pChar The character to check on being whitespace.
   * @return <code>true</code> if the character is whitespace,
   *         <code>false</code> if not.
   */
  public static boolean isWhiteSpace(final char pChar) {
    return (pChar == ' ') || (pChar == '\t') || (pChar == Const._CR) || (pChar == Const._LF);
  }

  @Override
  public boolean eof() {
    return aCharStream.eof();
  }

  @Override
  public int getPos() {
    return aCharStream.getPos();
  }

  @Override
  public Iterator<LinedToken<MLang>> iterator() {
    return new Iterator<LinedToken<MLang>>() {

      @Override
      public boolean hasNext() {
        final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aCharStream.peek();
        char ch = ' ';
        while (!peek.eof() && Character.isWhitespace(ch)) {
          try {
            ch = peek.getNextToken().getChar();
          } catch (final TokenException e) {
            throw new RuntimeException("Character streams should not have unexpected tokens", e);
          }
        }
        return !peek.eof();
      }

      @Override
      public LinedToken<MLang> next() {
        try {
          return getNextToken();
        } catch (final TokenException e) {
          throw new RuntimeException(e);
        }
      }

      @Override
      public void remove() {
        throw new UnsupportedOperationException("Removing tokens out of a parsing stream makes no sense.");

      }

    };
  }

}
