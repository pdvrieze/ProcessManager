package net.devrieze.meta;

import meta.lang.TypeRef;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.MLang;


public interface NamedObject {

  /**
   * Compile the reference to the referred object. The result is that the object
   * is put on the stack.
   * 
   * @param pToken TODO
   * @param pScope The scope
   * @param pCleanupStack TODO
   * @throws CompilationException
   */
  TypeRef<?> compileRef(LinedToken<MLang> pToken, Scope pScope, boolean pCleanupStack) throws CompilationException;

  /**
   * Get the type of the referred to object. This is the same as the result of
   * {@link #compileRef(LinedToken, Scope, boolean)}.
   * 
   * @param pScope
   * @return
   */
  TypeRef<?> getReferredType(Scope pScope);

  /**
   * Compile assignment to the referred object. This should fail when assignment
   * is illegal on the object
   * 
   * @param pScope
   * @param pToken TODO
   * @param pCleanupStack TODO
   * @return The type of the new value on the stack.
   * @throws CompilationException
   */
  TypeRef<?> compileAssign(Scope pScope, LinedToken<MLang> pToken, boolean pCleanupStack) throws CompilationException;

}
