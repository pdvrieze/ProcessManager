package net.devrieze.meta;

import meta.lang.Expression;
import meta.lang.FunctionRef;
import meta.lang.Symbol;
import meta.lang.TypeRef;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;
import net.devrieze.meta.eval.EvalResult;
import net.devrieze.parser.LinePosition;


public abstract class AbstractExpression implements Expression {


  private final LinePosition aPosition;


  public AbstractExpression(final LinePosition pPosition) {
    aPosition = pPosition;
  }

  @Override
  public EvalResult eval(final Scope pScope) throws CompilationException {
    throw new UnsupportedOperationException(getClass().getName() + " - Not yet implemented");
  }

  @Override
  public FunctionRef resolveFunction(final Scope pScope, final Symbol pName, final TypeRef<?>... pParamTypes) throws CompilationException {
    throw new UnsupportedOperationException(getClass().getName() + " - Not yet implemented");
  }

  @Override
  public String toMetaCode(final int pIndent) {
    return toString();
  }

  @Override
  public LinePosition getPos() {
    return aPosition;
  }

}
