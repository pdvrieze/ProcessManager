/**
 * This package provides parsers for streams.
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.parser.streams;

