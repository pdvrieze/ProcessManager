/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.lang.Const;
import net.devrieze.parser.AbstractBufferedTokenStream;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.TokenType;
import net.devrieze.parser.TokenTypeFactory;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.tokens.CharToken;


/**
 * A tokenstream that reads from a string.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class StringTokenStream extends AbstractBufferedTokenStream<CharToken, CharStreamEnum> {

  protected static final TokenTypeFactory _FACTORY = new TokenTypeFactory();

  public static final TokenType _CHARTOKEN = _FACTORY.getTokenType("Char");

  private final String aString;

  private int aPos;

  private int aLinePos = 1;

  private int aLineNo = 1;

  public StringTokenStream(final String pString) {
    super(null);
    aString = pString;
  }

  /**
   * Does not do anything as Strings don't need to be closed.
   */
  @Override
  public void close() {
    // NOP for
  }

  @Override
  protected boolean sourceEof() {
    return aPos >= aString.length();
  }

  /**
   * Get the next character in the string.
   *
   * @see net.devrieze.parser.AbstractBufferedTokenStream#readNextToken()
   * @todo Make the newline system work, this needs not using
   *       {@link AbstractBufferedTokenStream}
   */
  @Override
  protected CharToken readNextToken() {
    if (aPos >= aString.length()) {
      return null;
    }
    final CharToken result = new CharToken(new LinePosition(null, aPos, aLineNo, aLinePos), aString.charAt(aPos));
    aPos++;
    aLinePos++;
    if (result.getChar() == Const._CR) {
      if ((aPos < aString.length()) && (aString.charAt(aPos) == Const._LF)) {
        pushBufferToken(new CharToken(new LinePosition(null, aPos, aLineNo, aLinePos), aString.charAt(aPos)), aPos + 1);
        aPos++;
      }
      aLineNo++;
      aLinePos = 1;
    } else if (result.getChar() == Const._LF) {
      if ((aPos < aString.length()) && (aString.charAt(aPos) == Const._CR)) {
        pushBufferToken(new CharToken(new LinePosition(null, aPos, aLineNo, aLinePos), aString.charAt(aPos)), aPos + 1);
        aPos++;
      }
      aLineNo++;
      aLinePos = 1;
    }
    return result;
  }

  @Override
  protected int getSourcePos() {
    return aPos;
  }

  @Override
  public String toString() {
    final StringBuilder b = new StringBuilder("StringTokenStream read: ").append(getPos()).append("-'");
    if (getPos() < aString.length()) {
      b.append(aString.charAt(getPos()));
    } else {
      b.append("EOF");
    }
    b.append("\'");
    return b.toString();
  }

  /**
   * Add a context to the description of the error. This allows for more human
   * understandeable error messages.
   *
   * @param <T> The type of the exception to which the context must be added.
   * @param pException The exception to which to add the context
   * @return The context of the exception
   */
  public <T extends TokenException> T addContext(final T pException) {
    final int pos = pException.getToken().getPos().getOffset();
    int lineStart = pos;
    int lineEnd = pos;
    while ((lineStart >= 0) && (aString.charAt(lineStart) != Const._CR) && (aString.charAt(lineStart) != Const._LF)) {
      lineStart--;
    }
    lineStart++;
    while ((lineEnd < aString.length()) && (aString.charAt(lineEnd) != Const._CR) && (aString.charAt(lineEnd) != Const._LF)) {
      lineEnd++;
    }
    final StringBuilder b = new StringBuilder(aString.substring(lineStart, lineEnd));
    b.append('\n');
    for (int i = lineStart; i < pos; i++) {
      b.append(' ');
    }
    b.append("^\n");
    if (pException.getToken().getPos() instanceof LinePosition) {
      final LinePosition t = (LinePosition) pException.getToken().getPos();
      b.append("At line: ").append(t.getLineNo()).append(" at Character: ").append(t.getLinePos());
    } else {
      b.append("At position: ").append(pos);
    }

    pException.setTokenContext(b.toString());
    return pException;
  }

}
