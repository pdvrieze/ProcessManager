/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.streams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import net.devrieze.parser.AbstractTokenStream;
import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.UnexpectedTokenException;
import net.devrieze.parser.eval.Type;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.languages.StatementTokens;
import net.devrieze.parser.tokens.*;
import net.devrieze.util.StringUtil;


/**
 * A parser for statements.
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @todo Make the parser provider variable
 */
public class StatementParser extends AbstractTokenStream<LinedToken<StatementTokens>, StatementTokens> implements Iterable<LinedToken<StatementTokens>> {

  private ExpressionParserProvider<ExpressionTokens> aParserProvider;

  /**
   * @param pParentStream
   */
  public StatementParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream.getFile());
    aParserProvider = new DefaultParserProvider(pParentStream);
  }

  public StatementParser(final ExpressionParserProvider<ExpressionTokens> pParserProvider) {
    super(pParserProvider.getExpressionParser().getFile());
    aParserProvider = pParserProvider;
  }

  @Override
  public LinedToken<StatementTokens> getNextToken() throws TokenException {
    return getNextToken(true);
  }

  public LinedToken<StatementTokens> getNextToken(final boolean pParseEOS) throws TokenException {
    aParserProvider.skipWhiteSpace();
    if (eof()) {
      return null;
    }
    if (aParserProvider.getSymbolParser().peek().getNextToken() != null) {
      if (isKeyword(aParserProvider.getSymbolParser().peek().getNextToken().getSymbol())) {
        return handleKeyword(pParseEOS);
      }

      final SymbolToken<ExpressionTokens> symbol1 = aParserProvider.getSymbolParser().getNextToken();
      final ExprToken<ExpressionTokens> accessor = aParserProvider.getExpressionParser().handleAccessor(symbol1);
      if (accessor != symbol1) {
        if (accessor.getTokenType() == ExpressionTokens.ARRAYACCESS) {
          return handleArrayAssign(accessor);
        } else if (accessor.getTokenType() == ExpressionTokens.FUNCCALL) {
          return handleFunctionCall((FunctionCallToken<ExpressionTokens>) accessor);
        } else if (accessor.getTokenType() != ExpressionTokens.OBJECTACCESS) {
          throw new UnexpectedTokenException("Unknown accessor found", accessor);
        } /* Let Object access tokens flow through */
      } /* no else, objects also apply */

      aParserProvider.skipWhiteSpace();
      if (peekAssignment()) {
        getAssignment();
        aParserProvider.skipWhiteSpace();
        final ExprToken<ExpressionTokens> expression = aParserProvider.getExpressionParser().getNextToken();
        return new AssignmentToken<>(StatementTokens.ASSIGN, symbol1.getPos(), accessor, expression);
      }
      if (pParseEOS) {
        getEndOfStatement();
      }
      return handleSymbolExpr(symbol1);
    } else if (peekBlockOpen()) {
      return handleBlockOpen();
    } else if (aParserProvider.getCharStream().peek().getNextToken().getChar() == ';') {
      getEndOfStatement(); // Empty statement
      return null;
    } else {
      final ExprToken<ExpressionTokens> token = aParserProvider.getExpressionParser().getNextToken();
      getEndOfStatement();
      return new ExprStatementToken<>(StatementTokens.EXPR, token.getPos(), token);
    }
  }

  /**
   * @param pAccessor
   * @return A statement token for assignment to array variables
   * @throws TokenException
   */
  protected StatementToken<StatementTokens> handleArrayAssign(final ExprToken<ExpressionTokens> pAccessor) throws TokenException {
    aParserProvider.skipWhiteSpace();
    getAssignment();
    aParserProvider.skipWhiteSpace();
    final ExprToken<ExpressionTokens> value = aParserProvider.getExpressionParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    getEndOfStatement();
    return new AssignmentToken<>(StatementTokens.ASSIGN, pAccessor.getPos(), pAccessor, value);
  }

  /**
   * @param pAccessor
   * @return A function call token
   * @throws TokenException
   */
  protected StatementToken<StatementTokens> handleFunctionCall(final FunctionCallToken<ExpressionTokens> pAccessor) throws TokenException {
    getEndOfStatement();
    return new VoidStatementToken<>(StatementTokens.FUNCCALL, pAccessor.getPos(), pAccessor);
  }

  /**
   * @param pSymbol
   * @return A function call token
   * @throws TokenException
   */
  protected StatementToken<StatementTokens> handleSymbolExpr(final SymbolToken<ExpressionTokens> pSymbol) throws TokenException {
    //    getEndOfStatement();
    return new ExprStatementToken<>(StatementTokens.EXPR, pSymbol.getPos(), pSymbol);
  }

  /**
   * @return A block statement token
   * @throws TokenException
   */
  protected LinedToken<StatementTokens> handleBlockOpen() throws TokenException {
    final List<LinedToken<StatementTokens>> subStatements = new ArrayList<>();
    final CharToken firstToken = aParserProvider.getCharStream().getNextToken();
    assertTokenS('{', firstToken);
    aParserProvider.skipWhiteSpace();
    while (aParserProvider.getCharStream().peek().getNextToken().getChar() != '}') {
      final LinedToken<StatementTokens> subStatement = getNextToken();
      if (subStatement != null) {
        subStatements.add(subStatement);
      }
      aParserProvider.skipWhiteSpace();
    }
    assertTokenS('}', aParserProvider.getCharStream().getNextToken());
    return new BlockToken<>(StatementTokens.BLOCK, firstToken.getPos(), subStatements);
  }

  protected boolean peekBlockOpen() throws TokenException {
    if (aParserProvider.getCharStream().peek().getNextToken().getChar() == '{') {
      return true;
    }
    return false;
  }

  protected void getEndOfStatement() throws TokenException {
    assertTokenS(';', aParserProvider.getCharStream().getNextToken());
  }

  protected void getAssignment() throws TokenException {
    assertTokenS('=', aParserProvider.getCharStream().getNextToken());
  }

  protected boolean peekAssignment() throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aParserProvider.getCharStream().peek();
    final CharToken nextToken = peek != null ? peek.getNextToken() : null;
    return nextToken != null ? nextToken.getChar() == '=' : false;
  }

  /**
   * Handle the parsing of a keyword.
   * 
   * @param pParseEOS Determines whether the endofstatement token also has to be
   *          parsed.
   * @return The token representing the result of the keyword
   * @throws TokenException
   */
  protected LinedToken<StatementTokens> handleKeyword(final boolean pParseEOS) throws TokenException {
    final SymbolToken<ExpressionTokens> firstToken = aParserProvider.getSymbolParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    if (StringUtil.isEqual(firstToken.getSymbol(), "return")) {
      final ReturnToken<StatementTokens, ExpressionTokens> result = new ReturnToken<>(StatementTokens.RETURN, firstToken.getPos(), aParserProvider.getExpressionParser().getNextToken());
      if (pParseEOS) {
        getEndOfStatement();
      }
      return result;
    } else if (StringUtil.isEqual(firstToken.getSymbol(), "func")) {
      return handleFuncDef(firstToken, pParseEOS);
    } else if ((StringUtil.isEqual(firstToken.getSymbol(), "int")) || (StringUtil.isEqual(firstToken.getSymbol(), "string"))
        || (StringUtil.isEqual(firstToken.getSymbol(), "boolean")) || (StringUtil.isEqual(firstToken.getSymbol(), "char"))
        || (StringUtil.isEqual(firstToken.getSymbol(), "object")) || (StringUtil.isEqual(firstToken.getSymbol(), "double"))) {
      return handlePrimitive(pParseEOS, firstToken);
    } else if (StringUtil.isEqual(firstToken.getSymbol(), "if")) {
      return handleIf(firstToken);
    } else if (StringUtil.isEqual(firstToken.getSymbol(), "for")) {
      return handleFor(pParseEOS, firstToken);
    } else if (StringUtil.isEqual(firstToken.getSymbol(), "while")) {
      return handleWhile(firstToken);
    }
    throw new UnexpectedTokenException("Keyword " + firstToken.getSymbol() + " found while not expected", firstToken);
  }

  private StatementToken<StatementTokens> handleWhile(final SymbolToken<ExpressionTokens> pFirstToken) throws TokenException {
    aParserProvider.skipWhiteSpace();
    final LinedToken<ExpressionTokens> condition = aParserProvider.getExpressionParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    if (aParserProvider.getCharStream().peek().getNextToken().getChar() == ';') {
      getEndOfStatement();
      aParserProvider.skipWhiteSpace();
    }
    SymbolToken<ExpressionTokens> symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    final ArrayList<LinedToken<StatementTokens>> action = new ArrayList<>();
    while ((symbol == null) || (!(symbol.getSymbol().toString().equals("endwhile")))) {
      final LinedToken<StatementTokens> subStatement = getNextToken();
      if (subStatement != null) {
        action.add(subStatement);
      }
      aParserProvider.skipWhiteSpace();
      symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    }
    aParserProvider.getSymbolParser().getNextToken();
    return new WhileToken<>(StatementTokens.WHILE, pFirstToken.getPos(), condition, action);
  }

  private StatementToken<StatementTokens> handleFor(final boolean pParseEOS, final SymbolToken<ExpressionTokens> pFirstToken) throws TokenException {
    aParserProvider.skipWhiteSpace();
    assertTokenS('(', aParserProvider.getCharStream().getNextToken());
    aParserProvider.skipWhiteSpace();
    final LinedToken<StatementTokens> init = getNextToken(true);
    aParserProvider.skipWhiteSpace();
    final LinedToken<ExpressionTokens> condition = aParserProvider.getExpressionParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    getEndOfStatement();
    final LinedToken<StatementTokens> cont = getNextToken(false);
    aParserProvider.skipWhiteSpace();
    assertTokenS(')', aParserProvider.getCharStream().getNextToken());
    final LinedToken<StatementTokens> action = getNextToken(pParseEOS);
    return new ForToken<>(StatementTokens.FOR, pFirstToken.getPos(), init, condition, cont, action);
  }

  private LinedToken<StatementTokens> handleIf(final SymbolToken<ExpressionTokens> pFirstToken) throws TokenException {
    aParserProvider.skipWhiteSpace();
    final LinedToken<ExpressionTokens> condition = aParserProvider.getExpressionParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    SymbolToken<ExpressionTokens> symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    if ((symbol != null) && symbol.getSymbol().toString().equals("then")) {
      aParserProvider.getSymbolParser().getNextToken();
      aParserProvider.skipWhiteSpace();
      final LinedToken<StatementTokens> subStatement = getNextToken();
      final List<LinedToken<StatementTokens>> then = Collections.singletonList(subStatement);
      return new IfToken<>(StatementTokens.IF, pFirstToken.getPos(), condition, then, new ArrayList<LinedToken<StatementTokens>>());
    }

    if (aParserProvider.getCharStream().peek().getNextToken().getChar() == ';') {
      getEndOfStatement();
    }
    aParserProvider.skipWhiteSpace();
    symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    final ArrayList<LinedToken<StatementTokens>> then = new ArrayList<>();
    while ((symbol == null) || (!(symbol.getSymbol().toString().equals("else") || symbol.getSymbol().toString().equals("endif")))) {
      final LinedToken<StatementTokens> subStatement = getNextToken();
      if (subStatement != null) {
        then.add(subStatement);
      }
      aParserProvider.skipWhiteSpace();
      symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    }
    if (symbol.getSymbol().toString().equals("else")) {
      symbol = aParserProvider.getSymbolParser().getNextToken();
    }
    final ArrayList<LinedToken<StatementTokens>> alt = new ArrayList<>();
    while ((symbol == null) || (!symbol.getSymbol().toString().equals("endif"))) {
      final LinedToken<StatementTokens> subStatement = getNextToken();
      if (subStatement != null) {
        alt.add(subStatement);
      }
      aParserProvider.skipWhiteSpace();
      symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    }
    aParserProvider.getSymbolParser().getNextToken();/* Skip endif */
    return new IfToken<>(StatementTokens.IF, pFirstToken.getPos(), condition, then, alt);
  }

  private StatementToken<StatementTokens> handlePrimitive(final boolean pParseEOS, final SymbolToken<ExpressionTokens> pFirstToken) throws TokenException {
    final String name = aParserProvider.getSymbolParser().getNextToken().getSymbol().toString();

    aParserProvider.skipWhiteSpace();
    ExprToken<ExpressionTokens> value;
    if (peekAssignment()) {
      getAssignment();
      aParserProvider.skipWhiteSpace();
      value = aParserProvider.getExpressionParser().getNextToken();
    } else {
      value = null;
    }
    if (pParseEOS) {
      getEndOfStatement();
    }
    if (StringUtil.isEqual(pFirstToken.getSymbol(), "int")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_INT, name, value);
    } else if (StringUtil.isEqual(pFirstToken.getSymbol(), "double")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_DOUBLE, name, value);
    } else if (StringUtil.isEqual(pFirstToken.getSymbol(), "string")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_STRING, name, value);
    } else if (StringUtil.isEqual(pFirstToken.getSymbol(), "boolean")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_BOOLEAN, name, value);
    } else if (StringUtil.isEqual(pFirstToken.getSymbol(), "char")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_CHAR, name, value);
    } else if (StringUtil.isEqual(pFirstToken.getSymbol(), "object")) {
      return new VarDefToken<>(StatementTokens.VARDEF, pFirstToken.getPos(), Type._VT_OBJECT, name, value);
    }
    throw new UnexpectedTokenException("we should never get here", pFirstToken);
  }

  /**
   * @param pFirstToken
   * @param pParseEOS
   * @return The token corresponding to this function definition.
   * @throws TokenException
   */
  private StatementToken<StatementTokens> handleFuncDef(final SymbolToken<?> pFirstToken, final boolean pParseEOS) throws TokenException {
    final SymbolToken<ExpressionTokens> funcName = aParserProvider.getSymbolParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    assertTokenS('(', aParserProvider.getCharStream().getNextToken());
    final List<VarDefToken<StatementTokens, ExpressionTokens>> params = new ArrayList<>();
    aParserProvider.skipWhiteSpace();
    while (aParserProvider.getSymbolParser().peek().getNextToken() != null) {
      final SymbolToken<ExpressionTokens> paramTypeToken = aParserProvider.getSymbolParser().getNextToken();
      final Type paramType = Type.typeForName(paramTypeToken.getSymbol().toString());
      aParserProvider.skipWhiteSpace();
      final String paramName = aParserProvider.getSymbolParser().getNextToken().getSymbol().toString();
      aParserProvider.skipWhiteSpace();
      params.add(new VarDefToken<StatementTokens, ExpressionTokens>(StatementTokens.VARDEF, paramTypeToken.getPos(), paramType, paramName, null));
      if (aParserProvider.getCharStream().peek().getNextToken().getChar() == ')') {
        break;
      }
      assertTokenS(',', aParserProvider.getCharStream().getNextToken());
      aParserProvider.skipWhiteSpace();
    }
    assertTokenS(')', aParserProvider.getCharStream().getNextToken());
    if (aParserProvider.getCharStream().peek().getNextToken().getChar() == ';') {
      getEndOfStatement();
    }
    SymbolToken<ExpressionTokens> symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    final List<LinedToken<StatementTokens>> body = new ArrayList<>();
    while ((symbol == null) || (!symbol.getSymbol().toString().equals("endfunc"))) {
      final LinedToken<StatementTokens> subStatement = getNextToken();
      if (subStatement != null) {
        body.add(subStatement);
      }
      aParserProvider.skipWhiteSpace();
      symbol = aParserProvider.getSymbolParser().peek().getNextToken();
    }
    aParserProvider.getSymbolParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    if (pParseEOS) {
      getEndOfStatement();
    }
    return new FuncDefToken<>(StatementTokens.FUNCDEF, pFirstToken.getPos(), funcName.getSymbol(), params, body);
  }

  /**
   * A function that determines whether a symbol is a keyword.
   * 
   * @param pSymbol
   * @return <code>true</code> if it is, <code>false</code> if not.
   */
  protected boolean isKeyword(final CharSequence pSymbol) {
    if (StringUtil.isEqual(pSymbol, "return") || StringUtil.isEqual(pSymbol, "int") || StringUtil.isEqual(pSymbol, "string")
        || StringUtil.isEqual(pSymbol, "double") || StringUtil.isEqual(pSymbol, "char") || StringUtil.isEqual(pSymbol, "object")
        || StringUtil.isEqual(pSymbol, "func") || StringUtil.isEqual(pSymbol, "if") || StringUtil.isEqual(pSymbol, "while")
        || StringUtil.isEqual(pSymbol, "for") || StringUtil.isEqual(pSymbol, "boolean")) {
      return true;
    }
    return false;
  }

  @Override
  public boolean eof() {
    return aParserProvider.getCharStream().eof();
  }

  @Override
  public int getPos() {
    return aParserProvider.getCharStream().getPos();
  }


  public ExpressionParserProvider<ExpressionTokens> getParserProvider() {
    return aParserProvider;
  }


  public void setParserProvider(final ExpressionParserProvider<ExpressionTokens> pParserProvider) {
    aParserProvider = pParserProvider;
  }

  @Override
  public Iterator<LinedToken<StatementTokens>> iterator() {
    return new Iterator<LinedToken<StatementTokens>>() {

      @Override
      public boolean hasNext() {
        final PeekBuffer<? extends CharToken, CharStreamEnum> peek = aParserProvider.getCharStream().peek();
        char ch = ' ';
        while (!peek.eof() && Character.isWhitespace(ch)) {
          try {
            ch = peek.getNextToken().getChar();
          } catch (final TokenException e) {
            throw new RuntimeException("Character streams should not have unexpected tokens", e);
          }
        }
        return !peek.eof();
      }

      @Override
      public LinedToken<StatementTokens> next() {
        try {
          return getNextToken();
        } catch (final TokenException e) {
          throw new RuntimeException(e);
        }
      }

      @Override
      public void remove() {
        throw new UnsupportedOperationException("Removing tokens out of a parsing stream makes no sense.");

      }

    };
  }

}
