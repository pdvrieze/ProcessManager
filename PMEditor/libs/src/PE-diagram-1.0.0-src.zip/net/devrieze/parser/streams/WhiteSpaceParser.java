/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.*;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.MiscTokens;
import net.devrieze.parser.tokens.AbstractLinedToken;
import net.devrieze.parser.tokens.CharToken;


/**
 * A parser for whitespace.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class WhiteSpaceParser extends ForwardingTokenStream<MiscTokens, LinedToken<MiscTokens>, CharStreamEnum, CharToken> {

  public static class WhiteSpaceToken extends AbstractLinedToken<MiscTokens> {

    private final CharSequence aChars;

    public WhiteSpaceToken(final LinePosition pPos, final CharSequence pChars) {
      super(MiscTokens.WHITESPACE, pPos);
      aChars = pChars;
    }

    public CharSequence getChars() {
      return aChars;
    }

  }

  /**
   * @param pParentStream
   */
  public WhiteSpaceParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream);
  }

  @Override
  protected LinedToken<MiscTokens> readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final StringBuilder b = new StringBuilder();
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return null;
    }

    char c = firstToken.getChar();
    while (isWhiteSpace(c)) {
      b.append(c);
      peek.take();
      if (pBuffer.eof()) {
        break;
      }
      c = peek.getNextToken().getChar();
    }
    if (b.length() > 0) {
      return new WhiteSpaceToken(firstToken.getPos(), b);
    }
    return null;
  }

  /**
   * Parse the stream for all whitespace. Returns null if there is no
   * whitespace.
   * 
   * @param pChar The character to check on being whitespace.
   * @return <code>true</code> if the character is whitespace,
   *         <code>false</code> if not.
   * @deprecated in favor of {@link Character#isWhitespace(char)}
   */
  @Deprecated
  public static boolean isWhiteSpace(final char pChar) {
    return Character.isWhitespace(pChar);
  }

}
