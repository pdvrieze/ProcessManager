/*
 * Created on Dec 15, 2005
 *
 */
package net.devrieze.parser.streams;

import java.io.File;
import java.io.IOException;
import java.io.Reader;

import net.devrieze.lang.Const;
import net.devrieze.parser.AbstractBufferedTokenStream;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.UnexpectedTokenException;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.util.StringUtil;


/**
 * A tokenstream for input streams.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ReaderTokenStream extends AbstractBufferedTokenStream<CharToken, CharStreamEnum> {

  private final Reader aReader;

  private int aLineNo;

  private int aLinePos;

  private int aStreamPos;

  private String aLastLine = "";

  private StringBuilder aCurrentLine;

  private boolean aEof = false;

  /**
   * Create a new file based tokenstream.
   *
   * @param pIn The stream to base the tokenstream on.
   */
  public ReaderTokenStream(final File pFile, final Reader pIn) {
    super(pFile);
    aReader = pIn;
    aLineNo = 1;
    aLinePos = 1;
    aCurrentLine = new StringBuilder();
  }

  private int read() throws IOException {
    final int result = aReader.read();
    if (result >= 0) {
      aStreamPos++;
    } else {
      aEof = true;
    }
    return result;
  }

  /** {@inheritDoc} */
  @Override
  protected CharToken readNextToken() throws UnexpectedTokenException {
    try {
      final LinePosition position = new LinePosition(getFile(), aStreamPos, aLineNo, aLinePos);
      int c = read();
      if (c < 0) {
        return null;
      }
      if (c == Const._CR) {
        c = read();
        if (c >= 0) {
          if (c == Const._LF) {
            pushBufferToken(new CharToken(new LinePosition(getFile(), position.getOffset() + 1, aLineNo, aLinePos + 1), (char) c), position.getOffset() + 2);
            aLastLine = aCurrentLine.toString();
            aCurrentLine = new StringBuilder();
            aLinePos = 1;
          } else {
            pushBufferToken(new CharToken(new LinePosition(getFile(), position.getOffset() + 1, aLineNo + 1, 1), (char) c), position.getOffset() + 2);
            if (c == Const._CR) {
              aLineNo++;
              aLastLine = "";
              aCurrentLine = new StringBuilder();
              aLinePos = 1;
            } else {
              aLastLine = aCurrentLine.toString();
              aCurrentLine = new StringBuilder((char) c);
              aLinePos = 2;
            }
          }
          aLineNo++;
        }
        return new CharToken(position, Const._CR);
      } else if (c == Const._LF) {
        c = read();
        if (c >= 0) {
          if (c == Const._CR) {
            pushBufferToken(new CharToken(new LinePosition(getFile(), position.getOffset() + 1, aLineNo, aLinePos + 1), (char) c), position.getOffset() + 2);
            aLastLine = aCurrentLine.toString();
            aCurrentLine = new StringBuilder();
            aLinePos = 1;
          } else {
            pushBufferToken(new CharToken(new LinePosition(getFile(), position.getOffset() + 1, aLineNo + 1, 1), (char) c), position.getOffset() + 2);
            if (c == Const._LF) {
              aLineNo++;
              aLastLine = "";
              aCurrentLine = new StringBuilder();
              aLinePos = 1;
            } else {
              aLastLine = aCurrentLine.toString();
              aCurrentLine = new StringBuilder((char) c);
              aLinePos = 2;
            }
          }
          aLineNo++;
        }
        return new CharToken(position, Const._LF);
      } else {
        aLinePos++;
        aCurrentLine.append((char) c);
      }

      return new CharToken(position, (char) c);
    } catch (final IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws IOException
   */
  @Override
  protected boolean sourceEof() throws IOException {
    return peekEof();
  }

  private boolean peekEof() {
    /*
     * Force the detection of the end of the stream. If there are bytes
     * available, the end of the stream has not been reached. Else peek the next
     * token, as that will an eof if the end of the stream was reached.
     */
    try {
      if (!aReader.ready()) {
        peek().getNextToken();
      }
    } catch (final TokenException e) {
      e.printStackTrace();
    } catch (final IOException e) {
      e.printStackTrace();
    }
    return aEof;
  }

  /** {@inheritDoc} */
  @Override
  public int getSourcePos() {
    return aStreamPos;
  }

  /**
   * Close the underlying stream.
   *
   * @throws IOException When something goes wrong.
   */
  @Override
  public void close() throws IOException {
    aReader.close();
  }

  /**
   * Use this stream to add a context to the token exception.
   *
   * @param pE The token to add a context to.
   */
  public void addContext(final TokenException pE) {
    if (pE.getToken() instanceof LinedToken) {
      final LinedToken<?> token = (LinedToken<?>) pE.getToken();
      final int lineNo = token.getPos().getLineNo();
      StringBuilder line;
      if (lineNo == aLineNo) {
        int c;
        try {
          while ((c = read()) >= 0) {
            if ((c == Const._CR) || (c == Const._LF)) {
              break;
            }
            aCurrentLine.append((char) c);
          }
        } catch (final IOException e) {
          /* Ignore exceptions */
        }
        line = aCurrentLine;
      } else if (lineNo == (aLineNo - 1)) {
        line = new StringBuilder(aLastLine);
      } else {
        return;
      }
      line.append('\n');
      for (int i = 0; i < token.getPos().getLinePos(); i++) {
        line.append(' ');
      }
      line.append("^\nAt line: ").append(lineNo);
      line.append(" at Character: ").append(token.getPos().getLinePos());
      pE.setTokenContext(line.toString());
    }
  }

  protected Reader getReader() {
    return aReader;
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder();
    result.append(StringUtil.toLengthString(aLineNo, 4)).append(':').append(aCurrentLine).append('\n');
    result.append(StringUtil.toLengthString(aLinePos, 4)).append(':');
    result.append(StringUtil.charRepeat(aLinePos - 1, ' ')).append('^');
    return result.toString();
  }

}
