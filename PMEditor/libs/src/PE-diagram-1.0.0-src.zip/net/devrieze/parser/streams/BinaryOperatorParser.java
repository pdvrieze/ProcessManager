/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.ForwardingTokenStream;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.OperatorToken;


/**
 * A parser for binary operators.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class BinaryOperatorParser extends ForwardingTokenStream<BinaryOperatorTokens, OperatorToken<BinaryOperatorTokens>, CharStreamEnum, CharToken> {

  /**
   * Create a new parser based on the given stream.
   * 
   * @param pParentStream The parent stream.
   */
  public BinaryOperatorParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream);
  }

  /** {@inheritDoc} */
  @Override
  protected OperatorToken<BinaryOperatorTokens> readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return null;
    }
    switch (firstToken.getChar()) {
      case '+': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.PLUS, firstToken.getPos());
      }
      case '-': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.MINUS, firstToken.getPos());
      }
      case '×':
      case '*': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.TIMES, firstToken.getPos());
      }
      case '/': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.DIV, firstToken.getPos());
      }
      case '%': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.MOD, firstToken.getPos());
      }
      case '^': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.POWER, firstToken.getPos());
      }
      case '.': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.MEMBERACCESS, firstToken.getPos());
      }
      case '=': {
        if (peek.getNextToken().getChar() == '=') {
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.EQUALS, firstToken.getPos());
        }
        return null;
      }
      case '≠':
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.UNEQUALS, firstToken.getPos());
      case '!': {
        if (peek.getNextToken().getChar() == '=') {
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.UNEQUALS, firstToken.getPos());
        }
        return null;
      }
      case '∧': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.LOGIC_AND, firstToken.getPos());
      }
      case '&': {
        if (peek.getNextToken().getChar() == '&') {
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.LOGIC_AND, firstToken.getPos());
        }
        return null;
      }
      case '∨': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.LOGIC_OR, firstToken.getPos());
      }
      case '|': {
        if (peek.getNextToken().getChar() == '|') {
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.LOGIC_OR, firstToken.getPos());
        }
        return null;
      }
      case '≤': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.LESSEQ, firstToken.getPos());
      }
      case '<': {
        final PeekBuffer<? extends CharToken, CharStreamEnum> peek2 = peek.peek();
        final char nextChar = peek2.getNextToken().getChar();
        if (nextChar == '=') {
          peek2.take();
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.LESSEQ, firstToken.getPos());
        }
        if (nextChar == '-') {
          return null;
        }
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.LESS, firstToken.getPos());
      }
      case '≥': {
        peek.take();
        return new OperatorToken<>(BinaryOperatorTokens.GREATEREQ, firstToken.getPos());
      }
      case '>': {
        peek.take();
        if (peek.getNextToken().getChar() == '=') {
          peek.take();
          return new OperatorToken<>(BinaryOperatorTokens.GREATEREQ, firstToken.getPos());
        }
        return new OperatorToken<>(BinaryOperatorTokens.GREATER, firstToken.getPos());
      }
      default: {
        return null;
      }
    }
  }

}
