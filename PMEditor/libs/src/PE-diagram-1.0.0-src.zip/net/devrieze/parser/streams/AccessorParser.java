/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.ForwardingTokenStream;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.AccessorTokens;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.OperatorToken;


/**
 * A parser that parses accessors for symbols.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class AccessorParser extends ForwardingTokenStream<AccessorTokens, OperatorToken<AccessorTokens>, CharStreamEnum, CharToken> {

  /**
   * @param pParentStream
   */
  public AccessorParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream);
  }

  /** {@inheritDoc} */
  @Override
  protected OperatorToken<AccessorTokens> readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return null;
    }
    switch (firstToken.getChar()) {
      case '[': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.ARRAYACCESSOPEN, firstToken.getPos());
      }
      case ']': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.ARRAYACCESSCLOSE, firstToken.getPos());
      }
      case '.': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.OBJECTACCESS, firstToken.getPos());
      }
      case '(': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.FUNCTIONACCESSOPEN, firstToken.getPos());
      }
      case ',': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.FUNCTIONACCESSSEPARATOR, firstToken.getPos());
      }
      case ')': {
        peek.take();
        return new OperatorToken<>(AccessorTokens.FUNCTIONACCESSCLOSE, firstToken.getPos());
      }
      default: {
        return null;
      }
    }
  }

}
