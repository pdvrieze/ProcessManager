/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.ForwardingUnexpectedTokenException;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.*;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LiteralToken;
import net.devrieze.parser.tokens.OperatorToken;
import net.devrieze.parser.tokens.SymbolToken;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class DefaultParserProvider implements ExpressionParserProvider<ExpressionTokens> {

  private final BufferedTokenStream<? extends CharToken, CharStreamEnum> aCharStream;

  private final WhiteSpaceParser aWhiteSpaceParser;

  private final BufferedTokenStream<? extends OperatorToken<UnaryOperatorTokens>, UnaryOperatorTokens> aUnaryOperatorParser;

  private final BinaryOperatorParser aBinaryOperatorParser;

  private final LiteralParser<ExpressionTokens> aLiteralParser;

  private final SymbolParser<ExpressionTokens, SymbolToken<ExpressionTokens>> aSymbolParser;

  private final AccessorParser aAccessorParser;

  private ExpressionParser aExpressionParser;

  public DefaultParserProvider(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) {
    aCharStream = pStream;
    aWhiteSpaceParser = new WhiteSpaceParser(pStream);
    aUnaryOperatorParser = new UnaryOperatorParser(pStream);
    aBinaryOperatorParser = new BinaryOperatorParser(pStream);
    aLiteralParser = new LiteralParser<>(ExpressionTokens.LITERAL, pStream);
    aSymbolParser = new SymbolParser<>(false, pStream, SymbolToken.getFactory(ExpressionTokens.SYMBOL));
    aAccessorParser = new AccessorParser(pStream);
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends CharToken, CharStreamEnum> getCharStream() {
    return aCharStream;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends LinedToken<MiscTokens>, MiscTokens> getWhiteSpaceParser() {
    return aWhiteSpaceParser;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends OperatorToken<AccessorTokens>, AccessorTokens> getAccessorParser() {
    return aAccessorParser;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends OperatorToken<BinaryOperatorTokens>, BinaryOperatorTokens> getBinaryOperatorParser() {
    return aBinaryOperatorParser;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends LiteralToken<ExpressionTokens, ?>, ExpressionTokens> getLiteralParser() {
    return aLiteralParser;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends SymbolToken<ExpressionTokens>, ExpressionTokens> getSymbolParser() {
    return aSymbolParser;
  }

  /** {@inheritDoc} */
  @Override
  public BufferedTokenStream<? extends OperatorToken<UnaryOperatorTokens>, UnaryOperatorTokens> getUnaryOperatorParser() {
    return aUnaryOperatorParser;
  }

  /** {@inheritDoc} */
  @Override
  public void skipWhiteSpace() throws TokenException {
    try {
      aWhiteSpaceParser.getNextToken();
    } catch (final ForwardingUnexpectedTokenException e) {
      /* Ignore this exception */
    }
  }

  /** {@inheritDoc} */
  @Override
  public ExpressionParser getExpressionParser() {
    if (aExpressionParser == null) {
      aExpressionParser = new ExpressionParser(this);
    }
    return aExpressionParser;
  }

}
