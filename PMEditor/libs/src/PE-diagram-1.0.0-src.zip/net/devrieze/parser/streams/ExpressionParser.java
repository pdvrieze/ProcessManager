/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.streams;

import java.util.ArrayList;
import java.util.List;

import net.devrieze.annotation.Published;
import net.devrieze.parser.*;
import net.devrieze.parser.languages.*;
import net.devrieze.parser.tokens.*;


/**
 * A TokenStream that produces expression tokens.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@Published({ "net.devrieze.parser.inherit", "net.devrieze.parser.use" })
public class ExpressionParser extends AbstractTokenStream<ExprToken<ExpressionTokens>, ExpressionTokens> {

  private static class UnaryExprTokenImpl extends UnaryExprToken<ExpressionTokens> {

    /**
     * Create a new impl.
     * 
     * @param pOperatorType Type of the token.
     * @param pPos Position of the token.
     * @param pSubToken The subtoken.
     */
    protected UnaryExprTokenImpl(final ExpressionTokens pOperatorType, final LinePosition pPos, final ExprToken<ExpressionTokens> pSubToken) {
      super(pOperatorType, pPos, pSubToken);
    }
  }

  /**
   * A class representing an accessor token.
   * 
   * @param <T> The type of the tokens.
   * @author Paul de Vrieze
   */
  public static class AccessorToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> implements ExprToken<T> {

    private final ExprToken<T> aTarget;

    private final ExprToken<T> aQualifier;

    /**
     * Create a new Accessor token.
     * 
     * @param pTokenType The type of the token.
     * @param pPos The position of the token.
     * @param pTarget The token (tree) being accessed.
     * @param pQualifier The token (tree) representing the access.
     */
    protected AccessorToken(final T pTokenType, final LinePosition pPos, final ExprToken<T> pTarget, final ExprToken<T> pQualifier) {
      super(pTokenType, pPos);
      aTarget = pTarget;
      aQualifier = pQualifier;
    }

    public ExprToken<T> getTarget() {
      return aTarget;
    }

    public ExprToken<T> getQualifier() {
      return aQualifier;
    }

  }

  private final ExpressionParserProvider<ExpressionTokens> aParserProvider;

  /**
   * Create a new expression parser.
   * 
   * @param pStream The stream to base the parser on.
   */
  public ExpressionParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) {
    super(pStream.getFile());
    aParserProvider = new DefaultParserProvider(pStream);
  }

  /**
   * Create a new expression parser based on a nondefault parser provider.
   * 
   * @param pParserProvider The provider to use for parsing subtokens.
   */
  public ExpressionParser(final ExpressionParserProvider<ExpressionTokens> pParserProvider) {
    super(pParserProvider.getCharStream().getFile());
    aParserProvider = pParserProvider;
  }

  /** {@inheritDoc} */
  @Override
  @SuppressWarnings("unchecked")
  public ExprToken<ExpressionTokens> getNextToken() throws TokenException {
    aParserProvider.skipWhiteSpace();
    final ExprToken<ExpressionTokens> left = getSingleToken();

    aParserProvider.skipWhiteSpace();

    final OperatorToken<BinaryOperatorTokens> operator = aParserProvider.getBinaryOperatorParser().peek().getNextToken();
    if (operator == null) {
      return left;
    }

    aParserProvider.getBinaryOperatorParser().getNextToken();
    aParserProvider.skipWhiteSpace();
    final ExprToken<ExpressionTokens> right = getNextToken();
    if (right.getTokenType() == ExpressionTokens.BINARYOPERATOR) {
      final BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>> right2 = (BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>>) right;
      if (operator.getTokenType().compare(right2.getOperatorType()) <= 0) {
        /* Assign to the left */
        final ExprToken<ExpressionTokens> newLeft = new BinaryExprToken<>(ExpressionTokens.BINARYOPERATOR, operator.getTokenType(), left.getPos(), left, right2.getLeft());
        return new BinaryExprToken<>(ExpressionTokens.BINARYOPERATOR, right2.getOperatorType(), left.getPos(), newLeft, right2.getRight());
      }

      return new BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>>(ExpressionTokens.BINARYOPERATOR, operator.getTokenType(), left.getPos(), left, right);
    }

    return new BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>>(ExpressionTokens.BINARYOPERATOR, operator.getTokenType(), left.getPos(), left, right);
  }

  private UnaryExprToken<ExpressionTokens> handleUnaryOperator() throws TokenException {
    final OperatorToken<UnaryOperatorTokens> firstToken = aParserProvider.getUnaryOperatorParser().peek().getNextToken();
    if (firstToken.getTokenType() == UnaryOperatorTokens.NOT) {
      assertToken(UnaryOperatorTokens.NOT, aParserProvider.getUnaryOperatorParser().getNextToken());
      aParserProvider.skipWhiteSpace();
      /*
       * TODO check whether this is correct, symbols should also fall under
       * this, and other unaries.
       */
      return new UnaryExprTokenImpl(ExpressionTokens.NOT, firstToken.getPos(), getSingleToken());
    } else if (firstToken.getTokenType() == UnaryOperatorTokens.PARENOPEN) {

      assertNextToken(UnaryOperatorTokens.PARENOPEN, aParserProvider.getUnaryOperatorParser());
      aParserProvider.skipWhiteSpace();
      final ExprToken<ExpressionTokens> subToken = getNextToken();
      aParserProvider.skipWhiteSpace();
      assertNextToken(UnaryOperatorTokens.PARENCLOSE, aParserProvider.getUnaryOperatorParser());

      return new UnaryExprTokenImpl(ExpressionTokens.PAREN, firstToken.getPos(), subToken);
    } else {
      throw new UnexpectedTokenException("An unexpected token encountered", firstToken);
    }
  }

  /** {@inheritDoc} */
  @Override
  @Published({ "net.devrieze.parser.inherit" })
  protected void assertToken(final Language<?> pExpected, final Token<?> pReceived) throws TokenException {
    if (pReceived == null) {
      final CharToken found = aParserProvider.getCharStream().peek().getNextToken();
      if (found != null) {
        throw new UnexpectedTokenException("Expected " + pExpected + " but found " + found.getTokenType(), found);
      }

      super.assertToken(pExpected, pReceived);
    } else {
      super.assertToken(pExpected, pReceived);
    }
  }

  private ExprToken<ExpressionTokens> getSingleToken() throws TokenException {
    if (aParserProvider.getUnaryOperatorParser().peek().getNextToken() != null) {
      return handleAccessor(handleUnaryOperator());
    } else if (aParserProvider.getLiteralParser().peek().getNextToken() != null) {
      return handleAccessor(aParserProvider.getLiteralParser().getNextToken());
    } else if (aParserProvider.getSymbolParser().peek().getNextToken() != null) {
      return handleAccessor(aParserProvider.getSymbolParser().getNextToken());
    }
    throw new UnexpectedTokenException("Expected, a unary operator, literal or symbol, but found", aParserProvider.getCharStream().getNextToken());
  }

  /**
   * Handle an accessor token.
   * 
   * @param pLeft The token to handle
   * @return The resulting expression token.
   * @throws UnexpectedTokenException
   */
  @Published({ "net.devrieze.parser.inherit" })
  public ExprToken<ExpressionTokens> handleAccessor(final ExprToken<ExpressionTokens> pLeft) throws TokenException {
    final OperatorToken<AccessorTokens> accessor = aParserProvider.getAccessorParser().peek().getNextToken();
    if (accessor == null) {
      return pLeft;
    }
    switch (accessor.getTokenType()) {
      case ARRAYACCESSOPEN: {
        assertNextToken(AccessorTokens.ARRAYACCESSOPEN, aParserProvider.getAccessorParser());
        aParserProvider.skipWhiteSpace();
        final ExprToken<ExpressionTokens> right = getNextToken();
        aParserProvider.skipWhiteSpace();
        assertNextToken(AccessorTokens.ARRAYACCESSCLOSE, aParserProvider.getAccessorParser());
        return handleAccessor(new AccessorToken<>(ExpressionTokens.ARRAYACCESS, pLeft.getPos(), pLeft, right));
      }
      case OBJECTACCESS: {
        assertNextToken(AccessorTokens.OBJECTACCESS, aParserProvider.getAccessorParser());
        final ExprToken<ExpressionTokens> right = aParserProvider.getSymbolParser().getNextToken();
        assertToken(ExpressionTokens.SYMBOL, right);
        return handleAccessor(new AccessorToken<>(ExpressionTokens.OBJECTACCESS, pLeft.getPos(), pLeft, right));
      }
      case FUNCTIONACCESSOPEN: {
        assertNextToken(AccessorTokens.FUNCTIONACCESSOPEN, aParserProvider.getAccessorParser());
        final List<ExprToken<ExpressionTokens>> params = new ArrayList<>();
        aParserProvider.skipWhiteSpace();
        OperatorToken<AccessorTokens> a = aParserProvider.getAccessorParser().peek().getNextToken();
        while ((a == null) || (a.getTokenType() != AccessorTokens.FUNCTIONACCESSCLOSE)) {
          params.add(getNextToken());
          aParserProvider.skipWhiteSpace();
          a = aParserProvider.getAccessorParser().peek().getNextToken();
          if ((a == null)
              || ((a.getTokenType() != AccessorTokens.FUNCTIONACCESSSEPARATOR) && (a.getTokenType() != AccessorTokens.FUNCTIONACCESSCLOSE))) {
            throw new UnexpectedTokenException("Unexpected token found while parsing function parameters", a != null ? a
                : aParserProvider.getCharStream().peek().getNextToken());
          }
          if (a.getTokenType() == AccessorTokens.FUNCTIONACCESSSEPARATOR) {
            aParserProvider.getAccessorParser().getNextToken();
            aParserProvider.skipWhiteSpace();
          }
        }
        assertNextToken(AccessorTokens.FUNCTIONACCESSCLOSE, aParserProvider.getAccessorParser());
        return handleAccessor(new FunctionCallToken<>(ExpressionTokens.FUNCCALL, pLeft.getPos(), pLeft, params));
      }
      case ARRAYACCESSCLOSE:
      case FUNCTIONACCESSSEPARATOR:
      case FUNCTIONACCESSCLOSE:
        return pLeft;
    }
    throw new UnexpectedTokenException("Unknown accessor found", accessor);
  }

  /** {@inheritDoc} */
  @Override
  public boolean eof() {
    return aParserProvider.getCharStream().eof();
  }

  /** {@inheritDoc} */
  @Override
  public int getPos() {
    return aParserProvider.getCharStream().getPos();
  }

}
