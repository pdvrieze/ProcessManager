/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.lang.Const;
import net.devrieze.parser.*;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.LineStreamEnum;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LineToken;


/**
 * A tokenstream that produces lines.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class LineTokenStream extends ForwardingTokenStream<LineStreamEnum, LineToken, CharStreamEnum, CharToken> {

  /** The tokentype factory for this type. */
  protected static final TokenTypeFactory _FACTORY = new TokenTypeFactory();

  /** The token type for a line. */
  public static final TokenType _LINETOKEN = _FACTORY.getTokenType("Line");

  /**
   * Create a new line token stream based on the given char token stream.
   * 
   * @param pSource The source stream.
   */
  public LineTokenStream(final BufferedTokenStream<CharToken, CharStreamEnum> pSource) {
    super(pSource);
  }

  /** {@inheritDoc} */
  @Override
  protected LineToken readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final StringBuilder b = new StringBuilder();
    CharToken token = pBuffer.getNextToken();
    if (token == null) {
      return null;
    }
    final LinePosition startPos = token.getPos();
    char c = token.getChar();
    while ((c != Const._CR) && (c != Const._LF)) {
      b.append(c);
      if (pBuffer.eof()) {
        break;
      }
      token = pBuffer.getNextToken();
      c = token.getChar();
    }
    final CharToken next = pBuffer.peek().getNextToken();
    if ((c == Const._CR) && (next != null) && (next.getChar() == Const._LF)) {
      pBuffer.getNextToken();
      /* Flush an extra cariage return */
    } else if ((c == Const._LF) && (next != null) && (next.getChar() == Const._CR)) {
      pBuffer.getNextToken();
      /* Flush an extra cariage return */
    }
    return new LineToken(startPos, b);
  }
}
