/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.*;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LiteralToken;


/**
 * A parser for parsing literals like digits, strings, booleans, and characters.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @todo redesign for the new peeking implementation.
 */
public class LiteralParser<T extends Enum<T> & Language<T>> extends ForwardingTokenStream<T, LiteralToken<T, ?>, CharStreamEnum, CharToken> {

  private final char aSeparator = '.';

  private final T aTokenType;

  /**
   * @param pTokenType TODO
   * @param pParentStream
   */
  public LiteralParser(final T pTokenType, final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream);
    aTokenType = pTokenType;
  }

  /**
   * {@inheritDoc}
   * 
   * @throws TokenException
   */
  @Override
  protected LiteralToken<T, ?> readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.peek().getNextToken();
    if (firstToken == null) {
      return null;
      //      throw new UnexpectedTokenException("Literal expected but NULL found", firstToken);
    }
    final char c = firstToken.getChar();
    if ((c == '-') || ((c >= '0') && (c <= '9')) || (c == getSeparator())) {
      return readDigit(pBuffer);
    } else if (c == '\'') {
      return readChar(pBuffer);
    } else if (c == '\"') {
      return readString(pBuffer);
    } else if (peekBoolean(pBuffer)) {
      return readBoolean(pBuffer);
    } else if (peekNull(pBuffer)) {
      return readNull(pBuffer);
    } else {
      return null;
    }
  }

  protected boolean peekString(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer, final CharSequence pString) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    for (int i = 0; i < pString.length(); i++) {
      final CharToken c = peek.getNextToken();
      if (c == null) {
        return false;
      } else if (c.getChar() != pString.charAt(i)) {
        return false;
      }
    }
    return true;
  }

  protected boolean peekStringInsensitive(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer, final CharSequence pString) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    for (int i = 0; i < pString.length(); i++) {
      final CharToken c = peek.getNextToken();
      if (c == null) {
        return false;
      } else if (Character.toLowerCase(c.getChar()) != Character.toLowerCase(pString.charAt(i))) {
        return false;
      }
    }
    return true;
  }

  protected boolean peekNull(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    return peekStringInsensitive(pBuffer, "null");
  }

  protected LiteralToken<T, Object> readNull(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.peek().getNextToken();
    if (peekStringInsensitive(pBuffer, "null")) {
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      return new LiteralToken<>(aTokenType, firstToken.getPos(), null);
    }
    throw new UnexpectedTokenException("Expected object literal but found '" + firstToken.getChar() + "'", firstToken);
  }

  protected boolean peekBoolean(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    return peekStringInsensitive(pBuffer, "true") || peekStringInsensitive(pBuffer, "false");
  }

  protected LiteralToken<T, Boolean> readBoolean(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.peek().getNextToken();
    if (peekStringInsensitive(pBuffer, "true")) {
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      return new LiteralToken<>(aTokenType, firstToken.getPos(), Boolean.TRUE);
    } else if (peekStringInsensitive(pBuffer, "false")) {
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      pBuffer.getNextToken();
      return new LiteralToken<>(aTokenType, firstToken.getPos(), Boolean.FALSE);
    }
    throw new UnexpectedTokenException("Expected boolean literal but found '" + firstToken.getChar() + "'", firstToken);
  }

  protected LiteralToken<T, ? extends Number> readDigit(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final StringBuilder b = new StringBuilder();
    final CharToken firstToken = pBuffer.getNextToken();
    final LinePosition firstPos = firstToken.getPos();

    boolean separator = false;
    final char c = firstToken.getChar();
    if ((c != '-') && ((c < '0') || (c > '9')) && (c != aSeparator)) {
      throw new UnexpectedTokenException("Digit literals start with - or a digit", firstToken);
    }
    if (c == aSeparator) {
      separator = true;
    }
    b.append(c);
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    CharToken token = peek.getNextToken();
    while ((!pBuffer.eof()) && (((token.getChar() >= '0') && (token.getChar() <= '9')) || (!separator && (token.getChar() == aSeparator)))) {
      peek.take();
      if (token.getChar() == aSeparator) {
        separator = true;
      }
      b.append(token.getChar());
      token = peek.getNextToken();
    }

    if (separator) {
      try {
        return new LiteralToken<>(aTokenType, firstPos, Double.valueOf(b.toString()));
      } catch (final NumberFormatException e) {
        return null;
      }
    }

    return new LiteralToken<>(aTokenType, firstPos, Integer.valueOf(b.toString()));
  }

  protected LiteralToken<T, Character> readChar(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.getNextToken();
    assertTokenS('\'', firstToken);
    final char c = readSingleChar(pBuffer);
    assertTokenS('\'', pBuffer.getNextToken());
    return new LiteralToken<>(aTokenType, firstToken.getPos(), Character.valueOf(c));
  }

  /**
   * Help method for reading characters, shared for chars and strings.
   * 
   * @param pBuffer The character stream to read from.
   * @return one character, takes escapes into account.
   * @throws TokenException
   */
  protected char readSingleChar(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.getNextToken();
    if (firstToken == null) {
      throw new UnexpectedTokenException("End of file found while parsing char", firstToken);
    }
    if ((firstToken.getChar() == '\n') || (firstToken.getChar() == '\r')) {
      throw new UnexpectedTokenException("End of line within a string literal", firstToken);
    } else if (firstToken.getChar() != '\\') {
      return firstToken.getChar();
    } else {
      final CharToken token = pBuffer.getNextToken();
      switch (token.getChar()) {
        case 'n': {
          return '\n';
        }
        case 'r': {
          return '\r';
        }
        case 't': {
          return '\t';
        }
        case 'f': {
          return '\f';
        }
        case 'b': {
          return '\b';
        }
        case '\\':
        case '"':
        case '\'': {
          return token.getChar();
        }
        default: {
          throw new UnexpectedTokenException("Invalid escape sequence: \\" + firstToken.getChar(), firstToken);
        }

      }
    }
  }

  protected LiteralToken<T, String> readString(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.getNextToken();
    assertTokenS('"', firstToken);

    final StringBuilder b = new StringBuilder();
    while ((pBuffer.peek().getNextToken() != null) && (pBuffer.peek().getNextToken().getChar() != '"')) {
      b.append(readSingleChar(pBuffer));
    }
    assertTokenS('"', pBuffer.getNextToken());
    return new LiteralToken<>(aTokenType, firstToken.getPos(), b.toString());
  }

  public char getSeparator() {
    return aSeparator;
  }

  /** {@inheritDoc} */
  @Override
  public LiteralToken<T, ?> getNextToken() throws TokenException {
    final LiteralToken<T, ?> result = super.getNextToken();
    if (result == null) {
      throw new UnexpectedTokenException("Literal expected", peek().getNextToken());
    }
    return result;
  }
}
