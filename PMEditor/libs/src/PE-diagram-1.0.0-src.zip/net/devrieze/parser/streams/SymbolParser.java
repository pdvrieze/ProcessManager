/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.*;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.CharToken;


/**
 * A parser for symbols.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class SymbolParser<T extends Enum<T> & Language<T>, U extends LinedToken<T>> extends ForwardingTokenStream<T, U, CharStreamEnum, CharToken> {


  public abstract static class SymbolTokenFactory<S extends LinedToken<?>> {

    protected abstract S createSymbol(LinePosition pPosition, String pValue);
  }

  private final SymbolTokenFactory<U> aSymbolTokenFactory;

  private final boolean aHandleOperator;

  public SymbolParser(final boolean pHandleOperator, final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream, final SymbolTokenFactory<U> pSymbolTokenFactory) {
    super(pParentStream);
    aHandleOperator = pHandleOperator;
    aSymbolTokenFactory = pSymbolTokenFactory;
  }

  @Override
  protected U readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final CharToken firstToken = pBuffer.peek().getNextToken();
    final StringBuilder b = new StringBuilder();
    if (firstToken == null) {
      return null;
    }
    if (!isValidFirstChar(firstToken.getChar())) {
      return null;
    }
    b.append(pBuffer.getNextToken().getChar());
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    while ((!pBuffer.eof()) && isValidSymbolChar(peek.getNextToken().getChar())) {
      b.append(pBuffer.getNextToken().getChar());
      if (aHandleOperator) {
        if ((b.length() == 8) && b.toString().equals("operator")) {
          final PeekBuffer<? extends CharToken, CharStreamEnum> newPeek = peek.peek();
          if ((newPeek.getNextToken().getChar() == '(') && (newPeek.getNextToken().getChar() == ')')) {
            pBuffer.getNextToken();
            pBuffer.getNextToken();
            b.append("()");
            break;
          }
          while (isValidOperatorChar(peek.getNextToken().getChar())) {
            b.append(pBuffer.getNextToken().getChar());
          }
          break;
        }
      }
    }
    return aSymbolTokenFactory.createSymbol(firstToken.getPos(), b.toString());
  }

  protected boolean isValidFirstChar(final char pChar) {
    return Character.isJavaIdentifierStart(pChar);
  }

  protected boolean isValidSymbolChar(final char pChar) {
    return Character.isJavaIdentifierPart(pChar);
  }

  protected boolean isValidOperatorChar(final char pChar) {
    switch (pChar) {
      case ' ':
      case ':':
      case '\t':
      case '\n':
      case '(':
        return false;
      default:
        return true;
    }

  }

}
