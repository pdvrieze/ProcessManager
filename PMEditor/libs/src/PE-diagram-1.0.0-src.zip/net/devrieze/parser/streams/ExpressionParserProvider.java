/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.*;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.LiteralToken;
import net.devrieze.parser.tokens.OperatorToken;
import net.devrieze.parser.tokens.SymbolToken;


/**
 * An interface for classes that provide parsers to other parsers.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enumerator of the expression tokens.
 */
public interface ExpressionParserProvider<T extends Enum<T> & Language<T>> {

  /**
   * Get the character stream.
   * 
   * @return The character stream to provide.
   */
  BufferedTokenStream<? extends CharToken, CharStreamEnum> getCharStream();

  /**
   * Get the whitespace parser.
   * 
   * @return The whitespace parser.
   */
  BufferedTokenStream<? extends LinedToken<MiscTokens>, MiscTokens> getWhiteSpaceParser();

  /**
   * Get the binary operator parser.
   * 
   * @return The binary operator parser.
   */
  BufferedTokenStream<? extends OperatorToken<BinaryOperatorTokens>, BinaryOperatorTokens> getBinaryOperatorParser();

  /**
   * Get the unary operator parser.
   * 
   * @return The unary operator parser.
   */
  BufferedTokenStream<? extends OperatorToken<UnaryOperatorTokens>, UnaryOperatorTokens> getUnaryOperatorParser();

  /**
   * Get the literal (string, integer, boolean etc.) parser.
   * 
   * @return The literal parser.
   */
  BufferedTokenStream<? extends LiteralToken<T, ?>, T> getLiteralParser();

  /**
   * Get the symbol parser.
   * 
   * @return The symbol parser.
   */
  BufferedTokenStream<? extends SymbolToken<T>, T> getSymbolParser();

  /**
   * Get the accessor parser.
   * 
   * @return The accessor parser.
   */
  BufferedTokenStream<? extends OperatorToken<AccessorTokens>, AccessorTokens> getAccessorParser();

  /**
   * Utility method for skipping whitespace.
   * 
   * @throws TokenException When an unexpected token is encountered. This should
   *           not happen as no whitespace is also valid.
   */
  void skipWhiteSpace() throws TokenException;

  /**
   * Get the expression parser.
   * 
   * @return The expression parser.
   */
  ExpressionParser getExpressionParser();
}
