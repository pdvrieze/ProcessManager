package net.devrieze.parser.streams;

import java.io.File;
import java.io.IOException;

import net.devrieze.parser.AbstractBufferedTokenStream;
import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.tokens.CharToken;


public class JavaCharStream extends AbstractBufferedTokenStream<CharToken, CharStreamEnum> {

  private final BufferedTokenStream<CharToken, CharStreamEnum> aParent;

  private boolean aSlash;

  public JavaCharStream(final File pFile, final BufferedTokenStream<CharToken, CharStreamEnum> pParent) {
    super(pFile);
    aParent = pParent;
    aSlash = false;
  }

  @Override
  public void close() throws IOException {
    aParent.close();
  }

  @Override
  protected int getSourcePos() {
    return aParent.getPos();
  }

  @Override
  protected CharToken readNextToken() throws TokenException {
    final CharToken sourceToken = aParent.getNextToken();
    if (sourceToken.getChar() == '\\') {
      aSlash = !aSlash;
      if ((!aSlash) && (!aParent.eof())) {
        final PeekBuffer<CharToken, CharStreamEnum> peek = aParent.peek();
        if (peek.getNextToken().getChar() == 'u') {
          char d1;
          do {
            d1 = peek.getNextToken().getChar();
          } while (d1 == 'u');
          final char d2 = peek.getNextToken().getChar();
          final char d3 = peek.getNextToken().getChar();
          final char d4 = peek.getNextToken().getChar();
          if (isHex(d1) && isHex(d2) && isHex(d3) && isHex(d4)) {
            final int intvalue = Integer.parseInt("" + d1 + d2 + d3 + d4, 16);
            return new CharToken(sourceToken.getPos(), (char) intvalue);
          }
        }
      }
    }
    return sourceToken;
  }

  private static boolean isHex(final char pChar) {
    return ((pChar >= '0') && (pChar <= '9')) || ((pChar >= 'A') && (pChar <= 'F')) || ((pChar >= 'a') && (pChar <= 'z'));
  }

  @Override
  protected boolean sourceEof() throws IOException {
    return aParent.eof();
  }

}
