/*
 * Created on Feb 6, 2005
 *
 */
package net.devrieze.parser.streams;

import java.io.*;

import net.devrieze.lang.Const;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.TokenException;


/**
 * A stream of chartokens from a file.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class FileTokenStream extends ReaderTokenStream {

  /**
   * Create a new file based tokenstream.
   * 
   * @param pFile The file.
   * @throws FileNotFoundException When the file is not found.
   * @see FileInputStream#FileInputStream(java.io.File)
   * @todo refactor to use encodings properly
   */
  @SuppressWarnings("resource")
  public FileTokenStream(final File pFile) throws FileNotFoundException {
    super(pFile, new FileReader(pFile));
  }

  /**
   * Use this stream to add a context to the token exception.
   * 
   * @param pE The token to add a context to.
   */
  @Override
  public void addContext(final TokenException pE) {
    if (pE.getToken() instanceof LinedToken) {
      final LinedToken<?> token = (LinedToken<?>) pE.getToken();
      final int lineNo = token.getPos().getLineNo();
      final StringBuilder line = new StringBuilder();
      int c;
      try {
        while ((c = getReader().read()) >= 0) {
          if ((c == Const._CR) || (c == Const._LF)) {
            break;
          }
          line.append((char) c);
        }
      } catch (final IOException e) {
        /* Ignore exceptions */
      }
      line.append('\n');
      for (int i = 0; i < token.getPos().getLinePos(); i++) {
        line.append(' ');
      }
      line.append("^\nAt line: ").append(lineNo);
      line.append(" at Character: ").append(token.getPos().getLinePos());
      pE.setTokenContext(line.toString());
    }
  }

  @Override
  protected FileReader getReader() {
    return (FileReader) super.getReader();
  }

}
