/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.streams;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.ForwardingTokenStream;
import net.devrieze.parser.PeekBuffer;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.UnaryOperatorTokens;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.parser.tokens.OperatorToken;


/**
 * A parser that parses operators with a single argument.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class UnaryOperatorParser extends ForwardingTokenStream<UnaryOperatorTokens, OperatorToken<UnaryOperatorTokens>, CharStreamEnum, CharToken> {

  /**
   * @param pParentStream
   */
  public UnaryOperatorParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pParentStream) {
    super(pParentStream);
  }

  @Override
  protected OperatorToken<UnaryOperatorTokens> readNextToken(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pBuffer) throws TokenException {
    final PeekBuffer<? extends CharToken, CharStreamEnum> peek = pBuffer.peek();
    final CharToken firstToken = peek.getNextToken();
    if (firstToken == null) {
      return null;
    }
    switch (firstToken.getChar()) {
      case '!': {
        if (peek.peek().getNextToken().getChar() == '=') {
          return null; /* Exception for unequals */
        }
        peek.take();
        return new OperatorToken<>(UnaryOperatorTokens.NOT, firstToken.getPos());
      }
      case '(': {
        peek.take();
        return new OperatorToken<>(UnaryOperatorTokens.PARENOPEN, firstToken.getPos());
      }
      case ')': {
        peek.take();
        return new OperatorToken<>(UnaryOperatorTokens.PARENCLOSE, firstToken.getPos());
      }
      default: {
        return null;
      }
    }
  }

}
