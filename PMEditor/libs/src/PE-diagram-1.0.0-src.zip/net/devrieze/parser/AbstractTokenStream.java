/*
 * Created on Jan 7, 2005
 *
 */

package net.devrieze.parser;

import java.io.File;

import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.CharToken;


/**
 * An abstract base class for tokenstreams, implements utility methods.
 * 
 * @param <T> The type of token returned
 * @param <U> The enumeration of all tokentypes
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractTokenStream<T extends Token<U>, U extends Enum<U> & Language<U>> implements TokenStream<T, U> {

  private final File aFile;

  public AbstractTokenStream(final File pFile) {
    aFile = pFile;
  }

  /**
   * Utility function that asserts that the next token is of the expected type.
   * 
   * @param <W> The type of the enumeration.
   * @param <V> The next token
   * @param pExpected The type expected
   * @param pStream The stream from which the token should be retrieved
   * @throws TokenException When the expected token is not next in the stream
   */
  protected <W extends Enum<W> & Language<W>, V extends Token<W>> void assertNextToken(final W pExpected, final TokenStream<V, W> pStream) throws TokenException {
    try {
      final V token = pStream.getNextToken();
      assertToken(pExpected, token);
    } catch (final ForwardingUnexpectedTokenException e) {
      assertToken(pExpected, null);
    }
  }

  /**
   * Utility function that asserts that the given token is of the expected type.
   * 
   * @param pExpected The type expected
   * @param pReceived The token to test
   * @throws TokenException When the token is not of the expected type
   */
  protected void assertToken(final Language<?> pExpected, final Token<?> pReceived) throws TokenException {
    if (pReceived == null) {
      throw new UnexpectedTokenException("Expected " + pExpected + " but found NULL", pReceived);
    }
    if (pReceived.getTokenType() != pExpected) {
      throw new UnexpectedTokenException("Expected " + pExpected + " but found " + pReceived.getTokenType(), pReceived);
    }
  }

  /**
   * Utility function that checks that the token has a certain character.
   * 
   * @param pExpected The character expected
   * @param pReceived The token to test
   * @throws UnexpectedTokenException When the token is not of the expected type
   */
  protected static void assertTokenS(final char pExpected, final CharToken pReceived) throws UnexpectedTokenException {
    if (pReceived == null) {
      throw new UnexpectedTokenException("Expected " + pExpected + " but found NULL", pReceived);
    } else if (pReceived.getChar() != pExpected) {
      throw new UnexpectedTokenException("Expected " + pExpected + " but found " + pReceived.getTokenType(), pReceived);
    }

  }

  @Override
  public File getFile() {
    return aFile;
  }

}
