/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser;

import java.io.IOException;

import net.devrieze.parser.languages.Language;


/**
 * A class that helps in streams that create complex tokens from simple ones.
 * This class allows them to still support the BufferedTokenStream interface,
 * and not violate the parent stream either.
 *
 * @param <T> The type of the source tokens
 * @param <TT> The enumeration of all tokentypes for tokentype <code>T</code>
 * @param <U> The type of the result tokens
 * @param <UT> The enumeration of all tokentypes for tokentype <code>U</code>
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class ForwardingTokenStream<TT extends Enum<TT> & Language<TT>, T extends Token<TT>, UT extends Enum<UT> & Language<UT>, U extends Token<UT>> extends AbstractBufferedTokenStream<T, TT> {

  private final PeekBuffer<? extends U, UT> aParentStream;

  /**
   * Create a new stream.
   *
   * @param pParentStream The stream to base this stream on.
   */
  protected ForwardingTokenStream(final BufferedTokenStream<? extends U, UT> pParentStream) {
    // TODO refactor things to just the file out of aParentStream, not from the instance
    super(pParentStream.getFile());
    aParentStream = pParentStream.peek();
  }

  @Override
  public void close() throws IOException {
    aParentStream.close();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected boolean sourceEof() throws IOException {
    return aParentStream.eof();
  }

  /**
   * Method used to read the next token from a bufferstream.
   *
   * @param pBuffer the buffer to read from.
   * @return The next token in the file, without buffering
   * @throws UnexpectedTokenException When an unexpected token is found
   */
  protected abstract T readNextToken(final BufferedTokenStream<? extends U, UT> pBuffer) throws TokenException;

  @Override
  protected int getSourcePos() {
    return aParentStream.getPos();
  }

  @Override
  protected final T readNextToken() throws TokenException {
    return readNextToken(aParentStream);
  }

  @Override
  public T getNextToken() throws TokenException {
    final T token = super.getNextToken();
    // Shift the parent stream
    aParentStream.take();
    return token;
  }

}
