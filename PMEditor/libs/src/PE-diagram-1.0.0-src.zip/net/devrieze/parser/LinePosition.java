/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser;

import java.io.File;


/**
 * A class representing a position in a line.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class LinePosition extends Position {

  private final int aLinePos;

  private final int aLineNo;

  /**
   * Create a new <code>LinePosition</code>.
   * 
   * @param pPos The position in the file from the start position.
   * @param pLineNo The current line number.
   * @param pLinePos The position in the current line.
   */
  public LinePosition(final File pFile, final int pPos, final int pLineNo, final int pLinePos) {
    super(pFile, pPos);
    aLineNo = pLineNo;
    aLinePos = pLinePos;
  }

  /**
   * Create a new <code>LinePosition</code>.
   * 
   * @param pPos The position in the file from the start position.
   * @param pLineNo The current line number.
   * @param pLinePos The position in the current line.
   */
  public LinePosition(final Position pPos, final int pLineNo, final int pLinePos) {
    super(pPos.getFile(), pPos.getOffset());
    aLineNo = pLineNo;
    aLinePos = pLinePos;
  }

  /**
   * Create a copy <code>LinePosition</code>.
   * 
   * @param pPos The position in the file from the start position.
   * @deprecated Pointless as LinePosition objects are immutable
   */
  @Deprecated
  public LinePosition(final LinePosition pPos) {
    super(pPos.getFile(), pPos.getOffset());
    aLineNo = pPos.aLineNo;
    aLinePos = pPos.aLinePos;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    if (getFile() != null) {
      return getFile().toString() + ':' + Integer.toString(aLineNo) + ',' + Integer.toString(aLinePos);
    } else {
      return Integer.toString(aLineNo) + ',' + Integer.toString(aLinePos);
    }
  }

  /** {@inheritDoc} */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + aLineNo;
    result = prime * result + aLinePos;
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!super.equals(obj))
      return false;
    if (getClass() != obj.getClass())
      return false;
    LinePosition other = (LinePosition) obj;
    if (aLineNo != other.aLineNo)
      return false;
    if (aLinePos != other.aLinePos)
      return false;
    return true;
  }

  /**
   * Get the line number.
   * 
   * @return The line number
   */
  public int getLineNo() {
    return aLineNo;
  }

  /**
   * Get the position in the line.
   * 
   * @return the position in the line.
   */
  public int getLinePos() {
    return aLinePos;
  }
}
