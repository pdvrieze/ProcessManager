/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;


/**
 * A token for a statement.
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public class StatementToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> {

  /**
   * @param pTokenType
   * @param pPos
   */
  public StatementToken(final T pTokenType, final LinePosition pPos) {
    super(pTokenType, pPos);
  }

}
