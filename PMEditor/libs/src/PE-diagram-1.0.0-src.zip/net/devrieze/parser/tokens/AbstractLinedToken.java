/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A base class for a lined token.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public abstract class AbstractLinedToken<T extends Enum<T> & Language<T>> extends AbstractToken<T> implements LinedToken<T> {

  /**
   * @param pTokenType
   * @param pPos
   */
  public AbstractLinedToken(final T pTokenType, final LinePosition pPos) {
    super(pTokenType, pPos);
  }

  @Override
  public LinePosition getPos() {
    return (LinePosition) super.getPos();
  }

}
