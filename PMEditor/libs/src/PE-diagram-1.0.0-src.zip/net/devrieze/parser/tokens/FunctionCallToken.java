/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.tokens;

import java.util.List;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A FunctionCallToken instance represents a functioncall.
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @param <T> The enum of the types of this token.
 */
public class FunctionCallToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> implements ExprToken<T> {

  private final List<? extends LinedToken<T>> aParams;

  private final LinedToken<T> aFunctionReference;

  public FunctionCallToken(final T pTokenType, final LinePosition pPos, final LinedToken<T> pName, final List<? extends LinedToken<T>> pList) {
    super(pTokenType, pPos);
    aFunctionReference = pName;
    aParams = pList;
  }

  public LinedToken<T> getFunctionReference() {
    return aFunctionReference;
  }

  public List<? extends LinedToken<T>> getParams() {
    return aParams;
  }
}
