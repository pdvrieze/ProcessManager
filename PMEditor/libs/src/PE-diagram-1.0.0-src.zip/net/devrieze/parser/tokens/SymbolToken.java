/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.streams.SymbolParser.SymbolTokenFactory;


/**
 * A token that represents symbols. A symbol is basically a name but one that is
 * not predefined by the language.
 * 
 * @author Paul de Vrieze
 * @version 1.1 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public class SymbolToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> implements ExprToken<T> {

  private final CharSequence aSymbol;

  /**
   * @param pTokenType The type of the token.
   * @param pPos The positino the token was found.
   * @param pSymbol The symbol parsed.
   */
  public SymbolToken(final T pTokenType, final LinePosition pPos, final CharSequence pSymbol) {
    super(pTokenType, pPos);
    assert pSymbol.toString().indexOf(' ') < 0;
    aSymbol = pSymbol;
  }

  public CharSequence getSymbol() {
    return aSymbol;
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder(super.toString());
    result.setCharAt(result.length() - 1, ':');
    result.append(" \"").append(aSymbol).append("\"]");
    return result.toString();
  }

  public static <T extends Enum<T> & Language<T>> SymbolTokenFactory<SymbolToken<T>> getFactory(final T pTokenType) {
    return new SymbolTokenFactory<SymbolToken<T>>() {

      @Override
      protected SymbolToken<T> createSymbol(final LinePosition pPosition, final String pValue) {
        return new SymbolToken<>(pTokenType, pPosition, pValue);
      }

    };
  }
}
