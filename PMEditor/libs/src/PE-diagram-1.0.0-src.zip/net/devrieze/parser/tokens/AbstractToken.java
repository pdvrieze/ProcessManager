/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.Position;
import net.devrieze.parser.Token;
import net.devrieze.parser.languages.Language;
import net.devrieze.util.StringUtil;


/**
 * The base token class as used by the tokenizer parsers.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public abstract class AbstractToken<T extends Enum<T> & Language<T>> implements Token<T> {

  private final T aTokenType;

  private final Position aPos;

  protected AbstractToken(final T pTokenType, final Position pPos) {
    aTokenType = pTokenType;
    aPos = pPos;
  }

  /**
   * Get the type of the token.
   * 
   * @return The type of this token
   */
  @Override
  public T getTokenType() {
    return aTokenType;
  }

  /**
   * Get the start position of the token in the stream.
   * 
   * @return The start position
   */
  @Override
  public Position getPos() {
    return aPos;
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder("[");
    result.append(StringUtil.simpleClassName(getClass()));
    result.append(" - ").append(getTokenRepr());
    result.append(" <");
    result.append(getPos().toString());
    result.append(">]");
    return result.toString();
  }

  /**
   * Get a representation of the type of this token.
   * 
   * @return By default returns the name of the token.
   */
  protected String getTokenRepr() {
    return getTokenType().name();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((aPos == null) ? 0 : aPos.hashCode());
    result = prime * result + ((aTokenType == null) ? 0 : aTokenType.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    AbstractToken<?> other = (AbstractToken<?>) obj;
    if (aPos == null) {
      if (other.aPos != null)
        return false;
    } else if (!aPos.equals(other.aPos))
      return false;
    if (aTokenType == null) {
      if (other.aTokenType != null)
        return false;
    } else if (!aTokenType.equals(other.aTokenType))
      return false;
    return true;
  }
  
}
