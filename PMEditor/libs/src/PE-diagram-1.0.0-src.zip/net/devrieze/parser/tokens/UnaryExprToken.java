/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;


/**
 * An expression node that has only one sub-element (like the not operator).
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public abstract class UnaryExprToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> implements ExprToken<T> {

  private final ExprToken<T> aSubToken;

  /**
   * Create a new token that contains unary expressions (like negation).
   * 
   * @param pTokenType The type of the token.
   * @param pPos The position of the token.
   * @param pSubToken The contained token.
   */
  protected UnaryExprToken(final T pTokenType, final LinePosition pPos, final ExprToken<T> pSubToken) {
    super(pTokenType, pPos);
    aSubToken = pSubToken;
  }

  public ExprToken<T> getSubToken() {
    return aSubToken;
  }
}
