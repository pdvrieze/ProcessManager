/**
 * The tokens that the parser can generate live in this package.
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.parser.tokens;

