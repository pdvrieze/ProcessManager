/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.lang.Const;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.CharStreamEnum;


/**
 * An interface implemented by tokens that represent a single character.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class CharToken extends AbstractLinedToken<CharStreamEnum> {

  private final char aChar;

  /**
   * Create a new character token.
   * 
   * @param pPos The position of the character.
   * @param pChar the character. TODO remove the token type parameter
   */
  public CharToken(final LinePosition pPos, final char pChar) {
    super(CharStreamEnum.CHARTOKEN, pPos);
    aChar = pChar;
  }

  /**
   * Get the Character.
   * 
   * @return The character in the token
   */
  public char getChar() {
    return aChar;
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder(super.toString());
    result.setCharAt(result.length() - 1, ':');
    if (getChar() == Const._CR) {
      result.append("CR");
    } else if (getChar() == Const._LF) {
      result.append("LF");
    } else {
      result.append(" \"").append(getChar()).append('"');
    }
    result.append(']');
    return result.toString();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + aChar;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    CharToken other = (CharToken) obj;
    if (aChar != other.aChar)
      return false;
    return true;
  }
  
  
}
