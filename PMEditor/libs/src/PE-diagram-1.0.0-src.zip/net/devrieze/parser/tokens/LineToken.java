/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.lang.Const;
import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.LineStreamEnum;
import net.devrieze.util.StringUtil;


/**
 * A token type that represents a line as read by a linetokenstream.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class LineToken extends AbstractLinedToken<LineStreamEnum> {

  private final CharSequence aLine;

  public LineToken(final LinePosition pPos, final CharSequence pLine) {
    super(LineStreamEnum.LINE, pPos);
    aLine = pLine;
  }

  /**
   * Get the Character.
   * 
   * @return The character in the token
   */
  public CharSequence getLine() {
    return aLine;
  }

  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder(super.toString());
    result.setCharAt(result.length() - 1, ':');
    result.append(getLine());
    result.append(']');
    return result.toString();
  }

  @Override
  public boolean equals(final Object pObject) {
    if (this == pObject) {
      return true;
    }
    if (!(pObject instanceof LineToken)) {
      return false;
    }
    /* Try the other object to see whether it can compare to a linetoken */
    if (pObject.getClass() != LineToken.class) {
      return pObject.equals(this);
    }
    final LineToken token = (LineToken) pObject;
    return StringUtil.isEqual(aLine, token.aLine) && getPos().equals(token.getPos());
  }

  @Override
  public int hashCode() {
    return (aLine.hashCode() * Const._HASHPRIME) + 1;
  }
}
