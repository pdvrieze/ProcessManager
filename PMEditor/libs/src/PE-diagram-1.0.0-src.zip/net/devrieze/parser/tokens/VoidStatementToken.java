package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;


/**
 * A token class for function calls (for now).
 * 
 * @author Paul de Vrieze
 * @param <E> The type of the expressions used.
 * @param <T> The enumeration of all tokentypes that could be returned.
 * @version 0.2 $Revision$
 */
public class VoidStatementToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final FunctionCallToken<E> aFuncCall;

  public VoidStatementToken(final T pTokenType, final LinePosition pPos, final FunctionCallToken<E> pFuncCall) {
    super(pTokenType, pPos);
    aFuncCall = pFuncCall;
  }

  public FunctionCallToken<E> getFuncCall() {
    return aFuncCall;
  }
}
