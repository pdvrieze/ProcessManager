/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public class OperatorToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> {

  public OperatorToken(final T pTokenType, final LinePosition pPos) {
    super(pTokenType, pPos);
  }

}
