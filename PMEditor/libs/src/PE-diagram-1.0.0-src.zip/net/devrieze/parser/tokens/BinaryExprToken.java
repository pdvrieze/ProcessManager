/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * An expression token for operators with two sides.
 * 
 * @param <T> The enumeration of all tokentypes that could be returned.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <O> The enumerator of operator types in the token.
 */
public class BinaryExprToken<T extends Enum<T> & Language<T>, O extends Enum<O> & Language<O>, M extends LinedToken<T>> extends AbstractLinedToken<T> implements ExprToken<T> {

  private final M aLeft;

  private final M aRight;

  private final O aOperatorType;

  /**
   * Create a new <code>BinaryExprToken</code>.
   * 
   * @param pTokenType The type of the token.
   * @param pOperatorType The type of the operator embedded.
   * @param pPos The starting position of the token.
   * @param pLeft The left part of the expression.
   * @param pRight The right part of the expression.
   */
  public BinaryExprToken(final T pTokenType, final O pOperatorType, final LinePosition pPos, final M pLeft, final M pRight) {
    super(pTokenType, pPos);
    aLeft = pLeft;
    aRight = pRight;
    aOperatorType = pOperatorType;
  }

  public M getLeft() {
    return aLeft;
  }

  public M getRight() {
    return aRight;
  }

  /**
   * Get the type of the operator.
   * 
   * @return the type of the operator.
   */
  public O getOperatorType() {
    return aOperatorType;
  }

  @Override
  protected String getTokenRepr() {
    return getOperatorType().name();
  }
}
