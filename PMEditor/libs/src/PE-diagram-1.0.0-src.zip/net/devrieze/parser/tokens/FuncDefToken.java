/*
 * Created on Dec 10, 2005
 *
 */
package net.devrieze.parser.tokens;

import java.util.List;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * The type of function definition tokens.
 * 
 * @author Paul de Vrieze
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 */
public class FuncDefToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final String aName;

  private final List<? extends VarDefToken<T, E>> aParams;

  private final List<? extends LinedToken<T>> aBody;

  public FuncDefToken(final T pTokenType, final LinePosition pPos, final CharSequence pName, final List<? extends VarDefToken<T, E>> pParams, final List<? extends LinedToken<T>> pBody) {
    super(pTokenType, pPos);
    aName = pName.toString();
    aParams = pParams;
    aBody = pBody;
  }

  public List<? extends LinedToken<T>> getBody() {
    return aBody;
  }

  public String getName() {
    return aName;
  }

  public List<? extends VarDefToken<T, E>> getParams() {
    return aParams;
  }
}
