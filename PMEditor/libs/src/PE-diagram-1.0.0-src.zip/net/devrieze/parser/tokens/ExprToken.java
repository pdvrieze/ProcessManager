/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * The parent Token for all expression tokens.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enumeration of all tokentypes that could be returned.
 */
public interface ExprToken<T extends Enum<T> & Language<T>> extends LinedToken<T> {
  // No special body. Just marker
}
