package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.eval.Type;
import net.devrieze.parser.languages.Language;


/**
 * A token class for a variable definition.
 * 
 * @author Paul de Vrieze
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 */
public class VarDefToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final String aName;

  private final Type aType;

  private final LinedToken<E> aValue;

  /**
   * @param pTokenType The type of the token.
   * @param pPos
   * @param pValue
   * @param pName
   * @param pType
   */
  public VarDefToken(final T pTokenType, final LinePosition pPos, final Type pType, final String pName, final LinedToken<E> pValue) {
    super(pTokenType, pPos);
    aType = pType;
    aName = pName;
    aValue = pValue;
  }

  public String getName() {
    return aName;
  }

  public Type getReferredType() {
    return aType;
  }

  public LinedToken<E> getValue() {
    return aValue;
  }
}
