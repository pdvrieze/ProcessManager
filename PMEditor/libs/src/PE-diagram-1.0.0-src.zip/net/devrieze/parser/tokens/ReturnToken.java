/*
 * Created on Dec 10, 2005
 *
 */
package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A token representing a return statement.
 * 
 * @author Paul de Vrieze
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 */
public class ReturnToken<T extends Enum<T> & Language<T>, U extends Enum<U> & Language<U>> extends StatementToken<T> {

  private final LinedToken<U> aExpression;

  public ReturnToken(final T pTokenType, final LinePosition pPos, final LinedToken<U> pExpression) {
    super(pTokenType, pPos);
    aExpression = pExpression;
  }

  public LinedToken<U> getExpression() {
    return aExpression;
  }
}
