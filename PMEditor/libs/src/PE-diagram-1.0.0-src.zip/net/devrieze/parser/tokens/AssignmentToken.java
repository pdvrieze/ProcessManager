package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A token class for assignments.
 * 
 * @param <T> The enum of the token types.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class AssignmentToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final LinedToken<E> aValue;

  private final LinedToken<E> aVariable;

  public AssignmentToken(final T pTokenType, final LinePosition pPos, final LinedToken<E> pVariable, final LinedToken<E> pValue) {
    super(pTokenType, pPos);
    aVariable = pVariable;
    aValue = pValue;
  }

  public LinedToken<E> getVariable() {
    return aVariable;
  }

  public LinedToken<E> getValue() {
    return aValue;
  }
}
