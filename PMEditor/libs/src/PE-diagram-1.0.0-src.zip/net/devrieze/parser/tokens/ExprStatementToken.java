/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.languages.Language;


/**
 * An {@link ExprStatementToken} represents an expression used as statement.
 * 
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 * @param <T> The enum of the types of this token.
 */
public class ExprStatementToken<T extends Enum<T> & Language<T>, S extends Enum<S> & Language<S>> extends StatementToken<T> {

  private final ExprToken<S> aExpression;

  public ExprStatementToken(final T pTokenType, final LinePosition pPos, final ExprToken<S> pExpr) {
    super(pTokenType, pPos);
    aExpression = pExpr;
  }

  public ExprToken<S> getExpression() {
    return aExpression;
  }
}
