package net.devrieze.parser.tokens;

import java.util.List;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A token representing a block of code.
 * 
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 * @author Paul de Vrieze
 */
public class BlockToken<T extends Enum<T> & Language<T>> extends AbstractLinedToken<T> {

  private final List<? extends LinedToken<T>> aSubStatements;

  public BlockToken(final T pTokenType, final LinePosition pPos, final List<? extends LinedToken<T>> pSubStatements) {
    super(pTokenType, pPos);
    aSubStatements = pSubStatements;
  }

  public List<? extends LinedToken<T>> getSubStatements() {
    return aSubStatements;
  }
}
