package net.devrieze.parser.tokens;

import java.util.List;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A token for the if statement.
 * 
 * @author Paul de Vrieze
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 */
public class WhileToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final LinedToken<E> aCondition;

  private final List<? extends LinedToken<T>> aAction;

  public WhileToken(final T pTokenType, final LinePosition pPos, final LinedToken<E> pCondition, final List<? extends LinedToken<T>> pAction) {
    super(pTokenType, pPos);
    aCondition = pCondition;
    aAction = pAction;
  }

  public LinedToken<E> getCondition() {
    return aCondition;
  }

  public List<? extends LinedToken<T>> getAction() {
    return aAction;
  }
}
