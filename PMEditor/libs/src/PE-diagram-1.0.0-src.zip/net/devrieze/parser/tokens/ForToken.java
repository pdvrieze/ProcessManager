/*
 * Created on Dec 10, 2005
 *
 */
package net.devrieze.parser.tokens;

import net.devrieze.parser.LinePosition;
import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.Language;


/**
 * A token representing a classical for statement.
 * 
 * @param <T> The enum of the token types.
 * @version 0.1 $Revision$
 * @author Paul de Vrieze
 */
public class ForToken<T extends Enum<T> & Language<T>, E extends Enum<E> & Language<E>> extends StatementToken<T> {

  private final LinedToken<T> aInitialisation;

  private final LinedToken<E> aCondition;

  private final LinedToken<T> aContinuation;

  private final LinedToken<T> aAction;

  public ForToken(final T pTokenType, final LinePosition pPos, final LinedToken<T> pInit, final LinedToken<E> pCondition, final LinedToken<T> pCont, final LinedToken<T> pAction) {
    super(pTokenType, pPos);
    aInitialisation = pInit;
    aCondition = pCondition;
    aContinuation = pCont;
    aAction = pAction;
  }


  public LinedToken<T> getAction() {
    return aAction;
  }


  public LinedToken<E> getCondition() {
    return aCondition;
  }


  public LinedToken<T> getContinuation() {
    return aContinuation;
  }


  public LinedToken<T> getInitialisation() {
    return aInitialisation;
  }
}
