/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import net.devrieze.parser.languages.Language;


/**
 * The abstract interface that represents a token.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 * @param <T> the enumerator of the token contains the types.
 */
public interface Token<T extends Enum<T> & Language<T>> {

  /**
   * Get the type of the token.
   * 
   * @return The type of this token
   */
  T getTokenType();

  /**
   * Get the start position of the token in the stream.
   * 
   * @return The start position
   */
  Position getPos();
}
