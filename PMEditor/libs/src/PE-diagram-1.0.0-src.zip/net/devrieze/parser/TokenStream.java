/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import java.io.File;

import net.devrieze.parser.languages.Language;


/**
 * A class that represents a stream of tokens.
 * 
 * @param <T> The kinds of tokens that this stream returns
 * @param <U> The enumeration of all tokentypes that could be returned.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface TokenStream<T extends Token<U>, U extends Enum<U> & Language<U>> {

  /**
   * Get the next token in the stream.
   * 
   * @return The next token in the stream
   * @throws UnexpectedTokenException When an unexpected token or subtoken has
   *           been found.
   */
  T getNextToken() throws TokenException;

  /**
   * End of file.
   * 
   * @return <code>true</code> if the end of the stream has been reached
   */
  boolean eof();

  /**
   * The position of the stream. That is the position of the next parsed
   * element.
   * 
   * @return The current position of the stream
   */
  int getPos();

  /**
   * Get the file this stream represents, or <code>null</code> if none.
   * 
   * @return the file backing the stream.
   */
  File getFile();
}
