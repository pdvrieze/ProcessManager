/**
 * This package provides the main classes for parsing scripts.
 *
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.parser;

