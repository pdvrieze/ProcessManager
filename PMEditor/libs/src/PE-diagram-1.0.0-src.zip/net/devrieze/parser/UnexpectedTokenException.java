/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser;

/**
 * Exception thrown when unexpected tokens are encountered.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class UnexpectedTokenException extends TokenException {

  private static final long serialVersionUID = 3256720697551435828L;

  /**
   * Create a new exception.
   * 
   * @param pToken The token causing the exception.
   * @deprecated
   */
  @Deprecated
  public UnexpectedTokenException(final Token<?> pToken) {
    super(pToken);
  }

  /**
   * Create a new exception.
   * 
   * @param pMessage The message for the exception
   * @param pToken The token causing the exception.
   */
  public UnexpectedTokenException(final String pMessage, final Token<?> pToken) {
    super(pToken, pMessage);
  }

  /**
   * Create a new exception.
   * 
   * @param pMessage The message for the exception
   * @param pCause The exception causing this exception.
   * @param pToken The token causing the exception.
   */
  public UnexpectedTokenException(final String pMessage, final Throwable pCause, final Token<?> pToken) {
    super(pToken, pCause, pMessage);
  }

  /**
   * Create a new exception.
   * 
   * @param pCause The exception causing this exception.
   * @param pToken The token causing the exception.
   */
  public UnexpectedTokenException(final Throwable pCause, final Token<?> pToken) {
    super(pToken, pCause);
  }

}
