/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import java.util.HashMap;
import java.util.Map;


/**
 * A factory class for generating token types. Token types should allways be
 * created through a factory to ensure that the same objects are used.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class TokenTypeFactory {

  private final Map<String, TokenType> aTypes;

  /**
   * Create a new factory for token types.
   */
  public TokenTypeFactory() {
    aTypes = new HashMap<>();
  }

  /**
   * Get the token type with the specified name. This is guaranteed to allways
   * return the same object for the same name.
   * 
   * @param pName The name of the type.
   * @return The token type.
   */
  public TokenType getTokenType(final String pName) {
    if (aTypes.containsKey(pName)) {
      return aTypes.get(pName);
    }
    final TokenType result = new TokenType(this, pName);
    aTypes.put(pName, result);
    return result;
  }

}
