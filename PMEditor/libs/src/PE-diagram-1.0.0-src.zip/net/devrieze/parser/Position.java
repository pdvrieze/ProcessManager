/*
 * Created on Jan 6, 2005
 *
 */

package net.devrieze.parser;

import java.io.File;


/**
 * A class representing a position.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class Position implements Comparable<Position> {

  private final int aPos;

  private final File aFile;

  /**
   * Create a new position object with the given position.
   * 
   * @param pPos The offset from the start of the file.
   */
  public Position(final File pFile, final int pPos) {
    aFile = pFile;
    aPos = pPos;
  }

  /**
   * Get the position as an offset from the start of the file.
   * 
   * @return The position
   */
  public int getOffset() {
    return aPos;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    if (aFile != null) {
      return aFile.toString() + ':' + Integer.toString(aPos);
    } else {
      return Integer.toString(aPos);
    }
  }

  /** {@inheritDoc} */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((aFile == null) ? 0 : aFile.hashCode());
    result = prime * result + aPos;
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Position other = (Position) obj;
    if (aFile == null) {
      if (other.aFile != null)
        return false;
    } else if (!aFile.equals(other.aFile))
      return false;
    if (aPos != other.aPos)
      return false;
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public int compareTo(final Position pPos) {
    return aPos - pPos.aPos;
  }


  /**
   * Get the file the token comes from
   * 
   * @return The file, or <code>null</code> if not known.
   */
  public File getFile() {
    return aFile;
  }
}
