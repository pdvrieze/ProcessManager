/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

import net.devrieze.parser.tokens.LineToken;


public enum LineStreamEnum implements Language<LineStreamEnum> {
  LINE {

    @Override
    public Class<LineToken> getReferredType() {
      return LineToken.class;
    }
  };

  public abstract Class<? extends LineToken> getReferredType();

}
