/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

import net.devrieze.parser.LinedToken;


public enum MLang implements Language<MLang> {
  IF,
  // For is just a fancy while
  //  FOR,
  WHILE,
  FUNCDEF,
  //  BLOCK,
  FUNCCALL,
  RETURN,
  VARASSIGN,
  //  EXPR, 
  SYMBOL,
  LITERAL,
  CLASS,
  TUPPLE,
  FILE,
  ANNOTATE,
  /**
   * A wildcard token
   */
  ANY,
  BINARYOPERATOR,
  /**
   * A reference to the function.
   */
  FUNCREF,
  FUNCTYPE,
  OBJLITERAL,
  INTLITERAL,
  BOOLLITERAL,
  BYTELITERAL,
  CHARLITERAL,
  SHORTLITERAL,
  LONGLITERAL,
  FLOATLITERAL,
  DOUBLELITERAL,
  TYPECAST,
  TYPEREF,
  LAMBDA,
  THROW,
  PACKAGEDECL,
  INSTANCEOF,
  LOOP,
  FOREACH, ;

  @SuppressWarnings("static-method")
  public Class<? extends LinedToken<?>> getReferredType() {
    return null;
  }

  public String friendlyName() {
    return toString();
  }

}
