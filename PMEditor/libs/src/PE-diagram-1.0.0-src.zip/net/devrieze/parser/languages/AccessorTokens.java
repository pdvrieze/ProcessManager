/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

public enum AccessorTokens implements Language<AccessorTokens> {
  ARRAYACCESSOPEN,
  ARRAYACCESSCLOSE,
  FUNCTIONACCESSOPEN,
  OBJECTACCESS,
  FUNCTIONACCESSSEPARATOR,
  FUNCTIONACCESSCLOSE;

}
