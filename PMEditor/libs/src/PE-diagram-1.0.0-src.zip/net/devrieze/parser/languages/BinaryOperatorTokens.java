/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

public enum BinaryOperatorTokens implements Language<BinaryOperatorTokens> {
  POWER(1, "^"),
  TIMES(2, "×", "*"),
  DIV(3, "/"),
  MOD(3, "%"),
  PLUS(5, "+"),
  MINUS(5, "-"),
  EQUALS(7, "=="),
  UNEQUALS(7, "≠", "!="),
  LESSEQ(7, "≤", "<="),
  LESS(7, "<"),
  GREATEREQ(7, "≥", ">="),
  GREATER(7, ">"),
  LOGIC_AND(8, "∧", "&&"),
  LOGIC_OR(8, "∨", "||"),
  MEMBERACCESS(0, ".");

  private final int aOrder;

  private final String aOperatorRepr;

  private final String[] aAlternatives;

  private BinaryOperatorTokens(final int pOrder, final String pOperatorRepr, final String... pAlternatives) {
    aOrder = pOrder;
    aOperatorRepr = pOperatorRepr;
    aAlternatives = pAlternatives;
  }

  public int compare(final BinaryOperatorTokens pOperator2) {
    return getOrder() - pOperator2.getOrder();
  }

  public int getOrder() {
    return aOrder;
  }


  @Override
  public String toString() {
    return aOperatorRepr;
  }


  public boolean isRepr(final String pOperatorToken) {
    if (aOperatorRepr.equals(pOperatorToken)) {
      return true;
    }
    for (final String alternative : aAlternatives) {
      if (alternative.equals(pOperatorToken)) {
        return true;
      }
    }
    return false;
  }
}
