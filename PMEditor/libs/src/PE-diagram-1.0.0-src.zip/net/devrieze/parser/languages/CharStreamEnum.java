/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

import net.devrieze.parser.tokens.CharToken;


public enum CharStreamEnum implements Language<CharStreamEnum> {
  CHARTOKEN {

    @Override
    public Class<CharToken> getReferredType() {
      return CharToken.class;
    }
  };

  public abstract Class<? extends CharToken> getReferredType();

}
