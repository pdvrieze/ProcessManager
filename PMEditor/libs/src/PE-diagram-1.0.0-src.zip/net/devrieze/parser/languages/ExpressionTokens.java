/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

public enum ExpressionTokens implements Language<ExpressionTokens> {
  OBJECTACCESS,
  SYMBOL,
  FUNCCALL,
  BINARYOPERATOR,
  LITERAL,
  ARRAYACCESS,
  NOT,
  PAREN;

}
