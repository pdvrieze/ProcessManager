/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;

import net.devrieze.parser.tokens.*;


public enum StatementTokens implements Language<StatementTokens> {
  IF {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<IfToken<?,?>> getReferredType() {
      return (Class) IfToken.class;
    }
  },
  FOR {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<ForToken<?,?>> getReferredType() {
      return (Class) ForToken.class;
    }
  },
  WHILE {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<WhileToken<?,?>> getReferredType() {
      return (Class) WhileToken.class;
    }
  },
  FUNCDEF {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<FuncDefToken<?,?>> getReferredType() {
      return (Class) FuncDefToken.class;
    }
  },
  ASSIGN {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<AssignmentToken<?,?>> getReferredType() {
      return (Class) AssignmentToken.class;
    }
  },
  BLOCK {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<BlockToken<?>> getReferredType() {
      return (Class) BlockToken.class;
    }
  },
  FUNCCALL {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<VoidStatementToken<?,?>> getReferredType() {
      return (Class) VoidStatementToken.class;
    }
  },
  RETURN {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<ReturnToken<?,?>> getReferredType() {
      return (Class) ReturnToken.class;
    }
  },
  VARDEF {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<VarDefToken<?,?>> getReferredType() {
      return (Class) VarDefToken.class;
    }
  },
  EXPR {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Class<ExprStatementToken<?,?>> getReferredType() {
      return (Class) ExprStatementToken.class;
    }
  };

  public abstract Class<? extends AbstractLinedToken<?>> getReferredType();

}
