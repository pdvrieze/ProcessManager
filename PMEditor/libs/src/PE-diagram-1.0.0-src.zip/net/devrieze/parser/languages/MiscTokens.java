/*
 * Created on Dec 11, 2005
 *
 */
package net.devrieze.parser.languages;


/**
 * A language for miscelaneous tokens.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public enum MiscTokens implements Language<MiscTokens> {
  WHITESPACE

}
