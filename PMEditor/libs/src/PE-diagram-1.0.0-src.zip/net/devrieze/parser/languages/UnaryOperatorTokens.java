/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.languages;


public enum UnaryOperatorTokens implements Language<UnaryOperatorTokens> {
  NOT("¬", "!"),
  PARENOPEN("("),
  PARENCLOSE(")"),
  PREINC("++_"),
  POSTINC("_++"),
  PREDEC("--_"),
  POSTDEC("_--"), ;

  private final String aOperatorRepr;

  private final String[] aAlternatives;


  private UnaryOperatorTokens(final String pOperatorRepr, final String... pAlternatives) {
    aOperatorRepr = pOperatorRepr;
    aAlternatives = pAlternatives;
  }

  @Override
  public String toString() {
    return aOperatorRepr;
  }

  public boolean isRepr(final String pOperatorToken) {
    if (aOperatorRepr.equals(pOperatorToken)) {
      return true;
    }
    for (final String alternative : aAlternatives) {
      if (alternative.equals(pOperatorToken)) {
        return true;
      }
    }
    return false;
  }

}
