/*
 * Created on Dec 10, 2005
 *
 */
package net.devrieze.parser.languages;


/**
 * An interface for enumerations that implement languages.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The enum of this language. A self reference.
 */
public interface Language<T extends Enum<T> & Language<T>> {
  //  abstract public Class<? extends Token<T>> getType();

}
