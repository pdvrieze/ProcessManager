/*
 * Created on Mar 10, 2006
 *
 */
package net.devrieze.parser.eval;

import java.io.FileOutputStream;
import java.io.IOException;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import net.devrieze.lang.Lambda;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.streams.ExpressionParser;
import net.devrieze.parser.streams.StringTokenStream;
import net.devrieze.parser.tokens.ExprToken;
import net.devrieze.parser.tokens.LiteralToken;


/**
 * A class that can generate a bytecode representation of an expression.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class FScriptExpressionCompiler implements Opcodes {

  private FScriptExpressionCompiler() {
    // No body
  }

  /**
   * Create a compiled version of the expression.
   * 
   * @param <T> The return type of the expression.
   * @param pReturn The result of the functor
   * @param pExpression The expression representing the functor
   * @return The functor.
   */
  public static <T> Lambda<T> compileLoad(final Class<T> pReturn, final ExprToken<?> pExpression) {
    return null;
  }

  /**
   * Compile the expressions to a class.
   * 
   * @param pClassName The name of the class to be compiled.
   * @param pExpr The expression for the class.
   * @return The bytes representing the class file.
   */
  public static byte[] compile(final String pClassName, final ExprToken<ExpressionTokens> pExpr) {
    final ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
    cw.visit(V1_5, ACC_PUBLIC + ACC_SUPER, pClassName, null, "java/lang/Object", new String[] { "net/devrieze/lang/Lambda" });

    final MethodVisitor initVisitor = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
    initVisitor.visitCode();
    initVisitor.visitVarInsn(ALOAD, 0);
    initVisitor.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V");
    initVisitor.visitInsn(RETURN);
    initVisitor.visitMaxs(1, 1);
    initVisitor.visitEnd();

    final MethodVisitor lambdaVisitor = cw.visitMethod(ACC_PUBLIC, "lambda", "()Ljava/lang/Object;", null, null);
    lambdaVisitor.visitCode();
    compile(lambdaVisitor, pExpr);

    lambdaVisitor.visitMaxs(1, 1);
    lambdaVisitor.visitEnd();
    cw.visitEnd();

    return cw.toByteArray();
  }

  @SuppressWarnings({ "incomplete-switch", "unchecked" })
  private static void compile(final MethodVisitor pLambdaVisitor, final ExprToken<ExpressionTokens> pExpr) {
    // TODO implement the rest
    switch (pExpr.getTokenType()) {
      case LITERAL:
        compileLiteral(pLambdaVisitor, (LiteralToken<ExpressionTokens, ?>) pExpr);
        break;
    }
    pLambdaVisitor.visitInsn(ARETURN);
  }

  /**
   * @param pLambdaVisitor
   * @param pToken
   */
  private static void compileLiteral(final MethodVisitor pLambdaVisitor, final LiteralToken<ExpressionTokens, ?> pToken) {
    final Object aValue = pToken.getValue();
    pLambdaVisitor.visitLdcInsn(aValue);
  }

  /**
   * Test script.
   * 
   * @param pArgs
   */
  public static void main(final String[] pArgs) {
    try {
      final ExprToken<ExpressionTokens> myExpr = new ExpressionParser(new StringTokenStream("\"hello\"+\"world\"")).getNextToken();
      final byte[] comp = compile("Test", myExpr);
      try(final FileOutputStream f = new FileOutputStream("Test.class")) {
        f.write(comp);
      }
    } catch (final TokenException ex) {
      ex.printStackTrace();
    } catch (final IOException ex) {
      ex.printStackTrace();
    }
  }

}
