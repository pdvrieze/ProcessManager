/*
 * Created on Jan 8, 2005
 *
 */

package net.devrieze.parser.eval;

/**
 * An exception that is thrown by a handler for access of unsupported arrays
 * etc. Or by function implementations etc.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class HandlerException extends Exception {

  private static final long serialVersionUID = 3618420410639790896L;

  /**
   * Create a new exception.
   */
  public HandlerException() {
    super();
  }

  /**
   * Create a new exception.
   * 
   * @param pMessage The message for the exception.
   */
  public HandlerException(final String pMessage) {
    super(pMessage);
  }

  /**
   * Create a new exception.
   * 
   * @param pMessage The message for the exception.
   * @param pCause The cause of the exception.
   */
  public HandlerException(final String pMessage, final Throwable pCause) {
    super(pMessage, pCause);
  }

  /**
   * Create a new exception.
   * 
   * @param pCause The cause of the exception.
   */
  public HandlerException(final Throwable pCause) {
    super(pCause);
  }

}
