/**
 * This package contains the extra types that can be used for evaluation.
 * {@link net.devrieze.parser.streams.StatementParser parser} provides.
 * @version 1.0 $Revision$
 */
package net.devrieze.parser.eval.types;

