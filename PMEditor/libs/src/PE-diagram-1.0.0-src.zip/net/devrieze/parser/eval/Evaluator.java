/*
 * Created on 09-Dec-2005
 */
package net.devrieze.parser.eval;

import net.devrieze.parser.Token;
import net.devrieze.parser.languages.Language;


/**
 * An abstract class embodying an evaluator for tokens.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 * @param <T> The enumerator of the tokens to be evaluated.
 */
public interface Evaluator<T extends Enum<T> & Language<T>> {

  Object evaluate(Token<T> pToken, SymbolContext pContext) throws EvaluationException;

}
