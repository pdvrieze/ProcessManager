/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.eval;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import java.util.Collection;

import net.devrieze.annotation.ScriptSupport;
import net.devrieze.annotation.Scriptable;
import net.devrieze.parser.ObjectWrapper;


/**
 * An object wrapper class for reflection based access.
 * 
 * @param <T> The type that is wrapped. In most cases this is {@link Object}
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ReflectionObjectWrapper<T> extends ObjectWrapper<T> implements SymbolContext {

  /**
   * Create a new reflection based wrapper for the object.
   * 
   * @param pObject The object to wrap.
   */
  public ReflectionObjectWrapper(final T pObject) {
    super(pObject);
  }

  /** {@inheritDoc} */
  @Override
  public SymbolContext getContext() {
    return this;
  }

  /**
   * Object contexts don't have parent contexts.
   * 
   * @return <code>null</code>
   */
  @Override
  public SymbolContext getParentContext() {
    return null;
  }

  /** {@inheritDoc} */
  @Override
  public boolean isVariableSymbol(final String pName) {
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      if (Modifier.isFinal(f.getModifiers())) {
        return false;
      }
      return isScriptable(f);
    } catch (final SecurityException e) {
      return false;
    } catch (final NoSuchFieldException e) {
      return false;
    }
  }

  /** {@inheritDoc} */
  @Override
  public boolean isFunctionSymbol(final String pName) {
    return ReflectionHelper.isFunctionSymbol(getObject().getClass(), pName, false);
  }

  /** {@inheritDoc} */
  @Override
  public boolean isFunctionSymbol(final String pName, final Type[] pParamTypes) {
    return ReflectionHelper.isFunctionSymbol(getObject().getClass(), pName, pParamTypes, false);
  }

  /** {@inheritDoc} */
  @Override
  public boolean isConstantSymbol(final String pName) {
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      if (Modifier.isFinal(f.getModifiers())) {
        return isScriptable(f);
      }
      return false;
    } catch (final SecurityException e) {
      return false;
    } catch (final NoSuchFieldException e) {
      return false;
    }
  }

  /** {@inheritDoc} */
  @Override
  public boolean isTypeSymbol(final String pName) {
    return false; /* It is reflection ;-) */
  }

  /** {@inheritDoc} */
  @Override
  public boolean isSymbol(final String pName) {
    if (isFunctionSymbol(pName)) {
      return true;
    }
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      return isScriptable(f);
    } catch (final SecurityException e) {
      return false;
    } catch (final NoSuchFieldException e) {
      return false;
    }
  }

  /** {@inheritDoc} */
  @Override
  public Object getVariableSymbol(final String pName) throws HandlerException {
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      if (Modifier.isFinal(f.getModifiers())) {
        throw new HandlerException("The " + pName + " symbol is not a variable");
      } else if (!isScriptable(f)) {
        throw new HandlerException("The " + pName + " symbol is not accessible");
      } else {
        return f.get(getObject());
      }
    } catch (final HandlerException e) {
      throw e;
    } catch (final Exception e) {
      throw new HandlerException(e);
    }
  }

  /** {@inheritDoc} */
  @Override
  public void setVariableSymbol(final String pName, final Object pValue) throws HandlerException {
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      if (Modifier.isFinal(f.getModifiers())) {
        throw new HandlerException("The " + pName + " symbol is not a variable");
      } else if (!isScriptable(f)) {
        throw new HandlerException("The " + pName + " symbol is not accessible");
      } else {
        f.set(getObject(), pValue);
      }
    } catch (final HandlerException e) {
      throw e;
    } catch (final Exception e) {
      throw new HandlerException(e);
    }
  }

  /** {@inheritDoc} */
  @Override
  public FunctionReference getFunctionSymbol(final String pName, final Type[] pParamTypes) throws HandlerException {
    return ReflectionHelper.getFunctionSymbol(getObject().getClass(), pName, pParamTypes, getObject());
  }

  /** {@inheritDoc} */
  @Override
  public Collection<FunctionReference> getFunctionSymbols(final String pName) throws HandlerException {
    return ReflectionHelper.getFunctionSymbols(getObject().getClass(), pName, getObject());
  }

  /** {@inheritDoc} */
  @Override
  public Object getConstantSymbol(final String pName) throws HandlerException {
    try {
      final Field f = getObject().getClass().getField(pName.toString());
      if (Modifier.isFinal(f.getModifiers())) {
        return f.get(getObject());
      } else if (!isScriptable(f)) {
        throw new HandlerException("The " + pName + " symbol is not accessible");
      } else {
        throw new HandlerException("The " + pName + " symbol is not a constant");
      }
    } catch (final HandlerException e) {
      throw e;
    } catch (final Exception e) {
      throw new HandlerException(e);
    }
  }

  /** {@inheritDoc} */
  @Override
  public Type getTypeSymbol(final String pName) throws HandlerException {
    throw new HandlerException("Reflection does not support type symbols (" + pName + ")");
  }

  /** {@inheritDoc} */
  @Override
  public SymbolType getSymbolType(final String pName) {
    if (isVariableSymbol(pName)) {
      return SymbolType.VARIABLE;
    } else if (isConstantSymbol(pName)) {
      return SymbolType.CONSTANT;
    } else if (isFunctionSymbol(pName)) {
      return SymbolType.FUNCTION;
    } else {
      return null;
    }
  }

  /** {@inheritDoc} */
  @Override
  public void defVariableSymbol(final Type pType, final String pName, final Object pValue) throws HandlerException {
    throw new HandlerException("Defining new attributes on a class is not possible");
  }

  /** {@inheritDoc} */
  @Override
  public void defFunctionSymbol(final String pName, final FunctionReference pFunction) throws HandlerException {
    throw new HandlerException("Defining new methods on a class is not possible");
  }

  public static boolean isScriptable(final Member pMember) {
    final Class<?> c = pMember.getDeclaringClass();
    if (!c.isAnnotationPresent(ScriptSupport.class)) {
      return true;
    }
    return (pMember instanceof AnnotatedElement) && ((AnnotatedElement) pMember).isAnnotationPresent(Scriptable.class);
  }

}
