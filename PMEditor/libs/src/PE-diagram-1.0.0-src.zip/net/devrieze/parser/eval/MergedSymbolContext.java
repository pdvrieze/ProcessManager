/*
 * Created on 10-Oct-2005
 */
package net.devrieze.parser.eval;

import java.util.Collection;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class MergedSymbolContext implements SymbolContext {

  private final SymbolContext[] aChildren;

  public MergedSymbolContext(final SymbolContext... pChildren) {
    aChildren = pChildren;
  }

  @Override
  public void defFunctionSymbol(final String pName, final FunctionReference pFunction) throws HandlerException {
    throw new HandlerException("Defining symbols in a MergedSymbolContext has unclear semantics");
  }

  @Override
  public void defVariableSymbol(final Type pType, final String pName, final Object pValue) throws HandlerException {
    throw new HandlerException("Defining symbols in a MergedSymbolContext has unclear semantics");
  }

  @Override
  public Object getConstantSymbol(final String pName) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isConstantSymbol(pName)) {
        return child.getConstantSymbol(pName);
      }
    }
    throw new HandlerException("Unknown constant symbol \"" + pName + "\"");
  }

  @Override
  public FunctionReference getFunctionSymbol(final String pName, final Type[] pParamTypes) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isFunctionSymbol(pName, pParamTypes)) {
        return child.getFunctionSymbol(pName, pParamTypes);
      }
    }
    throw new HandlerException("Unknown function symbol \"" + pName + "(" + pParamTypes.toString() + ")\"");
  }

  @Override
  public Collection<FunctionReference> getFunctionSymbols(final String pName) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isFunctionSymbol(pName)) {
        return child.getFunctionSymbols(pName);
      }
    }
    throw new HandlerException("Unknown function symbol \"" + pName + "\"");
  }

  @Override
  public SymbolContext getParentContext() {
    return null; // Has no parent context
  }

  public SymbolContext[] getParentContexts() {
    return aChildren;
  }

  @Override
  public SymbolType getSymbolType(final String pName) {
    for (final SymbolContext child : aChildren) {
      final SymbolType type = child.getSymbolType(pName);
      if (type != null) {
        return type;
      }
    }
    return null;
  }

  @Override
  public Type getTypeSymbol(final String pName) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isTypeSymbol(pName)) {
        return child.getTypeSymbol(pName);
      }
    }
    throw new HandlerException("Unknown type symbol \"" + pName + "\"");
  }

  @Override
  public Object getVariableSymbol(final String pName) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isVariableSymbol(pName)) {
        return child.getVariableSymbol(pName);
      }
    }
    throw new HandlerException("Unknown variable symbol \"" + pName + "\"");
  }

  @Override
  public boolean isConstantSymbol(final String pName) {
    for (final SymbolContext child : aChildren) {
      if (child.isConstantSymbol(pName)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isFunctionSymbol(final String pName) {
    for (final SymbolContext child : aChildren) {
      if (child.isFunctionSymbol(pName)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isFunctionSymbol(final String pName, final Type[] pParamTypes) {
    for (final SymbolContext child : aChildren) {
      if (child.isFunctionSymbol(pName, pParamTypes)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isSymbol(final String pName) {
    for (final SymbolContext child : aChildren) {
      if (child.isSymbol(pName)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isTypeSymbol(final String pName) {
    for (final SymbolContext child : aChildren) {
      if (child.isTypeSymbol(pName)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isVariableSymbol(final String pName) {
    for (final SymbolContext child : aChildren) {
      if (child.isVariableSymbol(pName)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public void setVariableSymbol(final String pName, final Object pValue) throws HandlerException {
    for (final SymbolContext child : aChildren) {
      if (child.isVariableSymbol(pName)) {
        child.setVariableSymbol(pName, pValue);
        return;
      } else if (isSymbol(pName)) {
        throw new HandlerException("The symbol \"" + pName + "\" is not a variable, so setting it is impossible.");
      }
    }
    throw new HandlerException("Attempting to set an unknown variable: \"" + pName + "\"");

  }
}
