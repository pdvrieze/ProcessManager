/*
 * Created on Jan 10, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import net.devrieze.parser.ObjectWrapper;
import net.devrieze.util.StringUtil;


/**
 * A symbol context that is used by the evaluator to define variables. It
 * represents the context for a code block.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class BlockSymbolContext extends AbstractSymbolContext {

  private final HashMap<String, Object> aVariables;

  private final HashMap<String, FunctionReference> aFunctions;

  private final HashMap<String, Object> aConstants;

  /**
   * @param pParentContext
   */
  public BlockSymbolContext(final SymbolContext pParentContext) {
    super(pParentContext);
    aVariables = new HashMap<>();
    aFunctions = new HashMap<>();
    aConstants = new HashMap<>();
  }

  /**
   * Check whether the symbol is defined in this context.
   * 
   * @param pName The name of the symbol
   * @return <code>true</code> if local, <code>false</code> if not.
   */
  protected boolean isLocalSymbol(final String pName) {
    return aVariables.containsKey(pName) || aConstants.containsKey(pName) || aFunctions.containsKey(pName);
  }

  /** {@inheritDoc} */
  @Override
  public boolean isConstantSymbol(final String pName) {
    return aConstants.containsKey(pName)
        || ((!isLocalSymbol(pName)) && (getParentContext() != null) && getParentContext().isConstantSymbol(pName));
  }

  /** {@inheritDoc} */
  @Override
  public Object getConstantSymbol(final String pName) throws HandlerException {
    if (aConstants.containsKey(pName)) {
      return aConstants.get(pName);
    } else if (aFunctions.containsKey(pName)) {
      throw new HandlerException("Trying to access function " + pName + " as Constant");
    } else if (aVariables.containsKey(pName)) {
      throw new HandlerException("Trying to access variable " + pName + " as Constant");
    } else if (getParentContext() != null) {
      return getParentContext().getConstantSymbol(pName);
    } else {
      return null;
    }
  }

  /** {@inheritDoc} */
  @Override
  public boolean isFunctionSymbol(final String pName) {
    return aFunctions.containsKey(pName)
        || ((!isLocalSymbol(pName)) && (getParentContext() != null) && getParentContext().isFunctionSymbol(pName));
  }

  /** {@inheritDoc} */
  @Override
  public boolean isFunctionSymbol(final String pName, final Type[] pParamTypes) {
    return isFunctionSymbol(pName);
  }

  /** {@inheritDoc} */
  @Override
  public FunctionReference getFunctionSymbol(final String pName, final Type[] pParamTypes) throws HandlerException {
    if (aConstants.containsKey(pName)) {
      throw new HandlerException("Trying to access constant " + pName + " as function");
    } else if (aFunctions.containsKey(pName)) {
      return aFunctions.get(pName);
    } else if (aVariables.containsKey(pName)) {
      throw new HandlerException("Trying to access variable " + pName + " as function");
    } else if (getParentContext() != null) {
      return getParentContext().getFunctionSymbol(pName, pParamTypes);
    } else {
      return null;
    }
  }

  /** {@inheritDoc} */
  @Override
  public Collection<FunctionReference> getFunctionSymbols(final String pName) throws HandlerException {
    final LinkedList<FunctionReference> result = new LinkedList<>();
    if (aFunctions.containsKey(pName)) {
      result.add(aFunctions.get(pName));
    }
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public boolean isVariableSymbol(final String pName) {
    return aVariables.containsKey(pName)
        || ((!isLocalSymbol(pName)) && (getParentContext() != null) && getParentContext().isVariableSymbol(pName));
  }

  /** {@inheritDoc} */
  @Override
  public Object getVariableSymbol(final String pName) throws HandlerException {
    if (aConstants.containsKey(pName)) {
      throw new HandlerException("Trying to access constant " + pName + " as variable");
    } else if (aFunctions.containsKey(pName)) {
      throw new HandlerException("Trying to access function " + pName + " as variable");
    } else if (aVariables.containsKey(pName)) {
      if (aVariables.get(pName) instanceof Class) {
        throw new HandlerException("Variable " + pName + " has not been initialised");
      }
      return aVariables.get(pName);
    } else if (getParentContext() != null) {
      return getParentContext().getVariableSymbol(pName);
    } else {
      return null;
    }
  }

  /** {@inheritDoc} */
  @Override
  public void setVariableSymbol(final String pName, final Object pValue) throws HandlerException {
    if (aVariables.containsKey(pName)) {
      if (((aVariables.get(pName) instanceof Class) && (((Class<?>) aVariables.get(pName)).isAssignableFrom(pValue.getClass())))
          || aVariables.get(pName).getClass().isAssignableFrom(pValue.getClass())) {
        aVariables.put(pName, pValue);
        return;
      }
      if (aVariables.get(pName) instanceof Class) {
        throw new HandlerException("Trying to assign a " + pValue.getClass().toString() + " to a "
            + ((Class<?>) aVariables.get(pName)).getName());
      }

      throw new HandlerException("Trying to assign a " + pValue.getClass().toString() + " to a "
          + aVariables.get(pName).getClass().getName());
    }
    super.setVariableSymbol(pName, pValue);
  }

  /** {@inheritDoc} */
  @Override
  public boolean isSymbol(final String pName) {
    return isLocalSymbol(pName) || ((getParentContext() != null) && getParentContext().isSymbol(pName));
  }

  /** {@inheritDoc} */
  @Override
  public SymbolType getSymbolType(final String pName) {
    if (aVariables.containsKey(pName)) {
      return SymbolType.VARIABLE;
    } else if (aConstants.containsKey(pName)) {
      return SymbolType.CONSTANT;
    } else if (aFunctions.containsKey(pName)) {
      return SymbolType.FUNCTION;
    } else if (getParentContext() != null) {
      return getParentContext().getSymbolType(pName);
    }
    return null;
  }

  /** {@inheritDoc} */
  @Override
  public void defVariableSymbol(final Type pType, final String pName, final Object pValue) throws HandlerException {
    if (isLocalSymbol(pName)) {
      throw new HandlerException("The symbol with name " + pName + " is allready defined, redefining not allowed");
    }
    if (pValue == null) {
      if (pType == Type._VT_OBJECT) {
        aVariables.put(pName, ObjectWrapper._NULL);
      } else {
        aVariables.put(pName, pType.getJavaClass()); /* Like a void value */
      }
    } else {
      if (pType.isAssignableFrom(Type.typeForClass(pValue.getClass()))) {
        aVariables.put(pName, pType.convertTo(pValue));
      } else {
        throw new HandlerException("Trying to assign a " + pValue.getClass().toString() + " to " + StringUtil.prefixA(pType.getName()));
      }
    }

  }

  /** {@inheritDoc} */
  @Override
  public void defFunctionSymbol(final String pName, final FunctionReference pFunction) throws HandlerException {
    if (isLocalSymbol(pName)) {
      throw new HandlerException("The symbol with name " + pName + " is allready defined, redefining not allowed");
    }
    aFunctions.put(pName, pFunction);
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    final StringBuilder result = new StringBuilder("<BlockSymbolContext>\n");
    result.append("Constants: ");
    for (final String c : aConstants.keySet()) {
      result.append(c).append('=').append(aConstants.get(c).toString()).append(", ");
    }
    result.delete(result.length() - 2, result.length());
    result.append("\nVariables: ");
    for (final String c : aVariables.keySet()) {
      result.append(c).append('=').append(aConstants.get(c)).append(", ");
    }
    result.delete(result.length() - 2, result.length());
    if (getParentContext() != null) {
      result.append('\n');
      result.append(getParentContext().toString());
    }

    return result.toString();
  }

  /**
   * Remove all function symbols from the context.
   */
  public void clearFuncSymbols() {
    aFunctions.clear();
  }
}
