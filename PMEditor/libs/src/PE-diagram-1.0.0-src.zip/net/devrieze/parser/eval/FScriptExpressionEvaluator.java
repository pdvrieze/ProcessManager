/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.eval;

import net.devrieze.parser.*;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.streams.ExpressionParser;
import net.devrieze.parser.streams.ExpressionParser.AccessorToken;
import net.devrieze.parser.streams.StringTokenStream;
import net.devrieze.parser.tokens.*;


/**
 * A class that can evaluate expressions.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class FScriptExpressionEvaluator extends AbstractExpressionEvaluator<ExpressionTokens, BinaryOperatorTokens> {

  private final ExpressionParserFactory aExpressionParserFactory;

  /**
   * Create a new evaluator based on the given expression parser factory.
   * 
   * @param pExpressionParserFactory The factory that can create the desired
   *          expression parser.
   */
  public FScriptExpressionEvaluator(final ExpressionParserFactory pExpressionParserFactory) {
    super(new DefaultOperatorEvaluator());
    aExpressionParserFactory = pExpressionParserFactory;
  }

  /**
   * Create a new evaluator based on the default {@link ExpressionParser}
   * parser.
   */
  public FScriptExpressionEvaluator() {
    this(new ExpressionParserFactory() {

      @Override
      public ExpressionParser getExpressionParser(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) {
        return new ExpressionParser(pStream);
      }
    });
  }

  /**
   * Evaluate the given expression.
   * 
   * @param pExpression The expression to evaluate.
   * @param pSymbolContext The context to evaluate against. If <code>null</code>
   *          , a new empty context is used.
   * @return The unwrapped result of the expression.
   * @throws EvaluationException When evaluating the expression fails.
   * @throws TokenException When parsing the expression fails.
   */
  public Object evalExpression(final String pExpression, final SymbolContext pSymbolContext) throws EvaluationException, TokenException {
    final StringTokenStream stream = new StringTokenStream(pExpression);
    final ExpressionParser exprParser = aExpressionParserFactory.getExpressionParser(stream);
    final ExprToken<ExpressionTokens> expression = exprParser.getNextToken();
    if (!exprParser.eof()) {
      throw new UnexpectedTokenException("Unexpected token found at the end of the expression", stream.getNextToken());
    }
    if (pSymbolContext == null) {
      return ObjectWrapper.unWrap(evaluate(expression, new BlockSymbolContext(null)));
    }
    return ObjectWrapper.unWrap(evaluate(expression, pSymbolContext));
  }

  /**
   * Evaluate the given expression token.
   * 
   * @param pExpression The expression token to evaluate.
   * @param pSymbolContext The context for the evaluation.
   * @return The possibly wrapped result.
   * @throws EvaluationException When evaluation fails.
   */
  @SuppressWarnings("unchecked")
  @Override
  public Object evaluate(final ExprToken<ExpressionTokens> pExpression, final SymbolContext pSymbolContext) throws EvaluationException {
    if (Thread.interrupted()) {
      throw new EvaluationException("Thread Interrupted", pExpression);
    }
    switch (pExpression.getTokenType()) {
      case BINARYOPERATOR: {
        return evaluateBinaryToken((BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>>) pExpression, pSymbolContext);
      }
      case NOT:
      case PAREN:
        return evaluateUnaryToken((UnaryExprToken<ExpressionTokens>) pExpression, pSymbolContext);
      case LITERAL: {
        return ((LiteralToken<ExpressionTokens, ?>) pExpression).getValue();
      }
      case SYMBOL: {
        return evaluateVarSymbol((SymbolToken<ExpressionTokens>) pExpression, pSymbolContext);
      }
      case FUNCCALL: {
        return evaluateFunctionCall((FunctionCallToken<ExpressionTokens>) pExpression, pSymbolContext);
      }
      case ARRAYACCESS:
        return evaluateArrayRead((AccessorToken<ExpressionTokens>) pExpression, pSymbolContext);
      case OBJECTACCESS:
        return evaluateObjectAccess((AccessorToken<ExpressionTokens>) pExpression, pSymbolContext);
    }
    throw new EvaluationException("Unknown expression element found", pExpression);
  }
}
