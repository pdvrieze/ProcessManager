/*
 * Created on 04-Nov-2005
 */
package net.devrieze.parser.eval;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static net.devrieze.parser.eval.ReflectionObjectWrapper.*;

import net.devrieze.parser.ObjectWrapper;
import net.devrieze.util.StringUtil;


/**
 * A static class to help with reflection code. This avoids duplication of code.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
final class ReflectionHelper {

  /**
   * A class that implements reflection based a function reference.
   */
  private static class FunctionReferenceImpl implements FunctionReference {

    private final Method aMethod;

    private final Object aObject;

    /**
     * Create a new FunctionReferenceImpl.
     * 
     * @param pObject The object of the method. <code>null</code> for static
     *          methods.
     * @param pMethod The method to wrap.
     */
    public FunctionReferenceImpl(final Object pObject, final Method pMethod) {
      aMethod = pMethod;
      aObject = pObject;
    }

    /** {@inheritDoc} */
    @Override
    public Type getReturnType() {
      return Type.typeForClass(aMethod.getReturnType());
    }

    /** {@inheritDoc} */
    @Override
    public List<Type> getParamTypes() {
      final Class<?>[] pTypes = aMethod.getParameterTypes();
      final List<Type> result = new ArrayList<>(pTypes.length);
      for (int i = 0; i < pTypes.length; i++) {
        final Class<?> c = pTypes[i];
        if (((i + 1) == pTypes.length) && aMethod.isVarArgs()) {
          result.add(Type.typeForClass(c.getComponentType()));
        } else {
          result.add(Type.typeForClass(c));
        }
      }
      return result;
    }

    /** {@inheritDoc} */
    @Override
    public Object call(final Object[] pParams) throws HandlerException {
      try {
        final Object[] params;
        if (isVarArgs()) {
          final Class<?>[] pTypes = aMethod.getParameterTypes();
          params = new Object[pTypes.length];
          for (int i = 0; i < (params.length - 1); i++) {
            params[i] = ObjectWrapper.unWrap(pParams[i]);
          }
          final Object[] varArgs = (Object[]) Array.newInstance(pTypes[params.length - 1].getComponentType(), (pParams.length - params.length) + 1);
          for (int i = 0; i < varArgs.length; i++) {
            varArgs[i] = ObjectWrapper.unWrap(pParams[(i + params.length) - 1]);
          }
          params[params.length - 1] = varArgs;
        } else {
          params = ObjectWrapper.unWrapArray(pParams);
        }
        return ObjectWrapper.wrap(getReturnType().convertTo(aMethod.invoke(aObject, params)));
      } catch (final Exception e) {
        throw new HandlerException(e);
      }
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
      final StringBuilder b = new StringBuilder(aMethod.getName());
      b.append('(');
      boolean first = true;
      for (final Class<?> c : aMethod.getParameterTypes()) {
        if (first) {
          first = false;
        } else {
          b.append(", ");
        }
        b.append(StringUtil.simpleClassName(c));
      }
      b.append(')');
      return b.toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean isVarArgs() {
      return aMethod.isVarArgs();
    }

  }


  private ReflectionHelper() {
    // Static only
  }

  /**
   * @param pClass
   * @param pName
   * @param pStatic
   * @return whether or not it is a function symbol.
   */
  public static boolean isFunctionSymbol(final Class<?> pClass, final String pName, final boolean pStatic) {
    for (final Method method : pClass.getMethods()) {
      if (method.getName().equals(pName) && (Modifier.isStatic(method.getModifiers()) == pStatic)) {
        return true;
      }
    }
    return false;
  }

  public static boolean isFunctionSymbol(final Class<?> pClass, final String pName, final Type[] pParamTypes, final boolean pStatic) {
    final Class<?>[] paramTypes = getParamClasses(pParamTypes);
    Method method;
    try {
      method = pClass.getMethod(pName.toString(), paramTypes);
    } catch (final NoSuchMethodException e) {
      final Method[] methods = pClass.getMethods();
      for (final Method m : methods) {
        if (pName.equals(m.getName()) && checkParams(pParamTypes, m)) {
          return true;
        }
      }
      return false;
    }
    return checkMethod(method, pStatic);
  }

  public static FunctionReference getFunctionSymbol(final Class<?> pClass, final String pName, final Type[] pParamTypes, final Object pObject) throws HandlerException {
    final Class<?>[] paramTypes = getParamClasses(pParamTypes);
    Method method;
    try {
      method = pClass.getMethod(pName.toString(), paramTypes);
      if (!isScriptable(method)) {
        throw new HandlerException("The " + pName + " symbol is not accessible for scripts");
      }
      if (Modifier.isStatic(method.getModifiers()) != (pObject == null)) {
        if (pObject == null) {
          throw new HandlerException("Trying to get a nonstatic method from a class");
        }
        throw new HandlerException("Trying to get a static method from an object");
      }
      return new FunctionReferenceImpl(pObject, method);
    } catch (final NoSuchMethodException e) {
      final Collection<FunctionReference> refs = getFunctionSymbols(pClass, pName, pObject);
      for (final FunctionReference ref : refs) {
        if (checkParams(pParamTypes, ref)) {
          return ref;
        }
      }
      throw new HandlerException(e);
    }
  }

  private static Class<?>[] getParamClasses(final Type[] pParamTypes) {
    final Class<?>[] paramTypes = new Class[pParamTypes.length];
    for (int i = 0; i < paramTypes.length; i++) {
      paramTypes[i] = pParamTypes[i].getJavaClass();
      if (ObjectWrapper.class.isAssignableFrom(paramTypes[i])) {
        paramTypes[i] = Object.class;
      }
    }
    return paramTypes;
  }

  public static Collection<FunctionReference> getFunctionSymbols(final Class<?> pClass, final String pName, final Object pObject) {
    final Method[] methods = pClass.getMethods();
    final List<FunctionReference> result = new ArrayList<>(methods.length);
    for (final Method method : methods) {
      if (StringUtil.isEqual(method.getName(), pName) && checkMethod(method, pObject == null)) {
        result.add(new FunctionReferenceImpl(pObject, method));
      }
    }
    return result;
  }

  private static boolean checkParams(final Type[] pParamTypes, final FunctionReference pRef) {
    final List<Type> candidateParams = pRef.getParamTypes();
    if ((pParamTypes.length == candidateParams.size()) || (pRef.isVarArgs() && (pParamTypes.length >= candidateParams.size()))) {
      for (int i = 0; i < pParamTypes.length; i++) {
        Type type;
        if (i < candidateParams.size()) {
          type = candidateParams.get(i);
        } else {
          type = candidateParams.get(candidateParams.size() - 1);
        }
        if (!type.isAssignableFrom(pParamTypes[i])) {
          return false;
        }
      }
    }
    return true;
  }

  private static boolean checkParams(final Type[] pParamTypes, final Method pMethod) {
    if (pMethod.isVarArgs()) {
      return checkParamsVarArgs(pParamTypes, pMethod);
    }
    return checkParamsNoVarArgs(pParamTypes, pMethod);
  }

  private static boolean checkParamsNoVarArgs(final Type[] pParamTypes, final Method pMethod) {
    final Class<?>[] paramTypes = pMethod.getParameterTypes();
    if (pParamTypes.length != paramTypes.length) {
      return false;
    }
    for (int i = 0; i < pParamTypes.length; i++) {
      final Type type = Type.typeForClass(paramTypes[i]);
      if (!type.isAssignableFrom(pParamTypes[i])) {
        return false;
      }
    }
    return true;
  }

  private static boolean checkParamsVarArgs(final Type[] pParamTypes, final Method pMethod) {
    final Class<?>[] paramTypes = pMethod.getParameterTypes();
    final int ln2 = paramTypes.length - 1;
    if (pParamTypes.length < ln2) {
      return false;
    }
    for (int i = 0; i < pParamTypes.length; i++) {
      Type type;
      if (i < paramTypes.length) {
        type = Type.typeForClass(paramTypes[i]);
      } else if (i == ln2) {
        type = Type.typeForClass(paramTypes[i].getComponentType());
      } else {
        type = Type.typeForClass(paramTypes[ln2]);
      }
      if (!type.isAssignableFrom(pParamTypes[i])) {
        return false;
      }
    }
    return true;
  }

  private static boolean checkMethod(final Method pMethod, final boolean pStatic) {
    return (pMethod != null) && isScriptable(pMethod)
        && ((pStatic && Modifier.isStatic(pMethod.getModifiers())) || (!pStatic && !Modifier.isStatic(pMethod.getModifiers())));
  }

}
