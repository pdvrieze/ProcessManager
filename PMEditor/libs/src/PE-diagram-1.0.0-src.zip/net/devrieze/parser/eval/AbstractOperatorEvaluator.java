/*
 * Created on Dec 11, 2005
 *
 */
package net.devrieze.parser.eval;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.ObjectWrapper;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.tokens.BinaryExprToken;
import net.devrieze.parser.tokens.UnaryExprToken;
import net.devrieze.util.Tupple;


/**
 * An evaluator class for operators.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <B> The type of the binary operator tokens
 * @param <U> The type of the expression tokens
 */
public abstract class AbstractOperatorEvaluator<U extends Enum<U> & Language<U>, B extends Enum<B> & Language<B>> {

  private static final class UnsupportedCoersionException extends Exception {

    private static final long serialVersionUID = -4697634181179724938L;
  }

  public abstract Object evaluateUnary(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, UnaryExprToken<U> pToken, final SymbolContext pSymbolContext) throws EvaluationException;

  public abstract Object evaluateBinary(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException;

  /**
   * Evaluate a plus token.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext
   * @return The result of the addition
   * @throws EvaluationException When the object is not of the required type
   */
  protected Object evaluatePlus(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Integer.valueOf(((Integer) pLeft).intValue() + ((Integer) pRight).intValue());
    } else if (pLeft instanceof Double) {
      return Double.valueOf(((Double) pLeft).doubleValue() + ((Double) pRight).doubleValue());
    } else if ((pLeft instanceof String) || (pLeft instanceof Character)) {
      return new StringBuilder().append(pLeft).append(pRight).toString();
    }
    throw new EvaluationException("The plus operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate a minus token.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext
   * @return The result of the subtraction
   * @throws EvaluationException When the object is not of the required type
   */
  protected Object evaluateMinus(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Integer.valueOf(((Integer) pLeft).intValue() - ((Integer) pRight).intValue());
    } else if (pLeft instanceof Double) {
      return  Double.valueOf(((Double) pLeft).doubleValue() - ((Double) pRight).doubleValue());
    }
    throw new EvaluationException("The minus operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate a plus token.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext
   * @return The result of the addition
   * @throws EvaluationException When the object is not of the required type
   */
  protected Object evaluateTimes(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return  Integer.valueOf(((Integer) pLeft).intValue() * ((Integer) pRight).intValue());
    } else if (pLeft instanceof Double) {
      return  Double.valueOf(((Double) pLeft).doubleValue() * ((Double) pRight).doubleValue());
    }
    throw new EvaluationException("The times operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate division.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the division token.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Double evaluateDiv(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Double.valueOf(((Integer) pLeft).doubleValue() / ((Integer) pRight).doubleValue());
    } else if (pLeft instanceof Double) {
      return  Double.valueOf(((Double) pLeft).doubleValue() / ((Double) pRight).doubleValue());
    }
    throw new EvaluationException("The div operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate division.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the division token.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Integer evaluateIDiv(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return  Integer.valueOf(((Integer) pLeft).intValue() / ((Integer) pRight).intValue());
    } else if (pLeft instanceof Double) {
      return Integer.valueOf(((Double) pLeft).intValue() / ((Double) pRight).intValue());
    }
    throw new EvaluationException("The div operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate integer remainder / modulo (_TT_MOD).
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the division token.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Integer evaluateMod(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Integer.valueOf(((Integer) pLeft).intValue() % ((Integer) pRight).intValue());
    }
    throw new EvaluationException("The mod operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate a power token.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the power
   * @throws EvaluationException When the object is not of the required type
   */
  protected Double evaluatePower(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Double.valueOf(Math.pow(((Integer) pLeft).intValue(), ((Integer) pRight).intValue()));
    } else if (pLeft instanceof Double) {
      return Double.valueOf(Math.pow(((Double) pLeft).doubleValue(), ((Double) pRight).doubleValue()));
    }
    throw new EvaluationException("The power operator is not defined for " + pLeft.getClass().getName() + " and "
        + pRight.getClass().getName(), pToken);
  }

  /**
   * Evaluate equality.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the equality.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateEquals(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft == pRight) { // The same object is equal no matter what
      return Boolean.TRUE;
    } else if (pLeft instanceof Integer) {
      return Boolean.valueOf(((Integer) pLeft).equals(pRight));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf(((Double) pLeft).equals(pRight));
    } else if (pLeft instanceof String) {
      return Boolean.valueOf(((String) pLeft).equals(pRight));
    } else if (pLeft instanceof Character) {
      return Boolean.valueOf(((Character) pLeft).equals(pRight));
    } else if (pLeft instanceof ObjectWrapper) {
      return Boolean.valueOf(((ObjectWrapper<?>) pLeft).equals(pRight));
    }
    throw new EvaluationException("The equality operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate inequality.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the inequality.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateUnequals(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Boolean.valueOf(!((Integer) pLeft).equals(pRight));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf(!((Double) pLeft).equals(pRight));
    } else if (pLeft instanceof String) {
      return Boolean.valueOf(!((String) pLeft).equals(pRight));
    }
    throw new EvaluationException("The inequality operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate the lessthan operator.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the less operator.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateLess(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Boolean.valueOf((((Integer) pLeft).intValue()) < (((Integer) pRight).intValue()));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf((((Double) pLeft).doubleValue()) < (((Double) pRight).doubleValue()));
    }
    throw new EvaluationException("The less operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate less or equal.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the operator.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateLessEquals(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Boolean.valueOf((((Integer) pLeft).intValue()) <= (((Integer) pRight).intValue()));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf((((Double) pLeft).doubleValue()) <= (((Double) pRight).doubleValue()));
    }
    throw new EvaluationException("The lessorequal operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate greater.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the operator.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateGreater(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Boolean.valueOf((((Integer) pLeft).intValue()) > (((Integer) pRight).intValue()));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf((((Double) pLeft).doubleValue()) > (((Double) pRight).doubleValue()));
    }
    throw new EvaluationException("The greater operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate greater or equal.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that represents the operator.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateGreaterEquals(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Tupple<Object, Object> r = coerceTypes(pExpressionEvaluator, pToken, pSymbolContext);
    final Object pLeft = r.getElem1();
    final Object pRight = r.getElem2();
    if (pLeft instanceof Integer) {
      return Boolean.valueOf((((Integer) pLeft).intValue()) >= (((Integer) pRight).intValue()));
    } else if (pLeft instanceof Double) {
      return Boolean.valueOf((((Double) pLeft).doubleValue()) >= (((Double) pRight).doubleValue()));
    }
    throw new EvaluationException("The greaterorequal operator is not defined for " + pLeft.getClass().getName(), pToken);
  }

  /**
   * Evaluate a logical and. Uses short circuit evaluation.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The logical and token.
   * @param pSymbolContext The context for the evaluation.
   * @return The result.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateLogicAnd(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Object pLeft = pExpressionEvaluator.evaluate(pToken.getLeft(), pSymbolContext);
    if (!((Boolean) pLeft).booleanValue()) {
      return Boolean.FALSE;
    }
    final Object pRight = pExpressionEvaluator.evaluate(pToken.getRight(), pSymbolContext);
    return (Boolean) pRight;
  }

  /**
   * Evaluate a logical or. Uses short circuit evaluation.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The logical or token.
   * @param pSymbolContext The context for the evaluation.
   * @return The result.
   * @throws EvaluationException When evaluation fails.
   */
  protected Boolean evaluateLogicOr(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final BinaryExprToken<U, B, LinedToken<U>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Object pLeft = pExpressionEvaluator.evaluate(pToken.getLeft(), pSymbolContext);
    if (((Boolean) pLeft).booleanValue()) {
      return Boolean.TRUE;
    }
    final Object pRight = pExpressionEvaluator.evaluate(pToken.getRight(), pSymbolContext);
    return (Boolean) pRight;
  }

  /**
   * Evaluate a logical not.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext
   * @return The oposite value of the value of the pObject parameter
   * @throws EvaluationException When the object is not of the required type
   */
  protected Boolean evaluateNot(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final UnaryExprToken<U> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    try {
      return Boolean.valueOf(!((Boolean) pExpressionEvaluator.evaluate(pToken.getSubToken(), pSymbolContext)).booleanValue());
    } catch (final ClassCastException e) {
      throw new EvaluationException("The \"not\" method is not defined for " + pToken.getSubToken().getClass().getName(), e, pToken);
    }
  }

  /**
   * Evaluate a parenthesis.
   * 
   * @param pExpressionEvaluator The evaluator for further tokens.
   * @param pToken The token that is being evaluated
   * @param pSymbolContext
   * @return The oposite value of the value of the pObject parameter
   * @throws EvaluationException When the object is not of the required type
   */
  protected Object evaluateParen(final AbstractExpressionEvaluator<U, B> pExpressionEvaluator, final UnaryExprToken<U> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    try {
      return pExpressionEvaluator.evaluate(pToken.getSubToken(), pSymbolContext);
    } catch (final ClassCastException e) {
      throw new EvaluationException("The \"not\" method is not defined for " + pToken.getSubToken().getClass().getName(), e, pToken);
    }
  }

  private static <E extends Enum<E> & Language<E>> Tupple<Object, Object> coerceTypes(final AbstractExpressionEvaluator<E, ?> pExpressionEvaluator, final BinaryExprToken<E, ?, LinedToken<E>> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final Object pLeft = pExpressionEvaluator.evaluate(pToken.getLeft(), pSymbolContext);
    final Object pRight = pExpressionEvaluator.evaluate(pToken.getRight(), pSymbolContext);
    try {
      if (pLeft instanceof Integer) {
        return coerceTypesInt((Integer) pLeft, pRight);
      } else if (pLeft instanceof Double) {
        return coerceTypesDouble((Double) pLeft, pRight);
      } else if (pLeft instanceof String) {
        return coerceTypesString((String) pLeft, pRight);
      } else if (pLeft instanceof Character) {
        return coerceTypesCharacter((Character) pLeft, pRight);
      } else if (pLeft instanceof ObjectWrapper) {
        return coerceTypesObject((ObjectWrapper<?>) pLeft, pRight);
      } else {
        throw new UnsupportedCoersionException();
      }
    } catch (final UnsupportedCoersionException e) {
      throw new EvaluationException("Unmatching types " + (pLeft != null ? pLeft.getClass().getName() : "null") + " and "
          + (pRight != null ? pRight.getClass().getName() : "null"), pToken);
    }
  }

  private static Tupple<Object, Object> coerceTypesObject(final ObjectWrapper<?> pLeft, final Object pRight) throws UnsupportedCoersionException {
    if (pRight instanceof ObjectWrapper) {
      return new Tupple<Object, Object>(pLeft, pRight);
    } else if (pRight == null) {
      return new Tupple<Object, Object>(pLeft, ObjectWrapper.wrap((Object) null));
    } else {
      throw new UnsupportedCoersionException();
    }
  }

  private static Tupple<Object, Object> coerceTypesCharacter(final Character pLeft, final Object pRight) throws UnsupportedCoersionException {
    if (pRight instanceof Character) {
      return new Tupple<Object, Object>(pLeft, pRight);
    } else if (pRight instanceof String) {
      return new Tupple<Object, Object>(pLeft.toString(), pRight);
    } else {
      throw new UnsupportedCoersionException();
    }
  }

  private static Tupple<Object, Object> coerceTypesString(final String pLeft, final Object pRight) throws UnsupportedCoersionException {
    if (pRight instanceof String) {
      return new Tupple<Object, Object>(pLeft, pRight);
    } else if (pRight instanceof Character) {
      return new Tupple<Object, Object>(pLeft, ((Character) pRight).toString());
    } else {
      throw new UnsupportedCoersionException();
    }
  }

  private static Tupple<Object, Object> coerceTypesDouble(final Double pLeft, final Object pRight) throws UnsupportedCoersionException {
    if (pRight instanceof Number) {
      return new Tupple<Object, Object>(pLeft, Double.valueOf(((Number) pRight).doubleValue()));
    }
    throw new UnsupportedCoersionException();
  }

  private static Tupple<Object, Object> coerceTypesInt(final Integer pLeft, final Object pRight) throws UnsupportedCoersionException {
    if (pRight instanceof Integer) {
      return new Tupple<Object, Object>(pLeft, pRight);
    } else if (pRight instanceof Double) {
      return new Tupple<Object, Object>(Double.valueOf(pLeft.doubleValue()), pRight);
    } else if (pRight instanceof Float) {
      return new Tupple<Object, Object>(Double.valueOf(pLeft.doubleValue()), Double.valueOf(((Float) pRight).doubleValue()));
    } else {
      throw new UnsupportedCoersionException();
    }
  }

}
