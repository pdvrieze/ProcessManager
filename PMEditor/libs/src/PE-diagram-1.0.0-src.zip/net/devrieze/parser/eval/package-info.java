/**
 * This package contains the main classes for evaluating the trees that the
 * {@link net.devrieze.parser.streams.StatementParser parser} provides.
 * @version 1.0 $Revision$
 */
package net.devrieze.parser.eval;

