/*
 * Created on Jan 8, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.Collection;

import net.devrieze.util.StringUtil;


/**
 * An interface representing the context in which variables exist.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface SymbolContext {

  /**
   * An enumeration representing the different kinds of symbols known.
   * 
   * @author Paul de Vrieze
   */
  public enum SymbolType {
    /** A symbol type for a variable. */
    VARIABLE("Variable"),
    /** A symbol type for a function. */
    FUNCTION("Function"),
    /** A symbol type for a constant. */
    CONSTANT("Constant"),
    /** A symbol type for a type. */
    TYPE("Type");

    private final String aName;

    /**
     * Create a new Symbol Type.
     * 
     * @param pName The name of the symbol type.
     */
    SymbolType(final CharSequence pName) {
      aName = pName.toString();
    }

    /**
     * Get the name of the symbol type.
     * 
     * @return the name
     */
    public String getName() {
      return aName;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
      return "<" + StringUtil.simpleClassName(getClass()) + ": " + aName + ">";
    }
  }

  /**
   * Get the parent symbol context. If this is <code>null</code> then there is
   * no parent context. The parent context is used for resolving symbols unknown
   * to this context.
   * 
   * @return The parent context.
   */
  SymbolContext getParentContext();

  /**
   * Check whether the symbol represents a variable.
   * 
   * @param pName The name of the symbol.
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isVariableSymbol(String pName);

  /**
   * Check whether the symbol represents a function.
   * 
   * @param pName The name of the symbol.
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isFunctionSymbol(String pName);

  /**
   * Check whether the symbol parameter combination represents a function.
   * 
   * @param pName The name of the symbol.
   * @param pParamTypes The types of the parameters
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isFunctionSymbol(String pName, Type[] pParamTypes);

  /**
   * Check whether the symbol represents a constant.
   * 
   * @param pName The name of the symbol.
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isConstantSymbol(String pName);

  /**
   * Check whether the symbol represents a type.
   * 
   * @param pName The name of the symbol.
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isTypeSymbol(String pName);

  /**
   * Check whether the name represents a symbol in this or the parent context.
   * 
   * @param pName The name of the symbol.
   * @return <code>true</code> if it does, <code>false</code> if it doesn't.
   */
  boolean isSymbol(String pName);

  /**
   * Define a new variable in the context.
   * 
   * @param pType The type of the variable.
   * @param pName The name of the variable
   * @param pValue The value of the variable
   * @throws HandlerException When something goes wrong. For example when
   *           defining new symbols is not allowed/possible.
   */
  void defVariableSymbol(Type pType, String pName, Object pValue) throws HandlerException;

  /**
   * Get the value associated with the variable symbol of the given name.
   * 
   * @param pName The name of the symbol
   * @return The value of the variable.
   * @throws HandlerException When something is wrong, like a type problem.
   */
  Object getVariableSymbol(String pName) throws HandlerException;

  /**
   * Set the value associated with the variable symbol of the given name.
   * 
   * @param pName The name of the symbol.
   * @param pValue The new value to be associated with the name.
   * @throws HandlerException When something is wrong, like a type problem.
   */
  void setVariableSymbol(String pName, Object pValue) throws HandlerException;

  /**
   * Define a new function in the context.
   * 
   * @param pName The name of the function.
   * @param pFunction The function to associate with the name.
   * @throws HandlerException When something goes wrong. For example when
   *           defining new symbols is not allowed/possible.
   */
  void defFunctionSymbol(String pName, FunctionReference pFunction) throws HandlerException;

  /**
   * Get the function reference associated with the function symbol of the given
   * signature.
   * 
   * @param pName The name of the symbol
   * @param pParamTypes The types of the parameters to the function
   * @return The function reference.
   * @throws HandlerException When something is wrong, like a nonexistent
   *           symbol.
   */
  FunctionReference getFunctionSymbol(String pName, Type[] pParamTypes) throws HandlerException;

  /**
   * Get all function references associated with the function symbol of the
   * given name.
   * 
   * @param pName The name of the symbol
   * @return The function references that have this name. In a non-overloaded
   *         language this list will allways have size 1.
   * @throws HandlerException When something is wrong, like a nonexistent
   *           symbol.
   */
  Collection<FunctionReference> getFunctionSymbols(String pName) throws HandlerException;

  /**
   * Get the value associated with the constant symbol of the given name.
   * 
   * @param pName The name of the symbol
   * @return The value of the constant.
   * @throws HandlerException When something is wrong, like a nonexistent
   *           symbol.
   */
  Object getConstantSymbol(String pName) throws HandlerException;

  /**
   * Get the type symbol with the specified name.
   * 
   * @param pName The name of the symbol
   * @return The type symbol
   * @throws HandlerException If there is no type symbol with the specified
   *           name.
   */
  Type getTypeSymbol(String pName) throws HandlerException;

  /**
   * Get the type of the symbol. Note that this function will return a type. If
   * the language supports symbol overloading this is not reliable.
   * 
   * @param pName
   * @return The type of the symbol, <code>null</code> when there isn't a symbol
   *         with this name
   */
  SymbolType getSymbolType(String pName);
}
