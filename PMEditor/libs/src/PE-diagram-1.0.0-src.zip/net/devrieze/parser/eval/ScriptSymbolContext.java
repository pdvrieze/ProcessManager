package net.devrieze.parser.eval;

import java.util.Collection;

import javax.script.Bindings;
import javax.script.ScriptContext;

import static net.devrieze.parser.eval.SymbolContext.SymbolType.*;


/**
 * A {@link SymbolContext} that integrates with the java 1.6 scripting API
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ScriptSymbolContext implements SymbolContext {

  private final ScriptContext aContext;

  public ScriptSymbolContext(final ScriptContext pContext) {
    aContext = pContext;
  }

  @Override
  public void defFunctionSymbol(final String pName, final FunctionReference pFunction) throws HandlerException {
    throw new HandlerException("Functions can not be defined in this context");
  }

  @Override
  public void defVariableSymbol(final Type pType, final String pName, final Object pValue) throws HandlerException {
    aContext.setAttribute(pName, pValue, ScriptContext.ENGINE_SCOPE);
  }

  @Override
  public Object getConstantSymbol(final String pName) throws HandlerException {
    throw new HandlerException("A ScriptSymbolContext has no constants");
  }

  @Override
  public FunctionReference getFunctionSymbol(final String pName, final Type[] pParamTypes) throws HandlerException {
    throw new HandlerException("A ScriptSymbolContext has no functions");
  }

  @Override
  public Collection<FunctionReference> getFunctionSymbols(final String pName) throws HandlerException {
    throw new HandlerException("A ScriptSymbolContext has no functions");
  }

  @Override
  public SymbolContext getParentContext() {
    return null;
  }

  @Override
  public SymbolType getSymbolType(final String pName) {
    for (final int scope : aContext.getScopes()) {
      final Bindings bindings = aContext.getBindings(scope);
      if (bindings.containsKey(pName)) {
        return SymbolType.VARIABLE;
      }
    }
    return null;
  }

  @Override
  public Type getTypeSymbol(final String pName) throws HandlerException {
    throw new HandlerException("A ScriptSymbolContext has no functions");
  }

  @Override
  public Object getVariableSymbol(final String pName) throws HandlerException {
    return aContext.getAttribute(pName);
  }

  @Override
  public boolean isConstantSymbol(final String pName) {
    return false;
  }

  @Override
  public boolean isFunctionSymbol(final String pName) {
    return false;
  }

  @Override
  public boolean isFunctionSymbol(final String pName, final Type[] pParamTypes) {
    return false;
  }

  @Override
  public boolean isSymbol(final String pName) {
    return isVariableSymbol(pName);
  }

  @Override
  public boolean isTypeSymbol(final String pName) {
    return false;
  }

  @Override
  public boolean isVariableSymbol(final String pName) {
    return getSymbolType(pName) == VARIABLE;
  }

  @Override
  public void setVariableSymbol(final String pName, final Object pValue) throws HandlerException {
    aContext.setAttribute(pName, pValue, ScriptContext.ENGINE_SCOPE);
  }

}
