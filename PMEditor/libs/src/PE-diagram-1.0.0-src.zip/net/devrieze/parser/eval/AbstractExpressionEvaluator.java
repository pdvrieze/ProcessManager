/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.List;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.ObjectWrapper;
import net.devrieze.parser.Token;
import net.devrieze.parser.languages.Language;
import net.devrieze.parser.streams.ExpressionParser;
import net.devrieze.parser.streams.ExpressionParser.AccessorToken;
import net.devrieze.parser.tokens.*;


/**
 * A class that can evaluate expressions.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The type of the expression tokens to evaluate.
 * @param <O> The type of binary operators.
 */
public abstract class AbstractExpressionEvaluator<T extends Enum<T> & Language<T>, O extends Enum<O> & Language<O>> implements Evaluator<T> {

  private final AbstractOperatorEvaluator<T, O> aOperatorEvaluator;

  /**
   * Create a new evaluator based on the default {@link ExpressionParser}
   * parser.
   * 
   * @param pOperatorEvaluator
   */
  protected AbstractExpressionEvaluator(final AbstractOperatorEvaluator<T, O> pOperatorEvaluator) {
    aOperatorEvaluator = pOperatorEvaluator;
  }

  @Override
  public Object evaluate(final Token<T> pToken, final SymbolContext pContext) throws EvaluationException {
    return evaluate((ExprToken<T>) pToken, pContext);
  }

  /**
   * Evaluate the given expression token.
   * 
   * @param pExpression The expression token to evaluate.
   * @param pSymbolContext The context for the evaluation.
   * @return The possibly wrapped result.
   * @throws EvaluationException When evaluation fails.
   */
  public abstract Object evaluate(final ExprToken<T> pExpression, final SymbolContext pSymbolContext) throws EvaluationException;

  protected Object evaluateBinaryToken(final BinaryExprToken<T, O, LinedToken<T>> pExpression, final SymbolContext pSymbolContext) throws EvaluationException {
    return aOperatorEvaluator.evaluateBinary(this, pExpression, pSymbolContext);
  }

  protected Object evaluateUnaryToken(final UnaryExprToken<T> pExpression, final SymbolContext pSymbolContext) throws EvaluationException {
    return aOperatorEvaluator.evaluateUnary(this, pExpression, pSymbolContext);
  }

  /**
   * Evaluate the access to an object member.
   * 
   * @param pToken The object access token.
   * @param pSymbolContext The context to find the object symbol in.
   * @return The result of evaluating the member in the context of the object.
   * @throws EvaluationException When evaluation fails.
   */
  protected Object evaluateObjectAccess(final AccessorToken<T> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    final ExprToken<T> subToken = pToken.getQualifier();
    final Object obj = evaluate(pToken.getTarget(), pSymbolContext);
    if (obj instanceof Contexed) {
      return evaluate(subToken, ((Contexed) obj).getContext());
    }
    throw new EvaluationException(obj.getClass().getName() + " is not an object", pToken.getTarget());
  }

  /**
   * Handle a variable reference symbol.
   * 
   * @param pToken The token that references a variable
   * @param pContext Context for the evaluation.
   * @return The variable
   * @throws EvaluationException
   */
  protected Object evaluateVarSymbol(final SymbolToken<T> pToken, final SymbolContext pContext) throws EvaluationException {
    final String symbolName = pToken.getSymbol().toString();
    try {
      if (pContext != null) {
        if (pContext.isVariableSymbol(symbolName)) {
          return pContext.getVariableSymbol(symbolName);
        } else if (pContext.isConstantSymbol(symbolName)) {
          return pContext.getConstantSymbol(symbolName);
        } else if (pContext.isFunctionSymbol(symbolName)) {
          final FunctionReference symbol = pContext.getFunctionSymbol(symbolName, new Type[0]);
          if (symbol == null) {
            throw new EvaluationException("Accessing functions as variables is only allowed for functions with no parameters", pToken);
          }
          return symbol.call(new Object[0]);
        } else if (pContext.isSymbol(symbolName)) {
          throw new EvaluationException("Variable symbol expected, but found " + pContext.getSymbolType(symbolName), pToken);
        }
      }
    } catch (final EvaluationException e) {
      throw e; /* Just rethrow evaluation exceptions, wrap everything else up */
    } catch (final Exception e) {
      throw new EvaluationException("External failure: " + e.getMessage(), e, pToken);
    }
    throw new EvaluationException("Unknown symbol found :\"" + symbolName + "\"\n" + pContext, pToken);
  }

  /**
   * Evaluate the access to an array element.
   * 
   * @param pToken The token that represents the access.
   * @param pSymbolContext The context for the evaluation.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Object evaluateArrayRead(final AccessorToken<T> pToken, final SymbolContext pSymbolContext) throws EvaluationException {

    final Object array = ObjectWrapper.unWrap(evaluate(pToken.getTarget(), pSymbolContext));
    final Object index = ObjectWrapper.unWrap(evaluate(pToken.getQualifier(), pSymbolContext));

    try {
      final Object result = handleArrayRead(array, index);
      if (result != null) {
        return result;
      }
    } catch (final HandlerException e) {
      throw new EvaluationException("External failure: " + e.getMessage(), e, pToken);
    }

    if (array instanceof String) {
      if (index instanceof Integer) {
        return Character.valueOf(((String) array).charAt(((Integer) index).intValue()));
      }
      throw new EvaluationException("String indices must be integers", pToken);
    }
    throw new EvaluationException("The symbol is not an array", pToken);
  }

  /**
   * A method that can be overridden by inheriting classes to support other
   * kinds of array access. The default implementation does nothing
   * 
   * @param pArray The array object
   * @param pIndex The index to the array
   * @return The (wrapped) resulting object. If this object is unknown return
   *         <code>null</code>.
   * @throws HandlerException When something is wrong in the access, this
   *           exception can be thrown. This means that the symbol is known.
   */
  protected Object handleArrayRead(final Object pArray, final Object pIndex) throws HandlerException {
    if (pArray instanceof IndexedAccess) {
      return ObjectWrapper.wrap(((IndexedAccess) pArray).getWrapped(((Integer) pIndex).intValue()));
    } else if (pArray instanceof CharSequence) {
      return Character.valueOf(((CharSequence) pArray).charAt(((Integer) pIndex).intValue()));
    }
    throw new HandlerException("The default implementation does not support array access");
  }

  /**
   * Evaluate the writing to an array element. By default not implemented.
   * 
   * @param pArray The array object.
   * @param pIndex the index in the array.
   * @param pValue The new value.
   * @return <code>true</code> if writing succeeded.
   * @throws HandlerException
   */
  protected boolean handleArrayWrite(final Object pArray, final Object pIndex, final Object pValue) throws HandlerException {
    if (pArray instanceof IndexedAccess) {
      return ((IndexedAccess) pArray).set(((Integer) pIndex).intValue(), pValue);
    }
    throw new HandlerException("The default implementation does not support array access");
  }

  /**
   * Evaluate a function call.
   * 
   * @param pToken The token that represents the function call.
   * @param pSymbolContext The context for the evaluation. Note that this is for
   *          the parameters. The function has it's own context.
   * @return The result of the evaluation.
   * @throws EvaluationException When evaluation fails.
   */
  protected Object evaluateFunctionCall(final FunctionCallToken<T> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    try {
      final Object[] params = new Object[pToken.getParams().size()];
      for (int i = 0; i < params.length; i++) {
        params[i] = evaluate(pToken.getParams().get(i), pSymbolContext);
      }
      FunctionReference function;

      if (pToken.getFunctionReference() instanceof SymbolToken) {
        function = getFunctionSymbol(pSymbolContext, ((SymbolToken<T>) pToken.getFunctionReference()).getSymbol().toString(), params);
      } else if (pToken.getFunctionReference() instanceof AccessorToken) {
        final AccessorToken<T> tmp = (AccessorToken<T>) pToken.getFunctionReference();
        final ObjectWrapper<?> obj = (ObjectWrapper<?>) evaluate(tmp.getTarget(), pSymbolContext);
        if (obj == null) {
          throw new EvaluationException("The object to which you try to call a function is null", tmp.getTarget());
        }
        if (tmp.getQualifier() instanceof SymbolToken) {
          function = getFunctionSymbol(obj.getContext(), ((SymbolToken<T>) tmp.getQualifier()).getSymbol().toString(), params);
        } else {
          throw new EvaluationException("The token does not appear to be a symbol, let alone a function symbol", tmp.getQualifier());
        }
      } else {
        throw new EvaluationException("Don't know how to handle this function call", pToken);
      }
      return callFunction(function, params);
    } catch (final HandlerException e) {
      if (e.getCause() instanceof EvaluationException) {
        throw (EvaluationException) e.getCause();
      }
      throw new EvaluationException("External failure: " + e.getMessage(), e, pToken);
    }
  }

  /**
   * Call the function with the given reference and parameters. This function is
   * separate from
   * {@link #evaluateFunctionCall(FunctionCallToken, SymbolContext)} to be able
   * to have it overriden separately. This function does checking on the
   * parameters of the functions and coerces them to the right type if
   * appropriate.
   * 
   * @param pFunction The function reference to call
   * @param pParams The parameters to
   * @return The result of the function.
   * @throws HandlerException When something goes wrong in the function or the
   *           parameters are wrong.
   */
  public Object callFunction(final FunctionReference pFunction, final Object[] pParams) throws HandlerException {
    Object[] newParams;
    final List<Type> paramTypes = pFunction.getParamTypes();
    if (paramTypes != null) {
      newParams = new Object[pParams.length];
      if ((paramTypes.size() != pParams.length) && (!pFunction.isVarArgs())) {
        throw new HandlerException("Calling a function with an incorrect amount of arguments");
      }

      for (int i = 0; i < newParams.length; i++) {
        final Type type;
        if (i < paramTypes.size()) {
          type = paramTypes.get(i);
        } else {
          type = paramTypes.get(paramTypes.size() - 1);
        }
        newParams[i] = type.convertTo(pParams[i]);
      }
    } else {
      newParams = pParams; /* No conversion as it is variable length old style */
    }
    return pFunction.call(newParams);
  }

  /**
   * @param pSymbolContext
   * @throws HandlerException
   */
  private static FunctionReference getFunctionSymbol(final SymbolContext pSymbolContext, final String pName, final Object[] pParams) throws HandlerException {
    final Type[] types = new Type[pParams.length];
    for (int i = 0; i < types.length; i++) {
      types[i] = Type.typeForClass(pParams[i].getClass());
      if (types[i] == null) {
        throw new HandlerException("The type of parameter " + i + " ( " + pParams[i].getClass().getName() + ") is unknown");
      }
    }

    return pSymbolContext.getFunctionSymbol(pName, types);
  }
}
