/*
 * Created on Jan 22, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.ArrayList;
import java.util.List;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.languages.StatementTokens;
import net.devrieze.parser.tokens.FuncDefToken;
import net.devrieze.parser.tokens.VarDefToken;


/**
 * A class that represents a function reference based on a {@link FuncDefToken}.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @todo param &lt;T&gt; The type of the statements that can be evaluated.
 */
public class EvalFunctionReference implements FunctionReference {

  private final StatementEvaluator aEvaluator;

  private final List<? extends VarDefToken<StatementTokens, ExpressionTokens>> aParams;

  private final List<? extends LinedToken<StatementTokens>> aBody;

  private final SymbolContext aContext;

  /**
   * Create a new function reference based on the token.
   * 
   * @param pEvaluator The evaluator class for statements.
   * @param pToken The function token to evaluate.
   * @param pContext The context in which the function may be evaluated.
   */
  public EvalFunctionReference(final StatementEvaluator pEvaluator, final FuncDefToken<StatementTokens, ExpressionTokens> pToken, final SymbolContext pContext) {
    aEvaluator = pEvaluator;
    aBody = pToken.getBody();
    aParams = pToken.getParams();
    aContext = pContext;
  }

  /**
   * Get the return type for the reference.
   * 
   * @return <code>null</code> as the language has no return types.
   * @see net.devrieze.parser.eval.FunctionReference#getReturnType()
   */
  @Override
  public Type getReturnType() {
    /* Undefined for EvalFunctionReferences */
    return null;
  }

  /** {@inheritDoc} */
  @Override
  public List<Type> getParamTypes() {
    final List<Type> result = new ArrayList<>(aParams.size());
    for (final VarDefToken<StatementTokens, ExpressionTokens> token : aParams) {
      result.add(token.getReferredType());
    }
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public Object call(final Object[] pParams) throws HandlerException {
    final BlockSymbolContext context = new BlockSymbolContext(aContext);
    if (pParams.length > aParams.size()) {
      throw new HandlerException("There are too many parameters to the function");
    }
    for (int i = 0; i < aParams.size(); i++) {
      if (i >= pParams.length) {
        if (aParams.get(i).getValue() != null) {
          context.defVariableSymbol(aParams.get(i).getReferredType(), aParams.get(i).getName(), aParams.get(i).getValue());
        } else {
          throw new HandlerException("Trying to invoke a function with too few parameters, and no defined default for parameter: "
              + aParams.get(i).getName());
        }
      }
      if (pParams[i] == null) {
        throw new HandlerException("Unset variables are not allowed param(" + i + ": " + aParams.get(i).getName() + ")");
      }
      context.defVariableSymbol(aParams.get(i).getReferredType(), aParams.get(i).getName(), pParams[i]);
    }
    try {
      for (final LinedToken<StatementTokens> subStatement : aBody) {
        final Object result = aEvaluator.evaluate(subStatement, context);
        if (result != null) { /*
                               * Handle returns, only the return statement
                               * should initiate a return
                               */
          return result;
        }
      }
    } catch (final EvaluationException e) {
      throw new HandlerException(e);
    }
    return null; /* void function */
  }

  /**
   * Allways <code>false</code>.
   * 
   * @return <code>false</code>.
   */
  @Override
  public boolean isVarArgs() {
    return false;
  }

}
