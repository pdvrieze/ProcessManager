/**
 * 
 */
package net.devrieze.parser.eval;

import java.io.Reader;

import javax.script.*;

import net.devrieze.parser.streams.StatementParser;
import net.devrieze.parser.streams.StringTokenStream;


/**
 * @author paul
 */
public class FScriptEngine extends AbstractScriptEngine implements Compilable {

  /*
   * (non-Javadoc)
   * @see javax.script.Compilable#compile(java.lang.String)
   */
  @Override
  public CompiledScript compile(final String pScript) throws ScriptException {
    // TODO Auto-generated method stub
    return null;
  }

  /*
   * (non-Javadoc)
   * @see javax.script.Compilable#compile(java.io.Reader)
   */
  @Override
  public CompiledScript compile(final Reader pScript) throws ScriptException {
    // TODO Auto-generated method stub
    return null;
  }

  /*
   * (non-Javadoc)
   * @see javax.script.ScriptEngine#createBindings()
   */
  @Override
  public Bindings createBindings() {
    // TODO Auto-generated method stub
    return null;
  }

  /*
   * (non-Javadoc)
   * @see javax.script.ScriptEngine#eval(java.lang.String,
   * javax.script.ScriptContext)
   */
  @Override
  public Object eval(final String pScript, final ScriptContext pContext) throws ScriptException {
    final StatementParser s = new StatementParser(new StringTokenStream(pScript));
    final StatementEvaluator e = new StatementEvaluator();
    Object result = null;
    while (!s.eof()) {
      result = e.evaluate(s.getNextToken(), new ScriptSymbolContext(pContext));
    }
    return result;
  }

  /*
   * (non-Javadoc)
   * @see javax.script.ScriptEngine#eval(java.io.Reader,
   * javax.script.ScriptContext)
   */
  @Override
  public Object eval(final Reader pReader, final ScriptContext pContext) throws ScriptException {
    // TODO Auto-generated method stub
    return null;
  }

  /*
   * (non-Javadoc)
   * @see javax.script.ScriptEngine#getFactory()
   */
  @Override
  public ScriptEngineFactory getFactory() {
    // TODO Auto-generated method stub
    return null;
  }

}
