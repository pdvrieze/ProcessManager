/*
 * Created on Jan 8, 2005
 *
 */

package net.devrieze.parser.eval;

import net.devrieze.lang.Const;
import net.devrieze.parser.ObjectWrapper;


/**
 * An interface reflecting a value type.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class Type {

  public static final Type _VT_VOID = new Type("Void", Void.class);

  /** A valuetype for a {@link Boolean}. */
  public static final Type _VT_BOOLEAN = new Type("Boolean", Boolean.class);

  /** A valuetype for an {@link Integer}. */
  public static final Type _VT_INT = new Type("Integer", Integer.class);

  /** A valuetype for a {@link Double}. */
  public static final Type _VT_DOUBLE = new Type("Double", Double.class);

  /** A valuetype for a {@link Float}. */
  public static final Type _VT_FLOAT = new Type("Float", Float.class);

  /** A valuetype for an {@link Object}. */
  public static final Type _VT_OBJECT = new Type("Object", Object.class);

  /** A valuetype for a {@link String}. */
  public static final Type _VT_STRING = new Type("String", String.class);

  /** A valuetype for a {@link Character}. */
  public static final Type _VT_CHAR = new Type("Character", Character.class);

  private final String aName;

  private final Class<?> aJavaClass;

  /**
   * Create a new type. Only subclasses are allowed to create them. This is kind
   * of an enumeration, but an extendable one.
   * 
   * @param pName The name of the value type.
   * @param pJavaClass The class of the things that this type represents.
   */
  protected Type(final String pName, final Class<?> pJavaClass) {
    aName = pName;
    aJavaClass = pJavaClass;
  }

  /**
   * Get the name of the type.
   * 
   * @return The name of the type.
   */
  public String getName() {
    return aName;
  }

  /**
   * Get the class of the objects represented by this type.
   * 
   * @return The class.
   */
  public Class<?> getJavaClass() {
    return aJavaClass;
  }

  /**
   * Determine whether it is possible to assign to this type from the given
   * type. The implementation is rather tollerant.
   * 
   * @param pType The type to assign from
   * @return <code>true</code> if possible, <code>false</code> if not.
   */
  public boolean isAssignableFrom(final Type pType) {
    if (pType.getJavaClass() == getJavaClass()) {
      return true;
    }
    if (getJavaClass() == Double.class) {
      return pType.getJavaClass() == Integer.class;
    }
    if (getJavaClass() == String.class) {
      return true;
    }
    if (getJavaClass() == Object.class) {
      return true;
    }
    return false;
  }

  /**
   * Convert the given object to the type.
   * 
   * @param pObject The object to convert.
   * @return An object of this type
   * @throws HandlerException When the conversion is not possible
   */
  public Object convertTo(final Object pObject) throws HandlerException {
    if (getJavaClass().isInstance(pObject)) {
      return getJavaClass().cast(pObject);
    }
    if ((getJavaClass() == Double.class) && (pObject instanceof Integer)) {
      return Double.valueOf(((Integer) pObject).doubleValue());
    } else if (getJavaClass() == String.class) {
      if (pObject instanceof ObjectWrapper) {
        return ((ObjectWrapper<?>) pObject).getObject().toString();
      }
      return pObject.toString();
    } else if (getJavaClass() == Integer.class) {
      if (pObject instanceof Long) {
        return Long.valueOf(((Long) pObject).intValue());
      }
    } else if (getJavaClass() == Void.class) {
      return null;
    }
    throw new HandlerException("Conversion to the " + aName + " type is not possible from " + pObject.getClass().getName());
  }

  /**
   * Get the type of an element of a certain class.
   * 
   * @param pClass
   * @return The type that is used for this class
   */
  public static Type typeForClass(final Class<?> pClass) {
    if (pClass == null) {
      return null;
    } else if (Integer.class.isAssignableFrom(pClass) || int.class.isAssignableFrom(pClass) || long.class.isAssignableFrom(pClass)
        || Long.class.isAssignableFrom(pClass)) {
      return Type._VT_INT;
    } else if (Boolean.class.isAssignableFrom(pClass) || boolean.class.isAssignableFrom(pClass)) {
      return Type._VT_BOOLEAN;
    } else if (Double.class.isAssignableFrom(pClass) || double.class.isAssignableFrom(pClass)) {
      return Type._VT_DOUBLE;
    } else if (Float.class.isAssignableFrom(pClass) || float.class.isAssignableFrom(pClass)) {
      return Type._VT_FLOAT;
    } else if (Character.class.isAssignableFrom(pClass) || char.class.isAssignableFrom(pClass)) {
      return Type._VT_CHAR;
    } else if (String.class.isAssignableFrom(pClass)) {
      return Type._VT_STRING;
    } else if (void.class == pClass) {
      return Type._VT_VOID;
    } else {
      return Type._VT_OBJECT;
    }
  }

  /**
   * Get the type with the specified typename.
   * 
   * @param pName The name of the type as expressed in the language.
   * @return The type with the specified language representation.
   */
  public static Type typeForName(final String pName) {
    if ("int".equals(pName)) {
      return Type._VT_INT;
    } else if ("boolean".equals(pName)) {
      return Type._VT_BOOLEAN;
    } else if ("double".equals(pName)) {
      return Type._VT_DOUBLE;
    } else if ("char".equals(pName)) {
      return Type._VT_CHAR;
    } else if ("string".equals(pName)) {
      return Type._VT_STRING;
    } else if ("object".equals(pName)) {
      return Type._VT_OBJECT;
    } else {
      return new Type(pName, null);
    }
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    return "<Type: " + aName + ">";
  }

  /** {@inheritDoc} */
  @Override
  public boolean equals(final Object pObject) {
    if (this == pObject) {
      return true;
    }
    if (pObject == null) {
      return false;
    }
    if (pObject instanceof Type) {
      if (pObject.getClass() != Type.class) {
        return pObject.equals(this);
      }
      final Type t2 = (Type) pObject;
      return aName.equals(t2.getName()) && aJavaClass.equals(t2.aJavaClass);
    }
    return false;
  }

  @Override
  public int hashCode() {
    return (aName.hashCode() * Const._HASHPRIME) + aJavaClass.hashCode();
  }

  public static Type[] typesForClassses(final Class<?>... pParams) {
    final Type[] result = new Type[pParams.length];
    for (int i = 0; i < pParams.length; i++) {
      result[i] = typeForClass(pParams[i]);
    }
    return result;
  }
}
