/*
 * Created on Dec 11, 2005
 *
 */
package net.devrieze.parser.eval;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.tokens.BinaryExprToken;
import net.devrieze.parser.tokens.UnaryExprToken;


/**
 * The default operator evaluator.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class DefaultOperatorEvaluator extends AbstractOperatorEvaluator<ExpressionTokens, BinaryOperatorTokens> {

  @Override
  public Object evaluateBinary(final AbstractExpressionEvaluator<ExpressionTokens, BinaryOperatorTokens> pExpressionEvaluator, final BinaryExprToken<ExpressionTokens, BinaryOperatorTokens, LinedToken<ExpressionTokens>> pExpression, final SymbolContext pSymbolContext) throws EvaluationException {
    switch (pExpression.getOperatorType()) {
      case PLUS: {
        return evaluatePlus(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case MINUS: {
        return evaluateMinus(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case TIMES: {
        return evaluateTimes(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case DIV: {
        return evaluateDiv(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case MOD: {
        return evaluateMod(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case POWER: {
        return evaluatePower(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case EQUALS: {
        return evaluateEquals(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case UNEQUALS: {
        return evaluateUnequals(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case LESS: {
        return evaluateLess(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case LESSEQ: {
        return evaluateLessEquals(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case GREATER: {
        return evaluateGreater(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case GREATEREQ: {
        return evaluateGreaterEquals(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case LOGIC_AND: {
        return evaluateLogicAnd(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case LOGIC_OR: {
        return evaluateLogicOr(pExpressionEvaluator, pExpression, pSymbolContext);
      }
      case MEMBERACCESS:
    }
    throw new EvaluationException("Don't know how to handle this binary token " + pExpression.getTokenType().toString(), pExpression);
  }

  @Override
  public Object evaluateUnary(final AbstractExpressionEvaluator<ExpressionTokens, BinaryOperatorTokens> pExpressionEvaluator, final UnaryExprToken<ExpressionTokens> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    switch (pToken.getTokenType()) {
      case NOT:
        return evaluateNot(pExpressionEvaluator, pToken, pSymbolContext);
      case PAREN:
        return evaluateParen(pExpressionEvaluator, pToken, pSymbolContext);
      case ARRAYACCESS:
      case BINARYOPERATOR:
      case FUNCCALL:
      case LITERAL:
      case OBJECTACCESS:
      case SYMBOL:
        throw new EvaluationException("This token is not an unary expression token", pToken);
    }
    throw new EvaluationException("An unsupported token in the evaluation of unary expression tokens.", pToken);
  }

}
