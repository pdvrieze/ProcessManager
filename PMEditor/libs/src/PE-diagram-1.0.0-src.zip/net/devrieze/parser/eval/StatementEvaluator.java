/*
 * Created on Jan 9, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.List;

import net.devrieze.parser.LinedToken;
import net.devrieze.parser.ObjectWrapper;
import net.devrieze.parser.Token;
import net.devrieze.parser.UnexpectedTokenException;
import net.devrieze.parser.languages.BinaryOperatorTokens;
import net.devrieze.parser.languages.ExpressionTokens;
import net.devrieze.parser.languages.StatementTokens;
import net.devrieze.parser.streams.ExpressionParser.AccessorToken;
import net.devrieze.parser.tokens.*;


/**
 * A class for evaluating statements.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class StatementEvaluator implements Evaluator<StatementTokens> {


  private static class ReturnWrapper {

    private final Object aValue;

    ReturnWrapper(final Object pValue) {
      aValue = pValue;
    }

    Object getValue() {
      return aValue;
    }
  }

  private final AbstractExpressionEvaluator<ExpressionTokens, BinaryOperatorTokens> aExpressionEvaluator;

  /**
   * Create a new StatementEvaluator that uses a default
   * {@link AbstractExpressionEvaluator}.
   */
  public StatementEvaluator() {
    aExpressionEvaluator = new FScriptExpressionEvaluator();
  }

  /**
   * Create a new StatementEvaluator.
   * 
   * @param pExpressionEvaluator The ExpressionEvaluator to use.
   */
  public StatementEvaluator(final AbstractExpressionEvaluator<ExpressionTokens, BinaryOperatorTokens> pExpressionEvaluator) {
    aExpressionEvaluator = pExpressionEvaluator;
  }

  public Object evaluate(final Iterable<? extends Token<StatementTokens>> pTokens, final SymbolContext pContext) throws EvaluationException, UnexpectedTokenException {
    Object result = null;
    final BlockSymbolContext context = new BlockSymbolContext(pContext);
    try {
      for (final Token<StatementTokens> token : pTokens) {
        result = evaluate3((StatementToken<StatementTokens>) token, context);
        if (result instanceof ReturnWrapper) {
          return ((ReturnWrapper) result).getValue();
        }
      }
    } catch (final RuntimeException e) {
      if ((e.getCause() != null) && (e.getCause() instanceof UnexpectedTokenException)) {
        throw ((UnexpectedTokenException) e.getCause());
      }
    }
    return result;
  }

  @Override
  public Object evaluate(final Token<StatementTokens> pToken, final SymbolContext pContext) throws EvaluationException {
    final Object result = evaluate2((LinedToken<StatementTokens>) pToken, pContext);
    return (result instanceof ReturnWrapper) ? ((ReturnWrapper) result).getValue() : result;
  }

  /**
   * Evaluate the given statement token.
   * 
   * @param pToken The statement token to evaluate.
   * @param pSymbolContext The context to evaluate the token in. This will be
   *          wrapped in a {@link BlockSymbolContext}.
   * @return The result of the token. If there is no <code>return</code>
   *         statement this is <code>null</code>. If <code>null</code> is
   *         returned by the script itself, then {@link ObjectWrapper#_NULL} is
   *         returned.
   * @throws EvaluationException
   */
  private Object evaluate2(final LinedToken<StatementTokens> pToken, final SymbolContext pSymbolContext) throws EvaluationException {
    try {
      return evaluate3(pToken, new BlockSymbolContext(pSymbolContext));
    } catch (final Exception e) {
      if (e instanceof EvaluationException) {
        throw (EvaluationException) e;
      }
      throw new EvaluationException(e, pToken);
    }
  }

  /**
   * Evaluate the given statement token.
   * 
   * @param pStatement The statement token to evaluate.
   * @param pSymbolContext The context to evaluate the token in.
   * @return The result of the token. If there is no <code>return</code>
   *         statement this is <code>null</code>. If <code>null</code> is
   *         returned by the script itself, then {@link ObjectWrapper#_NULL} is
   *         returned.
   * @throws EvaluationException
   */
  @SuppressWarnings("unchecked")
  private Object evaluate3(final LinedToken<StatementTokens> pStatement, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    if (Thread.interrupted()) {
      throw new EvaluationException("Thread Interrupted", pStatement);
    }
    switch (pStatement.getTokenType()) {
      case BLOCK: {
        return evaluateBlock((BlockToken<StatementTokens>) pStatement, pSymbolContext);
      }
      case RETURN: {
        return evaluateReturn((ReturnToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case IF: {
        return evaluateIf((IfToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case FOR: {
        return evaluateFor((ForToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case WHILE: {
        return evaluateWhile((WhileToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case VARDEF: {
        return evaluateVarDef((VarDefToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case FUNCDEF: {
        return evaluateFuncDef((FuncDefToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case ASSIGN: {
        return evaluateAssign((AssignmentToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case FUNCCALL: {
        return evaluateFuncCall((VoidStatementToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
      case EXPR: {
        return evaluateExpr((ExprStatementToken<StatementTokens, ExpressionTokens>) pStatement, pSymbolContext);
      }
    }
    throw new EvaluationException("Unknown statement found: " + pStatement.getTokenType().name(), pStatement);
  }

  protected Object evaluateFuncCall(final VoidStatementToken<StatementTokens, ExpressionTokens> pToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    Object result = aExpressionEvaluator.evaluate(pToken.getFuncCall(), pSymbolContext);
    if (result instanceof ReturnWrapper) {
      result = ((ReturnWrapper) result).getValue();
    }
    return result;
  }

  protected Object evaluateAssign(final AssignmentToken<StatementTokens, ExpressionTokens> pToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    final LinedToken<ExpressionTokens> variable = pToken.getVariable();
    final Object value = aExpressionEvaluator.evaluate(pToken.getValue(), pSymbolContext);
    if (variable.getTokenType() == ExpressionTokens.ARRAYACCESS) {
      evaluateArrayWrite((AccessorToken<ExpressionTokens>) variable, value, pSymbolContext);
      return value;
    }
    try {
      if (variable.getTokenType() == ExpressionTokens.OBJECTACCESS) {
        final ObjectWrapper<?> obj = (ObjectWrapper<?>) aExpressionEvaluator.evaluate(((AccessorToken<ExpressionTokens>) variable).getTarget(), pSymbolContext);
        try {
          obj.getContext().setVariableSymbol(((SymbolToken<ExpressionTokens>) ((AccessorToken<ExpressionTokens>) variable).getQualifier()).getSymbol().toString(), value);
        } catch (final Exception e) {
          throw new EvaluationException(e, pToken);
        }
        return value;
      } else if (variable.getTokenType() == ExpressionTokens.SYMBOL) {
        pSymbolContext.setVariableSymbol(((SymbolToken<ExpressionTokens>) variable).getSymbol().toString(), value);
        return value;
      } else {

        throw new EvaluationException("Unknown assignment", pToken);
      }
    } catch (final HandlerException e) {
      throw new EvaluationException("External Exception " + e.getMessage(), e, pToken);
    }
  }

  protected Object evaluateFuncDef(final FuncDefToken<StatementTokens, ExpressionTokens> pToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    try {
      pSymbolContext.defFunctionSymbol(pToken.getName(), new EvalFunctionReference(this, pToken, pSymbolContext));
    } catch (final HandlerException e) {
      throw new EvaluationException("External failure: " + e.getMessage(), e, pToken);
    }
    return null; //No function objects yet
  }

  protected Object evaluateVarDef(final VarDefToken<StatementTokens, ExpressionTokens> pToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    Object value;
    if (pToken.getValue() != null) {
      value = aExpressionEvaluator.evaluate(pToken.getValue(), pSymbolContext);
    } else {
      value = null;
    }
    try {
      pSymbolContext.defVariableSymbol(pToken.getReferredType(), pToken.getName(), value);
    } catch (final HandlerException e) {
      throw new EvaluationException("External failure: " + e.getMessage(), e, pToken);
    }
    return value;
  }

  protected Object evaluateWhile(final WhileToken<StatementTokens, ExpressionTokens> pWhileToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    Object condition = aExpressionEvaluator.evaluate(pWhileToken.getCondition(), pSymbolContext);
    if (!(condition instanceof Boolean)) {
      throw new EvaluationException("The condition is not of type boolean, but: " + condition.getClass().getName(), pWhileToken.getCondition());
    }
    Object result = null;
    while (((Boolean) condition).booleanValue()) {
      final BlockSymbolContext blockContext = new BlockSymbolContext(pSymbolContext);
      for (final LinedToken<StatementTokens> subStatement : pWhileToken.getAction()) {
        result = evaluate3(subStatement, blockContext);
        if (result instanceof ReturnWrapper) {
          return result;
        }
      }
      condition = aExpressionEvaluator.evaluate(pWhileToken.getCondition(), pSymbolContext);
      if (!(condition instanceof Boolean)) {
        throw new EvaluationException("The condition is not of type boolean, but: " + condition.getClass().getName(), pWhileToken.getCondition());
      }
    }
    return result;
  }

  protected Object evaluateFor(final ForToken<StatementTokens, ExpressionTokens> pForToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    final BlockSymbolContext forContext = new BlockSymbolContext(pSymbolContext);
    evaluate3(pForToken.getInitialisation(), forContext);
    Boolean b = (Boolean) aExpressionEvaluator.evaluate(pForToken.getCondition(), forContext);
    Object result = null;
    while (b.booleanValue()) {
      result = evaluate3(pForToken.getAction(), forContext);
      if (result instanceof ReturnWrapper) {
        return result;
      }
      evaluate3(pForToken.getContinuation(), forContext);
      b = (Boolean) aExpressionEvaluator.evaluate(pForToken.getCondition(), forContext);
    }
    return result;
  }

  protected Object evaluateIf(final IfToken<StatementTokens, ExpressionTokens> pIfToken, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    List<? extends LinedToken<StatementTokens>> block;
    Object result = null;
    final Object condition = aExpressionEvaluator.evaluate(pIfToken.getCondition(), pSymbolContext);
    if (!(condition instanceof Boolean)) {
      throw new EvaluationException("The condition is not of type boolean, but: " + condition.getClass().getName(), pIfToken.getCondition());
    }
    if (((Boolean) condition).booleanValue()) {
      block = pIfToken.getThen();
    } else {
      block = pIfToken.getElse();
    }
    final BlockSymbolContext blockContext = new BlockSymbolContext(pSymbolContext);
    for (final LinedToken<StatementTokens> subStatement : block) {
      result = evaluate3(subStatement, blockContext);
      if (result instanceof ReturnWrapper) {
        return result;
      }
    }
    return result;
  }

  protected Object evaluateBlock(final BlockToken<StatementTokens> pStatement, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    final BlockSymbolContext blockContext = new BlockSymbolContext(pSymbolContext);
    Object result = null;
    for (final LinedToken<StatementTokens> subStatement : pStatement.getSubStatements()) {
      result = evaluate3(subStatement, blockContext);
      if (result instanceof ReturnWrapper) {
        return result;
      }
    }
    return result;
  }

  protected Object evaluateReturn(final ReturnToken<StatementTokens, ExpressionTokens> pStatement, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    return new ReturnWrapper(aExpressionEvaluator.evaluate(pStatement.getExpression(), pSymbolContext));
  }

  protected Object evaluateExpr(final ExprStatementToken<StatementTokens, ExpressionTokens> pStatement, final BlockSymbolContext pSymbolContext) throws EvaluationException {
    return aExpressionEvaluator.evaluate(pStatement.getExpression(), pSymbolContext);
  }

  /**
   * A basic handler for array writes. It basically forwards stuff to the
   * associated {@link AbstractExpressionEvaluator}.
   * 
   * @param pArray The array access token.
   * @param pValue The new value.
   * @param pSymbolContext The symbol evaluation context.
   * @throws EvaluationException When something is wrong, like the object not
   *           being an array.
   */
  protected void evaluateArrayWrite(final AccessorToken<ExpressionTokens> pArray, final Object pValue, final SymbolContext pSymbolContext) throws EvaluationException {
    assert pArray.getTokenType() == ExpressionTokens.ARRAYACCESS;

    final Object array = ObjectWrapper.unWrap(aExpressionEvaluator.evaluate(pArray.getTarget(), pSymbolContext));
    final Object index = ObjectWrapper.unWrap(aExpressionEvaluator.evaluate(pArray.getQualifier(), pSymbolContext));

    try {
      if (aExpressionEvaluator.handleArrayWrite(array, index, pValue)) {
        return;
      }
    } catch (final HandlerException e) {
      throw new EvaluationException("External failure: " + e.getMessage(), e, pArray);
    }

    if (array instanceof String) {
      throw new EvaluationException("String characters can not be set", pArray);
    }
    throw new EvaluationException("The symbol is not an array", pArray);
  }

}
