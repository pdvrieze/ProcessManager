/*
 * Created on Oct 24, 2005
 *
 */
package net.devrieze.parser.eval.types;

import java.util.ArrayList;
import java.util.Arrays;

import net.devrieze.annotation.ScriptSupport;
import net.devrieze.annotation.Scriptable;
import net.devrieze.parser.ObjectWrapper;
import net.devrieze.parser.eval.Contexed;
import net.devrieze.parser.eval.IndexedAccess;
import net.devrieze.parser.eval.ReflectionObjectWrapper;
import net.devrieze.parser.eval.SymbolContext;


/**
 * A class for array types.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@ScriptSupport
public class Array implements IndexedAccess, Contexed {

  private final ArrayList<Object> aObjects;

  /**
   * @param pElems
   */
  public Array(final Object... pElems) {
    aObjects = new ArrayList<>(Arrays.asList(pElems));
  }

  @Scriptable
  public static ReflectionObjectWrapper<Array> array(final Object... pElems) {
    return new ReflectionObjectWrapper<>(new Array(pElems));
  }

  @Override
  public Object getWrapped(final int pIndex) {
    return ObjectWrapper.wrap(get(pIndex));
  }

  @Scriptable
  public Object get(final int pIndex) {
    return aObjects.get(pIndex);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Scriptable
  public boolean set(final int pIndex, final Object pValue) {
    if ((pIndex < 0) || (pIndex > aObjects.size())) {
      return false;
    }
    if (pIndex == aObjects.size()) {
      aObjects.add(pValue);
    } else {
      aObjects.set(pIndex, pValue);
    }
    return true;
  }

  @Scriptable
  public void add(final Object pValue) {
    aObjects.add(pValue);
  }

  @Scriptable
  public void clear() {
    aObjects.clear();
  }

  @Scriptable
  public int size() {
    return aObjects.size();
  }

  @Scriptable
  public Object remove(final int pIndex) {
    return aObjects.remove(pIndex);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public SymbolContext getContext() {
    return new ReflectionObjectWrapper<>(this);
  }

  @Override
  public String toString() {
    return aObjects.toString();
  }
}
