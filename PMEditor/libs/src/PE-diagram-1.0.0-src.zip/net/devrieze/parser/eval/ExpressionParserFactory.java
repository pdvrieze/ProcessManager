/*
 * Created on Jan 7, 2005
 *
 */

package net.devrieze.parser.eval;

import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.streams.ExpressionParser;
import net.devrieze.parser.tokens.CharToken;


/**
 * A interface for a factory that creates expression parser objects.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface ExpressionParserFactory {

  /**
   * Create a new {@link ExpressionParser} for the given stream.
   * 
   * @param pStream The stream that will be parsed.
   * @return A parser for this stream.
   */
  ExpressionParser getExpressionParser(BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream);
}
