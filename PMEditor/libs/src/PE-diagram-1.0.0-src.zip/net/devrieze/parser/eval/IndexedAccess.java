/*
 * Created on Oct 24, 2005
 *
 */
package net.devrieze.parser.eval;


/**
 * Interface that allows indexed access to itself. It allows evaluation of array
 * types.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface IndexedAccess {

  /**
   * Get the value at the given index.
   * 
   * @param pIndex The index of the value.
   * @return The value at the given index.
   */
  Object getWrapped(int pIndex);

  /**
   * Set the value at the given index.
   * 
   * @param pIndex The index
   * @param pValue The value to put at the index.
   * @return The type of the value.
   */
  boolean set(int pIndex, Object pValue);

}
