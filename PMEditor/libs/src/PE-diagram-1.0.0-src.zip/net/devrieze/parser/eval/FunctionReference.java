/*
 * Created on Jan 8, 2005
 *
 */

package net.devrieze.parser.eval;

import java.util.List;


/**
 * An interface specifying a function reference.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface FunctionReference {

  /**
   * Get the return type of the function. For a void function this is
   * <code>null</code>. For unknown types the type is <code>Object</code>
   * 
   * @return The return type of the function.
   */
  Type getReturnType();

  /**
   * Get the parameter types for this function. If the function has a variable
   * amount of parameters, return <code>null</code>.
   * 
   * @return The parameter types or <code>null</code>
   */
  List<Type> getParamTypes();

  /**
   * Call the function.
   * 
   * @param pParams The parameters to the function.
   * @return The result of the function.
   * @throws HandlerException When the evaluation fails.
   */
  Object call(Object[] pParams) throws HandlerException;

  /**
   * Determine whether the function accepts a variable amount of parameters.
   * 
   * @return <code>true</code> if it does.
   */
  boolean isVarArgs();
}
