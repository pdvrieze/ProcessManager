/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser.eval;

import net.devrieze.parser.Token;
import net.devrieze.parser.TokenException;


/**
 * Thrown when the evaluation fails.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class EvaluationException extends TokenException {

  private static final long serialVersionUID = 3257288041188962873L;

  /**
   * Create a new evaluation exception.
   * 
   * @param pMessage The message for the exception.
   * @param pCause The cause of the exception.
   * @param pToken The most specific token on whose evaluation the exception
   *          occurred.
   */
  public EvaluationException(final String pMessage, final Throwable pCause, final Token<?> pToken) {
    super(pToken, pCause, pMessage);
    if (pCause instanceof HandlerException) {
      if ((pCause.getCause() != null) && (pCause.getCause() instanceof EvaluationException)) {
        throw new RuntimeException("Exception Stacking disallowed");
      }
    }
  }

  /**
   * Create a new evaluation exception.
   * 
   * @param pCause The cause of the exception.
   * @param pToken The most specific token on whose evaluation the exception
   *          occurred.
   */
  public EvaluationException(final Throwable pCause, final Token<?> pToken) {
    super(pToken, pCause);
    if (pCause instanceof HandlerException) {
      if ((pCause.getCause() != null) && (pCause.getCause() instanceof EvaluationException)) {
        throw new RuntimeException("Exception Stacking disallowed");
      }
    }
  }

  /**
   * Create a new evaluation exception.
   * 
   * @param pMessage The message for the exception.
   * @param pToken The most specific token on whose evaluation the exception
   *          occurred.
   */
  public EvaluationException(final String pMessage, final Token<?> pToken) {
    super(pToken, pMessage);
  }
}
