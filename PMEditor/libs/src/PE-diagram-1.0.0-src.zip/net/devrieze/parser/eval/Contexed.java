/*
 * Created on Oct 24, 2005
 *
 */
package net.devrieze.parser.eval;


/**
 * Interface for objects that have a symbolContext.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface Contexed {

  /**
   * Get the symbol context for the class.
   * 
   * @return The symbol context.
   */
  SymbolContext getContext();

}
