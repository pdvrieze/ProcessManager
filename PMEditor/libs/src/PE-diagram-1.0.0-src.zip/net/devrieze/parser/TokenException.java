/*
 * Created on Jan 5, 2005
 *
 */

package net.devrieze.parser;

import javax.script.ScriptException;


/**
 * The base class for all exceptions that contain token references.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class TokenException extends ScriptException {

  private static final long serialVersionUID = 3256445785334755639L;

  private final Token<?> aToken;

  private String aTokenContext = null;

  /**
   * Create a new Exception.
   * 
   * @param pToken The token the exception is based on.
   * @deprecated
   */
  @Deprecated
  public TokenException(final Token<?> pToken) {
    this(pToken, null, "");
  }

  /**
   * Create a new Exception.
   * 
   * @param pToken The token the exception is based on.
   * @param pMessage The message for the exception.
   */
  public TokenException(final Token<?> pToken, final String pMessage) {
    this(pToken, null, pMessage);
  }

  /**
   * Create a new Exception.
   * 
   * @param pToken The token the exception is based on.
   * @param pCause The cause of the exception.
   */
  public TokenException(final Token<?> pToken, final Throwable pCause) {
    this(pToken, pCause, pCause != null ? pCause.getMessage() : null);
  }

  /**
   * Create a new Exception.
   * 
   * @param pToken The token the exception is based on.
   * @param pCause The cause of the exception.
   * @param pMessage The message for the exception.
   */
  public TokenException(final Token<?> pToken, final Throwable pCause, final String pMessage) {
    super(pMessage == null ? (pCause != null ? pCause.getMessage() : "<null>") : pMessage, getFileString(pToken), ((pToken != null)
        && (pToken.getPos() != null) && (pToken instanceof LinedToken)) ? ((LinedToken<?>) pToken).getPos().getLineNo() : -1, ((pToken != null)
        && (pToken.getPos() != null) && (pToken instanceof LinedToken)) ? ((LinedToken<?>) pToken).getPos().getLinePos()
        : (((pToken == null) || (pToken.getPos() == null)) ? -1 : pToken.getPos().getOffset()));
    aToken = pToken;
    if (pCause != null) {
      initCause(pCause);
    }
  }

  private static String getFileString(final Token<?> pToken) {
    if ((pToken == null) || (pToken.getPos() == null) || (pToken.getPos().getFile() == null)) {
      return "<unknown>";
    }
    return pToken.getPos().getFile().toString();
  }

  /**
   * Get the token that caused the exception.
   * 
   * @return The token that caused the exception.
   */
  public final Token<?> getToken() {
    return aToken;
  }

  /**
   * Set the context for the token. This is appended to the message. Normally
   * this would be some kind of indication where the token is in the stream.
   * 
   * @param pTokenContext
   */
  public void setTokenContext(final String pTokenContext) {
    aTokenContext = pTokenContext;
  }

  /**
   * Get the message for this exception.
   * 
   * @return The normal message, appended with a description of the token or the
   *         token context if was set.
   * @see java.lang.Throwable#getMessage()
   */
  @Override
  public String getMessage() {
    final String message = super.getMessage();
    final StringBuilder result = new StringBuilder();
    if (message != null) {
      result.append(message);
    }
    result.append('\n');
    if (aTokenContext != null) {
      result.append(aTokenContext);
    } else if (getToken() == null) {
      result.append("-- NULL token --");
    } else {
      result.append(getToken().toString());
    }
    return result.toString();
  }
}
