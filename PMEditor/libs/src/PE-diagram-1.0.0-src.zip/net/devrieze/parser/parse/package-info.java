/**
 * Package that should contain parse scripts.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
package net.devrieze.parser.parse;

