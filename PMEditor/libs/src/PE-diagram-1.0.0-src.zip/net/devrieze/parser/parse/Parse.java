/*
 * Created on Feb 6, 2005
 *
 */
package net.devrieze.parser.parse;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.devrieze.lang.Const;
import net.devrieze.parser.BufferedTokenStream;
import net.devrieze.parser.TokenException;
import net.devrieze.parser.UnexpectedTokenException;
import net.devrieze.parser.languages.CharStreamEnum;
import net.devrieze.parser.streams.FileTokenStream;
import net.devrieze.parser.tokens.CharToken;
import net.devrieze.util.StringUtil;


/**
 * A parser class for parse files.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class Parse {

  private static class Element {

    private final Name aName;

    /**
     * Create a new element.
     * 
     * @param pName The name of the element.
     */
    public Element(final Name pName) {
      aName = pName;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
      return "<Element " + aName + ">";
    }
  }

  private static class Name {

    private final String aValue;

    /**
     * Create a new name.
     * 
     * @param pValue The name.
     */
    public Name(final String pValue) {
      aValue = pValue;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
      return aValue;
    }
  }

  private final List<Element> aValue;

  /**
   * @param pValue
   */
  private Parse(final List<Element> pValue) {
    aValue = pValue;
  }

  /**
   * Get the value.
   * 
   * @return The value
   */
  public List<Element> getValue() {
    return aValue;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    final StringBuilder b = new StringBuilder();
    b.append("<Parse>\n");
    for (final Element element : aValue) {
      b.append(StringUtil.indent(2, element.toString())).append("\n");
    }
    return b.toString();
  }

  /**
   * Create a parser based on the given parser description.
   * 
   * @param pStream The stream to parse.
   * @return The resulting parser.
   * @throws TokenException When an unexpected token is found.
   */
  public static Parse parse(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    final List<Element> value = parseElements(pStream);
    parseWhiteSpace(pStream);
    if (!pStream.eof()) {
      final CharToken t = pStream.peek().getNextToken();
      throw new UnexpectedTokenException("Expected end of file, but found: \"" + t.getChar() + "\"", pStream.getNextToken());
    }

    return new Parse(value);
  }

  private static List<Element> parseElements(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    final List<Element> result = new ArrayList<>();
    parseWhiteSpace(pStream);
    Element element = parseElement(pStream);
    parseWhiteSpace(pStream);
    result.add(element);
    while (peekElement(pStream)) {
      parseWhiteSpace(pStream);
      element = parseElement(pStream);
      parseWhiteSpace(pStream);
      result.add(element);
    }

    return result;
  }

  private static Element parseElement(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    final Name name = parseName(pStream);
    char c;
    do {
      c = pStream.getNextToken().getChar();
    } while (c != ';');
    return new Element(name);
  }

  /**
   * @param pStream
   * @return The resulting name
   * @throws TokenException
   */
  private static Name parseName(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    final StringBuilder b = new StringBuilder();
    final CharToken ct = pStream.getNextToken();
    char c = ct.getChar();
    if (!(((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || (c == '_'))) {
      throw new UnexpectedTokenException("Expected a name start character, not " + c, ct);
    }
    b.append(c);
    c = pStream.peek().getNextToken().getChar();
    while (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || (c == '_') || ((c >= '0') && (c <= '9'))) {
      pStream.getNextToken();
      b.append(c);
      c = pStream.peek().getNextToken().getChar();
    }
    return new Name(b.toString());
  }

  private static boolean peekElement(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    return peekName(pStream);
  }

  private static boolean peekName(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    final char c = pStream.peek().getNextToken().getChar();
    if (!(((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || (c == '_'))) {
      return false;
    }
    return true;
  }

  private static void parseWhiteSpace(final BufferedTokenStream<? extends CharToken, CharStreamEnum> pStream) throws TokenException {
    char peek = pStream.peek().getNextToken().getChar();
    while ((peek == Const._CR) || (peek == Const._LF) || (peek == ' ') || (peek == '\t')) {
      pStream.getNextToken();
      if (pStream.eof()) {
        break;
      }
      peek = pStream.peek().getNextToken().getChar();
    }
  }

  /**
   * Create a parser based on the given parse program.
   * 
   * @param pArgs The arguments to the program.
   */
  public static void main(final String[] pArgs) {
    if (pArgs.length != 1) {
      System.err.println("Invoke with:\nParse <FileName>");
      System.exit(1);
    }
    try (FileTokenStream st = new FileTokenStream(new File(pArgs[0]))) {
      try {
        System.out.println(parse(st).toString());
      } catch (final TokenException e) {
        st.addContext(e);
        e.printStackTrace();
        System.exit(1);
      }
    } catch (final Exception e) {
      e.printStackTrace();
      System.exit(1);
    }
  }

}
