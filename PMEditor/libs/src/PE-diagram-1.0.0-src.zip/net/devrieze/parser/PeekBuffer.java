/*
 * Created on Dec 18, 2005
 *
 */
package net.devrieze.parser;

import net.devrieze.parser.languages.Language;


/**
 * A buffer for peeking support in buffered tokenstreams.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <T> The kinds of tokens that this stream returns
 * @param <U> The enumeration of all tokentypes that could be returned.
 */
public interface PeekBuffer<T extends Token<U>, U extends Enum<U> & Language<U>> extends BufferedTokenStream<T, U> {

  /**
   * Indicate that the buffer is no longer needed. Reset the buffer.
   */
  void reset();

  /**
   * When the buffer is no longer valid, this is <code>false</code>.
   * 
   * @return <code>false</code> when the buffer is no longer valid.
   */
  boolean isValid();

  /**
   * Indicate that the peeked tokens are to be taken from the parent stream.
   */
  void take();

}
