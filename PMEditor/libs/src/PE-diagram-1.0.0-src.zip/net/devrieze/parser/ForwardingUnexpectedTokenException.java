/*
 * Created on Jan 7, 2005
 *
 */

package net.devrieze.parser;

/**
 * Thrown by the {@link ForwardingTokenStream} when getting a token will not
 * succeed. This is a separate class to allow overriding methods to throw a
 * better described exception.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ForwardingUnexpectedTokenException extends UnexpectedTokenException {

  private static final long serialVersionUID = 3978707277023098165L;

  /**
   * Create a new exception.
   * 
   * @param pToken The unexpected token
   * @deprecated
   */
  @Deprecated
  public ForwardingUnexpectedTokenException(final Token<?> pToken) {
    super(pToken);
  }

  /**
   * Create a new exception.
   * 
   * @param pMessage The message for the exception
   * @param pToken The unexpected token
   */
  public ForwardingUnexpectedTokenException(final String pMessage, final Token<?> pToken) {
    super(pMessage, pToken);
  }
}
