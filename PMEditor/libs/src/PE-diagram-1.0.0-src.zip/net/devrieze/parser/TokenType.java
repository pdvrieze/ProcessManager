/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import net.devrieze.util.StringUtil;


/**
 * A class representing the type of a token.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class TokenType {

  private final TokenTypeFactory aTypeFactory;

  private final String aName;

  /**
   * @param pTypeFactory
   * @param pName
   */
  public TokenType(final TokenTypeFactory pTypeFactory, final String pName) {
    aTypeFactory = pTypeFactory;
    aName = pName;
  }

  /**
   * Get a factory object for this type.
   * 
   * @return a factory object for this type.
   */
  public TokenTypeFactory getTypeFactory() {
    return aTypeFactory;
  }

  /**
   * The name of the token.
   * 
   * @return The name of the token.
   */
  public String getName() {
    return aName;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    return "<" + StringUtil.simpleClassName(getClass()) + " " + getName() + ">";
  }
}
