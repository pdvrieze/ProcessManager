/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import net.devrieze.parser.languages.Language;


/**
 * A token that knows linenumbers.
 * 
 * @param <T> The enumeration of all tokentypes that could be returned.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public interface LinedToken<T extends Enum<T> & Language<T>> extends Token<T> {

  /**
   * Get the position of the token in the line.
   * 
   * @return the position
   */
  @Override
  LinePosition getPos();

}
