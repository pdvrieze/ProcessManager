/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import net.devrieze.parser.languages.Language;


/**
 * Represents a base class for buffered {@link TokenStream TokenStreams}. It
 * should only be overridden, but not used directly.
 *
 * @param <T> The type of the tokens produced by this stream
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 * @param <U> The type of the tokens returned
 */
public abstract class AbstractBufferedTokenStream<T extends Token<U>, U extends Enum<U> & Language<U>> extends AbstractTokenStream<T, U> implements BufferedTokenStream<T, U> {


  private static class BufferElem<T> {

    public final int aStartPos;

    public final int aEndPos;

    public final T aToken;

    public BufferElem(final int pStartPos, final int pEndPos, final T pToken) {
      aStartPos = pStartPos;
      aEndPos = pEndPos;
      aToken = pToken;
    }

  }

  private class BufferedPeekBuffer implements PeekBuffer<T, U> {

    private int aLastPos;

    private int aBufferPos;

    private BufferedPeekBuffer aParent;

    BufferedPeekBuffer(final int pPos) {
      aLastPos = pPos;
      aBufferPos = 0;
      aParent = null;
    }

    BufferedPeekBuffer(final int pPos, final int pBufferPos, final BufferedPeekBuffer pParent) {
      aLastPos = pPos;
      aBufferPos = pBufferPos;
      aParent = pParent;
    }

    @Override
    public void reset() {
      aLastPos = AbstractBufferedTokenStream.this.getPos();
      aBufferPos = 0;
      aParent = null;
    }

    @Override
    public boolean isValid() {
      final int sp = getSourcePos();

      if (aBuffer.size() == 0) {
        // The buffer is empty
        aBufferPos = 0;
        if (aLastPos < sp) {
          aLastPos = sp;
          return true;
        }
        return aLastPos == sp;
      }
      if (aBuffer.getLast().aEndPos < sp) {
        // The parent stream is past the buffer
        aBuffer.clear();
        aLastPos = sp;
        aBufferPos = 0;
        return true;
      }
      if (aBufferPos > aBuffer.size()) {
        aBufferPos = aBuffer.size();
      }
      if (aBufferPos == aBuffer.size()) {
        if (aLastPos == getSourcePos()) {
          return true;
        }
        aBufferPos--;
      }
      while ((aBufferPos > 0) && (aLastPos > aBuffer.get(aBufferPos).aStartPos)) {
        aBufferPos--;
      }
      if (aBufferPos < 0) {
        return aLastPos == getSourcePos();
      }
      final int bufferStart = aBuffer.get(0).aStartPos;
      if ((aBufferPos == 0) && (aLastPos < bufferStart)) {
        aLastPos = bufferStart;
      }
      return (aBufferPos >= 0) && (aLastPos == aBuffer.get(aBufferPos).aStartPos);
    }

    @Override
    public void take() {
      validate();
      if (aParent != null) {
        aParent.aBufferPos = aBufferPos;
        aParent.aLastPos = aLastPos;
      } else {
        while (aBufferPos > 0) {
          aBufferPos--;
          aBuffer.removeFirst();
        }
      }
    }

    @Override
    public PeekBuffer<T, U> peek() {
      return new BufferedPeekBuffer(getPos(), aBufferPos, this);
    }

    @Override
    public T getNextToken() throws TokenException {
      validate();
      if (aBuffer.size() > (aBufferPos + 1)) {
        aLastPos = aBuffer.get(aBufferPos + 1).aStartPos;
      } else if (aBuffer.size() == (aBufferPos + 1)) {
        aLastPos = getSourcePos();
      } else {
        while (aBuffer.size() <= aBufferPos) {
          final int aInsertPos = aBuffer.size();
          final T t = readNextToken();
          if (t == null) {
            return null;
          }
          if (aBuffer.size() > aInsertPos) {
            aLastPos = aBuffer.get(aInsertPos).aStartPos;
          } else {
            aLastPos = getSourcePos();
          }
          aBuffer.add(aInsertPos, new BufferElem<>(t.getPos().getOffset(), aLastPos, t));
        }
      }
      aBufferPos++;

      return aBuffer.get(aBufferPos - 1).aToken;
    }

    @Override
    public boolean eof() {
      validate();
      try {
        return (aBufferPos >= aBuffer.size()) && sourceEof();
      } catch (final IOException ex) {
        throw new RuntimeException(ex);
      }
    }

    @Override
    public int getPos() {
      validate();
      return aLastPos;
    }

    private void validate() {
      if (!isValid()) {
        throw new IllegalStateException("The peeking buffer is no longer valid.");
      }
    }

    /**
     * {@inheritDoc}
     *
     * @deprecated
     */
    @Override
    @Deprecated
    public T simplePeek(final int pPos) {
      final PeekBuffer<T, U> peek = peek();
      T token = null;
      for (int i = 0; i < pPos; i++) {
        try {
          token = peek.getNextToken();
        } catch (final TokenException ex) {
          return null;
        }
      }
      return token;
    }

    @Override
    public void close() throws IOException {
      AbstractBufferedTokenStream.this.close();
    }

    @Override
    public String toString() {
      final StringBuilder result = new StringBuilder("Peeking (");
      result.append(getPos());
      result.append("): ");
      try {
        if (eof()) {
          result.append("EOF");
        } else {
          result.append(peek().getNextToken());
        }
      } catch (final TokenException ex) {
        result.append("-ERROR-");
      }
      return result.toString();
    }

    @Override
    public File getFile() {
      return aParent.getFile();
    }

  }

  private final LinkedList<BufferElem<T>> aBuffer;

  private int aPeekPos = 0;

  /**
   * Create a new instance.
   *
   * @param pFile The file represented
   */
  protected AbstractBufferedTokenStream(final File pFile) {
    super(pFile);
    aBuffer = new LinkedList<>();
  }

  /**
   * Get the next token of this type from the stream.
   *
   * @return The enxt token
   * @throws UnexpectedTokenException When the next token is not of a type
   *           accepted by this stream
   * @throws TokenException
   * @see net.devrieze.parser.TokenStream#getNextToken()
   */
  @Override
  public T getNextToken() throws TokenException {
    if (aBuffer.size() > 0) {
      if (aPeekPos > 0) {
        aPeekPos--; /*
                     * Remove one from the peeking position, but not from start
                     */
      }
      return aBuffer.removeFirst().aToken;
    }
    return readNextToken();
  }

  /**
   * Push a token to the end of the buffer.
   *
   * @param pToken The token to add.
   * @param pEndPos The ending posisition of the token.
   */
  protected void pushBufferToken(final T pToken, final int pEndPos) {
    aBuffer.addLast(new BufferElem<>(pToken.getPos().getOffset(), pEndPos, pToken));
  }

  /**
   * Method used to read the next token, invoked by {@link #getNextToken}.
   *
   * @return The next token in the file, without buffering
   * @throws TokenException When a token was found that was not expected.
   */
  protected abstract T readNextToken() throws TokenException;

  /**
   * Checks whether the end of the stream has been reached.
   *
   * @return <code>true</code> if the end of the stream has been reached
   * @see net.devrieze.parser.TokenStream#eof()
   */
  @Override
  public final boolean eof() {
    try {
      return (aBuffer.size() == 0) && sourceEof();
    } catch (final IOException ex) {
      throw new RuntimeException(ex);
    }
  }

  /**
   * Check whether the parent end of file has been reached.
   *
   * @return <code>true</code> if the end of the source has been reached.
   * @throws IOException When something goes wrong.
   */
  protected abstract boolean sourceEof() throws IOException;

  @Override
  public PeekBuffer<T, U> peek() {
    return new BufferedPeekBuffer(getPos());
  }

  @Override
  public final int getPos() {
    if (aBuffer.size() > 0) {
      return aBuffer.get(0).aStartPos;
    }
    return getSourcePos();
  }

  /**
   * Get the position that corresponds to {@link #readNextToken()}.
   *
   * @return The position.
   */
  protected abstract int getSourcePos();

  /**
   * {@inheritDoc}
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public T simplePeek(final int pPos) {
    final PeekBuffer<T, U> peek = peek();
    T token = null;
    for (int i = 0; i < pPos; i++) {
      try {
        token = peek.getNextToken();
      } catch (final TokenException ex) {
        return null;
      }
    }
    return token;
  }


}
