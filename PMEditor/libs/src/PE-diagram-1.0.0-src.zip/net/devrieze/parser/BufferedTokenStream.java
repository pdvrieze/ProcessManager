/*
 * Created on Jan 4, 2005
 *
 */

package net.devrieze.parser;

import java.io.IOException;

import net.devrieze.parser.languages.Language;


/**
 * A tokenstream that supports peeking tokens, and resetting.
 *
 * @param <T> The type of the tokens in the stream
 * @param <U> The enumeration of all tokentypes
 * @author Paul de Vrieze
 * @version 0.2 $Revision$
 */
public interface BufferedTokenStream<T extends Token<U>, U extends Enum<U> & Language<U>> extends TokenStream<T, U>, AutoCloseable {

  /**
   * Get a new peeking buffer.
   *
   * @return The new peeking buffer.
   */
  PeekBuffer<T, U> peek();

  /**
   * Perform a simple peek.
   *
   * @param pPos How many tokens to look forward.
   * @return The token to look for.
   * @deprecated for now not advised.
   */
  @Deprecated
  T simplePeek(int pPos);

  @Override
  void close() throws IOException;
}
