/*
 * Created on Jan 7, 2005
 *
 */

package net.devrieze.parser;

import net.devrieze.lang.Const;
import net.devrieze.parser.eval.AbstractSymbolContext;
import net.devrieze.parser.eval.Contexed;
import net.devrieze.parser.eval.SymbolContext;
import net.devrieze.parser.eval.Type;


/**
 * A wrapper for objects, so that it is clear that the contained value is an
 * object.
 * 
 * @param <T> The type of object wrapped
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ObjectWrapper<T> implements Contexed {

  private final T aObject;

  /**
   * Constant representing a <code>null</code> object.
   */
  public static final ObjectWrapper<Object> _NULL = new ObjectWrapper<>(null);

  /**
   * Create a new wrapper for the given object.
   * 
   * @param pObject The object to wrap.
   */
  protected ObjectWrapper(final T pObject) {
    if (pObject instanceof ObjectWrapper) {
      throw new IllegalArgumentException("Wrapping an object wrapper");
    }
    if (!wrapAble(pObject)) {
      throw new IllegalArgumentException("Wrappin an inappropriate object");
    }
    aObject = pObject;
  }

  /**
   * Get the wrapped object.
   * 
   * @return The wrapped object.
   */
  public T getObject() {
    return aObject;
  }

  /**
   * Help method for unwrapping objects.
   * 
   * @param pObject The possibly wrapped object
   * @return The resulting value
   */
  public static Object unWrap(final Object pObject) {
    if (pObject instanceof ObjectWrapper) {
      return ((ObjectWrapper<?>) pObject).getObject();
    }
    return pObject;
  }

  /**
   * Unwrap the objects in the list.
   * 
   * @param pObjects The list to unwrapped
   * @return An unwrapped list.
   */
  public static Object[] unWrapArray(final Object[] pObjects) {
    final Object[] result = new Object[pObjects.length];
    for (int i = 0; i < result.length; i++) {
      result[i] = unWrap(pObjects[i]);
    }
    return result;
  }

  private static boolean wrapAble(final Object pObject) {
    return !((pObject instanceof ObjectWrapper) || (pObject instanceof Double) || (pObject instanceof Float)
        || (pObject instanceof Integer) || (pObject instanceof Long) || (pObject instanceof Short) || (pObject instanceof Byte)
        || (pObject instanceof String) || (pObject instanceof Boolean) || (pObject instanceof Character));
  }

  /**
   * Help method for wrapping objects. Java versions of the primitives are not
   * wrapped. These classes are:
   * <ul>
   * <li>{@link ObjectWrapper} (this should not be wrapped)</li>
   * <li>{@link Double}</li>
   * <li>{@link Float}</li>
   * <li>{@link Integer}</li>
   * <li>{@link Long}</li>
   * <li>{@link Short}</li>
   * <li>{@link Byte}</li>
   * <li>{@link String}</li>
   * <li>{@link Character}</li>
   * <li>{@link Boolean}</li>
   * </ul>
   * 
   * @param <U> The type of the object being wrapped
   * @param pObject The object to (conditionally) wrap.
   * @return The resulting object that is wrapped when needed.
   */
  public static Object wrap(final Object pObject) {
    if (!wrapAble(pObject)) {
      return pObject;
    }
    return new ObjectWrapper<>(pObject);
  }

  public static Object[] wrap(final Object... pObjects) {
    final Object[] result = new Object[pObjects.length];
    for (int i = 0; i < pObjects.length; i++) {
      result[i] = wrap(pObjects[i]);
    }
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public boolean equals(final Object pObj) {
    if (!(pObj instanceof ObjectWrapper)) {
      return false;
    }
    final ObjectWrapper<?> other = (ObjectWrapper<?>) pObj;

    if (aObject == null) {
      return other.aObject == null;
    }
    return aObject.equals(other.aObject);
  }

  /** {@inheritDoc} */
  @Override
  public int hashCode() {
    return (aObject.hashCode() * Const._HASHPRIME) + 1;
  }

  /**
   * Get a context class for this object. By default an empty context is
   * returned
   * 
   * @return An empty object context
   */
  @Override
  public SymbolContext getContext() {
    if (aObject instanceof Contexed) {
      return ((Contexed) aObject).getContext();
    }

    /* Return an empty context without methods */
    return new AbstractSymbolContext(null) {

      @Override
      public SymbolType getSymbolType(final String pName) {
        return null;
      }

      @Override
      public boolean isFunctionSymbol(final String pName, final Type[] pParamTypes) {
        return false;
      }

      @Override
      public String toString() {
        return "<Empty Symbol Context>";
      }

    };
  }
}
