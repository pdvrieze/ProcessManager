/*
 * Created on 25-Oct-2005
 */
package net.devrieze.parser.gui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.*;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoableEdit;

import net.devrieze.parser.TokenException;
import net.devrieze.parser.streams.LineTokenStream;
import net.devrieze.parser.streams.StringTokenStream;
import net.devrieze.util.StringUtil;


/**
 * A document class for editing scripts. Work in progress.
 * 
 * @author Paul de Vrieze
 * @version 0.01 $Revision$
 */
public class ScriptDocument extends AbstractDocument {

  public static class ScriptUndoableEdit implements UndoableEdit {

    private final int aLineNo;

    private final char[][] aNew;

    private final char[][] aOrig;

    private final ScriptContent aContent;

    private final boolean aDone;

    private boolean aDead = false;

    public ScriptUndoableEdit(final ScriptContent pContent, final char[][] pOrig, final char[][] pNew, final int pLineNo) {
      aContent = pContent;
      aOrig = pOrig;
      aNew = pNew;
      aLineNo = pLineNo;
      aDone = true;
    }

    @Override
    public void undo() throws CannotUndoException {
      if (!canUndo()) {
        throw new CannotUndoException();
      }
      for (@SuppressWarnings("unused")
      final char[] element : aNew) {
        aContent.aScript.remove(aLineNo);
      }
      for (int i = 0; i < aOrig.length; i++) {
        aContent.aScript.add(aLineNo + i, new Line(-1, aOrig[i]));
      }
      aContent.reOffsetFrom(aLineNo);

    }

    @Override
    public boolean canUndo() {
      if (aDead || !aDone) {
        return false;
      }
      for (int i = 0; i < aNew.length; i++) {
        if (!aNew[i].equals(aContent.aScript.get(i + aLineNo))) {
          return false;
        }
      }

      return true;
    }

    @Override
    public void redo() throws CannotRedoException {
      if (!canRedo()) {
        throw new CannotRedoException();
      }
      for (@SuppressWarnings("unused")
      final char[] element : aOrig) {
        aContent.aScript.remove(aLineNo);
      }
      for (int i = 0; i < aNew.length; i++) {
        aContent.aScript.add(aLineNo + i, new Line(-1, aNew[i]));
      }
      aContent.reOffsetFrom(aLineNo);
    }

    @Override
    public boolean canRedo() {
      if (aDead || aDone) {
        return false;
      }
      for (int i = 0; i < aOrig.length; i++) {
        if (!aOrig[i].equals(aContent.aScript.get(i + aLineNo))) {
          return false;
        }
      }
      return true;
    }

    @Override
    public void die() {
      aDead = true;
    }

    @Override
    public boolean addEdit(final UndoableEdit pAnEdit) {
      // @todo Unsupported
      return false;
    }

    @Override
    public boolean replaceEdit(final UndoableEdit pAnEdit) {
      // @todo Unsupported
      return false;
    }

    @Override
    public boolean isSignificant() {
      return true;
    }

    @Override
    public String getPresentationName() {
      return "Change Text";
    }

    @Override
    public String getUndoPresentationName() {
      return getPresentationName();
    }

    @Override
    public String getRedoPresentationName() {
      return getPresentationName();
    }

  }

  public static class Line {

    private char[] aValue;

    private int aOffset;

    public Line(final int pOffset, final char[] pValue) {
      aOffset = pOffset;
      aValue = pValue;
    }

  }

  public static class ScriptContent implements Content {

    private final List<Line> aScript;

    private int aLength = -1;

    public ScriptContent(final String pScript) {
      aScript = new ArrayList<>();
      final LineTokenStream lts = new LineTokenStream(new StringTokenStream(pScript));
      try {
        int offset = 0;
        while (!lts.eof()) {
          final char[] s = lts.getNextToken().getLine().toString().toCharArray();
          aScript.add(new Line(offset, s));
          offset += 1 + s.length;
        }
        aLength = offset;
      } catch (final TokenException e) {
        throw new RuntimeException(e);
      }
    }

    /**
     * Recalculate the offset of the line from the beginning of the document.
     * 
     * @param pLineNo The line to start at.
     */
    public void reOffsetFrom(final int pLineNo) {
      for (int i = pLineNo; i < aScript.size(); i++) {
        if (i == 0) {
          aScript.get(i).aOffset = 0;
        } else {
          final Line prev = aScript.get(i - 1);
          aScript.get(i).aOffset = prev.aOffset + prev.aValue.length + 1;
        }
      }
      final Line lastLine = aScript.get(aScript.size() - 1);
      aLength = lastLine.aOffset + lastLine.aValue.length + 1;
    }

    @Override
    public Position createPosition(final int pOffset) throws BadLocationException {
      // @todo Auto-generated method stub
      return null;
    }

    @Override
    public int length() {
      if (aLength < 0) {
        aLength = aScript.get(aScript.size() - 1).aOffset + aScript.get(aScript.size() - 1).aValue.length;
      }
      return aLength;
    }

    @Override
    public UndoableEdit insertString(final int pWhere, final String pStr) throws BadLocationException {
      checkRange(pWhere, 0);
      final char[][] lines = toCharArrays(StringUtil.splitLines(pStr));
      if (lines.length == 0) {
        return null; // No edit
      }
      if (pWhere == length()) {
        final UndoableEdit result = new ScriptUndoableEdit(this, new char[][] {}, lines, aScript.size());
        int offset = aLength;
        for (final char[] line : lines) {
          aScript.add(new Line(offset, line));
          offset += line.length + 1;
        }
        aLength = offset;
        return result;
      }
      int i = 0;
      while (i < aScript.size()) {
        if ((aScript.get(i).aOffset >= pWhere)
            && ((pWhere == (aScript.size() - 1)) || (aScript.get(i).aOffset < aScript.get(i + 1).aOffset))) {
          // Found the index where to insert.
          final Line line = aScript.get(i);
          final String before = new String(line.aValue).substring(0, pWhere - line.aOffset);
          final String after = new String(line.aValue).substring(pWhere - line.aOffset);
          char[][] oldS;
          char[][] newS;
          if ((after.length() == 0) && (lines[0].length == 0)) {
            i++;
            oldS = new char[0][];
            newS = new char[lines.length - 1][];
            for (int j = 0; j < newS.length; j++) {
              newS[j] = lines[j + 1];
            }
          } else {
            oldS = new char[][] { line.aValue };
            newS = new char[lines.length][];
            newS[0] = (before + new String(lines[0])).toCharArray();
            for (int j = 1; j < newS.length; j++) {
              newS[j] = lines[j];
            }
          }
          newS[newS.length - 1] = (new String(newS[newS.length - 1]) + after).toCharArray();
          return new ScriptUndoableEdit(this, oldS, newS, i);
        }
        i++;
      }
      throw new BadLocationException("Index out of bounds", pWhere);
    }

    @Override
    public UndoableEdit remove(final int pWhere, final int pNitems) throws BadLocationException {
      if (pWhere < 0) {
        throw new BadLocationException("Index out of bounds", pWhere);
      }
      for (int i = 0; i < aScript.size(); i++) {
        final Line line = aScript.get(i);
        if ((pWhere >= line.aOffset) && (pWhere <= (line.aOffset + line.aValue.length))) {
          final int start = i;
          final String before = new String(line.aValue).substring(0, pWhere - line.aOffset);
          while (i < aScript.size()) {
            final Line endLine = aScript.get(i);
            if (((pWhere + pNitems) >= endLine.aOffset) && ((pWhere + pNitems) <= (endLine.aOffset + endLine.aValue.length))) {
              final int end = i;
              final String after = new String(endLine.aValue).substring((pWhere + pNitems) - endLine.aOffset);
              final char[][] orig = new char[(end - start) + 1][];
              for (int j = 0; j < orig.length; j++) {
                orig[j] = aScript.get(j + start).aValue;
              }
              final char[][] result = new char[][] { (before + after).toCharArray() };
              for (int j = start; j < end; j++) {
                aScript.remove(start);
              }
              line.aValue = result[0];
              reOffsetFrom(start + 1);
              return new ScriptUndoableEdit(this, orig, result, start);
            }
            i++;
          }
          throw new BadLocationException("Deleting beyond the file", pWhere + pNitems);
        }
      }

      throw new BadLocationException("Index out of bounds", pWhere);
    }

    @Override
    public String getString(final int pWhere, final int pLen) throws BadLocationException {
      checkRange(pWhere, pLen);
      final char[] result = new char[pLen];
      for (int i = 0; i < aScript.size(); i++) {
        final Line line = aScript.get(i);
        if ((pWhere >= line.aOffset) && (pWhere <= (line.aOffset + line.aValue.length))) {
          // Found initial point
          int j = 0;
          int lineOffset = pWhere - line.aOffset;
          Line line2 = line;
          while (j < result.length) {
            if (lineOffset == line2.aValue.length) {
              result[j] = '\n';
              i++;
              line2 = aScript.get(i);
              lineOffset = 0;
            } else {
              result[j] = line2.aValue[lineOffset];
              lineOffset++;
            }
            j++;
          }
          return new String(result);
        }
      }
      throw new BadLocationException("Did not find the string", pWhere);
    }

    private void checkRange(final int pWhere, final int pLen) throws BadLocationException {
      if (pWhere < 0) {
        throw new BadLocationException("Before the text", pWhere);
      } else if ((pWhere + pLen) >= aLength) {
        throw new BadLocationException("Beyond the text", pWhere + pLen);
      }
    }

    @Override
    public void getChars(final int pWhere, final int pLen, final Segment pTxt) throws BadLocationException {
      checkRange(pWhere, pLen);
      for (int i = 0; i < aScript.size(); i++) {
        final Line line = aScript.get(i);
        if ((pWhere >= line.aOffset) && (pWhere <= (line.aOffset + line.aValue.length))) {
          final int lineOffset = pWhere - line.aOffset;
          if ((lineOffset + pLen) < line.aValue.length) {
            pTxt.array = line.aValue;
            pTxt.offset = lineOffset;
            pTxt.count = pLen;
          } else if (pTxt.isPartialReturn()) {
            pTxt.array = line.aValue;
            pTxt.offset = lineOffset;
            pTxt.count = pTxt.array.length - lineOffset;
          }
        }
      }
    }

  }

  private static final long serialVersionUID = -4421183433471901168L;

  /**
   * @param pScript
   * @param pContext
   */
  public ScriptDocument(final String pScript, final AttributeContext pContext) {
    super(new ScriptContent(pScript), pContext);
  }

  public static char[][] toCharArrays(final String[] pStrings) {
    final char[][] result = new char[pStrings.length][];
    for (int i = 0; i < result.length; i++) {
      result[i] = pStrings[i].toCharArray();
    }
    return result;
  }

  /**
   * @param pScript
   */
  public ScriptDocument(final String pScript) {
    super(new ScriptContent(pScript));
  }

  @Override
  public Element getDefaultRootElement() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Element getParagraphElement(final int pPos) {
    // @todo Auto-generated method stub
    return null;
  }

}
