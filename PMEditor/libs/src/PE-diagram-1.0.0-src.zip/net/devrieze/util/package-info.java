/**
 * This package provides various utility classes that are not provided by
 * {@link java.util}
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.util;

