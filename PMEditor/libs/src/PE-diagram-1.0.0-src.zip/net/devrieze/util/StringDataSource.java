package net.devrieze.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.nio.charset.Charset;

import javax.activation.DataSource;


public class StringDataSource implements DataSource {

  private final String aContentType;

  private final String aContent;

  private final String aName;

  public StringDataSource(final String name, final String contentType, final String content) {
    aName = name;
    aContentType = contentType;
    aContent = content;
  }

  @Override
  public String getContentType() {
    return aContentType;
  }

  @Override
  public InputStream getInputStream() throws IOException {
    final StringReader reader = new StringReader(aContent);
    return new ReaderInputStream(Charset.forName("UTF-8"), reader);
  }

  @Override
  public String getName() {
    return aName;
  }

  @Override
  public OutputStream getOutputStream() throws IOException {
    throw new UnsupportedOperationException("Not supported");
  }

}
