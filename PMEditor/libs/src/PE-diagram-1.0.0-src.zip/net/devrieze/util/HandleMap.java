package net.devrieze.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;


public interface HandleMap<V> extends Set<V> {

  public static interface HandleAware<T> extends Handle<T> {

    public void setHandle(long pHandle);
  }

  /**
   * @param <T> Type parameter that should help with compile time handle differentiation
   */
  public static interface Handle<T> {

    public long getHandle();
  }

  /**
   * Clear out all elements from the map, but unlike creating a new map, don't
   * reset the other metadata determining the next handle.
   */
  @Override
  public void clear();

  @Override
  public Iterator<V> iterator();

  /**
   * Determine whether the given object is contained in the map. If the object
   * implements {@link HandleAware} a shortcut is applied instead of looping
   * through all values.
   *
   * @param pObject The object to check.
   * @return <code>true</code> if it does.
   */
  @Override
  public boolean contains(Object pObject);

  /**
   * Determine whether the given handle is contained in the map.
   *
   * @param pObject The object to check.
   * @return <code>true</code> if it does.
   */
  public boolean contains(long pHandle);

  /**
   * Put a new walue into the map. This is thread safe.
   *
   * @param pValue The value to put into the map.
   * @return The handle for the value.
   */
  public long put(V pValue);

  /**
   * Get the element with the given handle.
   *
   * @param pHandle The handle
   * @return The element corresponding to the given handle.
   */
  public V get(long pHandle);

  public V get(HandleMap.Handle<? extends V> pHandle);

  @Override
  public int size();

  public boolean remove(HandleMap.Handle<? extends V> pObject);

  public boolean remove(long pHandle);

  /**
   * Return a collection view over this map. Note that this collection is just a
   * view, and changes on the collection will change the underlying map.
   *
   * @return The collection view.
   */
  public Collection<V> toCollection();

}