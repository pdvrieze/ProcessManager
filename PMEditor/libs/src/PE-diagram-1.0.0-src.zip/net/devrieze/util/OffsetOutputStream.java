/*
 * Created on 14-Feb-2006
 */
package net.devrieze.util;

import java.io.IOException;
import java.io.OutputStream;


public class OffsetOutputStream extends OutputStream {

  private long aOffset;

  private final OutputStream aParent;

  public OffsetOutputStream(final OutputStream pParent) {
    super();
    aOffset = 0;
    aParent = pParent;
  }

  @Override
  public void write(final int pB) throws IOException {
    aParent.write(pB);
    incOffset(1);
  }

  @Override
  public void write(final byte[] pB, final int pOff, final int pLen) throws IOException {
    try {
      super.write(pB, pOff, pLen);
    } catch (final IOException e) {
      aOffset = -1;
      throw e;
    }
    incOffset(pLen);
  }

  @Override
  public void write(final byte[] pB) throws IOException {
    try {
      super.write(pB);
    } catch (final IOException e) {
      aOffset = -1;
      throw e;
    }
    incOffset(pB.length);
  }

  private void incOffset(final int pInc) {
    if (aOffset >= 0) {
      aOffset += pInc;
    }
  }

  @Override
  public void close() throws IOException {
    aParent.close();
  }

  @Override
  public void flush() throws IOException {
    aParent.flush();
  }

  public long getOffset() {
    if (aOffset < 0) {
      throw new IllegalStateException("The offset is not legal, probably due to an IO error when writing");
    }
    return aOffset;
  }

}
