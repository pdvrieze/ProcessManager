/**
 *
 */
package net.devrieze.util;

import java.util.Iterator;
import java.util.Map;


public class ValueIterator<T> implements Iterator<T> {

  private final Iterator<? extends Map.Entry<?, T>> aBackingIterator;

  public ValueIterator(final Iterator<? extends Map.Entry<?, T>> pBackingIterator) {
    aBackingIterator = pBackingIterator;
  }

  @Override
  public boolean hasNext() {
    return aBackingIterator.hasNext();
  }

  @Override
  public T next() {
    return aBackingIterator.next().getValue();
  }

  @Override
  public void remove() {
    throw new UnsupportedOperationException("Read only collection");
  }

}