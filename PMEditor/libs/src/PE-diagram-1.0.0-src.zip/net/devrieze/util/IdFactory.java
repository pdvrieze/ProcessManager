package net.devrieze.util;


public class IdFactory {

  private static long aNextId = 0;

  /**
   * Create an Id for use in xml
   * 
   * @return a Unique Id
   */
  public static String create() {
    final String result = "i" + aNextId;
    aNextId++;
    return result;
  }

}
