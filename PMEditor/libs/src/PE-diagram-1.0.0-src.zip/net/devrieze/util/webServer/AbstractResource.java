/*
 * ConfigResource.java
 *
 * Created on 16 May 2001, 09:19
 */

package net.devrieze.util.webServer;

import java.io.PrintStream;
import java.net.URL;

import static net.devrieze.util.WebServer.*;

import net.devrieze.util.WebServer;


/**
 * AbstractResource is a "default" implementation of the
 * {@link WebResourceProvider }interface. It provides for most of the functions
 * defined in the interface. Only the {@link #writeBody}function is declared
 * abstract, because that should be specific to each resource provider or even
 * resource.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public abstract class AbstractResource implements WebResourceProvider {

  /**
   * This is the base of the resource. This way the resourceprovider knows it's
   * own root, and can use that.
   */
  private URL aBase;

  /** This is the url that is requested by the webserver. */
  private URL aLocation;

  /**
   * The standard headers that will be used. This is for the courtesy of the
   * classes that derive from AbstractResource
   * 
   * @return An array with the headers that are used standard.
   */
  @Override
  public String[] getHeaders() {
    return _DEFAULTHEADERS;
  }

  /**
   * Returns a copy of the resource.
   * 
   * @return A copy of the resource (This is always an AbstractResource or any
   *         of its children).
   */
  @Override
  public AbstractResource clone() {
    AbstractResource c;

    try {
      c = getClass().newInstance();
    } catch (final Exception e) {
      e.printStackTrace();

      return null;
    }

    c.aBase = aBase;
    c.aLocation = aLocation;

    return c;
  }

  /**
   * This method is called when the body of the http return message needs to be
   * written. This means the html code must be written in this function. For a
   * class that returns a page for every requested url, it is enough to override
   * only this function.
   * 
   * @param pOut This is the stream where the body needs to be written to.
   * @param pRequest This is the request that needs to be answered. This object
   *          can be used to get parameters that are passed through with get or
   *          post methods.
   * @return The http response code. This version of the {@link WebServer}class
   *         doesn't use it though.
   */
  @Override
  public abstract int writeBody(final PrintStream pOut, final HttpRequest pRequest);

  /**
   * This sets the base url of this resource. This function is called by
   * {@link WebServer}. This allows the resource to know its location.
   * 
   * @param pLocation The base URL
   */
  @Override
  public void setBase(final URL pLocation) {
    aBase = pLocation;
  }

  protected URL getBase() {
    return aBase;
  }

  protected URL getLocation() {
    return aLocation;
  }

  protected void setLocation(final URL pLocation) {
    aLocation = pLocation;
  }

  /**
   * Set the url of this document.
   * 
   * @param pLocation The location of the document
   * @return ???
   */
  @Override
  public boolean setURL(final URL pLocation) {
    aLocation = pLocation;

    return (aBase == null) || pLocation.getPath().startsWith(aBase.getPath());
  }

  /**
   * This method is called when the headers of the resource need to be written.
   * A class that wants to be able to send custom headers must override this
   * method, and can use {@link #getHeaders}to get the standard headers.
   * 
   * @param pOut This is the stream where the headers need to be written to.
   * @param pRequest This is the request that needs to be answered. This object
   *          can be used to get parameters that are passed through with get or
   *          post methods.
   */
  @Override
  public void writeHeaders(final PrintStream pOut, final HttpRequest pRequest) {
    final String[] s = getHeaders();

    for (final String element : s) {
      pOut.print(element + _CRLF);
    }
  }
}
