/*
 * FileResource.java
 *
 * Created on November 26, 2001, 3:48 PM
 */

package net.devrieze.util.webServer;

import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;

import net.devrieze.util.WebServer;


/**
 * This is a webresource that just passes through resources as available for
 * java.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class ResourceResource extends AbstractResource {

  private static final int _BUFFER_SIZE = 32768;

  private String aResourceBase = null;

  private String aRes;

  /**
   * Creates new FileResource.
   * 
   * @param pResourceBase the string to prepend to get the resource
   */
  public ResourceResource(final String pResourceBase) {
    aResourceBase = pResourceBase;

    if (!aResourceBase.endsWith("/")) {
      aResourceBase = aResourceBase + '/';
    }
  }

  /**
   * The standard headers that will be used. This is for the courtesy of the
   * classes that derive from AbstractResource.
   * 
   * @return An array with the headers that are used standard.
   */
  @Override
  public String[] getHeaders() {
    final String s = aRes.toLowerCase();

    if (s.endsWith(".gif")) {
      return new String[] { "Server: " + WebServer.getIdentifier(), "Connection: close", "Accept-Ranges: bytes", "Content-Type: image/gif",
                           "Last-Modified: Wed, 25 Jun 2001 13:00:00 GMT",
      /* for caching on browser */
      };
    } else if (s.endsWith(".png")) {
      return new String[] { "Server: " + WebServer.getIdentifier(), "Connection: close", "Accept-Ranges: bytes", "Content-Type: image/png",
                           "Last-Modified: Wed, 25 Jun 2001 13:00:00 GMT",
      /* for caching on browser */
      };
    } else if (s.endsWith(".jpg") | s.endsWith(".jpeg")) {
      return new String[] { "Server: " + WebServer.getIdentifier(), "Connection: close", "Accept-Ranges: bytes",
                           "Content-Type: image/jpeg", "Last-Modified: Wed, 25 Jun 2001 13:00:00 GMT",
      /* for caching on browser */
      };
    } else {
      return _DEFAULTHEADERS;
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean setURL(final URL pLocation) {
    if ((getBase() == null) || pLocation.getPath().startsWith(getBase().getPath())) {
      setLocation(pLocation);

      String respost = pLocation.getPath();

      if (getBase() != null) {
        respost = respost.substring(getBase().getPath().length());
      }

      while (respost.startsWith("/")) {
        respost = respost.substring(1);
      }

      aRes = aResourceBase + respost;

      final URL u = ClassLoader.getSystemClassLoader().getResource(aRes);

      return u != null;
    }

    return false;
  }

  /**
   * This method is called when the body of the http return message needs to be
   * written. This means the html code must be written in this function. For a
   * class that returns a page for every requested url, it is enough to override
   * only this function.
   * 
   * @param pOut This is the stream where the body needs to be written to.
   * @param pRequest This is the request that needs to be answered. This object
   *          can be used to get parameters that are passed through with get or
   *          post methods.
   * @return The http response code. This version of the {@link WebServer}class
   *         doesn't use it though.
   */
  @Override
  public int writeBody(final PrintStream pOut, final HttpRequest pRequest) {
    try (InputStream in = ClassLoader.getSystemClassLoader().getResourceAsStream(aRes)) {
  
      final byte[] bbuf = new byte[_BUFFER_SIZE];
      int cnt;
  
      while ((cnt = in.read(bbuf)) > 0) {
        pOut.write(bbuf, 0, cnt);
      }
  
      return WebServer._RESPONSE_SUCCESS; /* success */
    } catch (final Exception e) {
      e.printStackTrace();
    }
    return WebServer._RESPONSE_INTERNAL_SERVER_ERROR;
  }
}
