/**
 * This package is an auxilary package for the
 * {@link net.devrieze.util.WebServer} class. It contains the classes that are
 * nescesarry to use the {@link net.devrieze.util.WebServer} class.
 *
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.util.webServer;

