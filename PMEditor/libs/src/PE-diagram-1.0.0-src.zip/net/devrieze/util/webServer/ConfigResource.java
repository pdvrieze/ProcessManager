/*
 * ConfigResource.java
 *
 * Created on 16 May 2001, 09:19
 */

package net.devrieze.util.webServer;

import java.io.PrintStream;
import java.net.URL;

import net.devrieze.util.WebServer;


/**
 * The ConfigResource class provides for a WebResourceProvider that serves pages
 * that can stop the browser.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class ConfigResource extends AbstractResource {

  private boolean aStop = false;

  /**
   * Returns the value of the stop property. If this value is <code>true</code>,
   * the {@linkWebServer}class will stop itself after a request for this
   * resource.
   * 
   * @return the value of the stop property
   */
  public boolean isStop() {
    return aStop;
  }

  /**
   * Get the query part of the url.
   * 
   * @param pUrl The url to be parsed
   * @return The query part
   */
  public static String urlQuery(final URL pUrl) {
    final String full = pUrl.toString();
    final int i = full.indexOf('?');

    if (i >= 0) {
      return full.substring(i + 1);
    }

    return "";
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public int writeBody(final PrintStream pOut, final HttpRequest pRequest) {
    if ((urlQuery(getLocation()) != null) && urlQuery(getLocation()).toLowerCase().startsWith("stopbutton")) {
      pOut.println("<html><head><title>Webserver stopped</title></head>");
      pOut.println("<body>The webserver has been stopped on the user's request");
      pOut.println("<hr>" + WebServer.getIdentifier() + " at " + getBase().getHost() + " port " + getBase().getPort());
      pOut.println("</body></html>");
      aStop = true;
    } else {
      pOut.println("<HTML><HEAD><TITLE>" + WebServer.getIdentifier() + ": Config</TITLE></HEAD>");
      pOut.println("<BODY><FORM action=\"" + getLocation().toString() + "\" method=\"get\">");
      pOut.println("<input type=\"submit\" name=\"stopButton\" value=\"Stop server\">");
      pOut.println("</form></body></html>");
    }

    return WebServer._RESPONSE_SUCCESS;
  }
}
