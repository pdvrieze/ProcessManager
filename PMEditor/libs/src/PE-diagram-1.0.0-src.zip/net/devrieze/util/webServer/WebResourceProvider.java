/*
 * WebResourceProvider.java
 *
 * Created on 15 May 2001, 13:38
 */

package net.devrieze.util.webServer;

import java.io.PrintStream;
import java.net.URL;

import net.devrieze.util.WebServer;


/**
 * The WebResourceProvider class is the interface that classes must implement to
 * be a resourceProvider for the {@link WebServer}class. Classes that implement
 * this interface don't need to know http, except for the headers that are sent.
 * They can however resort to default headers. In that case they don't even need
 * to know about that.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 * @see WebServer
 */
public interface WebResourceProvider {

  /** The standard headers that get transmitted when a web page is served. */
  String[] _DEFAULTHEADERS = new String[] { "Server: " + WebServer.getIdentifier(), "Connection: close", "Content-Type: text/html", };

  /**
   * This sets the base url of this resource. This function is called by
   * {@link WebServer}
   * 
   * @param pLocation The base URL
   */
  void setBase(final URL pLocation);

  /**
   * The standard headers that will be used. This is for the courtesy of the
   * classes that derive from AbstractResource
   * 
   * @return An array with the headers that are used standard.
   */
  String[] getHeaders();

  /**
   * This function is called first by the {@link WebServer}class when a request
   * is received. It specifies the url that is requested from this
   * WebResourceProvider. This function indicates whether or not the resource
   * indicated by this url is available.
   * 
   * @param pLocation The requested URL
   * @return <code>true</code> when the resource is available,
   *         <code>false</code> when not.
   */
  boolean setURL(final URL pLocation);

  /**
   * This method is called when the body of the http return message needs to be
   * written. This means the html code must be written in this function.
   * 
   * @param pOut This is the stream where the body needs to be written to.
   * @param pRequest This is the request that needs to be answered. This object
   *          can be used to get parameters that are passed through with get or
   *          post methods.
   * @return The http response code. This version of the {@link WebServer}class
   *         doesn't use it though.
   * @see AbstractResource#writeHeaders
   */
  int writeBody(final PrintStream pOut, final HttpRequest pRequest);

  /**
   * This method is called when the headers of the resource need to be written.
   * 
   * @param pOut This is the stream where the headers need to be written to.
   * @param pRequest This is the request that needs to be answered. This object
   *          can be used to get parameters that are passed through with get or
   *          post methods.
   */
  void writeHeaders(final PrintStream pOut, final HttpRequest pRequest);
}
