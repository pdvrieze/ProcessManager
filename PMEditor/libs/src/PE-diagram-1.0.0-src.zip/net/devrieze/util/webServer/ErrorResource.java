/*
 * ErrorResource.java
 *
 * Created on 15 May 2001, 22:21
 */

package net.devrieze.util.webServer;

import java.io.PrintStream;
import java.net.URL;

import static net.devrieze.util.WebServer.*;

import net.devrieze.util.WebServer;


/**
 * This class provides error messages for failed requests. It is mainly for
 * internal use of the {@link WebServer}class.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class ErrorResource implements WebResourceProvider {

  private URL aBase;

  private URL aLocation;

  /**
   * {@inheritDoc}
   */
  @Override
  public void setBase(final URL pLocation) {
    aBase = pLocation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String[] getHeaders() {
    return _DEFAULTHEADERS;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean setURL(final URL pLocation) {
    aLocation = pLocation;

    return true; /* all locations supported */
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ErrorResource clone() {
    final ErrorResource c = new ErrorResource();
    c.aBase = aBase;
    c.aLocation = aLocation;

    return c;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public int writeBody(final PrintStream pOut, final HttpRequest pRequest) {
    final int response = pRequest.getResponse();
    String description = "error";

    switch (response) {
      case WebServer._RESPONSE_ERROR: {
        description = "Malformed URL !";

        break;
      }

      case WebServer._RESPONSE_FILE_NOT_FOUND: {
        description = "File not found: " + aLocation.toString();

        break;
      }

      case WebServer._RESPONSE_INTERNAL_SERVER_ERROR: {
        description = "Internal server errror";

        break;
      }

      case WebServer._RESPONSE_NOT_IMPLEMENTED: {
        description = "Not Implemented: this method is not supported (yet)";

        break;
      }

      default:
        description = "Unknown error";
        break;
    }

    pOut.println("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">");
    pOut.println("<html><head>\n<title>" + Integer.toString(response) + " " + description + "</title>");
    pOut.println("</head><body>\n<h1>ERROR</h1>");
    pOut.println(description);
    pOut.println("<hr><adddress>" + WebServer.getIdentifier() + " at " + aLocation.getHost() + ":" + aLocation.getPort() + "</address>");
    pOut.println("</body></html>");

    return WebServer._RESPONSE_SUCCESS;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void writeHeaders(final PrintStream pOut, final HttpRequest pRequest) {
    final String[] s = getHeaders();

    for (final String element : s) {
      pOut.print(element + _CRLF);
    }
  }
}
