package net.devrieze.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import net.devrieze.lang.Const;


/*
 * Created on Feb 15, 2004
 *
 */

/**
 * A filter stream that sanitizes all newlines and replaces them by
 * <code>"\n"</code>.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class NewLineFilterOutputStream extends FilterOutputStream {

  private int aLast = 0;

  /**
   * Create a new stream.
   * 
   * @param pOut the stream that needs to be filtered
   */
  public NewLineFilterOutputStream(final OutputStream pOut) {
    super(pOut);
  }

  /**
   * @see OutputStream#write(byte[], int, int)
   */
  @Override
  public void write(final byte[] pBuffer, final int pOffset, final int pCount) throws IOException {
    final int stop = pOffset + pCount;
    for (int i = pOffset; i < stop; i++) {
      write(pBuffer[i]);
    }
  }

  /**
   * @see OutputStream#write(byte[])
   */
  @Override
  public void write(final byte[] pBuffer) throws IOException {
    write(pBuffer, 0, pBuffer.length);
  }

  /**
   * @see OutputStream#write(int)
   */
  @Override
  public void write(final int pToken) throws IOException {
    if (pToken == Const._LF) {
      if (aLast == Const._CR) {
        aLast = 0; /* Reset last */
      } else {
        aLast = Const._LF;
        super.write('\n');
      }
    } else if (pToken == Const._CR) {
      if (aLast == Const._LF) {
        aLast = 0;
      } else {
        aLast = Const._CR;
        super.write('\n');
      }
    } else {
      aLast = pToken;
      super.write(pToken);
    }
  }

}
