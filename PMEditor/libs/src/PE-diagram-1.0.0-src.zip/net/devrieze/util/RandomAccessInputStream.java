/*
 * Created on Feb 14, 2004
 *
 */

package net.devrieze.util;

import java.io.*;


/**
 * A stream that makes RandomAccessFile also an inputStream.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class RandomAccessInputStream extends InputStream implements DataInput {

  private final RandomAccessFile aSource;

  private long aMark = 0;

  /**
   * Create a new stream based on the named file.
   * 
   * @param pSource The file that needs to be streamed
   */
  public RandomAccessInputStream(final RandomAccessFile pSource) {
    aSource = pSource;
  }

  /**
   * Return the amount of bytes still available in the stream.
   * 
   * @return the amount of bytes
   * @see InputStream#available()
   */
  @Override
  public int available() throws IOException {
    return (int) (aSource.length() - aSource.getFilePointer());
  }

  /**
   * Set a mark for use with the {@link #reset}method.
   * 
   * @param pMin The minimum amount of bytes to support for the mark. This is
   *          ignored for this stream as it is irrelevant
   * @see InputStream#mark(int)
   */
  @Override
  public synchronized void mark(final int pMin) {
    try {
      aMark = aSource.getFilePointer();
    } catch (final IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Show whether mark is supported.
   * 
   * @return <code>true</code>
   */
  @Override
  public boolean markSupported() {
    return true;
  }

  /**
   * Reset the source to the mark position.
   * 
   * @throws IOException when an I/O exception occurs
   */
  @Override
  public synchronized void reset() throws IOException {
    aSource.seek(aMark);
  }

  /**
   * Skip the specified amount of bytes.
   * 
   * @param pCount the amount of bytes to skip
   * @return the amount of bytes actually skipped
   * @throws IOException When an I/O exception occurs
   */
  @Override
  public long skip(final long pCount) throws IOException {
    final long oldPos = aSource.getFilePointer();
    aSource.seek(Math.min(aSource.length(), oldPos + pCount));
    return aSource.getFilePointer() - oldPos;
  }

  /**
   * Close the stream.
   * 
   * @throws IOException When an I/O exception occurs
   * @see InputStream#close()
   */
  @Override
  public void close() throws IOException {
    aSource.close();
  }

  /**
   * Read a byte from the stream.
   * 
   * @throws IOException When an I/O exception occurs
   * @see InputStream#read()
   */
  @Override
  public int read() throws IOException {
    return aSource.read();
  }

  /**
   * Read a boolean from the stream.
   * 
   * @return the read boolean
   * @throws IOException When an I/O exception occurs
   */
  @Override
  public boolean readBoolean() throws IOException {
    return aSource.readBoolean();
  }

  /**
   * read a byte from the stream.
   * 
   * @return the read byte
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readByte()
   */
  @Override
  public byte readByte() throws IOException {
    return aSource.readByte();
  }

  /**
   * Read a character from the stream.
   * 
   * @return the read character
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readChar()
   */
  @Override
  public char readChar() throws IOException {
    return aSource.readChar();
  }

  /**
   * Read a double from the stream.
   * 
   * @return the read double
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readDouble()
   */
  @Override
  public double readDouble() throws IOException {
    return aSource.readDouble();
  }

  /**
   * Read a float from the stream.
   * 
   * @return the read float
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readFloat()
   */
  @Override
  public float readFloat() throws IOException {
    return aSource.readFloat();
  }

  /**
   * Read an integer from the stream.
   * 
   * @return the read integer
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readInt()
   */
  @Override
  public int readInt() throws IOException {
    return aSource.readInt();
  }

  /**
   * Read a line from the stream.
   * 
   * @return the read line
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readLine()
   */
  @Override
  public String readLine() throws IOException {
    return aSource.readLine();
  }

  /**
   * Read a long from the stream.
   * 
   * @return the read long
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readLong()
   */
  @Override
  public long readLong() throws IOException {
    return aSource.readLong();
  }

  /**
   * Read a short from the stream.
   * 
   * @return the read short
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readShort()
   */
  @Override
  public short readShort() throws IOException {
    return aSource.readShort();
  }

  /**
   * Read an unsigned byte from the stream.
   * 
   * @return the read unsigned byte
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readUnsignedByte()
   */
  @Override
  public int readUnsignedByte() throws IOException {
    return aSource.readUnsignedByte();
  }

  /**
   * Read an unsigned short from the stream.
   * 
   * @return the read unsigned short
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readUnsignedShort()
   */
  @Override
  public int readUnsignedShort() throws IOException {
    return aSource.readUnsignedShort();
  }

  /**
   * Read a string that is in UTF8 format in the file.
   * 
   * @return the read string
   * @throws IOException When an I/O exception occurs
   * @see DataInput#readUTF()
   */
  @Override
  public String readUTF() throws IOException {
    return aSource.readUTF();
  }

  /**
   * Skip the specified amount of bytes.
   * 
   * @return the skipped bytes
   * @throws IOException When an I/O exception occurs
   * @see DataInput#skipBytes(int)
   */
  @Override
  public int skipBytes(final int pCount) throws IOException {
    return aSource.skipBytes(pCount);
  }

  /**
   * Read the buffer entirely. It blocks when there are not enough bytes yet
   * 
   * @param pBuffer the buffer to read
   * @throws IOException when an I/O exception occurs
   * @throws EOFException when an EOF is reached before the buffer is full.
   * @see DataInput#readFully(byte[])
   */
  @Override
  public void readFully(final byte[] pBuffer) throws IOException, EOFException {
    aSource.readFully(pBuffer);
  }

  /**
   * Read the specified buffer range entirely.
   * 
   * @param pBuffer the buffer to fill
   * @param pOffset the position to start the reading to
   * @param pCount the amount of bytes to read
   * @see #readFully(byte[])
   * @see DataInput#readFully(byte[], int, int)
   */
  @Override
  public void readFully(final byte[] pBuffer, final int pOffset, final int pCount) throws IOException {
    aSource.readFully(pBuffer, pOffset, pCount);
  }

  /**
   * Read bytes into the specified buffer, starting at the specified offet. The
   * maximum amount of bytes is pCount.
   * 
   * @param pBuf The buffer to read into
   * @param pOffset the offset to start at
   * @param pCount the maximum amount of bytes to read
   * @return the actual amount of bytes read. This is -1 when the end of the
   *         file has been reached.
   * @see InputStream#read(byte[], int, int)
   */
  @Override
  public int read(final byte[] pBuf, final int pOffset, final int pCount) throws IOException {
    return aSource.read(pBuf, pOffset, pCount);
  }

  /**
   * Try to read as many bytes as fit into the buffer.
   * 
   * @param pBuf the buffer to fill
   * @return The actual amount of bytes read.
   * @see InputStream#read(byte[])
   */
  @Override
  public int read(final byte[] pBuf) throws IOException {
    return aSource.read(pBuf);
  }

  /**
   * Returns the current offset in this file.
   * 
   * @return the offset
   * @throws IOException when an I/O error occurs
   * @see RandomAccessFile#getFilePointer()
   */
  public long getFilePointer() throws IOException {
    return aSource.getFilePointer();
  }

}
