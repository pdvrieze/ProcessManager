/*
 * Created on Oct 27, 2004
 */

package net.devrieze.util;

import java.lang.ref.SoftReference;
import java.util.*;

import net.devrieze.lang.Const;


/**
 * A class implementing a Stack that can easilly grow due to the fact that the
 * stack is actually immutable. It's append and shrink methods allow operations
 * without cloneing. The contains operation is sped up using a HashSet
 * 
 * @param <E> The type of the elements in the stack
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class FastStack<E> implements List<E> {

  // Apparently faster without caching
  private static final boolean _ENABLE_CONTAINS_CACHING = false;

  private static final class FastStackIterator<U> implements ListIterator<U> {

    private final ListIterator<U> aParentIterator;

    /**
     * @param pStack the stack to iterate on {@inheritDoc}
     */
    private FastStackIterator(final FastStack<U> pStack) {
      aParentIterator = pStack.getList().listIterator();
    }

    /**
     * @param pStack The stack to iterate on
     * @param pStartPos The position to start at {@inheritDoc}
     */
    private FastStackIterator(final FastStack<U> pStack, final int pStartPos) {
      aParentIterator = pStack.getList().listIterator(pStartPos);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasNext() {
      return aParentIterator.hasNext();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public U next() {
      return aParentIterator.next();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void remove() {
      throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasPrevious() {
      return aParentIterator.hasPrevious();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public U previous() {
      return aParentIterator.previous();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int nextIndex() {
      return aParentIterator.nextIndex();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int previousIndex() {
      return aParentIterator.previousIndex();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void set(final U pArg0) {
      throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void add(final U pArg0) {
      throw new UnsupportedOperationException();
    }

  }

  private FastStack<E> aPrevious;

  private E aElem;

  private transient SoftReference<HashSet<E>> aContainsCache;

  List<E> getList() {
    FastStack<E> s = this;
    final ArrayDeque<E> elems = new ArrayDeque<>();
    while (s != null) {
      elems.addFirst(s.aElem);
      s = s.aPrevious;
    }
    return new ArrayList<>(elems);
  }

  /**
   * Create a new {@link FastStack}that contains the given element.
   * 
   * @param pElem The element to be contained in the stack
   */
  public FastStack(final E pElem) {
    this(pElem, null);
  }

  /**
   * Create a new FastStack, based on the to-be appended element and a previous
   * stack.
   * 
   * @param pElem The element to be appended
   * @param pPrevious The stack to base the stack on.
   */
  public FastStack(final E pElem, final FastStack<E> pPrevious) {
    super();
    aElem = pElem;
    aPrevious = pPrevious;
    aContainsCache = null;
  }

  /**
   * Create a new {@link FastStack}based on the given iterator.
   * 
   * @param pIterator The iterator to base on. It must return at least one
   *          element.
   */
  public FastStack(final Iterator<E> pIterator) {
    super();
    if (!pIterator.hasNext()) {
      throw new IllegalArgumentException("The iterator does not contain elements");
    }
    FastStack<E> s = new FastStack<>(pIterator.next());
    while (pIterator.hasNext()) {
      s = s.append(pIterator.next());
    }
    aPrevious = s.aPrevious;
    aElem = s.aElem;
  }

  /**
   * Create a new {@link FastStack}based on the given Iterable. The iterable may
   * not be empty.
   * 
   * @param pIterable The initial contents. May not be empty.
   */
  public FastStack(final Iterable<E> pIterable) {
    this(pIterable.iterator());
  }

  /**
   * Get a new fastStack representing the appended stack.
   * 
   * @param pElem The element to append
   * @return A new FastStack element representing the new list.
   */
  public FastStack<E> append(final E pElem) {
    return new FastStack<>(pElem, this);
  }

  /**
   * Get the FastStack representing a list with one less element.
   * 
   * @return The shorter stack
   */
  public FastStack<E> shrink() {
    return aPrevious;
  }

  /**
   * Note that this function is not efficient {@inheritDoc}.
   * 
   * @see Collection#size()
   */
  @Override
  public int size() {
    if (aPrevious == null) {
      return 1;
    }
    return aPrevious.size() + 1;
  }

  /**
   * Allways returns <code>false</code> because of FastStacks not being able to
   * be empty.
   * 
   * @return <code>false</code>
   * @see Collection#isEmpty()
   */
  @Override
  public boolean isEmpty() {
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see Collection#contains(Object)
   */
  @Override
  public boolean contains(final Object pO) {
    HashSet<E> cache;
    if (aElem == pO) {
      return true;
    }
    if (_ENABLE_CONTAINS_CACHING) {
      if (aContainsCache == null) {
        cache = null;
      } else {
        cache = aContainsCache.get();
      }
      if (cache == null) {
        cache = new HashSet<>();
        /* Use a private hash filling loop, as we don't need to reorder */
        aContainsCache = new SoftReference<>(cache);
        FastStack<E> s = this;
        while (s != null) {
          cache.add(s.aElem);
          s = s.aPrevious;
        }
      }
      return cache.contains(pO);
    }
    FastStack<E> s = aPrevious;
    while (s != null) {
      if (s.aElem == pO) {
        return true;
      }
      s = s.aPrevious;
    }
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Iterable#iterator()
   */
  @Override
  public Iterator<E> iterator() {
    return listIterator();
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.Collection#toArray()
   */
  @Override
  public Object[] toArray() {
    return getList().toArray();
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.Collection#toArray(E[])
   */
  @Override
  public <U> U[] toArray(final U[] pA) {
    return getList().toArray(pA);
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see java.util.Collection#add
   */
  @Override
  public boolean add(final E pO) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see java.util.Collection#remove(java.lang.Object)
   */
  @Override
  public boolean remove(final Object pO) {
    throw new UnsupportedOperationException();
  }

  /**
   * This method does not yet use the cache if enabled and available.
   * {@inheritDoc}
   * 
   * @see java.util.Collection#containsAll(java.util.Collection)
   */
  @Override
  public boolean containsAll(final Collection<?> pC) {
    final HashSet<Object> tmp = new HashSet<>(pC);
    return containsAll2(tmp);
  }

  /**
   * Helper function for the containsAll function. This function is recursive.
   * It checks whether the current element is part of the HashSet. It it is, the
   * element is removed. When the hash is empty, the function returns true.
   * 
   * @param pHash The hash set of elements that must be checked for containment
   * @return true if all elements are contained, false if not
   */
  private <U> boolean containsAll2(final HashSet<U> pHash) {
    pHash.remove(aElem);
    if (pHash.size() == 0) {
      return true;
    }
    if (aPrevious != null) {
      return aPrevious.containsAll2(pHash);
    }
    return false;
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see Collection#addAll(Collection)
   */
  @Override
  public boolean addAll(final Collection<? extends E> pC) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see List#addAll(int, Collection)
   */
  @Override
  public boolean addAll(final int pIndex, final Collection<? extends E> pC) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see Collection#removeAll(Collection)
   */
  @Override
  public boolean removeAll(final Collection<?> pC) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see Collection#retainAll(Collection)
   */
  @Override
  public boolean retainAll(final Collection<?> pC) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see java.util.Collection#clear()
   */
  @Override
  public void clear() {
    throw new UnsupportedOperationException();
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.List#get(int)
   */
  @Override
  public E get(final int pIndex) {
    final int size = size();
    if ((pIndex >= size) || (pIndex < 0)) {
      throw new IndexOutOfBoundsException();
    }
    return get(pIndex, size - 1);
  }

  /**
   * A helper function for the {@link #get(int)}.
   * 
   * @param pIndex The index to get the element from
   * @param pCurPos The current position
   * @return the element with the specified index
   */
  private E get(final int pIndex, final int pCurPos) {
    if (pIndex == pCurPos) {
      return aElem;
    }
    if (aPrevious == null) {
      throw new IndexOutOfBoundsException();
    }
    return aPrevious.get(pIndex, pCurPos - 1);
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see java.util.List#set
   */
  @Override
  public E set(final int pIndex, final E pElement) {
    throw new UnsupportedOperationException();
  }

  /**
   * Unsupported. {@inheritDoc}
   * 
   * @see java.util.List#add(int, Object)
   */
  @Override
  public void add(final int pIndex, final E pElement) {
    throw new UnsupportedOperationException();
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.List#remove(int)
   */
  @Override
  public E remove(final int pIndex) {
    throw new UnsupportedOperationException();
  }

  /**
   * The current implementation is very slow. {@inheritDoc}
   * 
   * @see java.util.List#indexOf(java.lang.Object)
   */
  @Override
  public int indexOf(final Object pO) {
    return getList().indexOf(pO);
  }

  /**
   * The current implementation is very slow. {@inheritDoc}
   * 
   * @see java.util.List#lastIndexOf(java.lang.Object)
   */
  @Override
  public int lastIndexOf(final Object pO) {
    return getList().lastIndexOf(pO);
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.List#listIterator()
   */
  @Override
  public ListIterator<E> listIterator() {
    return new FastStackIterator<>(this);
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.List#listIterator(int)
   */
  @Override
  public ListIterator<E> listIterator(final int pIndex) {
    return new FastStackIterator<>(this, pIndex);
  }

  /**
   * For now unsupported, but could be implemented with a subclass.
   * 
   * @param pFromIndex the starting index
   * @param pToIndex the end index
   * @return The resulting list
   * @see java.util.List#subList(int, int)
   */
  @Override
  public List<E> subList(final int pFromIndex, final int pToIndex) {
    throw new UnsupportedOperationException();
  }

  /**
   * {@inheritDoc}
   * 
   * @todo This function is notoriously slow
   */
  @Override
  public String toString() {
    return "[" + toString2() + "]";
  }

  /**
   * Helper function for {@link #toString()}.
   * 
   * @return a partial string
   */
  private StringBuilder toString2() {
    if (aPrevious == null) {
      return new StringBuilder(aElem.toString());
    }
    return aPrevious.toString2().append(", ").append(aElem.toString());
  }

  /**
   * Get the last item in the stack.
   * 
   * @return the element
   */
  public E getLast() {
    return aElem;
  }

  /**
   * Get the last x element in the stack.
   * 
   * @param pReverseIndex The index from the end
   * @return the element
   */
  public E getLast(final int pReverseIndex) {
    if (pReverseIndex == 0) {
      return aElem;
    }

    return aPrevious.getLast(pReverseIndex - 1);
  }

  /**
   * Flush the cache for this stack's containscache.
   */
  public void flushCache() {
    if (_ENABLE_CONTAINS_CACHING) {
      aContainsCache = null;
    }
  }

  /**
   * Check the cache status.
   * 
   * @return <code>true</code> if the contains function is cached,
   *         <code>false</code> if not.
   */
  public boolean isCached() {
    if (_ENABLE_CONTAINS_CACHING) {
      return aContainsCache != null;
    }

    return false;
  }

  /**
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object pObj) {
    if (pObj == null) {
      return false;
    }
    if (pObj == this) {
      return true;
    }
    if (pObj.getClass() == FastStack.class) {
      final FastStack<?> f = (FastStack<?>) pObj;
      if (!aElem.equals(f.aElem)) {
        return false;
      }
      if (aPrevious == null) {
        return f.aPrevious == null;
      }
      return aPrevious.equals(f.aPrevious);
    }
    return getList().equals(pObj);
  }

  @Override
  public int hashCode() {
    if (aPrevious == null) {
      return aElem.hashCode();
    }
    return (super.hashCode() * Const._HASHPRIME) ^ aElem.hashCode();
  }
}
