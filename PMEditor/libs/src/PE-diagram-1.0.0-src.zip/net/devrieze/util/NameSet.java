/*
 * Created on Nov 3, 2003
 *
 */

package net.devrieze.util;

import java.util.Collection;
import java.util.HashMap;


/**
 * <p>
 * The NameSet implements a Set of Named items that is backed by a HashMap. This
 * allows for fast finding out whether an item is in the set. However, the
 * NameSet also tries to implement most methods associated with the Map
 * interface. This unfortunately is not completely possible because of name
 * clashes. By default the set does not maintain order, but it can be
 * constructed to do so.
 * </p>
 * <p>
 * <b>Note </b> that the named elements should not change name midway, or the
 * retrieval will not be reliable. Similarly to the issues in {@link HashMap}
 * </p>
 *
 * @param <E> The type of the elements of the set
 * @author Paul de Vrieze
 * @version 1.1 $Revision$
 */
public final class NameSet<E extends Named> extends AbstractReadMap<String, E, Named> {

  private static final boolean DEFAULTSORTSTATE = false;

  /**
   * Creates a new NameSet object.
   */
  public NameSet() {
    this(DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pSorted Indicates whether the set should maintain order.
   */
  public NameSet(final boolean pSorted) {
    super(pSorted);
  }

  /**
   * Creates a new NameSet object with the specified initial size.
   *
   * @param pSize initial size
   */
  public NameSet(final int pSize) {
    this(pSize, DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object with the specified initial size.
   *
   * @param pSize initial size
   * @param pSorted Indicates whether the set should maintain order.
   */
  public NameSet(final int pSize, final boolean pSorted) {
    super(pSize, pSorted);
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pCollection The collection to initialise the set with
   */
  public NameSet(final Iterable<? extends E> pCollection) {
    this(pCollection, DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pCollection The collection to initialise the set with
   * @param pSorted Indicates whether the set should maintain order.
   */
  public NameSet(final Iterable<? extends E> pCollection, final boolean pSorted) {
    super(pCollection, pSorted);
  }

  /**
   * Create a new NameSet.
   *
   * @param pArraySource The array of Named elements that need to initially fill
   *          the NameSet
   */
  public NameSet(final E[] pArraySource) {
    this(pArraySource, DEFAULTSORTSTATE);
  }

  /**
   * Create a new NameSet.
   *
   * @param pArraySource The array of Named elements that need to initially fill
   *          the NameSet
   * @param pSorted Indicates whether the set should maintain order.
   */
  public NameSet(final E[] pArraySource, final boolean pSorted) {
    super(pArraySource, pSorted);
  }

  @Override
  protected String getKey(Named pValue) {
    return pValue.getName();
  }

  @Override
  protected Named asElement(Object pObject) {
    if (pObject instanceof Named) {
      return (Named) pObject;
    }
    return null;
  }

  /**
   * Check whether the specified element is contained in the NameSet.
   *
   * @param pObject The Name of the object
   * @return <code>true</code> if contained, <code>false</code> if not
   * @see Collection#contains(Object)
   */
  public boolean contains(final E pObject) {
    return containsKey(pObject.getName());
  }
}
