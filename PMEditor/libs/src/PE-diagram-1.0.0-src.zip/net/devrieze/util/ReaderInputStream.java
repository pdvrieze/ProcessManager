package net.devrieze.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.*;


public class ReaderInputStream extends InputStream {

  private final Reader aReader;

  private final CharsetEncoder aEncoder;

  private final CharBuffer aIn;

  private final ByteBuffer aOut;

  public ReaderInputStream(final Charset charset, final Reader reader) {
    aReader = reader;
    aEncoder = charset.newEncoder();
    aIn = CharBuffer.allocate(1024);
    aOut = ByteBuffer.allocate(Math.round((1024 * aEncoder.averageBytesPerChar()) + 0.5f));
    aIn.position(aIn.limit());
    aOut.position(aOut.limit());
  }

  @Override
  public int read() throws IOException {
    if (aOut.remaining() == 0) {

      aOut.rewind();

      updateBuffers();
    }
    if (aOut.remaining() == 0) {
      return -1;
    }
    return aOut.get();
  }


  @Override
  public int read(final byte[] pB, final int pOff, final int pLen) throws IOException {
    final int offset = pOff;
    // If we still have stuff in the buffer, flush that first.
    if (aOut.remaining() > 0) {
      final int length = Math.min(aOut.remaining(), pLen);
      aOut.get(pB, offset, length);
      return length;
    } else {
      final ByteBuffer out = ByteBuffer.wrap(pB, pOff, pLen);
      updateBuffers2(out);
      if ((out.remaining() == 0) && (pLen > 0)) {
        return -1;
      }
      return out.remaining();
    }
  }

  private void updateBuffers() throws IOException, CharacterCodingException {
    aOut.limit(aOut.capacity());
    updateBuffers2(aOut);
  }

  private void updateBuffers2(final ByteBuffer pOut) throws IOException, CharacterCodingException {
    pOut.mark();
    CoderResult encodeResult = null;
    if (aIn.remaining() == 0) {
      aIn.rewind();
      aIn.limit(aIn.capacity());
      final int readResult = aReader.read(aIn);
      if (readResult == -1) {
        aIn.limit(aIn.position());
        aIn.position(0);
        encodeResult = aEncoder.encode(aIn, pOut, true);
        pOut.limit(pOut.position());
        pOut.reset();
        return;
      } else {
        aIn.limit(readResult);
        aIn.position(0);
      }
    }
    encodeResult = aEncoder.encode(aIn, pOut, false);
    pOut.limit(pOut.position());
    pOut.reset();
    if (encodeResult.isError()) {
      encodeResult.throwException();
    }
  }

  public CodingErrorAction malformedInputAction() {
    return aEncoder.malformedInputAction();
  }

  public final CharsetEncoder onMalformedInput(final CodingErrorAction pNewAction) {
    return aEncoder.onMalformedInput(pNewAction);
  }

  public CodingErrorAction unmappableCharacterAction() {
    return aEncoder.unmappableCharacterAction();
  }

  public final CharsetEncoder onUnmappableCharacter(final CodingErrorAction pNewAction) {
    return aEncoder.onUnmappableCharacter(pNewAction);
  }

  @Override
  public void close() throws IOException {
    aReader.close();
  }

  /**
   * Skip characters, not bytes.
   */
  @Override
  public long skip(long pN) throws IOException {
    return aReader.skip(pN);
  }

  @Override
  public boolean markSupported() {
    return aReader.markSupported();
  }

  @Override
  public synchronized void mark(int pReadAheadLimit) {
    try {
      aReader.mark(pReadAheadLimit);
    } catch (IOException ex) {
      throw new RuntimeException(ex);
    }
  }

  @Override
  public synchronized void reset() throws IOException {
    aReader.reset();
  }

}
