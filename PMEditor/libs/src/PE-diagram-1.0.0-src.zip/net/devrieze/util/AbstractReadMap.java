/*
 * Created on Nov 3, 2003
 *
 */

package net.devrieze.util;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


/**
 * <p>
 * The NameSet implements a Set of Named items that is backed by a HashMap. This
 * allows for fast finding out whether an item is in the set. However, the
 * NameSet also tries to implement most methods associated with the Map
 * interface. This unfortunately is not completely possible because of name
 * clashes. By default the set does not maintain order, but it can be
 * constructed to do so.
 * </p>
 * <p>
 * <b>Note </b> that the named elements should not change name midway, or the
 * retrieval will not be reliable. Similarly to the issues in {@link HashMap}
 * </p>
 *
 * @param <E> The type of the elements of the set
 * @author Paul de Vrieze
 * @version 1.1 $Revision$
 */
public abstract class AbstractReadMap<K, V extends E, E> extends AbstractSet<V> implements ReadMap<K, V> {

  private static final boolean DEFAULTSORTSTATE = false;

  private Map<K, V> aStore;

  /**
   * Creates a new NameSet object.
   */
  public AbstractReadMap() {
    this(DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pSorted Indicates whether the set should maintain order.
   */
  public AbstractReadMap(final boolean pSorted) {
    aStore = pSorted ? new LinkedHashMap<K, V>() : new HashMap<K, V>();
  }

  /**
   * Creates a new NameSet object with the specified initial size.
   *
   * @param pSize initial size
   */
  public AbstractReadMap(final int pSize) {
    this(pSize, DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object with the specified initial size.
   *
   * @param pSize initial size
   * @param pSorted Indicates whether the set should maintain order.
   */
  public AbstractReadMap(final int pSize, final boolean pSorted) {
    if (pSorted) {
      aStore = new LinkedHashMap<>(pSize);
    } else {
      aStore = new HashMap<>(pSize);
    }
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pCollection The collection to initialise the set with
   */
  public AbstractReadMap(final Iterable<? extends V> pCollection) {
    this(pCollection, DEFAULTSORTSTATE);
  }

  /**
   * Creates a new NameSet object.
   *
   * @param pCollection The collection to initialise the set with
   * @param pSorted Indicates whether the set should maintain order.
   */
  public AbstractReadMap(final Iterable<? extends V> pCollection, final boolean pSorted) {
    if (pSorted) {
      if (pCollection instanceof Collection) {
        aStore = new LinkedHashMap<>(((Collection<?>) pCollection).size());
      } else {
        aStore = new LinkedHashMap<>();
      }
    } else {
      if (pCollection instanceof Collection) {
        aStore = new HashMap<>(((Collection<?>) pCollection).size());
      } else {
        aStore = new HashMap<>();
      }
    }

    for (final V i : pCollection) {
      add(i);
    }
  }

  /**
   * Create a new NameSet.
   *
   * @param pArraySource The array of Named elements that need to initially fill
   *          the NameSet
   */
  public AbstractReadMap(final V[] pArraySource) {
    this(pArraySource, DEFAULTSORTSTATE);
  }

  /**
   * Create a new NameSet.
   *
   * @param pArraySource The array of Named elements that need to initially fill
   *          the NameSet
   * @param pSorted Indicates whether the set should maintain order.
   */
  public AbstractReadMap(final V[] pArraySource, final boolean pSorted) {
    this(pArraySource == null ? 0 : pArraySource.length, pSorted);

    if (pArraySource != null) {
      for (final V n : pArraySource) {
        add(n);
      }
    }
  }

  /**
   * @see AbstractCollection#isEmpty()
   */
  @Override
  public boolean isEmpty() {
    return aStore.isEmpty();
  }

  /**
   * Add the specified value to the set. This function will not allow duplicate
   * names.
   *
   * @param pObject The value to add
   * @return <code>true</code> if succeeded, <code>false</code> if not
   * @see Collection#add(Object)
   */
  @Override
  public boolean add(final V pObject) {
    /*
     * if (!(pObject instanceof Named)) { throw new
     * IllegalArgumentException("The type of the value put into the map is not
     * an implementation of Named"); }
     */

    final K name = getKey(pObject);

    if (aStore.containsKey(name)) {
      return false;
    }

    aStore.put(name, pObject);
    return true;
  }

  /**
   * Method that subclasses must implement that is used to determine the key of an entered object.
   * @param pValue The object for which they key should be determined
   * @return The key for the object.
   */
  protected abstract K getKey(E pValue);

  /**
   * Method that allows an object to be cast to the element type.
   *
   * @param pObject The object to be cast. <code>null</code> values should not
   *          throw, but can not be distinguished from cast failures
   * @return <code>null</code> if not an instance, the casted object otherwise.
   */
  protected abstract E asElement(Object pObject);

  /**
   * @see AbstractCollection#clear()
   */
  @Override
  public void clear() {
    aStore.clear();
  }

  /**
   * Check whether the specified element is contained in the NameSet. Children
   * are encouraged to override this to allow for key based lookup. Clients
   * should consider {@link #containsKey(Object)} or
   * {@link #containsValue(Object)}
   *
   * @param pObject The Name of the object
   * @return <code>true</code> if contained, <code>false</code> if not
   * @see Map#containsValue(Object)
   */
  @Override
  public boolean contains(final Object pObject) {
    E elem = asElement(pObject);
    if (elem==null) {
      return false;
    }
    return containsKey(getKey(elem));
  }

  /**
   * Check whether the specified key is contained in the set.
   *
   * @param pKey The name to check
   * @return <code>true</code> if a Named with the specified named is contained
   * @see Map#containsKey(Object)
   */
  @Override
  public boolean containsKey(final K pKey) {
    return aStore.containsKey(pKey);
  }

  /**
   * {@inheritDoc}
   *
   * @see Map#containsValue(Object)
   */
  @Override
  public boolean containsValue(final V pValue) {
    return containsKey(getKey(pValue));
  }

  /**
   * {@inheritDoc}
   *
   * @see Map#get(Object)
   */
  @Override
  public V get(final K pKey) {
    return aStore.get(pKey);
  }

  /** {@inheritDoc} */
  @Override
  public boolean equals(final Object pObject) {
    if (this == pObject) {
      return true;
    }
    return aStore.equals(pObject);
  }

  /**
   * @see AbstractSet#hashCode()
   */
  @Override
  public int hashCode() {
    return aStore.hashCode();
  }

  /**
   * {@inheritDoc}
   *
   * @see Collection#iterator()
   */
  @Override
  public Iterator<V> iterator() {
    return aStore.values().iterator();
  }

  /**
   * {@inheritDoc}
   *
   * @see Map#keySet()
   */
  @Override
  public Set<K> keySet() {
    return aStore.keySet();
  }

  /**
   * Remove the given element if it is present.
   * @see Collection#remove(Object)
   */
  @Override
  public boolean remove(final Object pObject) {
    E elem = asElement(pObject);
    if (elem == null) {
      throw new IllegalArgumentException("The type of the value put into the map is not an Attribute");
    }

    return aStore.remove(getKey(elem)) != null;
  }

  /**
   * {@inheritDoc}
   *
   * @see Map#size()
   */
  @Override
  public int size() {
    return aStore.size();
  }

  /**
   * {@inheritDoc}
   *
   * @see Collection#toArray()
   */
  @Override
  public Object[] toArray() {
    final Object[] array = new Object[aStore.size()];
    final Iterator<V> i = iterator();

    for (int j = 0; i.hasNext(); j++) {
      array[j] = i.next();
    }

    return array;
  }

  /**
   * {@inheritDoc}
   *
   * @see AbstractCollection#toString()
   */
  @Override
  public String toString() {
    return aStore.toString();
  }

  /**
   * {@inheritDoc}
   *
   * @see Map#values()
   */
  @Override
  public Collection<V> values() {
    return aStore.values();
  }
}
