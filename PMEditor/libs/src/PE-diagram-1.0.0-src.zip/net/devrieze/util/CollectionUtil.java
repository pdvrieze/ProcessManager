/*
 * Created on Dec 1, 2003
 *
 */

package net.devrieze.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 * This class provides functions that the Collections class does not.
 *
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class CollectionUtil extends Object {


  private static class MonitoringIterator<T> implements Iterator<T> {

    private final Collection<CollectionChangeListener<? super T>> aListeners;

    private final Iterator<T> aOriginal;

    private T last;

    @Override
    public boolean hasNext() {
      return aOriginal.hasNext();
    }

    @Override
    public T next() {
      last = aOriginal.next();
      return last;
    }

    @Override
    public void remove() {
      aOriginal.remove();
      fireElementRemoved();
      last = null;
    }

    private void fireElementRemoved() {
      RuntimeException error = null;
      if (aListeners != null) {
        for (final CollectionChangeListener<? super T> listener : aListeners) {
          try {
            listener.elementRemoved(last);
          } catch (final RuntimeException e) {
            if (error == null) {
              error = e;
            }
          }
        }
        if (error != null) {
          throw error;
        }
      }
    }

    public MonitoringIterator(final Collection<CollectionChangeListener<? super T>> pListeners, final Iterator<T> pOriginal) {
      aListeners = pListeners;
      aOriginal = pOriginal;
    }

  }

  private static class MonitoringCollectionAdapter<V> implements MonitorableCollection<V> {

    private final Collection<V> aCollection;

    private Set<CollectionChangeListener<? super V>> aListeners;


    public MonitoringCollectionAdapter(final Collection<V> collection) {
      aCollection = collection;
    }

    @Override
    public void addCollectionChangeListener(final CollectionChangeListener<? super V> pListener) {
      getListeners().add(pListener);
    }

    @Override
    public void removeCollectionChangeListener(final CollectionChangeListener<? super V> pListener) {
      if (aListeners != null) {
        getListeners().remove(pListener);
      }
    }

    private Set<CollectionChangeListener<? super V>> getListeners() {
      if (aListeners == null) {
        aListeners = new HashSet<>();
      }
      return aListeners;
    }

    private void fireAddEvent(final V pElement) {
      if (aListeners != null) {
        MultiException error = null;
        for (final CollectionChangeListener<? super V> listener : aListeners) {
          try {
            listener.elementAdded(pElement);
          } catch (final RuntimeException e) {
            error = MultiException.add(error, e);
          }
        }
        MultiException.throwIfError(error);
      }
    }

    private void fireClearEvent() {
      if (aListeners != null) {
        MultiException error = null;
        for (final CollectionChangeListener<? super V> listener : aListeners) {
          try {
            listener.collectionCleared();
          } catch (final RuntimeException e) {
            error = MultiException.add(error, e);
          }
        }
        MultiException.throwIfError(error);
      }
    }

    private void fireRemoveEvent(final V pElement) {
      if (aListeners != null) {
        MultiException error = null;
        for (final CollectionChangeListener<? super V> listener : aListeners) {
          try {
            listener.elementRemoved(pElement);
          } catch (final RuntimeException e) {
            error = MultiException.add(error, e);
          }
        }
        MultiException.throwIfError(error);
      }
    }

    @Override
    public boolean add(final V pElement) {
      final boolean result = aCollection.add(pElement);
      if (result) {
        fireAddEvent(pElement);
      }
      return result;
    }

    @Override
    public boolean addAll(final Collection<? extends V> pC) {
      boolean result = false;
      for (final V elem : pC) {
        result |= add(elem);
      }
      return result;
    }

    @Override
    public void clear() {
      aCollection.clear();
      fireClearEvent();
    }

    @Override
    public boolean contains(final Object pO) {
      return aCollection.contains(pO);
    }

    @Override
    public boolean containsAll(final Collection<?> pC) {
      return aCollection.containsAll(pC);
    }

    @Override
    public boolean equals(final Object pO) {
      return aCollection.equals(pO);
    }

    @Override
    public int hashCode() {
      return aCollection.hashCode();
    }

    @Override
    public boolean isEmpty() {
      return aCollection.isEmpty();
    }

    @Override
    public Iterator<V> iterator() {
      return monitoringIterator(aListeners, aCollection.iterator());
    }

    @Override
    public boolean remove(final Object pO) {
      final boolean result = aCollection.remove(pO);
      if (result) {
        @SuppressWarnings("unchecked")
        final V element = (V) pO;
        fireRemoveEvent(element);
      }
      return result;
    }

    @Override
    public boolean removeAll(final Collection<?> pC) {
      boolean result = false;
      for (final Object o : pC) {
        result |= remove(o);
      }
      return result;
    }

    @Override
    public boolean retainAll(final Collection<?> pC) {
      boolean modified = false;
      final Iterator<V> e = iterator();
      while (e.hasNext()) {
        if (!pC.contains(e.next())) {
          e.remove();
          modified = true;
        }
      }
      return modified;
    }

    @Override
    public int size() {
      return aCollection.size();
    }

    @Override
    public Object[] toArray() {
      return aCollection.toArray();
    }

    @Override
    public <T> T[] toArray(final T[] pA) {
      return aCollection.toArray(pA);
    }

  }

  /**
   * This is only a static class, so the constructor only makes sense for
   * subclasses.
   */
  private CollectionUtil() {
    /* This class should not be instanciated */
  }

  /**
   * Check whether the collection contains only elements assignable to specified
   * class. This should allways hold when generics are used by the compiler
   *
   * @param <T> The type of the elements that returned collection should
   *          contain.
   * @param <X> The type of the elements of the checked collection.
   * @param pClass The class of which the elements need to be in the collection.
   * @param pCollection The collection to be checked
   * @return the checked collection. This allows faster assignment.
   * @throws ClassCastException When the element is not of the right class.
   */
  public static <T, X extends T> Collection<X> checkClass(final Class<T> pClass, final Collection<X> pCollection) throws ClassCastException {
    for (final Object x : pCollection) {
      if (!pClass.isInstance(x)) {
        throw new ClassCastException("An element of the collection is not of the required type: " + pClass.getName());
      }
    }

    return pCollection;
  }

  public static <T extends Comparable<? super T>> List<T> sortedList(final Collection<T> pCollection) {
    final List<T> result = new ArrayList<>(pCollection);
    Collections.sort(result);
    return result;
  }

  public static <T, U> HashMap<T, U> createMap(final T pKey, final U pValue) {
    final HashMap<T, U> map = new HashMap<>();
    map.put(pKey, pValue);
    return map;
  }

  /**
   * Create a hashmap from a set of key-value pairs.
   *
   * @param <T> The type of the keys to the hashmap
   * @param <U> The type of the values.
   * @param pTupples The elements to put into the map.
   * @return The resulting hashmap.
   */
  public static <T, U> HashMap<T, U> hashMap(@SuppressWarnings("unchecked") final Tupple<? extends T, ? extends U>... pTupples) {
    // Make the new hashmap have a capacity 125% of the amount of tuples.
    final HashMap<T, U> result = new HashMap<>(pTupples.length + (pTupples.length >> 2));
    for (final Tupple<? extends T, ? extends U> t : pTupples) {
      result.put(t.getElem1(), t.getElem2());
    }
    return result;
  }

  public static <T extends Enum<T>, U> EnumMap<T, U> enumMap(@SuppressWarnings("unchecked") final Tupple<? extends T, ? extends U>... pTupples) {
    if (pTupples.length < 1) {
      throw new IllegalArgumentException("For an enumeration map simple creator, at least one element must be present");
    }
    @SuppressWarnings("unchecked")
    final Class<T> type = (Class<T>) Enum.class.asSubclass(pTupples[0].getElem1().getClass());
    final EnumMap<T, U> result = new EnumMap<>(type);
    for (final Tupple<? extends T, ? extends U> t : pTupples) {
      result.put(t.getElem1(), t.getElem2());
    }
    return result;
  }

  /**
   * @deprecated Use {@link Collections#singletonList(Object)}
   */
  @Deprecated
  public static <T> List<T> singletonList(final T pElem) {
    return Collections.singletonList(pElem);
  }

  public static <T> Iterator<T> monitoringIterator(final Collection<CollectionChangeListener<? super T>> listeners, final Iterator<T> original) {
    return new MonitoringIterator<>(listeners, original);
  }

  public static <T> MonitorableCollection<T> monitorableCollection(final Collection<T> pCollection) {
    return new MonitoringCollectionAdapter<>(pCollection);
  }

  public static boolean containsInstances(final Iterable<?> pCollection, final Class<?>... pClasses) {
    for (final Object element : pCollection) {
      for (final Class<?> c : pClasses) {
        if (c.isInstance(element)) {
          return true;
        }
      }
    }
    return false;
  }

  public static <T, V extends Collection<T>> V addInstancesOf(final V pTarget, final Iterable<?> pSource, @SuppressWarnings("unchecked") final Class<? extends T>... pVerifiers) {
    for (final Object element : pSource) {
      for (final Class<? extends T> c : pVerifiers) {
        if (c.isInstance(element)) {
          final T e = c.cast(element);
          pTarget.add(e);
          break;
        }
      }
    }
    return pTarget;
  }


  public static <T, V extends Collection<T>> V addNonInstancesOf(final V pTarget, final Iterable<? extends T> pSource, final Class<?>... pVerifiers) {
    for (final T element : pSource) {
      for (final Class<?> c : pVerifiers) {
        if (!c.isInstance(element)) {
          pTarget.add(element);
          break;
        }
      }
    }
    return pTarget;
  }

  public static <T> List<T> copy(Collection<? extends T> pOrig) {
    if (pOrig==null) { return null; }
    if (pOrig.size()==1) {
      return Collections.<T>singletonList(pOrig.iterator().next());
    }
    ArrayList<T> result = new ArrayList<>(pOrig.size());
    result.addAll(pOrig);
    return result;
  }

}
