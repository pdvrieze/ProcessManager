package net.devrieze.util;

import java.util.ArrayList;
import java.util.Collection;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.namespace.QName;


@XmlAccessorType(XmlAccessType.NONE)
public class JAXBCollectionWrapper {

  private final Collection<?> aCollection;

  private final Class<?> aElementType;

  public JAXBCollectionWrapper() {
    aCollection = new ArrayList<>();
    aElementType = Object.class;
  }

  public JAXBCollectionWrapper(final Collection<?> pCollection, final Class<?> pElementType) {
    aCollection = pCollection;
    aElementType = pElementType;
  }

  @XmlMixed
  @XmlAnyElement(lax = true)
  public Collection<?> getElements() {
    return aCollection;
  }

  public JAXBElement<JAXBCollectionWrapper> getJAXBElement(final QName pName) {
    return new JAXBElement<>(pName, JAXBCollectionWrapper.class, this);
  }

  public Class<?> getElementType() {
    return aElementType;
  }

}
