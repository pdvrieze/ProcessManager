/*
 * Created on Jan 18, 2004
 *
 */

package net.devrieze.util;

/**
 * This class imlements most methods needed to implement the Named interfaces.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractNamed implements Named {

  private static final String _NO_NULL_NAME = "A type may not have a null name";

  private final String aName;

  /**
   * Creates a new AbstractName object.
   * 
   * @param pName The name of the object
   */
  protected AbstractNamed(final String pName) {
    DebugTool.ensureParamValid(isNullAllowed() || (pName != null), _NO_NULL_NAME);
    aName = pName;
    assert (getClass() == AbstractNamed.class) || invariant();
  }

  /**
   * Get the name of the type.
   * 
   * @return The name
   */
  @Override
  public final String getName() {
    assert invariant() : "The class invariant did not hold";
    return aName;
  }

  /**
   * Use this method to specify whether null names are allowed.
   * 
   * @return whether null names are allowed
   */
  protected abstract boolean isNullAllowed();

  /**
   * The class invariant.
   * 
   * @return <code>true</code> if the invariant holds (should allways be
   *         <code>true</code>).
   */
  protected boolean invariant() {
    return isNullAllowed() || (aName != null);
  }
}
