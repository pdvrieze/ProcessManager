package net.devrieze.util;

import java.util.*;


public class PrefixMap<V> extends AbstractCollection<PrefixMap.Entry<V>> {


  private static class NodeIterator<T> implements Iterator<Entry<T>> {

    Deque<Node<T>> stack;

    public NodeIterator(final Node<T> pRoot) {
      stack = new ArrayDeque<>();
      stack.push(pRoot);
      getLeftMost();
    }

    private boolean getLeftMost() {
      final Node<T> top = stack.peek();
      if (top.aLeft != null) {
        stack.push(top.aLeft);
        if (getLeftMost()) {
          return true;
        }
      }
      if (top.value != null) {
        return true;
      }
      if (top.aBelow != null) {
        stack.push(top.aBelow);
        if (getLeftMost()) {
          return true;
        }
      }
      if (top.aRight != null) {
        stack.push(top.aRight);
        if (getLeftMost()) {
          return true;
        }
      }

      stack.pop();
      return false;
    }

    private boolean getNext() {
      Node<T> top = stack.peek();
      if (top.aBelow != null) {
        stack.push(top.aBelow);
        if (getLeftMost()) {
          return true;
        }
      }
      if (top.aRight != null) {
        stack.push(top.aRight);
        if (getLeftMost()) {
          return true;
        }
      }
      while (stack.size() > 1) {
        top = stack.pop();
        final Node<T> parent = stack.peek();
        if (top == parent.aLeft) {
          if (parent.value != null) {
            return true;
          } else {
            if (parent.aBelow != null) {
              stack.push(parent.aBelow);
              if (getLeftMost()) {
                return true;
              }
            }
          }
        }
        if (((top == parent.aLeft) || (top == parent.aBelow)) && (parent.aRight != null)) {
          stack.push(parent.aRight);
          if (getLeftMost()) {
            return true;
          }
        }
        // Must have been right arm.
      }
      // Now finished
      stack.pop();
      return false;
    }

    @Override
    public boolean hasNext() {
      return stack.size() > 0;
    }

    @Override
    public Entry<T> next() {
      final Node<T> n = stack.peek();
      if ((n == null) || (n.value == null)) {
        throw new IllegalStateException("Invalid next value in iterator");
      }
      final Entry<T> result = new Entry<>(n);
      getNext();

      return result;
    }

    @Override
    public void remove() {
      // TODO Auto-generated method stub
      //
      throw new UnsupportedOperationException("Not yet implemented");

    }

  }

  private static class CompareResult {

    public static final CompareResult LEFT = new CompareResult(null, XCompareResult.XLEFT);

    @SuppressWarnings("unused")
    public static final CompareResult ABOVE = new CompareResult(null, XCompareResult.XABOVE);

    public static final CompareResult EQUAL = new CompareResult(null, XCompareResult.XEQUAL);

    public static final CompareResult BELOW = new CompareResult(null, XCompareResult.XBELOW);

    public static final CompareResult RIGHT = new CompareResult(null, XCompareResult.XRIGHT);

    final CharSequence commonPrefix;

    final XCompareResult cmp;

    private CompareResult(final CharSequence pCommonPrefix, final XCompareResult pCmp) {
      commonPrefix = pCommonPrefix;
      cmp = pCmp;
    }

    public boolean isLeft() {
      return cmp.isLeft();
    }

    public boolean isAbove() {
      return cmp.isAbove();
    }

    public boolean isEqual() {
      return cmp.isEqual();
    }

    public boolean isBelow() {
      return cmp.isBelow();
    }

    public boolean isEqOrBelow() {
      return cmp.isEqOrBelow();
    }

    @SuppressWarnings("unused")
    public boolean isEqOrAbove() {
      return cmp.isEqOrBelow();
    }

    public boolean isRight() {
      return cmp.isRight();
    }

    public CompareResult invert() {
      return new CompareResult(commonPrefix, cmp.invert());
    }

    public boolean hasCommonPrefix() {
      return commonPrefix != null;
    }

    @Override
    public String toString() {
      if (commonPrefix == null) {
        return cmp.toString();
      } else {
        return cmp.toString() + "[\"" + commonPrefix + "\"]";
      }
    }

  }

  private enum XCompareResult {
    XLEFT,
    XABOVE,
    XEQUAL,
    XBELOW,
    XRIGHT;

    public XCompareResult invert() {
      switch (this) {
        case XLEFT:
          return XRIGHT;
        case XABOVE:
          return XBELOW;
        case XEQUAL:
          return XEQUAL;
        case XBELOW:
          return XABOVE;
        case XRIGHT:
          return XLEFT;
        default:
          throw new RuntimeException("Should be unreachable");
      }
    }

    public boolean isLeft() {
      return this == XLEFT;
    }

    public boolean isAbove() {
      return this == XABOVE;
    }

    public boolean isEqual() {
      return this == XEQUAL;
    }

    public boolean isBelow() {
      return this == XBELOW;
    }

    public boolean isEqOrBelow() {
      return (this == XEQUAL) || (this == XBELOW);
    }

    public boolean isRight() {
      return this == XRIGHT;
    }
  }

  private static final class Node<T> {

    private Node<T> aLeft;

    private Node<T> aRight;

    private Node<T> aBelow;

    public final CharSequence prefix;

    public T value;

    private int aCount;

    public Node(final CharSequence pPrefix) {
      prefix = pPrefix;
    }

    public Node(final CharSequence pPrefix, final T pValue) {
      if (pValue == null) {
        throw new NullPointerException();
      }
      prefix = pPrefix;
      value = pValue;
      aCount = 1;
    }

    public void setLeft(final Node<T> left) {
      if (aLeft != left) {
        if (aLeft != null) {
          aCount -= aLeft.aCount;
        }
        aLeft = left;
        if (aLeft != null) {
          aCount += aLeft.aCount;
        }
      }
    }

    public Node<T> getLeft() {
      return aLeft;
    }

    public void setRight(final Node<T> right) {
      if (aRight != right) {
        if (aRight != null) {
          aCount -= aRight.aCount;
        }
        aRight = right;
        if (aRight != null) {
          aCount += aRight.aCount;
        }
      }
    }

    public Node<T> getRight() {
      return aRight;
    }

    public void setBelow(final Node<T> below) {
      if (aBelow != below) {
        if (aBelow != null) {
          aCount -= aBelow.aCount;
        }
        aBelow = below;
        if (aBelow != null) {
          aCount += aBelow.aCount;
        }
      }
    }

    public Node<T> getBelow() {
      return aBelow;
    }

    public int getCount() {
      return aCount;
    }

    public int incCount(final int pIncrease) {
      aCount += pIncrease;
      return pIncrease;
    }

    @Override
    public String toString() {
      final StringBuilder result = new StringBuilder();
      result.append("(\"").append(prefix).append('"');
      if (aLeft != null) {
        result.append(", l=").append(aLeft);
      }
      if (aBelow != null) {
        result.append(", b=").append(aBelow);
      }
      if (aRight != null) {
        result.append(", r=").append(aRight);
      }
      result.append(')');
      return result.toString();
    }

    @Override
    public Node<T> clone() {
      final Node<T> result = new Node<>(prefix);
      result.aLeft = aLeft;
      result.aRight = aRight;
      result.aBelow = aBelow;
      result.value = value;
      result.aCount = aCount;
      return result;
    }
  }

  public static final class Entry<T> implements Map.Entry<CharSequence, T> {

    private final Node<T> aNode;

    public Entry(final CharSequence pKey, final T pValue) {
      aNode = pValue == null ? new Node<T>(pKey) : new Node<>(pKey, pValue);
    }

    public Entry(final Node<T> pNode) {
      aNode = pNode;
    }

    public CharSequence getPrefix() {
      return aNode.prefix;
    }

    @Override
    public CharSequence getKey() {
      return aNode.prefix;
    }

    @Override
    public T setValue(final T pValue) {
      final T result = aNode.value;
      aNode.value = pValue;
      return result;
    }

    @Override
    public T getValue() {
      return aNode.value;
    }

    @Override
    public String toString() {
      return "[\"" + aNode.prefix + "\"->" + aNode.value + "]";
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = (prime * result) + aNode.prefix.hashCode();
      result = (prime * result) + ((aNode.value == null) ? 0 : aNode.value.hashCode());
      return result;
    }

    @Override
    public boolean equals(final Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      final Entry<?> other = (Entry<?>) obj;
      if (aNode.prefix == null) {
        if (other.aNode.prefix != null) {
          return false;
        }
      } else if (!aNode.prefix.equals(other.aNode.prefix)) {
        return false;
      }
      if (aNode.value == null) {
        if (other.aNode.value != null) {
          return false;
        }
      } else if (!aNode.value.equals(other.aNode.value)) {
        return false;
      }
      return true;
    }
  }

  private Node<V> aRoot;

  public PrefixMap() {
    aRoot = new Node<>("");
  }

  @Override
  public Iterator<Entry<V>> iterator() {
    final NodeIterator<V> iter = new NodeIterator<>(aRoot);
    return iter;
    //
    //    return toList().iterator();
  }

  public List<Entry<V>> toList() {
    return toList(new ArrayList<Entry<V>>(aRoot.getCount()), aRoot);
  }

  private List<Entry<V>> toList(final List<Entry<V>> pList, final Node<V> pNode) {
    if (pNode == null) {
      return pList;
    }
    toList(pList, pNode.getLeft());
    if (pNode.value != null) {
      pList.add(new Entry<>(pNode));
    }
    toList(pList, pNode.getBelow());
    return toList(pList, pNode.getRight());
  }

  @Override
  public int size() {
    return aRoot == null ? 0 : aRoot.getCount();
  }

  @Override
  public void clear() {
    aRoot = null;
  }

  public void put(final CharSequence prefix, final V value) {
    if ((prefix == null) || (value == null)) {
      throw new NullPointerException();
    }

    final Node<V> n = new Node<>(prefix, value);
    addNode(CompareResult.BELOW, 0, aRoot, n);
  }

  private int addNode(final CompareResult compare, final int prefixLength, final Node<V> pParent, final Node<V> pNode) {
    if (pNode == null) {
      return 0;
    }
    if (compare.isLeft()) {
      if (pParent.getLeft() == null) {
        pParent.setLeft(pNode);
        return pNode.getCount();
      } else {
        final CompareResult newCompare = prefixCompare(prefixLength, pParent.getLeft().prefix, pNode.prefix);

        if (newCompare.isAbove()) {
          final Node<V> oldLeft = pParent.getLeft();
          pParent.setLeft(pNode);
          return pParent.incCount(addNode(newCompare.invert(), prefixLength, pParent.getLeft(), oldLeft));
        }
        if (newCompare.hasCommonPrefix()) {
          final Node<V> intermediate = new Node<>(newCompare.commonPrefix);
          intermediate.setBelow(pParent.getLeft());
          pParent.setLeft(intermediate);
        }
        return pParent.incCount(addNode(newCompare, prefixLength, pParent.getLeft(), pNode));
      }
    } else if (compare.isEqOrBelow()) {
      if (pParent.getBelow() == null) {
        pParent.setBelow(pNode);
        return pNode.getCount();
      } else {
        final CompareResult newCompare = prefixCompare(pParent.prefix.length(), pParent.getBelow().prefix, pNode.prefix);

        if (newCompare.isAbove()) {
          final Node<V> oldBelow = pParent.getBelow();
          pParent.setBelow(pNode);
          return pParent.incCount(addNode(newCompare.invert(), prefixLength, pParent.getBelow(), oldBelow));
        }
        if (newCompare.hasCommonPrefix()) {
          final Node<V> intermediate = new Node<>(newCompare.commonPrefix);
          takeWings(prefixLength, intermediate, pParent.getBelow());
          intermediate.setBelow(pParent.getBelow());
          pParent.setBelow(intermediate);
          return pParent.incCount(addNode(CompareResult.BELOW, intermediate.prefix.length(), intermediate, pNode));
        } else {
          return pParent.incCount(addNode(newCompare, prefixLength, pParent.getBelow(), pNode));
        }
      }
    } else if (compare.isRight()) { // compare >0
      if (pParent.getRight() == null) {
        pParent.setRight(pNode);
        return pNode.getCount();
      } else {
        final CompareResult newCompare = prefixCompare(prefixLength, pParent.getRight().prefix, pNode.prefix);

        if (newCompare.isAbove()) {
          final Node<V> oldRight = pParent.getRight();
          pParent.setRight(pNode);
          return pParent.incCount(addNode(newCompare.invert(), prefixLength, pParent.getRight(), oldRight));
        }
        if (newCompare.hasCommonPrefix()) {
          final Node<V> intermediate = new Node<>(newCompare.commonPrefix);
          intermediate.setBelow(pParent.getRight());
          pParent.setRight(intermediate);
        }
        return pParent.incCount(addNode(newCompare, prefixLength, pParent.getRight(), pNode));
      }

    } else {
      throw new RuntimeException("Not expected");
    }
    //    rebalance(pParent);
    //    return increase;
  }

  private void takeWings(final int prefixLength, final Node<V> pTarget, final Node<V> pChild) {
    if (pChild.getLeft() != null) {
      final CompareResult compare = prefixCompare(prefixLength, pTarget.prefix, pChild.getLeft().prefix);
      if (compare.isLeft()) {
        final Node<V> left = pChild.getLeft();
        pChild.setLeft(null);
        addNode(compare, prefixLength, pTarget, left);
      } else if (!compare.isEqOrBelow()) {
        throw new RuntimeException("Unexpected code path");
      }
    }
    if (pChild.getRight() != null) {
      final CompareResult compare = prefixCompare(prefixLength, pTarget.prefix, pChild.getRight().prefix);
      if (compare.isRight()) {
        final Node<V> right = pChild.getRight();
        pChild.setRight(null);
        addNode(compare, prefixLength, pTarget, right);
      } else if (!compare.isEqOrBelow()) {
        throw new RuntimeException("Unexpected code path");
      }
    }
  }

  private CompareResult prefixCompare(final CharSequence s1, final CharSequence s2) {
    return prefixCompare(0, s1, s2);
  }

  private CompareResult prefixCompare(final int pOffset, final CharSequence s1, final CharSequence s2) {
    assert (s1.length() >= pOffset) && (s2.length() >= pOffset) && s2.toString().startsWith(s1.subSequence(0, pOffset).toString());
    if (s2.length() < s1.length()) {
      return prefixCompare(pOffset, s2, s1).invert();
    }
    for (int i = pOffset; i < s1.length(); ++i) {
      final char c = s1.charAt(i);
      final char d = s2.charAt(i);
      if (d < c) {
        return i == pOffset ? CompareResult.LEFT : new CompareResult(s1.subSequence(0, i), XCompareResult.XLEFT);
      } else if (d > c) {
        return i == pOffset ? CompareResult.RIGHT : new CompareResult(s1.subSequence(0, i), XCompareResult.XRIGHT);
      }
    }
    if (s1.length() == s2.length()) {
      return CompareResult.EQUAL;
    } else {
      return CompareResult.BELOW;
    }
  }

  @Override
  public boolean add(final Entry<V> entry) {
    put(entry.getPrefix(), entry.getValue());
    return true;
  }

  @Override
  public boolean contains(final Object pO) {
    if (!(pO instanceof Entry)) {
      return false;
    }
    final Entry<?> entry = (Entry<?>) pO;
    Node<V> candidate = getNodeForPrefix(aRoot, entry.getPrefix());
    while ((candidate != null) && candidate.prefix.equals(entry.getPrefix())) {
      if (candidate.value.equals(entry.getValue())) {
        return true;
      }
      candidate = candidate.getBelow();
    }
    return false;
  }

  public boolean containsKey(final Object pKey) {
    if (!(pKey instanceof CharSequence)) {
      return false;
    }
    final String key = pKey.toString();
    final Node<V> candidate = getNodeForPrefix(aRoot, key);
    if ((candidate != null) && candidate.prefix.equals(key)) {
      return true;
    }
    return false;
  }

  public boolean containsValue(final Object pKey) {
    if (pKey == null) {
      return false;
    }
    for (final Entry<V> entry : this) {
      if (pKey.equals(entry.getValue())) {
        return true;
      }
    }
    return false;
  }

  private Node<V> getNodeForPrefix(final Node<V> pNode, final CharSequence pPrefix) {
    final CompareResult comparison = prefixCompare(pNode.prefix, pPrefix);
    if (comparison.isEqual()) {
      return pNode;
    }
    if (comparison.isLeft()) {
      if (pNode.getLeft() == null) {
        return null;
      }
      return getNodeForPrefix(pNode.getLeft(), pPrefix);
    } else if (comparison.isBelow()) {
      if (pNode.getBelow() == null) {
        return null;
      }
      return getNodeForPrefix(pNode.getBelow(), pPrefix);
    } else if (comparison.isRight()) {
      if (pNode.getRight() == null) {
        return null;
      }
      return getNodeForPrefix(pNode.getRight(), pPrefix);
    } else { // above
      return pNode;
    }
  }

  @Override
  public boolean remove(final Object pO) {
    if (!(pO instanceof Entry)) {
      return false;
    }
    final Entry<?> entry = (Entry<?>) pO;
    return remove(CompareResult.BELOW, 0, aRoot, entry);
  }

  private boolean remove(final CompareResult compare, final int prefixLength, final Node<V> pRoot, final Entry<?> pEntry) {
    if (pRoot == null) {
      return false;
    }
    if (compare.isLeft()) {
      if (pRoot.getLeft() == null) {
        return false;
      }
      final CompareResult newCompare = prefixCompare(pRoot.aLeft.prefix, pEntry.getPrefix());
      if (newCompare.isEqual()) {
        if (pEntry.getValue().equals(pRoot.aLeft.value)) {
          final Node<V> oldLeft = pRoot.aLeft.aLeft;
          final Node<V> oldBelow = pRoot.aLeft.aBelow;
          final Node<V> oldRight = pRoot.aLeft.aRight;
          pRoot.setLeft(null);
          addNode(CompareResult.LEFT, prefixLength, pRoot, oldLeft);
          addNode(CompareResult.LEFT, prefixLength, pRoot, oldBelow);
          addNode(CompareResult.LEFT, prefixLength, pRoot, oldRight);
          return true;
        }
      }

      final boolean result = remove(newCompare, prefixLength, pRoot.aLeft, pEntry);
      if (result) {
        pRoot.incCount(-1);
      }
      return result;
    } else if (compare.isBelow()) {
      if (pRoot.getBelow() == null) {
        return false;
      }
      final CompareResult newCompare = prefixCompare(pRoot.aBelow.prefix, pEntry.getPrefix());
      if (newCompare.isEqual()) {
        if (pEntry.getValue().equals(pRoot.aBelow.value)) {
          final Node<V> oldLeft = pRoot.aBelow.aLeft;
          final Node<V> oldBelow = pRoot.aBelow.aBelow;
          final Node<V> oldRight = pRoot.aBelow.aRight;
          pRoot.setBelow(null);
          addNode(CompareResult.BELOW, prefixLength, pRoot, oldLeft);
          addNode(CompareResult.BELOW, prefixLength, pRoot, oldBelow);
          addNode(CompareResult.BELOW, prefixLength, pRoot, oldRight);
          return true;
        }
      }

      final boolean result = remove(newCompare, prefixLength, pRoot.aBelow, pEntry);
      if (result) {
        pRoot.incCount(-1);
      }
      return result;

    } else if (compare.isRight()) {
      if (pRoot.getRight() == null) {
        return false;
      }
      final CompareResult newCompare = prefixCompare(pRoot.aRight.prefix, pEntry.getPrefix());
      if (newCompare.isEqual()) {
        if (pEntry.getValue().equals(pRoot.aRight.value)) {
          final Node<V> oldLeft = pRoot.aRight.aLeft;
          final Node<V> oldBelow = pRoot.aRight.aBelow;
          final Node<V> oldRight = pRoot.aRight.aRight;
          pRoot.setRight(null);
          addNode(CompareResult.RIGHT, prefixLength, pRoot, oldLeft);
          addNode(CompareResult.RIGHT, prefixLength, pRoot, oldBelow);
          addNode(CompareResult.RIGHT, prefixLength, pRoot, oldRight);
          return true;
        }
      }

      final boolean result = remove(newCompare, prefixLength, pRoot.aRight, pEntry);
      if (result) {
        pRoot.incCount(-1);
      }
      return result;

    } else {
      throw new RuntimeException("Unexpected code path");
    }
  }

  @Override
  public boolean removeAll(final Collection<?> pC) {
    boolean result = false;
    for (final Object o : pC) {
      result |= remove(o);
    }
    return result;
  }

  @Override
  public boolean retainAll(final Collection<?> pC) {
    // Implement by creating a new map with items present in both collections,
    // and then swaping the contents to this one
    final PrefixMap<V> tmp = new PrefixMap<>();
    for (final Object o : pC) {
      if (contains(o)) {
        @SuppressWarnings("unchecked")
        final Entry<V> entry = (Entry<V>) o;
        tmp.add(entry);
      }
    }
    final boolean result = size() > tmp.size();
    aRoot = tmp.aRoot;
    return result;
  }

  public Collection<Entry<V>> getPrefixes(final String pString) {
    final Node<V> newRoot = getPrefixes(aRoot, pString, 0);
    final PrefixMap<V> result = new PrefixMap<>();
    result.aRoot = newRoot;
    return result;
  }

  private Node<V> getPrefixes(final Node<V> pNode, final CharSequence pString, final int pOffset) {
    if (pNode == null) {
      return null;
    }
    final CompareResult cmp = prefixCompare(pOffset, pNode.prefix, pString);
    if (cmp.isEqOrBelow()) {
      final Node<V> result = new Node<>(pNode.prefix);
      result.value = pNode.value;
      result.aBelow = getPrefixes(pNode.aBelow, pString, pNode.prefix.length());
      return result;
    } else if (cmp.isLeft()) {
      return getPrefixes(pNode.aLeft, pString, pOffset);
    } else if (cmp.isRight()) {
      return getPrefixes(pNode.aRight, pString, pOffset);
    } else { // Node prefix is longer than string
      return null;
    }
  }

  public Collection<V> getPrefixValues(final String pPrefix) {
    final PrefixMap<V> entryResult = (PrefixMap<V>) getPrefixes(pPrefix);
    return new ValueCollection<>(entryResult);
  }

  /**
   * Get a collection of all entries longer than or equal to the given prefix
   * 
   * @param pPrefix the prefix
   * @return the collection
   */
  public Collection<Entry<V>> getLonger(final String pPrefix) {
    final Node<V> baseNode = getNodeForPrefix(aRoot, pPrefix);
    if (baseNode == null) {
      return Collections.emptyList();
    }
    final Node<V> copy = baseNode.clone();
    final Node<V> resultNode = new Node<>(pPrefix);
    takeWings(0, resultNode, copy);
    resultNode.setLeft(null);
    resultNode.setRight(null);
    resultNode.setBelow(copy);

    final PrefixMap<V> result = new PrefixMap<>();
    result.addNode(CompareResult.BELOW, 0, result.aRoot, resultNode);
    return result;
  }

  public Collection<V> getLongerValues(final String pPrefix) {
    final PrefixMap<V> entryResult = (PrefixMap<V>) getLonger(pPrefix);
    return new ValueCollection<>(entryResult);
  }

  /** Get all values with the given key */
  public Collection<Entry<V>> get(final String pPrefix) {
    final Node<V> baseNode = getNodeForPrefix(aRoot, pPrefix);
    if ((baseNode == null) || (!baseNode.prefix.equals(pPrefix))) {
      return Collections.<Entry<V>> emptyList();
    }
    final Node<V> resultNode = baseNode.clone();
    resultNode.setLeft(null);
    resultNode.setRight(null);


    Node<V> v = resultNode;
    while ((v.aBelow != null) && v.aBelow.prefix.equals(pPrefix)) {
      v.aBelow = v.aBelow.clone();
      v.aBelow.setLeft(null);
      v.aBelow.setRight(null);
      v = v.aBelow;
    }
    fixCount(resultNode);

    final PrefixMap<V> resultMap = new PrefixMap<>();
    resultMap.addNode(CompareResult.BELOW, 0, resultMap.aRoot, resultNode);
    return resultMap;
  }

  private int fixCount(final Node<V> pNode) {
    if (pNode == null) {
      return 0;
    }
    final int newCount = fixCount(pNode.aLeft) + fixCount(pNode.aBelow) + fixCount(pNode.aRight) + (pNode.value == null ? 0 : 1);
    pNode.aCount = newCount;
    return newCount;
  }

}
