/*
 * WebServer.java
 *
 * Created on 15 May 2001, 13:41
 */

package net.devrieze.util;

import java.io.*;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;

import net.devrieze.annotation.VisibleFor;
import net.devrieze.lang.Const;
import net.devrieze.util.webServer.*;
import net.devrieze.util.webServer.HttpRequest.Method;


/**
 * <p>
 * The WebServer class is a small modular webserver. It works together with the
 * {@link WebResourceProvider}interface. It is not a full HTTP/1.1
 * implementation, but basic functions like HEAD, GET, and POST are supported.
 * The WebServer class itself doesn't know what to return on a request. That's
 * where the WebResourceProvider interface comes in.
 * </p>
 * <p>
 * The WebServer class maintains a list of WebResourceProviders. When a query
 * comes in, the resource part of the url is compared to the list. If there is a
 * match, the WebResourceProvider that matches is used to return a web page. If
 * not, the root WebResourceProvider is used.
 * </p>
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class WebServer {

  private static final int _BEGIN_NON_CONTROL_CHARS = 32;

  private static final int _LISTEN_TIMEOUT_MS = 1000;

  private static final int _MAX_PORT_NO = 65535;

  /** The string that represents Carriage return + Linefeed. */
  public static final String _CRLF = "" + Const._CR + Const._LF;

  public static final int _RESPONSE_SUCCESS = 200;

  public static final int _RESPONSE_ERROR = 400;

  public static final int _RESPONSE_FILE_NOT_FOUND = 404;

  public static final int _RESPONSE_INTERNAL_SERVER_ERROR = 500;

  public static final int _RESPONSE_NOT_IMPLEMENTED = 501;

  /** The __Identifier for the webserver. This will be passed through to clients */
  private static String __Identifier = "paul.tools.WebServer/1.0";

  private class ConnectionHandler implements Runnable {

    private final Socket aConnection;

    private final WebServer aServer;

    /**
     * The ConnectionHandler inner class handles specific connections for the
     * {@link WebServer}class. One should never have to use this class directly.
     * It is only usefull for the WebServer class
     * 
     * @param pServer The Webserver that creates this ConnectionHandler
     * @param pConnection The connection that needs to be handled
     */
    public ConnectionHandler(final WebServer pServer, final Socket pConnection) {
      aServer = pServer;
      aConnection = pConnection;
    }

    /**
     * After the ConnectionHandler is created, it will handle the request with
     * the run method. This means it can be handled in a separate thread. The
     * {@link WebServer}class works that way.
     */
    @Override
    public void run() {
      HttpRequest request = null;
      try(Socket connection = this.aConnection;
          BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
          PrintStream out = new PrintStream(new BufferedOutputStream(connection.getOutputStream()), false)) {
        try {
          request = new HttpRequest(in);
  
          URL requestURL;
  
          if (request.getURI() != null) {
            requestURL = new URL(aHost, request.getURI());
          } else {
            requestURL = new URL(aHost, "/");
          }
  
          final Method method = request.getMethod();
  
          if (method == Method.STOP) {
            aServer.aDoRun = false;
            aServer.aCurThread.interrupt();
          } else if ((method == Method.GET) || (method == Method.HEAD) || (method == Method.POST)) {
            int i;
            WebResourceProvider rp;
            final String path = requestURL.getPath().substring(1); /*
                                                                    * strip the
                                                                    * first dash
                                                                    * of
                                                                    */
            String s = path;
  
            i = path.indexOf('/');
            if (i >= 0) {
              s = path.substring(0, i);
            }
  
            rp = aServer.aResources.get(s);
  
            if (rp == null) {
              rp = aServer.aRootResource;
            }
  
            if ((rp != null) && rp.setURL(requestURL)) {
              request.setResponse(_RESPONSE_SUCCESS);
              out.print("HTTP/1.0 200 OK" + _CRLF);
  
              rp.writeHeaders(out, request);
  
              if (request.getMethod() != Method.HEAD) {
                out.print(_CRLF);
                rp.writeBody(out, request);
              }
  
              if (rp instanceof ConfigResource) {
                aDoRun = !((ConfigResource) rp).isStop();
  
                if (!aDoRun) {
                  aServer.aCurThread.interrupt();
                }
              }
            } else {
              rp = new ErrorResource();
              rp.setURL(requestURL);
              request.setResponse(_RESPONSE_FILE_NOT_FOUND);
              out.print("HTTP/1.0 404 Resource not found" + _CRLF);
              rp.writeHeaders(out, request);
              out.print(_CRLF);
              rp.writeBody(out, request);
            }
          } else {
            final WebResourceProvider rp = new ErrorResource();
            request.setResponse(_RESPONSE_NOT_IMPLEMENTED);
            out.print("HTTP/1.0 501 Not Implemented" + _CRLF);
            rp.setURL(new URL(aHost, request.getURI()));
            rp.writeHeaders(out, request);
            out.print(_CRLF); /* separate header */
            rp.writeBody(out, request);
          }
  
          System.out.println(requestURL.toString());
        } catch (final Exception e) {
          try {
            if (request == null) {
              request = new HttpRequest(null);
            }

            if (request.getURI() == null) {
              request.setURI(aHost.toString());
            }

            if (e instanceof MalformedURLException) {
              final WebResourceProvider rp = new ErrorResource();
              out.print("HTTP/1.0 400 Wrong URL" + _CRLF);
              request.setResponse(_RESPONSE_FILE_NOT_FOUND);
              rp.setURL(new URL(aHost, request.getURI()));
              rp.writeHeaders(out, request);
              out.print(_CRLF);
              rp.writeBody(out, request);
            } else {
              final WebResourceProvider rp = new ErrorResource();
              out.print("HTTP/1.0 500 Internal Server Error" + _CRLF);
              request.setResponse(_RESPONSE_INTERNAL_SERVER_ERROR);
              rp.setURL(new URL(aHost, request.getURI()));
              rp.writeHeaders(out, request);
              out.print(_CRLF);
              rp.writeBody(out, request);
            }
            e.printStackTrace();
          } catch (final Exception f) {
            f.printStackTrace();
            aServer.aDoRun = false;
          }
        }
      } catch (IOException ex) { // when closing the connection fails
        ex.printStackTrace();
        throw new RuntimeException(ex);
      }
    }
  }

  @VisibleFor(ConnectionHandler.class)
  private final HashMap<String, WebResourceProvider> aResources;

  @VisibleFor(ConnectionHandler.class)
  private Thread aCurThread;

  @VisibleFor(ConnectionHandler.class)
  private URL aHost;

  private WebResourceProvider aRootResource;

  @VisibleFor(ConnectionHandler.class)
  private boolean aDoRun = true;

  private ServerSocket aServerSocket;

  /**
   * Creates new WebServer. Don't forget to add {@link WebResourceProvider}s to
   * the webserver.
   * 
   * @param pHost The host parameter specifies the name and port of the server.
   *          Some WebResourceProviders can be requiring the host parameter to
   *          be right for making good links to themselves.
   */
  public WebServer(final URL pHost) {
    aResources = new HashMap<>();
    aHost = pHost;

    if ((aHost.getPort() < 0) || (aHost.getPort() >= _MAX_PORT_NO)) {
      try {
        aHost = new URL("http://" + aHost.getHost() + ":80");
      } catch (final Exception e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * Gets the resourceProvider belonging to the Path given.
   * 
   * @param pBase The path where the resource belongs too
   * @return The ResourceProvider
   */
  public WebResourceProvider getResource(final String pBase) {
    return aResources.get(pBase);
  }

  /**
   * This specifies the root WebResourceProvider. This is the resourceprovider
   * that will be called when the other ResourceProviders are not applicable. A
   * RootResourceProvider must be specified. It shouldn't (doesn't have to) be
   * specified with the {@link #addResource }function
   * 
   * @param pRootRes The root resource to be set
   */
  public void setRootRes(final WebResourceProvider pRootRes) {
    try {
      pRootRes.setBase(new URL(aHost, "/"));
    } catch (final Exception e) {
      DebugTool.handle(e);
    }

    aRootResource = pRootRes;
  }

  /**
   * Adds a new WebResourceProvider to the webserver.
   * 
   * @param pBase What is the path (from root) where this ResourceProvider
   *          should start from. The path may not include slashes, and so may
   *          only by one &amp;directory&amp; deep.
   * @param pResource The resource that has to be added.
   * @see WebServer
   */
  public void addResource(final String pBase, final WebResourceProvider pResource) {
    try {
      pResource.setBase(new URL(aHost, pBase + '/'));
    } catch (final Exception e) {
      DebugTool.handle(e);
    }

    aResources.put(pBase, pResource);
  }

  /**
   * Listen on the specified port. This starts the webserver. This function will
   * not return until the main Listening thread of the webserver stops. (There
   * can still be connection handlers active). The way to cause this function to
   * return is the {@link #stop}function.
   * 
   * @throws IOException When creation of the sockets goes wrong
   * @see #stop()
   */
  public void listen() throws IOException {
    aServerSocket = new ServerSocket(aHost.getPort());
    aCurThread = Thread.currentThread();
    aServerSocket.setSoTimeout(_LISTEN_TIMEOUT_MS); /*
                                                     * reset accept every 1000
                                                     * milliseconds
                                                     */

    aDoRun = true;

    do {
      try {
        @SuppressWarnings("resource")
        final Socket connection = aServerSocket.accept();
        (new Thread(new ConnectionHandler(this, connection), "connectionhandler")).start();
      } catch (final InterruptedIOException e) {
        DebugTool.handle(e);
      }
    } while (aDoRun);
  }

  /**
   * Stop the server in a safe way. This function is only accessible from other
   * threads, or from WebResourceProviders. It causes the listen function to
   * return.
   */
  public void stop() {
    aDoRun = false;
  }

  /**
   * Encode the given sequence to replace special characters with character
   * entities.
   * 
   * @param pCharSequence The sequence of characters to encode.
   * @return the resulting stringbuidler.
   * @deprecated for {@link #xmlEncode}
   */
  @Deprecated
  public static StringBuilder htmlEncode(final CharSequence pCharSequence) {
    return xmlEncode(pCharSequence);
  }

  /**
   * Get an xml encoded version of the character sequence. The characters :
   * &quot;&amp;&quot;, &quot;\&quot;&quot;, &quot;&lt;&quot; and
   * &quot;&gt;&quot; are replaced by their equivalent entities.
   * 
   * @param pCharSequence The sequence to quote
   * @return The resulting sequence.
   */
  public static StringBuilder xmlEncode(final CharSequence pCharSequence) {
    final StringBuilder result = new StringBuilder((int) Math.round(pCharSequence.length() * 1.1));
    for (int i = 0; i < pCharSequence.length(); i++) {
      final char c = pCharSequence.charAt(i);
      if (c == '&') {
        result.append("&amp;");
      } else if (c == '"') {
        result.append("&quot;");
      } else if (c == '<') {
        result.append("&lt;");
      } else if (c == '>') {
        result.append("&gt;");
      } else if ((c < _BEGIN_NON_CONTROL_CHARS) && (c != Const._CR) && (c != Const._LF)) {
        result.append("&#x" + Integer.toHexString(c) + ";");
      } else {
        result.append(c);
      }
    }
    return result;
  }

  /**
   * Transform a charsequence with basic xml entities into it's equivalent
   * decoded string.
   * 
   * @param pCharSequence The string to decode.
   * @return The decoded character sequence.
   */
  public static StringBuilder xmlDecode(final CharSequence pCharSequence) {
    final StringBuilder result = new StringBuilder(pCharSequence.length());
    for (int i = 0; i < pCharSequence.length(); i++) {
      char c = pCharSequence.charAt(i);
      if (c == '&') {
        final StringBuilder buf = new StringBuilder(5);
        while ((c != ';') && (c != ' ') && (i < pCharSequence.length())) {
          c = pCharSequence.charAt(i);
          i++;
          if (c == ';') {
            final String bufS = buf.toString();
            if (bufS.equals("&amp")) {
              result.append(buf);
            } else if (bufS.equals("&quot")) {
              result.append('\"');
            } else if (bufS.equals("&lt")) {
              result.append('<');
            } else if (bufS.equals("&gt")) {
              result.append('>');
            } else {
              result.append(buf).append(';');
            }
            buf.setLength(0);
          } else if (c == '&') {
            result.append(buf);
            buf.setCharAt(0, '&');
            buf.setLength(1);
          } else {
            buf.append(c);
          }
        }
        result.append(buf);
      } else {
        result.append(c);
      }
    }

    return result;
  }

  /**
   * Get the identifier for the webserver.
   * 
   * @return The current identifier
   */
  public static String getIdentifier() {
    return __Identifier;
  }

  /**
   * Get the identifier for the webserver.
   * 
   * @param pIdentifier The new current identifier
   */
  public static void setIdentifier(final String pIdentifier) {
    __Identifier = pIdentifier;
  }

}
