/*
 * Created on Feb 4, 2004
 *
 */

package net.devrieze.util;

/**
 * A linked list based stack implementation for characters.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public final class CharStack {

  /**
   * A class implementing the the nodes that make up the stack. This is in the
   * form of a classic linked list.
   * 
   * @author Paul de Vrieze
   */
  private static final class Node {

    /**
     * The next node in the linked list chain.
     */
    private final Node aNext;

    /**
     * The value contained in this node.
     */
    private final char aValue;

    /**
     * The constructor for a new node.
     * 
     * @param pValue The value of the node.
     * @param pNext The next element in the chain
     */
    private Node(final char pValue, final Node pNext) {
      aNext = pNext;
      aValue = pValue;
    }

    /**
     * Create a string representation of this node and the linked elements. This
     * function is mainly usefull for debugging purposes.
     * 
     * @return A string representation of the node
     */
    @Override
    public String toString() {
      if (aNext != null) {
        return aNext.toString() + ", " + Character.toString(aValue);
      }

      return Character.toString(aValue);
    }
  }

  private Node aTop = null;

  /**
   * Returns <code>true</code> if the stack is empty.
   * 
   * @return boolean
   */
  public boolean isEmpty() {
    return aTop == null;
  }

  /**
   * Get the value at the top of the stack.
   * 
   * @return The value at the top
   */
  public char peek() {
    return aTop.aValue;
  }

  /**
   * Get the top character from the stack.
   * 
   * @return the top character
   */
  public char pop() {
    final char val = aTop.aValue;
    aTop = aTop.aNext; /* fails if empty */

    return val;
  }

  /**
   * Push a value onto the stack.
   * 
   * @param pValue the value to be pushed
   */
  public void push(final char pValue) {
    final Node node = new Node(pValue, aTop);

    aTop = node;
  }

  /**
   * Get a string representation of this stack.
   * 
   * @return A string representation
   */
  @Override
  public String toString() {
    return aTop.toString();
  }
}
