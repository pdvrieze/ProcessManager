/*
 * InvalidCommandError.java
 *
 * Created on 10 March 2001, 20:53
 */

package net.devrieze.util;

/**
 * An error thrown in case of an invalid command. It is not really clear how
 * this is used.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class InvalidCommandError extends Error {

  private static final long serialVersionUID = 5404239724554016650L;

  /**
   * Creates new InvalidCommandError.
   */
  public InvalidCommandError() {
    super("invalid Command!");
  }

  /**
   * Creates a new InvalidCommandError object.
   * 
   * @param pMessage The message to use for the exception
   */
  public InvalidCommandError(final String pMessage) {
    super(pMessage);
  }
}
