/*
 * Created on Nov 4, 2003
 *
 */

package net.devrieze.util;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;


/**
 * This class implements an immutable NameSet.
 *
 * @param <V> The type of the elements in the set. Must extend
 *          {@link net.devrieze.util.Named}.
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class ImmutableNameSet<V extends Named> implements ReadMap<String, V> {

  /**
   * An iterator that does not allow removing items.
   *
   * @param <T> The elements of the iterator
   * @author Paul de Vrieze
   */
  static final class ImmutableIterator<T> implements Iterator<T> {

    private final Iterator<T> aParentIterator;

    private T aPeek;

    private boolean aPeeked = false;

    /**
     * Create new Iterator.
     *
     * @param pParent The original iterator
     */
    public ImmutableIterator(final Iterator<T> pParent) {
      super();
      aParentIterator = pParent;
    }

    /**
     * @see Iterator#hasNext()
     */
    @Override
    public boolean hasNext() {
      if (aPeeked) {
        return true;
      }

      return aParentIterator.hasNext();
    }

    /**
     * Get the next item in the iterator.
     *
     * @see Iterator#next()
     * @return The next item
     */
    @Override
    public T next() {
      if (aPeeked) {
        aPeeked = false;

        return aPeek;
      }

      return aParentIterator.next();
    }

    /**
     * This raises an exception.
     *
     * @see Iterator#remove()
     */
    @Override
    public void remove() {
      throw new UnsupportedOperationException("This iterator is immutable");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
      String next;

      if (hasNext()) {
        next = peekNext().toString();
      } else {
        next = "EOL";
      }

      return "ImmutableIterator(next: " + next + " )";
    }

    private T peekNext() {
      if (!aPeeked) {
        if (!hasNext()) {
          throw new NoSuchElementException();
        }

        aPeek = next();
        aPeeked = true;
      }

      return aPeek;
    }
  }

  /** The parent of the collection. */
  private final ReadMap<String, V> aParent;

  /**
   * Create a new Immutable NameSet.
   *
   * @param pParent The original NameSet
   */
  public ImmutableNameSet(final NameSet<V> pParent) {
    DebugTool.ensureParamNotNull(pParent);
    aParent = pParent;

    assert invariant() : "The class invariant did not hold";
  }

  /**
   * Returns <code>true</code> when the set is empty.
   *
   * @see ReadMap#isEmpty()
   * @return <code>true</code> if empty, <code>false</code> if not
   */
  @Override
  public boolean isEmpty() {
    assert invariant() : "The class invariant did not hold";
    return aParent.isEmpty();
  }

  /**
   * Normally this function supports adding items to the NameSet. In this case
   * it will rais an exception as this is an immutable set.
   *
   * @param pValue the value to be added
   * @return nothing
   * @throws UnsupportedOperationException Allways, as this is unsupported
   */
  @Override
  public boolean add(final V pValue) {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Add a whole collection. Not allowed.
   *
   * @param pValues the collection
   * @return nothing
   * @throws UnsupportedOperationException Allways thrown as it is unsupported
   */
  @Override
  public boolean addAll(final Collection<? extends V> pValues) {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Clearing the NameSet is also forbidden as that would change the NameSet.
   *
   * @throws UnsupportedOperationException This operation is not actually
   *           supported for an ImmutableNameSet
   */
  @Override
  public void clear() {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Check whether this element is in the set.
   *
   * @param pValue The element to be checked
   * @return <code>true</code> if present, <code>false</code> if not
   * @see ReadMap#contains(Object)
   */
  @Override
  public boolean contains(final Object pValue) {
    DebugTool.ensureParamNotNull(pValue);

    assert invariant() : "The class invariant did not hold";
    return aParent.contains(pValue);
  }

  /**
   * Returns <code>true</code> if all the elements are contained in the set.
   *
   * @see ReadMap#containsAll(Collection)
   * @param pValues The elements to check
   * @return True if all elements are in the set, <code>false</code> if not
   */
  @Override
  public boolean containsAll(final Collection<?> pValues) {
    DebugTool.ensureParamNotNull(pValues);

    assert invariant() : "The class invariant did not hold";
    return aParent.containsAll(pValues);
  }

  /**
   * Checks whether an element with the specified name is in the set.
   *
   * @param pKey The key to check
   * @return <code>true</code> if in the set, <code>false</code> if not
   * @see ReadMap#containsKey(Object)
   */
  @Override
  public boolean containsKey(final String pKey) {
    DebugTool.ensureParamNotNull(pKey);

    assert invariant() : "The class invariant did not hold";
    return aParent.containsKey(pKey);
  }

  /**
   * Checks whether an element is in the set. This is similar to
   * {@link #contains(Object) }.
   *
   * @see ReadMap#containsValue(Named)
   * @param pValue The value to check
   * @return <code>true</code> if the value is contained, <code>false</code> if
   *         not
   */
  @Override
  public boolean containsValue(final V pValue) {
    DebugTool.ensureParamNotNull(pValue);

    assert invariant() : "The class invariant did not hold";
    return aParent.containsValue(pValue);
  }

  /**
   * Check whether this map equals the specified object. This function is
   * relayed to the {@link NameSet}that this ImmutableNameSet implements.
   *
   * @param pValue the value to check
   * @return <code>true</code> if equal, <code>false</code> if not, or the types
   *         don't match
   * @see ReadMap#equals(Object)
   */
  @Override
  public boolean equals(final Object pValue) {
    assert invariant() : "The class invariant did not hold";
    return aParent.equals(pValue);
  }

  /**
   * Get the value with the specified name.
   *
   * @param pKey The name to check
   * @return the value corresponding to this type.
   * @see ReadMap#get(Object)
   */
  @Override
  public V get(final String pKey) {
    assert invariant() : "The class invariant did not hold";
    return aParent.get(pKey);
  }

  /**
   * Get the hashcode for this ImmutableNameSet. It is implemented as a
   * passthrough solution.
   *
   * @return the hashcode of the parent NameSet
   * @see ReadMap#hashCode()
   */
  @Override
  public int hashCode() {
    assert invariant() : "The class invariant did not hold";
    return aParent.hashCode();
  }

  /**
   * This creates a special immutable iterator.
   *
   * @return An immutable iterator for this NameSet
   * @see ReadMap#iterator()
   */
  @Override
  public Iterator<V> iterator() {
    assert invariant() : "The class invariant did not hold";
    return new ImmutableIterator<>(aParent.iterator());
  }

  /**
   * Get the set of keys for this ImmutableNameSet.
   *
   * @return the set of keys.
   * @see ReadMap#keySet()
   */
  @Override
  public Set<String> keySet() {
    assert invariant() : "The class invariant did not hold";
    return Collections.unmodifiableSet(aParent.keySet());
  }

  /**
   * Normally it removes an item, in this case that is not allowed.
   *
   * @param pObject the object to be removed
   * @return nothing
   * @throws UnsupportedOperationException Allways thrown, it is an immutable
   *           collection.
   */
  @Override
  public boolean remove(final Object pObject) {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Normally it removes a number of items, in this case that is not allowed.
   *
   * @param pObjects the object to be removed
   * @return nothing
   * @throws UnsupportedOperationException Allways thrown, it is an immutable
   *           collection.
   */
  @Override
  public boolean removeAll(final Collection<?> pObjects) {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Normally it removes a number of items, in this case that is not allowed.
   *
   * @param pObjects the object to be removed
   * @return nothing
   * @throws UnsupportedOperationException Allways thrown, it is an immutable
   *           collection.
   */
  @Override
  public boolean retainAll(final Collection<?> pObjects) {
    throw new UnsupportedOperationException("This collection is immutable");
  }

  /**
   * Get the amount of elements in the NameSet.
   *
   * @return the size
   * @see ReadMap#size()
   */
  @Override
  public int size() {
    assert invariant() : "The class invariant did not hold";
    return aParent.size();
  }

  /**
   * Get an array of the elements in the ImmutableNameSet.
   *
   * @return a newly created array with the elements
   * @see ReadMap#toArray()
   */
  @Override
  public Object[] toArray() {
    assert invariant() : "The class invariant did not hold";
    return aParent.toArray();
  }

  /**
   * Put the elements of the ImmutableNameSet in the given array. If the array
   * is not big enough, a new array of the same type is created and returned.
   *
   * @param <T> The type of the array to be returned.
   * @param pArray the array that the elements need to be put in.
   * @return either the new array, or the pArray parameter. Use of the return
   *         type is needed as it is guaranteed to contain the resulting array.
   * @see ReadMap#toArray(Object[])
   */
  /* ECLIPSE-FIX */
  @Override
  public <T> T[] toArray(final T[] pArray) {
    assert invariant() : "The class invariant did not hold";
    DebugTool.ensureParamNotNull(pArray);

    return aParent.toArray(pArray);
  }

  /**
   * Get a string representation of the ImmutableNameSet.
   *
   * @return The string representation.
   */
  @Override
  public String toString() {
    assert invariant() : "The class invariant did not hold";

    return "ImmutableNameSet(" + aParent.toString() + ")";
  }

  /**
   * Get the values in this ImmutableNameSet.
   *
   * @return The values.
   * @see ReadMap#values()
   */
  @Override
  public Collection<V> values() {
    assert invariant() : "The class invariant did not hold";

    return values();
  }

  /**
   * The class invariant.
   *
   * @return <code>true</code> if the invariant holds (should allways be
   *         <code>true</code>).
   */
  protected boolean invariant() {
    return aParent != null;
  }
}
