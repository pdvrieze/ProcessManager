package net.devrieze.util;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


/**
 * An abstract document listener that will use DebugTool for displaying the
 * calls.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class AbstractDocumentListener implements DocumentListener {

  /**
   * Called when the document changed in a way that is not an insert or a
   * remove.
   * 
   * @param pEvent The related event
   */
  @Override
  public void changedUpdate(final DocumentEvent pEvent) {
    doUpdate(pEvent);
  }

  /**
   * Called when something has been inserted into the document.
   * 
   * @param pEvent The related event
   */
  @Override
  public void insertUpdate(final DocumentEvent pEvent) {
    doUpdate(pEvent);
  }

  /**
   * Called when something is removed from a document.
   * 
   * @param pEvent The related event
   */
  @Override
  public void removeUpdate(final DocumentEvent pEvent) {
    doUpdate(pEvent);
  }

  /**
   * A method called when an update needs to be performed.
   * 
   * @param pEvent The related event
   */
  protected void doUpdate(final DocumentEvent pEvent) {
    DebugTool.dPrintLn(DebugTool._ABSTRACT_LISTENER_LEVEL, "AbstractDocumentListener.doUpdate");
  }
}
