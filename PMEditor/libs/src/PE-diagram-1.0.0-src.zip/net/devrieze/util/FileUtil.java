/*
 * Created on 01-Dec-2005
 */
package net.devrieze.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Random;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


/**
 * A class for file utilties.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public final class FileUtil {

  private static final int _TMPDIR_MASK = 0xffff;

  private static File __TmpDir;

  private static final int _BUFFERSIZE = 32 * 1024;

  private FileUtil() {
    // Do nothing
  }

  /**
   * Create a new temporary directory. Remember that this is NOT safe
   * 
   * @param pPrefix The prefix to create the dir with
   * @param pSuffix The suffix of the dir
   * @param pDirectory The directory to create the dir in. If <code>null</code>,
   *          it is the tmp dir.
   * @return The directory.
   */
  public static File createTempDir(final String pPrefix, final String pSuffix, final File pDirectory) {
    int i = new Random().nextInt() & _TMPDIR_MASK;
    File directory = pDirectory;
    if (directory == null) {
      directory = getTmpDir();
    }

    File dirName = new File(directory, pPrefix + i + pSuffix);
    while (dirName.exists()) {
      i = new Random().nextInt() & _TMPDIR_MASK;
      dirName = new File(directory, pPrefix + i + pSuffix);
    }
    if (!dirName.mkdir()) {
      return createTempDir(pPrefix, pSuffix, directory);
    }
    return dirName;
  }

  public static File getTmpDir() {
    if (__TmpDir == null) {
      __TmpDir = new File(System.getProperty("java.io.tmpdir"));
    }
    return __TmpDir;
  }

  public static void zipDirectory(final File pZipDirectory, final ZipOutputStream pOutStream) throws IOException {
    zipDirectory(pZipDirectory, pOutStream, "");
  }

  private static void zipDirectory(final File pZipDirectory, final ZipOutputStream pOutStream, final String pBase) throws IOException {
    String base = pBase;
    if (!pBase.equals("")) {
      if (!base.endsWith("/")) {
        base = base + "/";
      }
      final ZipEntry e = new ZipEntry(base);
      e.setSize(0);
      pOutStream.putNextEntry(e);
      pOutStream.closeEntry();
    }
    for (final File f : pZipDirectory.listFiles()) {
      if (f.isDirectory()) {
        zipDirectory(f, pOutStream, pBase + f.getName() + "/");
      } else {
        zipFile(f, pOutStream, pBase + f.getName());
      }
    }
    pOutStream.close();
  }

  private static void zipFile(final File pFile, final ZipOutputStream pOutStream, final String pName) throws IOException {
    final ZipEntry e = new ZipEntry(pName);
    e.setMethod(ZipEntry.DEFLATED);
    e.setTime(pFile.lastModified());
    final byte[] buffer = new byte[_BUFFERSIZE];
    try (FileInputStream in = new FileInputStream(pFile)) {
      int read = in.read(buffer);
      final CRC32 crc32 = new CRC32();
      long total = read;
      while (read >= 0) {
        crc32.update(buffer, 0, read);
        read = in.read(buffer);
        total += read;
      }
      e.setSize(total);
      e.setCrc(crc32.getValue());
      pOutStream.putNextEntry(e);
    }
    try (FileInputStream in = new FileInputStream(pFile)) {
      int read = in.read(buffer);
      while (read >= 0) {
        pOutStream.write(buffer, 0, read);
        read = in.read(buffer);
      }

      pOutStream.closeEntry();
    } finally {
      pFile.delete();
    }
  }
}
