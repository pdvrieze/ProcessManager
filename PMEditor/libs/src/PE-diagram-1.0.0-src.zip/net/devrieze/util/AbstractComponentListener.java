/*
 * AbstractComponentListener.java
 *
 * Created on 13 maart 2001, 11:31
 */

package net.devrieze.util;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;


/**
 * A class that implements ComponentListener with empty methods. These methods
 * use DebugTool to optionally print the event that hapenned.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class AbstractComponentListener implements ComponentListener {

  private static void componentEvent(final ComponentEvent pComponentEvent, final String pEventName) {
    DebugTool.dPrintLn(DebugTool._ABSTRACT_LISTENER_LEVEL, "AbstractComponentListener.componentEvent("
        + pComponentEvent.getComponent().getName() + "," + pEventName + ")");
  }

  /**
   * Called when a component is hidden.
   * 
   * @param pComponentEvent The event thrown
   */
  @Override
  public void componentHidden(final ComponentEvent pComponentEvent) {
    componentEvent(pComponentEvent, "componentHidden");
  }

  /**
   * Called when a component is moved.
   * 
   * @param pComponentEvent The event thrown
   */
  @Override
  public void componentMoved(final ComponentEvent pComponentEvent) {
    componentEvent(pComponentEvent, "componentMoved");
  }

  /**
   * Called when a component is resized.
   * 
   * @param pComponentEvent The related event
   */
  @Override
  public void componentResized(final ComponentEvent pComponentEvent) {
    componentEvent(pComponentEvent, "componentResized");
  }

  /**
   * Called when a component is shown.
   * 
   * @param pComponentEvent The related event
   */
  @Override
  public void componentShown(final ComponentEvent pComponentEvent) {
    componentEvent(pComponentEvent, "componentShown");
  }
}
