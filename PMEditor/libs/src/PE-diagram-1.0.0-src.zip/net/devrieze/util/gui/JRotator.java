/*
 * JRotator.java
 *
 * Created on 25 April 2001, 23:08
 */

package net.devrieze.util.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


/**
 * A class implementing a number editor with up and down controls.
 * 
 * @author Paul de Vrieze
 * @version 1.0.1 $Revision$
 */
public class JRotator extends javax.swing.JPanel {

  private final class TextFieldDocumentListener implements DocumentListener {

    @Override
    public void insertUpdate(final DocumentEvent pEvent) {
      doUpdate();
    }

    @Override
    public void removeUpdate(final DocumentEvent pEvent) {
      doUpdate();
    }

    @Override
    public void changedUpdate(final DocumentEvent pEvent) {
      doUpdate();
    }

    private void doUpdate() {
      try {
        final String s = aNumberTextField.getText().trim();
        if (!s.equals("")) {
          final int i = Integer.parseInt(s);
          if (aValue != i) {
            aValue = i;
          }
        }
      } catch (final Exception ex) {
        aNumberTextField.setText(String.valueOf(getValue()));
      }
    }
  }

  private static final int _TEXT_BUTTONS_DISTANCE = 5;

  private static final int _ARROWHEIGHT = 16;

  private static final int _ARROWWIDTH = 24;

  private static final int _MINIMUMHEIGHT = 30;

  private static final int _MINIMUMWIDTH = 124;

  private static final int _PREFERREDHEIGHT = 35;

  private static final int _PREFERREDWIDTH = _MINIMUMWIDTH;

  private static final long serialVersionUID = 2925850133965236483L;

  /** Creates new form JRotator. */
  public JRotator() {
    initComponents();
    aNumberTextField.getDocument().addDocumentListener(new TextFieldDocumentListener());
  }

  /**
   * This method is called from within the constructor to initialize the form.
   */
  private void initComponents() {
    aNumberTextField = new JTextField();
    aContainerPanel = new JPanel();
    aUpButton = new JButton();
    aDownButton = new JButton();
    setLayout(new BorderLayout());
    setPreferredSize(new Dimension(_PREFERREDWIDTH, _PREFERREDHEIGHT));
    setMinimumSize(new Dimension(_MINIMUMWIDTH, _MINIMUMHEIGHT));

    aNumberTextField.setText("0");
    aNumberTextField.setHorizontalAlignment(SwingConstants.RIGHT);
    aNumberTextField.setMargin(new Insets(0, 0, 0, _TEXT_BUTTONS_DISTANCE));

    add(aNumberTextField, BorderLayout.CENTER);

    aContainerPanel.setLayout(new GridLayout(2, 1));
    try {
      aUpButton.setIcon(new ImageIcon(ClassLoader.getSystemResource("net/devrieze/utils/gui/RotUp.gif")));
    } catch (final NullPointerException e) {
      aUpButton.setText("+");
      e.printStackTrace();
    }
    aUpButton.setPreferredSize(new Dimension(_ARROWWIDTH, _ARROWHEIGHT));
    aUpButton.setMargin(new Insets(0, 0, 0, 0));
    aUpButton.setMinimumSize(new Dimension(_ARROWWIDTH, _ARROWHEIGHT));
    aUpButton.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(final ActionEvent pEvent) {
        upButtonActionPerformed();
      }
    });
    aContainerPanel.add(aUpButton);

    try {
      aDownButton.setIcon(new ImageIcon(ClassLoader.getSystemResource("net/devrieze/utils/gui/RotDown.gif")));
    } catch (final NullPointerException e) {
      aDownButton.setText("-");
      e.printStackTrace();
    }
    aDownButton.setPreferredSize(new Dimension(_ARROWWIDTH, _ARROWHEIGHT));
    aDownButton.setMinimumSize(new Dimension(_ARROWWIDTH, _ARROWHEIGHT));
    aDownButton.setMargin(new Insets(0, 0, 0, 0));
    aDownButton.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(final ActionEvent pEvent) {
        downButtonActionPerformed();
      }
    });
    aContainerPanel.add(aDownButton);

    add(aContainerPanel, BorderLayout.EAST);

  }

  private void downButtonActionPerformed() {
    if ((getMinValue() >= getMaxValue()) || (getValue() > getMinValue())) {
      setValue(getValue() - 1);
    }
  }

  private void upButtonActionPerformed() {
    if ((getMinValue() >= getMaxValue()) || (getValue() < getMaxValue())) {
      setValue(getValue() + 1);
    }
  }

  private JTextField aNumberTextField;

  private JPanel aContainerPanel;

  private JButton aUpButton;

  private JButton aDownButton;

  /** Holds value of property minValue. */
  private int aMinValue = Integer.MIN_VALUE;

  /** Holds value of property maxValue. */
  private int aMaxValue = Integer.MAX_VALUE;

  private int aValue;

  /**
   * Getter for property value.
   * 
   * @return Value of property value.
   */
  public int getValue() {
    return aValue;
  }

  /**
   * Setter for property value.
   * 
   * @param pValue New value of property value.
   */
  public void setValue(final int pValue) {
    aValue = pValue;
    aNumberTextField.setText(String.valueOf(pValue));
  }

  /**
   * Getter for property minValue.
   * 
   * @return Value of property minValue.
   */
  public int getMinValue() {
    return aMinValue;
  }

  /**
   * Setter for property minValue.
   * 
   * @param pMinValue New value of property minValue.
   */
  public void setMinValue(final int pMinValue) {
    aMinValue = pMinValue;
    aValue = Math.min(pMinValue, aValue);
  }

  /**
   * Getter for property maxValue.
   * 
   * @return Value of property maxValue.
   */
  public int getMaxValue() {
    return aMaxValue;
  }

  /**
   * Setter for property maxValue.
   * 
   * @param pMaxValue New value of property maxValue.
   */
  public void setMaxValue(final int pMaxValue) {
    aMaxValue = pMaxValue;
  }

}
