/*
 * AbstractListener.java
 *
 * Created on 13 maart 2001, 13:13
 */

package net.devrieze.util;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


/**
 * An abstract class that implements a ListSelectionListener with debugging
 * messages.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public class AbstractListSelectionListener implements ListSelectionListener {

  /**
   * Called when the list selection changed.
   * 
   * @param pListSelectionEvent The related event object
   */
  @Override
  public void valueChanged(final ListSelectionEvent pListSelectionEvent) {
    DebugTool.dPrintLn(DebugTool._ABSTRACT_LISTENER_LEVEL, "AbstractListSelectionListener.valuechanged");
  }
}
