/*
 * PageLoader.java Created on 5 juni 2001, 12:59
 */

package net.devrieze.util;

import java.net.URL;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.*;


/**
 * A class that supports loading files from a list of urls in a managed fassion.
 * Probably needs updating to Executors etc.
 * 
 * @todo when final, stop suppressing warnings
 * @todo document further
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@SuppressWarnings("all")
public class URLLoader<T, D> {

  private static final int _TERMINATION_WAIT_MS = 100;

  private static final int _POOL_SIZE = 10;

  private class URLCallable implements Callable<T> {

    /** The result of the loading of the url. */
    private final T aResult = null;

    /** The url to load. */
    private final URL aURL;

    /**
     * Create a new URLCallable.
     * 
     * @param pURL the URL to load
     */
    URLCallable(final URL pURL) {
      aURL = pURL;
    }

    /**
     * The actual call function. It uses the urlprocessor to process the url.
     * 
     * @return the result of the processing
     * @throws Exception When something went wrong, based on the
     *           {@link URLProcessor#processURL(URL)}function
     */
    public T call() throws Exception {
      final T result = aProcessor.processURL(aURL);
      return result;
    }

    /**
     * Get the url of this callable.
     * 
     * @return the url
     */
    public URL getURL() {
      return aURL;
    }
  }

  /** The processor for this url. */
  private final URLProcessor<T> aProcessor;

  /** The master queue with all the data. */
  private final Queue<Tripple<URL, Future<T>, D>> aLoads;

  /**
   * The queue to contain the results that are "ready" to be returned. They are
   * in a separate queue to speed up things.
   */
  @SuppressWarnings("all")
  private final Queue<Tripple<URL, Future<T>, D>> aLoaded;

  private final ThreadPoolExecutor aThreadPool;

  /**
   * Create a new loader.
   * 
   * @param pProcessor The processor that needs to be run to create the results.
   */
  public URLLoader(final URLProcessor<T> pProcessor) {
    aProcessor = pProcessor;
    aThreadPool = new ThreadPoolExecutor(_POOL_SIZE, _POOL_SIZE, _POOL_SIZE, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
    aLoads = new LinkedList<Tripple<URL, Future<T>, D>>();
    aLoaded = new LinkedList<Tripple<URL, Future<T>, D>>();
  }

  /**
   * Add a new url to load.
   * 
   * @param pURL the url to load
   * @param pData the associated data
   */
  public void addURL(final URL pURL, final D pData) {
    final Future<T> f = aThreadPool.submit(new URLCallable(pURL));
    aLoads.add(new Tripple<URL, Future<T>, D>(pURL, f, pData));

  }

  /**
   * Add a new url to load.
   * 
   * @param pURL the url to load
   */
  public void addURL(final URL pURL) {
    addURL(pURL, null);
  }

  /**
   * Add the url's to the list.
   * 
   * @param pURLs
   */
  public void addURLs(final Collection<URL> pURLs) {
    for (final URL url : pURLs) {
      addURL(url);
    }
  }

  /**
   * Add a collection of URL,Data tupples.
   * 
   * @param pItems A collection of tupples containing the url and it's data
   */
  public void addTupples(final Collection<Tupple<URL, D>> pItems) {
    for (final Tupple<URL, D> item : pItems) {
      addURL(item.getElem1(), item.getElem2());
    }
  }

  /**
   * Set the maximum amount of threads used.
   * 
   * @param pMaximumSize the maximum amount of threads
   * @deprecated Foolish to use, because of the queue
   */
  @Deprecated
  public void setMaximumPoolSize(final int pMaximumSize) {
    aThreadPool.setMaximumPoolSize(pMaximumSize);
  }

  /**
   * Get the maximum amount of threads.
   * 
   * @return the maximum amount of threads
   * @deprecated Foolish to use, because of the queue
   */
  @Deprecated
  public int getMaximumPoolSize() {
    return aThreadPool.getMaximumPoolSize();
  }

  /**
   * Set the core amount of threads. Note that this must not be zero or no
   * loading will actually happen
   * 
   * @param pCoreSize the coreSize
   * @see ThreadPoolExecutor#setCorePoolSize(int)
   */
  public void setCorePoolSize(final int pCoreSize) {
    aThreadPool.setCorePoolSize(pCoreSize);
  }

  /**
   * Get the core amount of threads.
   * 
   * @return the core amount of threads
   * @see ThreadPoolExecutor#getCorePoolSize()
   */
  public int getCorePoolSize() {
    return aThreadPool.getCorePoolSize();
  }

  /**
   * Wait until all url's have been loaded.
   */
  public void waitAll() {
    aThreadPool.shutdown();
    while (!aThreadPool.isTerminated()) {
      try {
        aThreadPool.awaitTermination(_TERMINATION_WAIT_MS, TimeUnit.MILLISECONDS);
        System.out.print(".");
      } catch (final InterruptedException e) {
        e.printStackTrace();
      }
    }
  }

}
