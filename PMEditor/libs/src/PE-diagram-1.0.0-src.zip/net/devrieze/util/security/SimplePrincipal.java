package net.devrieze.util.security;

import java.security.Principal;


public class SimplePrincipal implements Principal {

  private final String aName;

  public SimplePrincipal(final String pName) {
    aName = pName;
  }

  @Override
  public String getName() {
    return aName;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((aName == null) ? 0 : aName.hashCode());
    return result;
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final SimplePrincipal other = (SimplePrincipal) obj;
    if (aName == null) {
      if (other.aName != null) {
        return false;
      }
    } else if (!aName.equals(other.aName)) {
      return false;
    }
    return true;
  }

}
