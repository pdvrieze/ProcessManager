package net.devrieze.util.db;

import java.io.IOException;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import net.devrieze.util.AutoCloseableIterator;


public class DbSet<T> implements AutoCloseable {


  /**
   * Iterable that automatically closes 
   * @author pdvrieze
   *
   */
  public final class ClosingIterable implements Iterable<T>, AutoCloseable {
    
    @Override
    public void close() {
      DbSet.this.close();
    }

    @Override
    public Iterator<T> iterator() {
      return DbSet.this.unsafeIterator();
    }
    
  }

  private class ResultSetIterator implements AutoCloseableIterator<T> {

    private final ResultSet aResultSet;
    private final PreparedStatement aStatement;
    private T aNextElem=null;
    private boolean aFinished = false;

    public ResultSetIterator(PreparedStatement pStatement, ResultSet pResultSet) throws SQLException {
      aStatement = pStatement;
      aResultSet = pResultSet;
      aElementFactory.initResultSet(pResultSet.getMetaData());
    }

    public int size() throws SQLException {
      int pos = aResultSet.getRow();
      try {
        aResultSet.last();
        return aResultSet.getRow();
      } finally {
        aResultSet.absolute(pos);
      }
    }
    
      @Override
      public boolean hasNext() {
      if (aFinished) { return false; }
      if (aNextElem!=null) { return true; }

      try {
        boolean success = aResultSet.next();
        if (! success) {
          aFinished = true;
          aConnection.commit();
          closeResultSet(aConnection, aStatement, aResultSet);
          return false;
        }
        aNextElem = aElementFactory.create(aConnectionProvider, aResultSet);
        // TODO hope that this works
        aElementFactory.postCreate(aConnection, aNextElem);
        return true;
      } catch (SQLException|IOException ex) {
        closeResultSet(aConnection, aStatement, aResultSet) ;
        throw new RuntimeException(ex);
      }
    }

      @Override
      public T next() {
      final T nextElem = aNextElem;
      aNextElem = null;
      if (nextElem !=null) {
        return nextElem;
      }
      if (!hasNext()) { // hasNext will actually update aNextElem;
        throw new IllegalStateException("Reading beyond iterator");
      }
      return nextElem;
    }

      @Override
      public void remove() {
      try {
        aResultSet.deleteRow();
      } catch (SQLException ex) {
        closeResultSet(aConnection, aStatement, aResultSet) ;
        throw new RuntimeException(ex);
      }

    }

      @Override
      public void close() {
      try {
        try {
          try{
            aResultSet.close();
          } finally {
            aStatement.close();
          }
        } finally {
          aIterators.remove(this);
          if (aIterators.isEmpty()) {
            DbSet.this.close();
          }
        }
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    }
  }


  private final DataSource aConnectionProvider;
  private final ElementFactory<T> aElementFactory;
  private Connection aConnection;
  private Collection<ResultSetIterator> aIterators = new ArrayList<>();

  public DbSet(DataSource pDataSource, ElementFactory<T> pElementFactory) {
    aConnectionProvider = pDataSource;
    aElementFactory = pElementFactory;
  }

  public final ClosingIterable closingIterable() {
    return new ClosingIterable();
  }
  
  
  public final AutoCloseableIterator<T> unsafeIterator() {
    return unsafeIterator(false);
  }

  @SuppressWarnings("resource")
  public AutoCloseableIterator<T> unsafeIterator(boolean pReadOnly) {
    Connection connection = getConnection();
    try {
      CharSequence columns = aElementFactory.getCreateColumns();

      String sql = addFilter("SELECT "+columns+" FROM `"+aElementFactory.getTableName()+"`", " WHERE ");

      PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, pReadOnly ? ResultSet.CONCUR_READ_ONLY : ResultSet.CONCUR_UPDATABLE);
      setFilterParams(statement,1);

      statement.execute();
      final ResultSetIterator it = new ResultSetIterator(statement, statement.getResultSet());
      aIterators.add(it);
      return it;
    } catch (RuntimeException e) {
      rollbackConnection(connection, e);
      close();
      throw e;
    } catch (SQLException e) {
      rollbackConnection(connection, e);
      close();
      throw new RuntimeException(e);
    }
  }

  public int size() {
    try(Connection connection = getConnection()) {
      try {
        CharSequence columns = aElementFactory.getCreateColumns();

        String sql = addFilter("SELECT COUNT( "+columns+" ) FROM `"+aElementFactory.getTableName()+"`", " WHERE ");

        try(PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
          setFilterParams(statement, 1);

          boolean result = statement.execute();
          if (result) {
            try(ResultSet resultset = statement.getResultSet()) {
              if (resultset.next()) {
                return resultset.getInt(1);
              } else {
                throw new RuntimeException("Retrieving row count failed");
              }
            }
          } else {
            throw new RuntimeException("Retrieving row count failed");
          }
        }
      } catch (Exception e) {
        rollbackConnection(connection, e);
        throw e;
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  public boolean contains(Object pO) {
    T object = aElementFactory.asInstance(pO);
    if (object!=null) {

      try(Connection connection = getConnection()) {
        try {

          String sql = addFilter("SELECT COUNT(*) FROM "+aElementFactory.getTableName()+ " WHERE (" +aElementFactory.getPrimaryKeyCondition(object)+")", " AND ");

          try(PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
            int cnt = aElementFactory.setPrimaryKeyParams(statement,object, 1);
            setFilterParams(statement,cnt);

            boolean result = statement.execute();
            if (!result) { return false; }
            try(ResultSet resultset = statement.getResultSet()) {
              return resultset.next();
            }
          }
        } catch (Exception e) {
          rollbackConnection(connection, e);
          throw e;
        }
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    } else {
      return false;
    }
  }

  public boolean add(T pE) {
    if (pE==null) { throw new NullPointerException(); }

    try(Connection connection = getConnection()) {
      try {
        String sql = "INSERT INTO "+aElementFactory.getTableName()+ " ( "+aElementFactory.getStoreColumns() +" ) VALUES ( " +aElementFactory.getStoreParamHolders()+" )";

        try(PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
          aElementFactory.setStoreParams(statement, pE, 1);

          int changecount = statement.executeUpdate();
          if (changecount>0) {
            aElementFactory.postStore(connection, pE);
            connection.commit();
            return true;
          } else {
            return false;
          }
        }
      } catch (Exception e) {
        rollbackConnection(connection, e);
        throw e;
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  public boolean addAll(Collection<? extends T> pC) {
    if (pC==null) { throw new NullPointerException(); }

    try(Connection connection = getConnection()) {
      try {
        String sql = "INSERT INTO "+aElementFactory.getTableName()+ " ( "+aElementFactory.getStoreColumns() +" ) VALUES ( " +aElementFactory.getStoreParamHolders()+" )";

        try(PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
          for(T element: pC) {
            aElementFactory.setStoreParams(statement, element, 1);
            statement.addBatch();
            aElementFactory.postStore(connection, element);
          }
          int[] result = statement.executeBatch();
          for(int c:result) {
            if (c<1) {
              rollbackConnection(connection, null);
              return false; // Error, we just roll back and don't change a thing
            }
          }
          for(T element: pC) {
            aElementFactory.postStore(connection, element);
          }
          connection.commit();
          return result.length>0;
        }
      } catch (Exception e) {
        rollbackConnection(connection, e);
        throw e;
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  public boolean remove(Object pO) {
    T object = aElementFactory.asInstance(pO);
    if (object!=null) {
      try(Connection connection = getConnection()) {
        try {
          aElementFactory.preRemove(connection, object);
          String sql = addFilter("DELETE FROM "+aElementFactory.getTableName()+ " WHERE (" +aElementFactory.getPrimaryKeyCondition(object)+")", " AND ");

          try (PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
            int cnt = aElementFactory.setPrimaryKeyParams(statement, object, 1);
            setFilterParams(statement,cnt);

            int changecount = statement.executeUpdate();
            connection.commit();
            return changecount>0;
          }
        } catch (Exception e) {
          rollbackConnection(connection, e);
          throw e;
        }
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }

    } else {
      return false;
    }
  }

  public void clear() {
    try(Connection connection = getConnection()) {
      try {
        aElementFactory.preClear(connection);
        String sql = addFilter("DELETE FROM "+aElementFactory.getTableName(), " WHERE ");

        try (PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
          setFilterParams(statement, 1);

          statement.executeUpdate();
          connection.commit();
        }
      } catch (Exception e) {
        rollbackConnection(connection, e);
        throw e;
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public void close() {
    if (aConnection!=null) {
      try {
        aConnection.close();
      } catch (SQLException ex) {
        throw new RuntimeException(ex);
      } finally {
        aConnection = null;
      }
    }
  }

  public boolean isEmpty() {
    try(ResultSetIterator it = (ResultSetIterator)unsafeIterator(true)) {
      return it.hasNext();
    }
  }

  public Object[] toArray() {
    return toArray(new Object[0]);
  }

  public <U> U[] toArray(U[] pA) {
    try (@SuppressWarnings({ "rawtypes", "unchecked" })
    DbSet<U>.ResultSetIterator it = (DbSet.ResultSetIterator) unsafeIterator(true)) {
      int size = it.size();
      
      @SuppressWarnings("unchecked")
      final U[] result = size<=pA.length? pA : (U[]) Array.newInstance(pA.getClass(), size);
      for(int i=0; it.hasNext() && i<result.length; ++i) {
        result[i] = it.next();
      }
      if (size<result.length) {
        result[size] = null;
      }
      return result;
    } catch (SQLException ex) {
      throw new RuntimeException(ex);
    }
  }

  public boolean containsAll(Collection<?> pC) {
    Collection<?> cpy = new HashSet<>(pC);
    try(ClosingIterable col = closingIterable()) {
      for(T elem:col) {
        cpy.remove(elem);
      }
    }
    return cpy.isEmpty();
  }

  public boolean retainAll(Collection<?> pC) {
    boolean changed = false;
    try(ClosingIterable col = closingIterable()) {
      for(Iterator<T> it = col.iterator(); it.hasNext();) {
        if (!pC.contains(it.next())) {
          it.remove();
          changed = true;
        }
      }
    }
    return changed;
  }

  public boolean removeAll(Collection<?> pC) {
    boolean changed = false;
    try(ClosingIterable col = closingIterable()) {
      for(Iterator<T> it = col.iterator(); it.hasNext();) {
        if (pC.contains(it.next())) {
          it.remove();
          changed = true;
        }
      }
    }
    return changed;
  }

  protected long addWithKey(T pE) {
    if (pE==null) { throw new NullPointerException(); }

    try(Connection connection = getConnection()) {
      try {
        String sql = "INSERT INTO "+aElementFactory.getTableName()+ " ( "+aElementFactory.getStoreColumns() +" ) VALUES ( " +aElementFactory.getStoreParamHolders()+" )";

        try (PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
          aElementFactory.setStoreParams(statement, pE, 1);

          int changecount = statement.executeUpdate();
          if (changecount>0) {
            final long result;
            try (ResultSet keys = statement.getGeneratedKeys()) {
              keys.next();
              result = keys.getLong(1);
            }
            aElementFactory.postStore(connection, pE);

            connection.commit();
            return result;
          } else {
            return -1;
          }
        }
      } catch (Exception e) {
        rollbackConnection(connection, e);
        throw e;
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }

  }

  protected ElementFactory<T> getElementFactory() {
    return aElementFactory;
  }

  protected final DataSource getConnectionProvider() {
    return aConnectionProvider;
  }

  protected final Connection getConnection() {
    try {
      @SuppressWarnings("resource")
      Connection connection = aConnectionProvider.getConnection();
      try {
        connection.setAutoCommit(false);
      } catch (SQLException ex) {
        connection.close();
        throw ex;
      }
      aConnection = connection;
      return connection;
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  protected static void rollbackConnection(Connection pConnection, Throwable pCause) {
    try {
      pConnection.rollback();
    } catch (SQLException ex) {
      if (pCause!=null) {
        pCause.addSuppressed(ex);
      } else {
        throw new RuntimeException(ex);
      }
    }
    if (pCause instanceof RuntimeException) {
      throw (RuntimeException) pCause;
    }
    throw new RuntimeException(pCause);
  }

  /**
   *
   * @deprecated Use try-with
   */
  @Deprecated
  protected static void closeConnection(Connection pConnection, Exception e) {
    try {
      if (pConnection!=null) {
        pConnection.close();
      }
    } catch (Exception ex) {
      e.addSuppressed(ex);
    }
  }

  protected static void closeResultSet(Connection pConnection, PreparedStatement pStatement, ResultSet pResultSet) {
    try {
      try {
        try {
          try {
            pResultSet.close();
          } finally {
            pStatement.close();
          }
        } finally {
          pConnection.rollback();
        }
      } finally {
        pConnection.close();
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  protected String addFilter(CharSequence pSQL, CharSequence pConnector) {
    CharSequence filterExpression = getElementFactory().getFilterExpression();
    if (filterExpression==null || filterExpression.length()==0) {
      return new StringBuilder(pSQL.length()+1).append(pSQL).append(';').toString();
    }
    StringBuilder result = new StringBuilder(pSQL.length()+pConnector.length()+filterExpression.length());
    return result.append(pSQL).append(pConnector).append(filterExpression).append(';').toString();
  }

  protected void setFilterParams(PreparedStatement pStatement, int pOffset) throws SQLException {
    final CharSequence filterExpression = getElementFactory().getFilterExpression();
    if (filterExpression==null || filterExpression.length()==0) {
      getElementFactory().setFilterParams(pStatement, pOffset);
    }
  }

  public static DataSource resourceNameToDataSource(String pResourceName) {
    try {
      return (DataSource) new InitialContext().lookup(pResourceName);
    } catch (NamingException e) {
      throw new RuntimeException(e);
    }
  }

}
