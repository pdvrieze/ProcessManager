package net.devrieze.util.db;

import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import net.devrieze.util.db.DBHandleMap.HMElementFactory;


/**
 * Abstract baseclass for {@link ElementFactory} and {@link HMElementFactory}.
 * This class provides implementations that allow optional extensions for
 * complex datatypes. Simple types do not need factories that override these.
 *
 * @author Paul de Vrieze
 * @param <T> Type of the element created / handled
 */
public abstract class AbstractElementFactory<T> implements HMElementFactory<T> {

  @Override
  public CharSequence getFilterExpression() {
    return null;
  }

  @Override
  public void initResultSet(ResultSetMetaData pMetaData) throws SQLException {
    // Do nothing.
  }

  @Override
  public void postCreate(Connection pConnection, T pElement) throws SQLException {
    // Do nothing.
  }

  @Override
  public void postStore(Connection pConnection, T pElement) throws SQLException {
    // Simple case, do nothing
  }

  @Override
  public void preRemove(Connection pConnection, long pHandle) throws SQLException {
    // Don't do anything
  }

  @Override
  public void preRemove(Connection pConnection, T pElement) throws SQLException {
    // Don't do anything
  }

  @Override
  public void preClear(Connection pConnection) throws SQLException {
    // Don't do anything
  }

}
