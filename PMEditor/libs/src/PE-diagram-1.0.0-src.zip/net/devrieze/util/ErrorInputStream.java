/*
 * Created on Oct 15, 2004
 */

package net.devrieze.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;


/**
 * The ErrorInputStream class is used to be able to pass through errors.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class ErrorInputStream extends InputStream {

  private final Future<Boolean> aFuture;

  private final InputStream aParent;

  /**
   * Create a new ErrorInputStream based on the specified tuple.
   * 
   * @param pParent The {@code &lt;InputStream,Future&lt;Boolean&gt;&gt;}tupple
   *          specifying what this stream is based on.
   */
  public ErrorInputStream(final Tupple<InputStream, Future<Boolean>> pParent) {
    this(pParent.getElem1(), pParent.getElem2());
  }

  /**
   * Create a new ErrorInputStream.
   * 
   * @param pParent The parent inputstream
   * @param pFuture The future, from which to extract the exceptions
   */
  public ErrorInputStream(final InputStream pParent, final Future<Boolean> pFuture) {
    super();
    DebugTool.ensureParamNotNull(pParent);
    DebugTool.ensureParamNotNull(pFuture);
    aFuture = pFuture;
    aParent = pParent;

    assert invariant() : "The class invariant did not hold";
  }

  /** {@inheritDoc} */
  @Override
  public int read() throws IOException {
    final int result = aParent.read();
    checkFuture();

    assert invariant() : "The class invariant did not hold";
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public int available() throws IOException {
    final int result = aParent.available();
    checkFuture();

    assert invariant() : "The class invariant did not hold";
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public void close() throws IOException {
    aParent.close();
    checkFuture();

    assert invariant() : "The class invariant did not hold";
  }

  /** {@inheritDoc} */
  @Override
  public synchronized void mark(final int pArg0) {
    aParent.mark(pArg0);

    assert invariant() : "The class invariant did not hold";
  }

  /** {@inheritDoc} */
  @Override
  public boolean markSupported() {

    assert invariant() : "The class invariant did not hold";
    return aParent.markSupported();
  }

  /** {@inheritDoc} */
  @Override
  public int read(final byte[] pArg0, final int pArg1, final int pArg2) throws IOException {
    final int result = aParent.read(pArg0, pArg1, pArg2);
    checkFuture();

    assert invariant() : "The class invariant did not hold";
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public synchronized void reset() throws IOException {
    aParent.reset();
    checkFuture();
    assert invariant() : "The class invariant did not hold";
  }

  /** {@inheritDoc} */
  @Override
  public long skip(final long pArg0) throws IOException {
    final long result = aParent.skip(pArg0);
    checkFuture();
    assert invariant() : "The class invariant did not hold";
    return result;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    assert invariant() : "The class invariant did not hold";
    return aParent.toString();
  }

  /**
   * Check what the status of the future is.
   * 
   * @throws IOException When something went wrong
   */
  private void checkFuture() throws IOException {
    if (aFuture.isDone()) {
      try {
        final Boolean fResult = aFuture.get();
        if (!fResult.booleanValue()) {
          throw new IOException("The execution failed");
        }
      } catch (final InterruptedException ex) {
        /* Shouldn't happen, but don't do anything */
      } catch (final ExecutionException ex) {
        throw (IOException) new IOException("The execution failed").initCause(ex);
      }
    }
  }

  /**
   * The class invariant.
   * 
   * @return <code>true</code> if the invariant holds (should allways be
   *         <code>true</code>).
   */
  protected boolean invariant() {
    return (aParent != null) && (aFuture != null);
  }

}
