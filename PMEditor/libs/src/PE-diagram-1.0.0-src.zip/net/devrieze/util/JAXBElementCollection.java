/**
 * 
 */
package net.devrieze.util;

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.namespace.QName;


class JAXBElementCollection extends AbstractCollection<JAXBElement<?>> {

  static final class JAXBElementIterator implements Iterator<JAXBElement<?>> {

    private final Iterator<?> aIterator;

    public JAXBElementIterator(final Iterator<?> pIterator) {
      aIterator = pIterator;
      // TODO Auto-generated constructor stub
    }

    @Override
    public boolean hasNext() {
      return aIterator.hasNext();
    }

    @Override
    public JAXBElement<?> next() {
      final Object next = aIterator.next();
      return objectToJaxbElement(next);
    }

    @Override
    public void remove() {
      aIterator.remove();
    }

  }

  private final Collection<?> aCollection;

  @Override
  public Iterator<JAXBElement<?>> iterator() {
    return new JAXBElementCollection.JAXBElementIterator(aCollection.iterator());
  }

  @Override
  public int size() {
    return aCollection.size();
  }

  private static JAXBElement<?> objectToJaxbElement(final Object next) {
    @SuppressWarnings({ "unchecked", "rawtypes" })
    final Class<Object> declaredType = (Class) next.getClass();

    final XmlRootElement xmlRootElement = declaredType.getAnnotation(XmlRootElement.class);
    String namespaceURI;
    String localPart;
    if (xmlRootElement != null) {
      {
        final String s = xmlRootElement.namespace();
        namespaceURI = s.equals("##default") ? XMLConstants.NULL_NS_URI : s;
      }
      {
        final String s = xmlRootElement.name();
        localPart = s.equals("##default") ? classNameToElementName(declaredType.getName()) : s;
      }
    } else {
      localPart = classNameToElementName(declaredType.getName());
      namespaceURI = null;
    }

    final XmlNs prefix = getPrefixPart(declaredType, namespaceURI);

    QName qname;
    if (prefix != null) {
      qname = new QName(prefix.namespaceURI(), localPart, prefix.prefix());
    } else {
      qname = new QName(namespaceURI == null ? XMLConstants.NULL_NS_URI : namespaceURI, localPart, XMLConstants.DEFAULT_NS_PREFIX);
    }


    return new JAXBElement<>(qname, declaredType, next);
  }

  private static String classNameToElementName(final String pName) {
    final int i = pName.lastIndexOf('.');
    if (i >= 0) {
      return pName.substring(i + 1).toLowerCase();
    }
    return pName.toLowerCase();
  }

  private static XmlNs getPrefixPart(final Class<?> pType, final String pNamespaceURI) {
    final Package p = pType.getPackage();
    final XmlSchema xmlSchema = p.getAnnotation(XmlSchema.class);
    if (xmlSchema == null) {
      return null;
    }
    final XmlNs[] xmlnss = xmlSchema.xmlns();
    if ((pNamespaceURI == null) && (xmlnss.length > 0)) {
      return xmlnss[0];
    }
    for (final XmlNs xmlns : xmlnss) {
      if (xmlns.namespaceURI().equals(pNamespaceURI)) {
        return xmlns;
      }
    }
    return null;
  }

  public JAXBElementCollection(final Collection<?> pCollection) {
    aCollection = pCollection;
  }

}