/*
 * HtmlFilterReader.java Created on 19 februari 2001, 12:46
 */

package net.devrieze.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import javax.swing.event.EventListenerList;


/**
 * The MiscFilterReader Class is a Reader Stream that can "prepare" a file
 * inputstream so that it will be more "well formed", for the program that will
 * process the file.
 * 
 * @author Paul de Vrieze
 * @version 0.5 $Revision$
 */
public class MiscFilterReader extends FilterReader {

  /**
   * This inner class specifies a list of values that need to be replaced by a
   * specific string.
   */
  public static class ReplaceStore extends Object {

    /** Utility field used by event firing mechanism. */
    private EventListenerList aListenerList = null;

    /** Holds value of property replaceTo. */
    private String aReplaceTo;

    private final ArrayList<String> aReplaceFrom;

    /** The length of the longest string in the from list. */
    private int aFromLength = -1;

    /**
     * Constructor for inner Class ReplaceStore.
     * 
     * @param pFrom The strings that need to be replaced with the to value
     * @param pTo The value that should replace the from strings
     */
    public ReplaceStore(final String[] pFrom, final String pTo) {
      aReplaceFrom = new ArrayList<>();

      for (final String s : pFrom) {
        aReplaceFrom.add(s);
      }

      aReplaceTo = pTo;
      searchFromLength();
    }

    /**
     * Get the size of the largest string that should be replaced.
     * 
     * @return int
     */
    public int getFromLength() {
      if (aFromLength < 0) {
        searchFromLength();
      }

      return aFromLength;
    }

    /**
     * Indexed setter for property replaceFrom.
     * 
     * @param pIndex Index of the property.
     * @param pReplaceFrom New value of the property at <CODE>pIndex</CODE>.
     * @return The original value at this index
     */
    public String setReplaceFrom(final int pIndex, final String pReplaceFrom) {
      if (aReplaceFrom.get(pIndex).length() >= aFromLength) {
        aFromLength = -1; /* we cannot say anything about the new longest value */
      } else {
        final int i = pReplaceFrom.length();
        if (i > aFromLength) {
          setFromLength(i);
        }
      }

      return aReplaceFrom.set(pIndex, pReplaceFrom);
    }

    /**
     * Indexed getter for property replaceFrom.
     * 
     * @param pIndex Index of the property.
     * @return Value of the property at <CODE>pIndex</CODE>.
     */
    public String getReplaceFrom(final int pIndex) {
      return aReplaceFrom.get(pIndex);
    }

    /**
     * A List representation of the replacement table.
     * 
     * @return The the list of strings that need to be replaced
     */
    public ArrayList<String> getReplaceFrom() {
      return aReplaceFrom;
    }

    /**
     * Get the amount of strings to be replaced.
     * 
     * @return the count
     */
    public int getReplaceFromCount() {
      return aReplaceFrom.size();
    }

    /**
     * Setter for property replaceTo.
     * 
     * @param pReplaceTo New value of property replaceTo.
     */
    public void setReplaceTo(final String pReplaceTo) {
      aReplaceTo = pReplaceTo;
    }

    /**
     * Getter for property replaceTo.
     * 
     * @return Value of property replaceTo.
     */
    public String getReplaceTo() {
      return aReplaceTo;
    }

    /**
     * Registers PropertyChangeListener to receive events.
     * 
     * @param pListener The listener to register.
     */
    public synchronized void addPropertyChangeListener(final PropertyChangeListener pListener) {
      if (aListenerList == null) {
        aListenerList = new EventListenerList();
      }

      aListenerList.add(PropertyChangeListener.class, pListener);
    }

    /**
     * Add a string to be replaced.
     * 
     * @param pFrom The string from which it needs to be replaced
     */
    public void addReplaceFrom(final String pFrom) {
      aReplaceFrom.add(pFrom);

      final int i = pFrom.length();

      if (i > aFromLength) {
        setFromLength(i);
      }
    }

    /**
     * Remove a string to be replaced.
     * 
     * @param pFrom the string that should no longer be replaced
     * @return <code>true</code> when the deletion succeeded
     */
    public boolean delReplaceFrom(final String pFrom) {
      boolean b;
      b = aReplaceFrom.remove(pFrom);

      if (b && (pFrom.length() >= aFromLength)) {
        setFromLength(-1);
      }

      return b;
    }

    /**
     * Remove a string to be replaced.
     * 
     * @param pIndex The index of the string that should no longer be replaced
     * @return The string that was removed
     */
    public String delReplaceFrom(final int pIndex) {
      setFromLength(-1);

      return aReplaceFrom.remove(pIndex);
    }

    /**
     * Removes PropertyChangeListener from the list of listeners.
     * 
     * @param pListener The listener to remove.
     */
    public synchronized void removePropertyChangeListener(final PropertyChangeListener pListener) {
      aListenerList.remove(PropertyChangeListener.class, pListener);
    }

    private void setFromLength(final int pValue) {
      final int old = aFromLength;
      aFromLength = pValue;

      if (pValue >= 0) {
        firePropertyChangeListenerPropertyChange(new PropertyChangeEvent(this, "fromLength", Integer.valueOf(old), Integer.valueOf(pValue)));
      }
    }

    /**
     * Notifies all registered listeners about the event.
     * 
     * @param pEvent The event to be fired
     */
    private void firePropertyChangeListenerPropertyChange(final PropertyChangeEvent pEvent) {
      if (aListenerList == null) {
        return;
      }

      final Object[] listeners = aListenerList.getListenerList();

      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == PropertyChangeListener.class) {
          ((PropertyChangeListener) listeners[i + 1]).propertyChange(pEvent);
        }
      }
    }

    private void searchFromLength() {
      int j = 0;

      for (final String repl : aReplaceFrom) {
        final int k = repl.length();
        if (k > j) {
          j = k;
        }
      }

      setFromLength(j);
    }
  }

  private class StoreChangeListener extends Object implements PropertyChangeListener {

    /**
     * {@inheritDoc}
     */
    @Override
    public void propertyChange(final PropertyChangeEvent pEvent) {
      if (aFromLength < ((Integer) pEvent.getNewValue()).intValue()) {
        aFromLength = ((Integer) pEvent.getNewValue()).intValue();
      } else if (aFromLength <= ((Integer) pEvent.getOldValue()).intValue()) {
        searchFromLength();
      }
    }

    private void searchFromLength() {
      aFromLength = -1;
      if (aCommentStart != null) {
        aFromLength = aCommentStart.length();
      }


      for (int i = 0; i < aReplacer.size(); i++) {
        final int j = aReplacer.get(i).getFromLength();
        if (j > aFromLength) {
          aFromLength = j;
        }
      }
    }
  }

  private final StoreChangeListener aStoreChange;

  /** Holds value of property commentEnd. */
  private CharSequence aCommentEnd;

  /** Holds value of property commentStart. */
  private CharSequence aCommentStart;

  /** This value takes care of the pushing back of characters. */
  private StringBuilder aPushBack;

  /** Holds value of property replacer. */
  private final ArrayList<ReplaceStore> aReplacer;

  /** Specifies if the reader is inside a comment. */
  private boolean aInComment = false;

  /** Holds value of property passtrhoughComment. */
  private boolean aPassTroughComment = true;

  /** Specifies how far in the comment we are. */
  private int aCommentPos = 0;

  private int aFromLength = -1;

  /**
   * Creates a new HtmlFilterReader.
   * 
   * @param pIn The Inputfile
   * @see FilterReader#FilterReader(Reader)
   */
  public MiscFilterReader(final Reader pIn) {
    super(pIn);
    aReplacer = new ArrayList<>();
    aStoreChange = new StoreChangeListener();

    assert invariant() : "The class invariant did not hold";
  }

  /**
   * Setter for property commentEnd. commentEnd is the text that signifies the
   * end of a comment.
   * 
   * @param pCommentEnd the new value for commentEnd
   */
  public void setCommentEnd(final CharSequence pCommentEnd) {
    aCommentEnd = pCommentEnd;

    assert invariant() : "The class invariant did not hold";
  }

  /**
   * Getter for property commentEnd. commentEnd is the text that signifies the
   * end of a comment.
   * 
   * @return Value of property commentEnd.
   */
  public CharSequence getCommentEnd() {
    assert invariant() : "The class invariant did not hold";
    return aCommentEnd;
  }

  /**
   * Setter for property commentStart. CommentStart specifies the value which
   * starts a comment
   * 
   * @param pCommentStart New value of property commentStart.
   */
  public void setCommentStart(final CharSequence pCommentStart) {
    aCommentStart = pCommentStart;
    assert invariant() : "The class invariant did not hold";
  }

  /**
   * Getter for property commentStart. CommentStart specifies the value which
   * starts a comment
   * 
   * @return Value of property commentStart.
   */
  public CharSequence getCommentStart() {
    return aCommentStart;
  }

  /**
   * Setter for property passtrhoughComment. This property determines whether
   * comments are visible or not.
   * 
   * @param pPassTroughComment New value of property passtrhoughComment.
   */
  public void setPassTroughComment(final boolean pPassTroughComment) {
    aPassTroughComment = pPassTroughComment;
  }

  /**
   * Getter for property passtrhoughComment.
   * 
   * @return Value of property passtrhoughComment.
   */
  public boolean isPassTroughComment() {
    return aPassTroughComment;
  }

  /**
   * Indexed setter for property replacer. The property replacer specifies a set
   * of {@link ReplaceStore}values.
   * 
   * @param pIndex Index of the property.
   * @param pReplacer New value of the property at <CODE>pIndex</CODE>.
   */
  public void setReplacer(final int pIndex, final ReplaceStore pReplacer) {
    aReplacer.get(pIndex).removePropertyChangeListener(aStoreChange);
    pReplacer.addPropertyChangeListener(aStoreChange);
    aReplacer.set(pIndex, pReplacer);
  }

  /**
   * Setter for property replacer. The property replacer specifies a set of
   * {@link ReplaceStore}values.
   * 
   * @param pReplacer New value of property replacer.
   */
  public void setReplacer(final ReplaceStore[] pReplacer) {
    for (final ReplaceStore r : aReplacer) {
      r.removePropertyChangeListener(aStoreChange);
    }

    aReplacer.clear();

    for (final ReplaceStore r : pReplacer) {
      addReplacer(r);
    }
  }

  /**
   * Indexed getter for property replacer.
   * 
   * @param pIndex Index of the property.
   * @return Value of the property at <CODE>pIndex</CODE>.
   */
  public ReplaceStore getReplacer(final int pIndex) {
    return aReplacer.get(pIndex);
  }

  /**
   * Getter for property replacer.
   * 
   * @return Value of property replacer.
   */
  public ReplaceStore[] getReplacer() {
    return (ReplaceStore[]) aReplacer.toArray();
  }

  /**
   * returns the amount of {@link ReplaceStore}values in the stream.
   * 
   * @return the amount
   */
  public int getReplacerCount() {
    return aReplacer.size();
  }

  /**
   * Add a new replacer.
   * 
   * @param pReplacer the replacer to be added
   */
  public void addReplacer(final ReplaceStore pReplacer) {
    pReplacer.addPropertyChangeListener(aStoreChange);
    aReplacer.add(pReplacer);
  }

  /**
   * Reads a single character from the stream. Returns -1 if the end of the
   * stream is reached. Blocks if the stream blocks.
   * 
   * @return The character
   * @throws IOException If an IO error occurs
   */
  @Override
  public int read() throws IOException {
    if (aPushBack.length() > 0) {
      final int i = aPushBack.charAt(0);
      aPushBack = aPushBack.deleteCharAt(0);

      return i;
    }

    int retValue;

    if (aFromLength <= 0) {
      return super.read(); /* no replacers then exit */
    }

    retValue = super.read();

    if (retValue == -1) {
      return -1;
    }

    if (!aInComment) {
      final StringBuilder sb = new StringBuilder(aFromLength);
      int ci = retValue;

      for (int i = 1; (i < aFromLength) && (ci >= 0); i++) {
        sb.append((char) ci);
        ci = doRead();
      }

      if (ci >= 0) {
        sb.append((char) ci);
      }

      String s = sb.toString();
      int x;
      int y;
      int z;
      x = -1;
      y = -1;
      z = -1;

      for (int ix = 0; ix < aReplacer.size(); ix++) {
        final ReplaceStore r = aReplacer.get(ix);

        for (int iy = 0; iy < r.getReplaceFromCount(); iy++) {
          if ((r.getReplaceFrom(iy).length() > z) && s.startsWith(r.getReplaceFrom(iy))) {
            x = ix;
            y = iy;
            z = (r.getReplaceFrom(iy)).length();
          }
        }
      }

      if (z >= 0) { /* x and y should also be bigger that -1 in this case */

        /* need to replace (the search was for the longest replace string */
        pushBack(aReplacer.get(x).getReplaceFrom(y));
        s = s.substring(z);
        pushBack(s); /* push back next values */
        retValue = doRead(); /* present retValue is invalid */
      } else {
        pushBack(s.substring(1));
      }
    } else { /* !inComment */

      /* Search for the end of the comment */
      if (retValue == aCommentEnd.charAt(aCommentPos)) {
        aCommentPos++;

        if (aCommentPos == aCommentEnd.length()) { /* end of comment reached */
          aInComment = false;
          aCommentPos = 0;
        }

        if (!aPassTroughComment) {
          retValue = read(); /* get next character */
        }
      } else {
        if (aCommentPos > 0) {
          pushBack(aCommentEnd.subSequence(0, aCommentPos));
          pushBack((char) retValue);
          retValue = aCommentEnd.charAt(0);
        }
      }
    }
    return retValue;
  }

  /**
   * Read characters into an array. This method will block until some input is
   * available, an I/O error occurs, or the end of the stream is reached.
   * 
   * @param pValues Destination buffer
   * @return The number of bytes read, or -1 if the end of the stream has been
   *         reached
   * @throws IOException If an I/O error occurs
   */
  @Override
  public int read(final char[] pValues) throws IOException {
    return read(pValues, 0, pValues.length);
  }

  /**
   * Read characters into a portion of an array.
   * 
   * @param pValues Destination buffer
   * @param pOffset Offset at which to start storing characters
   * @param pLength Maximum number of characters to read
   * @return The number of characters read, or -1 if the end of the stream has
   *         been reached
   * @throws IOException If an I/O error occurs
   * @throws IndexOutOfBoundsException When the offset and length are not within
   *           range for the array
   */
  @Override
  public int read(final char[] pValues, final int pOffset, final int pLength) throws IOException {
    if ((pOffset < 0) || (pLength < 0) || ((pLength + pOffset) > pValues.length)) {
      throw new IndexOutOfBoundsException("invalid parameters");
    }

    int i = 0;
    int j = 0;

    while ((i < pLength) && (j >= 0)) {
      j = read();

      if (j != -1) {
        pValues[pOffset + i] = (char) j;
        i++;
      }
    }

    if (i == 0) {
      i = -1;
    }

    return i;
  }

  private int doRead() throws IOException {
    if (aPushBack.length() > 0) {
      final int i = aPushBack.charAt(0);
      aPushBack = aPushBack.deleteCharAt(0);

      return i;
    }

    return super.read();
  }

  private void pushBack(final CharSequence pString) {
    aPushBack = aPushBack.append(pString);
  }

  private void pushBack(final char pChar) {
    aPushBack = aPushBack.append(pChar);
  }

  /**
   * The class invariant.
   * 
   * @return <code>true</code> if the invariant holds (should allways be
   *         <code>true</code>).
   */
  protected boolean invariant() {
    if (aReplacer == null) {
      return false;
    }
    if (aStoreChange == null) {
      return false;
    }
    if ((aCommentStart != null) && (aCommentEnd == null)) {
      return false;
    }
    return true;
  }
}
