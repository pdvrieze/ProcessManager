package net.devrieze.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;


/**
 * <p>
 * A map that helps with mapping items and their handles.
 * </p>
 * <p>
 * The system will generate handles in a systematic way. A handle consists of
 * two parts: the first part (most significant 32 bits) is the generation. The
 * second part is the position in the array. The generation allows reuse of
 * storage space while still being able to have unique handles. The handles are
 * not guaranteed to have any relation between each other.
 * </p>
 * <p>
 * While handles are not guaranteed, the generation of the handles is NOT secure
 * in the sense of being able to be predicted with reasonable certainty.
 * </p>
 *
 * @author Paul de Vrieze
 * @param <V> The type of object contained in the map.
 */
public class MemHandleMap<V> implements HandleMap<V> {

  static class MapCollection<T> implements Collection<T> {

    private final HandleMap<T> aHandleMap;

    MapCollection(HandleMap<T> pHandleMap) {
      aHandleMap = pHandleMap;
    }

    @Override
    public int size() {
      return aHandleMap.size();
    }

    @Override
    public boolean isEmpty() {
      return aHandleMap.size()==0;
    }

    @Override
    public boolean contains(final Object pObject) {
      return aHandleMap.contains(pObject);
    }

    @Override
    public Iterator<T> iterator() {
      return aHandleMap.iterator();
    }

    @Override
    public Object[] toArray() {
      synchronized (aHandleMap) {
        final Object[] result = new Object[size()];
        return writeToArray(result);
      }
    }

    @SuppressWarnings("unchecked")
    @Override
    public <U> U[] toArray(final U[] pA) {
      U[] array;
      synchronized (aHandleMap) {
        final int size = size();
        array = pA;
        if (pA.length < size) {
          array = (U[]) java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), size);
        }
        writeToArray(array);
      }
      return array;
    }

    private Object[] writeToArray(final Object[] result) {
      int i = 0;
      synchronized (aHandleMap) {
        for (final T elem : aHandleMap) {
          result[i] = elem;
          ++i;
        }
      }
      if (result.length > i) {
        result[i] = null; // Mark the element afterwards as null as by {@link #toArray(T[])}
      }
      return result;
    }

    @Override
    public boolean add(final T pElement) {
      aHandleMap.put(pElement);
      return true;
    }

    @Override
    public boolean remove(final Object pObject) {
      if (pObject instanceof HandleMap.HandleAware) {
        return aHandleMap.remove(((HandleMap.HandleAware<?>) pObject).getHandle());
      }
      synchronized (aHandleMap) {
        for (final Iterator<T> it = aHandleMap.iterator(); it.hasNext();) {
          if (it.next() == pObject) {
            it.remove();
            return true;
          }
        }
      }
      return false;
    }

    @Override
    public boolean containsAll(final Collection<?> pC) {
      synchronized (aHandleMap) {
        for (final Object elem : pC) {
          if (!contains(elem)) {
            return false;
          }
        }
        return true;
      }
    }

    @Override
    public boolean addAll(final Collection<? extends T> pC) {
      synchronized (aHandleMap) {
        boolean result = false;
        for (final T elem : pC) {
          result |= add(elem);
        }
        return result;
      }
    }

    @Override
    public boolean removeAll(final Collection<?> pC) {
      synchronized (aHandleMap) {
        boolean result = false;
        synchronized (aHandleMap) {
          for (final Object elem : pC) {
            result |= remove(elem);
          }
        }
        return result;
      }
    }

    @Override
    public boolean retainAll(final Collection<?> pC) {
      boolean result = false;
      synchronized (aHandleMap) {
        for (final Iterator<T> it = aHandleMap.iterator(); it.hasNext();) {
          final T elem = it.next();
          if (!pC.contains(elem)) {
            it.remove();
            result |= true;
          }
        }
      }
      return result;
    }

    @Override
    public void clear() {
      aHandleMap.clear();
    }

  }

  private final class MapIterator implements Iterator<V> {

    int aIterPos;

    final int aIteratorMagic;

    private int aOldPos = -1;

    private boolean aAtStart = true;

    public MapIterator() {
      synchronized (MemHandleMap.this) {
        aIterPos = aBarrier >= aValues.length ? 0 : aBarrier;
        aIteratorMagic = aChangeMagic;
      }
    }

    @Override
    public boolean hasNext() {
      synchronized (MemHandleMap.this) {
        if (aIteratorMagic != aChangeMagic) {
          throw new ConcurrentModificationException("Trying to iterate over a changed map.");
        }
        if ((aIterPos == aNextHandle) && (aBarrier == aNextHandle)) {
          return aAtStart;
        }
        if (aBarrier < aNextHandle) {
          return aIterPos < aNextHandle;
        }
        return (aIterPos >= aBarrier) || (aIterPos < aNextHandle);
      }
    }


    @Override
    public V next() {
      aOldPos = aIterPos;
      aAtStart = false;

      synchronized (MemHandleMap.this) {
        if (aIteratorMagic != aChangeMagic) {
          throw new ConcurrentModificationException("Trying to iterate over a changed map.");
        }

        @SuppressWarnings("unchecked")
        final V result = (V) aValues[aOldPos];
        do {
          aIterPos++;
          if (aIterPos >= aValues.length) {
            aIterPos = 0;
          }
        } while ((aValues[aIterPos] == null) && inRange(aIterPos));
        return result;
      }
    }

    @Override
    public void remove() {
      synchronized (MemHandleMap.this) {
        if (aValues[aOldPos] == null) {
          throw new IllegalStateException("Calling remove twice can not work");
        }
        aValues[aOldPos] = null;
        aGenerations[aOldPos]++;
        updateBarrier();
        if (aIterPos == aBarrier) {
          aAtStart = true;
        }
      }
    }

  }

  private static final float _DEFAULT_LOADFACTOR = 0.9f;

  private static final int _DEFAULT_CAPACITY = 1024;

  private int aChangeMagic = 0; // Counter that increases every change. This can detect concurrentmodification.

  /**
   * This array contains the actual values in the map.
   */
  private Object[] aValues;

  /**
   * This array records for each value what generation it is. This is used to
   * compare the generation of the value to the generation of the handle.
   */
  private int[] aGenerations;

  private final int aStartGeneration = 0;

  private int aNextHandle = 0;

  private int aBarrier = -1;

  /**
   * The handle at the 0th element of the list. This allows for handle numbers
   * to increase over time without storage being needed.
   */
  private int aOffset = 0;

  private int aSize = 0;

  private float aLoadFactor = _DEFAULT_LOADFACTOR;

  /**
   * Create a new map.
   */
  public MemHandleMap() {
    this(_DEFAULT_CAPACITY, _DEFAULT_LOADFACTOR);
  }

  /**
   * Create a new map with given initial capacity.
   *
   * @param pCapacity The capacity of the map.
   */
  public MemHandleMap(final int pCapacity) {
    this(pCapacity, _DEFAULT_LOADFACTOR);
  }

  /**
   * Create a new map with given load factor.
   *
   * @param pLoadFactor The load factor to use.
   */
  public MemHandleMap(final float pLoadFactor) {
    this(_DEFAULT_CAPACITY, pLoadFactor);
  }

  /**
   * Create a new map.
   *
   * @param pCapacity The initial capacity.
   * @param pLoadFactor The load factor to use for the map.
   */
  public MemHandleMap(final int pCapacity, final float pLoadFactor) {
    aValues = new Object[pCapacity];
    aGenerations = new int[pCapacity];
    aBarrier = pCapacity;
    aLoadFactor = pLoadFactor;
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#clear()
   */
  @Override
  public synchronized void clear() {
    Arrays.fill(aValues, null);
    Arrays.fill(aGenerations, 0);
    aSize = 0;
    updateBarrier();
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#iterator()
   */
  @Override
  public Iterator<V> iterator() {
    return new MapIterator();
  }



  @Override
  public boolean contains(long pHandle) {
    synchronized (this) {
      final int index = indexFromHandle(pHandle);
      return ! ((index < 0) || (index >= aValues.length));
    }
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#contains(java.lang.Object)
   */
  @Override
  public boolean contains(final Object pObject) {
    if (pObject instanceof HandleMap.Handle) {
      final long candidateHandle = ((HandleMap.Handle<?>) pObject).getHandle();
      synchronized (this) {
        final int index = indexFromHandle(candidateHandle);
        if ((index < 0) || (index >= aValues.length)) {
          return false;
        }
        return aValues[index] == pObject;
      }
    } else {
      synchronized (this) {
        for (final Object candidate : this) {
          if (candidate == pObject) {
            return true;
          }
        }
      }
      return false;
    }
  }

  /**
   * Determine whether a handle might be valid. Used by the iterator.
   */
  private boolean inRange(final int pIterPos) {
    if (aBarrier <= aNextHandle) {
      return ((pIterPos >= aBarrier) && (pIterPos < aNextHandle));
    }
    return ((pIterPos >= aBarrier) || (pIterPos < aNextHandle));
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#put(V)
   */
  @Override
  public long put(final V pValue) {
    if (pValue == null) {
      throw new NullPointerException("Handles can point to null objects");
    }
    int index; // The space in the aValues array where to store the value
    int generation; // To allow reuse of spaces without reuse of handles
    // every reuse increases it's generation.
    final long handle;
    synchronized (this) {
      ++aChangeMagic;
      // If we can just add a handle to the ringbuffer.
      if (aNextHandle != aBarrier) {
        index = aNextHandle;
        aNextHandle++;
        if (aNextHandle == aValues.length) {
          if (aBarrier == aValues.length) {
            aBarrier = 0;
          }
          aNextHandle = 0;
          aOffset += aValues.length;
        }
        generation = aStartGeneration;
      } else {
        // Ring buffer too full
        if ((aSize == aValues.length) || (aSize >= (aLoadFactor * aValues.length))) {
          expand();
          return put(pValue);
          // expand
        } else {
          // Reuse a handle.
          index = findNextFreeIndex();
          generation = Math.max(aGenerations[index], aStartGeneration);
        }
      }
      aValues[index] = pValue;
      aGenerations[index] = generation;
      aSize++;

      handle = ((long) generation << 32) + handleFromIndex(index);
    }
    if (pValue instanceof HandleMap.HandleAware<?>) {
      ((HandleMap.HandleAware<?>) pValue).setHandle(handle);
    }
    return handle;
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#get(long)
   */
  @Override
  public V get(final long pHandle) {
    // Split the handle up into generation and index.
    final int generation = (int) (pHandle >> 32);
    synchronized (this) {
      final int index = indexFromHandle((int) pHandle);

      // If the generation doesn't map we have a wrong handle.
      if (aGenerations[index] != generation) {
        throw new ArrayIndexOutOfBoundsException("Generation mismatch" + generation);
      }

      // Just get the element out of the map.
      final @SuppressWarnings("unchecked")
      V result = (V) aValues[index];
      return result;
    }
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#get(net.devrieze.util.MemHandleMap.Handle)
   */
  @Override
  public V get(final HandleMap.Handle<? extends V> pHandle) {
    return get(pHandle.getHandle());
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#size()
   */
  @Override
  public int size() {
    return aSize;
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#remove(net.devrieze.util.MemHandleMap.Handle)
   */
  @Override
  public boolean remove(final HandleMap.Handle<? extends V> pObject) {
    return remove(pObject.getHandle());
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#remove(long)
   */
  @Override
  public boolean remove(final long pHandle) {
    final int generation = (int) (pHandle >> 32);
    synchronized (this) {
      final int index = indexFromHandle((int) pHandle);
      if (aGenerations[index] != generation) {
        return false;
      }
      if (aValues[index] != null) {
        ++aChangeMagic;
        aValues[index] = null;
        aGenerations[index]++; // Update the generation for safety checking
        aSize--;
        updateBarrier();
        return true;
      } else {
        return false;
      }
    }
  }

  /**
   * Try to make the barrier move down to allow the map to stay small. This
   * method itself isn't synchronized as the calling method should be.
   */
  private void updateBarrier() {
    if (aSize == 0) {
      aOffset += aNextHandle;
      aBarrier = aValues.length;
      aNextHandle = 0;
    } else {
      if (aBarrier == aValues.length) {
        aBarrier = 0;
      }
      while (aValues[aBarrier] == null) {
        aBarrier++;
        if (aBarrier == aValues.length) {
          aBarrier = 0;
        }
      }
    }
  }

  /**
   * Get an index from the given handle. This method is not synchronized,
   * callers should be.
   *
   * @param pHandle The handle to use.
   * @return the index into the values array.
   * @throws ArrayIndexOutOfBoundsException when the handle is not a valid
   *           position.
   */
  private int indexFromHandle(final long pHandle) {
    final int handle = (int) pHandle;
    int result = handle - aOffset;
    if (result < 0) {
      result = result + aValues.length;
      if (result < aBarrier) {
        throw new ArrayIndexOutOfBoundsException(handle);
      }
    } else if (result >= aNextHandle) {
      throw new ArrayIndexOutOfBoundsException(handle);
    }
    if (result >= aValues.length) {
      throw new ArrayIndexOutOfBoundsException(handle);
    }
    return result;
  }

  private int handleFromIndex(final int pIndex) {
    if (aNextHandle > aBarrier) {
      return pIndex + aOffset;
    }

    if (pIndex < aBarrier) {
      // must be at same offset as aNextHandle
      return pIndex + aOffset;
    } else {
      return (pIndex + aOffset) - aValues.length;
    }
  }

  private int findNextFreeIndex() {
    int i = aBarrier;
    while (aValues[i] != null) {
      i++;
      if (i == aValues.length) {
        i = 0;
      }
    }
    return i;
  }

  private void expand() {
    if (aBarrier == aValues.length) {
      System.err.println("Unexpected code visit");
      aBarrier = 0;
    }

    if (aBarrier != aNextHandle) {
      System.err.println("Expanding while not full");
      return;
    }

    final int newLen = aValues.length * 2;
    final Object[] newValues = new Object[newLen];
    final int[] newGenerations = new int[newLen];


    System.arraycopy(aValues, aBarrier, newValues, 0, aValues.length - aBarrier);
    System.arraycopy(aGenerations, aBarrier, newGenerations, 0, aGenerations.length - aBarrier);
    if (aBarrier > 0) {
      System.arraycopy(aValues, 0, newValues, aValues.length - aBarrier, aBarrier);
      System.arraycopy(aGenerations, 0, newGenerations, aGenerations.length - aBarrier, aBarrier);
    }

    aOffset = handleFromIndex(aBarrier);
    aNextHandle = aValues.length;
    aValues = newValues;
    aGenerations = newGenerations;
    aBarrier = 0;
  }

  /**
   * Get a very simple Handle implementation.
   *
   * @param pHandle The handle
   * @return a Handle<T> object corresponding to the handle.
   */
  public static <T> HandleMap.Handle<T> handle(final long pHandle) {
    return new HandleMap.Handle<T>() {

      @Override
      public long getHandle() {
        return pHandle;
      }
    };
  }

  /* (non-Javadoc)
   * @see net.devrieze.util.HandleMap#toCollection()
   */
  @Deprecated
  @Override
  public Collection<V> toCollection() {
    return this;
  }

  @Override
  public boolean isEmpty() {
    return size()==0;
  }

  @Override
  public Object[] toArray() {
    synchronized (this) {
      final Object[] result = new Object[size()];
      return writeToArray(result);
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  public <U> U[] toArray(final U[] pA) {
    U[] array;
    synchronized (this) {
      final int size = size();
      array = pA;
      if (pA.length < size) {
        array = (U[]) java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), size);
      }
      writeToArray(array);
    }
    return array;
  }

  private Object[] writeToArray(final Object[] result) {
    int i = 0;
    synchronized (this) {
      for (final V elem : this) {
        result[i] = elem;
        ++i;
      }
    }
    if (result.length > i) {
      result[i] = null; // Mark the element afterwards as null as by {@link #toArray(T[])}
    }
    return result;
  }

  @Override
  public boolean add(final V pElement) {
    put(pElement);
    return true;
  }

  @Override
  public boolean remove(final Object pObject) {
    if (pObject instanceof HandleMap.Handle) {
      return remove(((HandleMap.Handle<?>) pObject).getHandle());
    }
    synchronized (this) {
      for (final Iterator<V> it = iterator(); it.hasNext();) {
        if (it.next() == pObject) {
          it.remove();
          return true;
        }
      }
    }
    return false;
  }

  @Override
  public boolean containsAll(final Collection<?> pC) {
    synchronized (this) {
      for (final Object elem : pC) {
        if (!contains(elem)) {
          return false;
        }
      }
      return true;
    }
  }

  @Override
  public boolean addAll(final Collection<? extends V> pC) {
    synchronized (this) {
      boolean result = false;
      for (final V elem : pC) {
        result |= add(elem);
      }
      return result;
    }
  }

  @Override
  public boolean removeAll(final Collection<?> pC) {
    synchronized (this) {
      boolean result = false;
      for (final Object elem : pC) {
        result |= remove(elem);
      }
      return result;
    }
  }

  @Override
  public boolean retainAll(final Collection<?> pC) {
    boolean result = false;
    synchronized (this) {
      for (final Iterator<V> it = iterator(); it.hasNext();) {
        final V elem = it.next();
        if (!pC.contains(elem)) {
          it.remove();
          result |= true;
        }
      }
    }
    return result;
  }

}
