package net.devrieze.util;

import java.net.MalformedURLException;
import java.net.URL;


public class Urls {

  private Urls() {}

  public static URL newURL(final String pUrl) {
    try {
      return new URL(pUrl);
    } catch (final MalformedURLException ex) {
      return null;
    }
  }

}
