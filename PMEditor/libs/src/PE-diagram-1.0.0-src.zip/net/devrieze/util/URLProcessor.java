/*
 * Created on Oct 7, 2004
 *
 */

package net.devrieze.util;

import java.net.URL;


/**
 * An interface that an url processor for the {@link URLLoader}class should
 * implement.
 * 
 * @author Paul de Vrieze
 * @todo more
 * @version 0.1 $Revision$
 * @param <T> The result type of the processing.
 */
public interface URLProcessor<T> {

  /**
   * Process the url, and return the result of this processing.
   * 
   * @param pUrl The url to process.
   * @return the result of the processing
   * @throws InterruptedException When the thread has been interrupted
   * @throws Exception When something goes wrong with the processing
   */
  T processURL(URL pUrl) throws InterruptedException, Exception;
}
