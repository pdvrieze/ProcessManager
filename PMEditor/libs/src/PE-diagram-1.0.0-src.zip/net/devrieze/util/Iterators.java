package net.devrieze.util;

import java.util.*;


public class Iterators {


  
  private static class AutoCloseIterable<T extends Iterable<? extends V> & AutoCloseable, V> implements Iterable<V>, Iterator<V>{

    private final T aParent;
    private Iterator<? extends V> aIterator;
    
    public AutoCloseIterable(T pIterable) {
      aParent = pIterable;
    }

    @Override
    public Iterator<V> iterator() {
      aIterator = aParent.iterator();
      if (!aIterator.hasNext()) {
        aIterator = null;
        try {
          aParent.close();
        } catch (Exception ex) {
          throw new RuntimeException(ex);
        }
      }
      return this;
    }

    @Override
    public boolean hasNext() {
      return aIterator !=null && aIterator.hasNext();
    }

    @Override
    public V next() {
      try {
        V n = aIterator.next();
        if (n==null) {
          aIterator = null;
          aParent.close();
        }
        return n;
      } catch (Exception e) {
        try {
          aParent.close();
        } catch (Exception ex) {
          e.addSuppressed(ex);
        }
        if (e instanceof RuntimeException) {
          throw (RuntimeException) e;
        } else {
          throw new RuntimeException(e);
        }
      }
    }

    @Override
    public void remove() {
      // TODO Auto-generated method stub
      
    }

  }

  private static class EnumIterator<T> implements Iterator<T> {

    private final Enumeration<T> aEnumeration;

    public EnumIterator(final Enumeration<T> pEnumeration) {
      aEnumeration = pEnumeration;
    }

    @Override
    public boolean hasNext() {
      return aEnumeration.hasMoreElements();
    }

    @Override
    public T next() {
      return aEnumeration.nextElement();
    }

    @Override
    public void remove() {
      throw new UnsupportedOperationException("Enumerations don't support deletion");
    }

  }

  private static class MergedIterable<T> implements Iterable<T> {

    private class MergedIterator implements Iterator<T> {

      int aIndex = 0;

      Iterator<? extends T> aIterator = aIterables[0].iterator();

      @Override
      public boolean hasNext() {
        if (aIterator.hasNext()) {
          return true;
        }
        while ((aIterator != null) && (!aIterator.hasNext())) {
          ++aIndex;
          if (aIndex < aIterables.length) {
            aIterator = aIterables[aIndex].iterator();
          } else {
            aIterator = null;
          }
        }
        return (aIterator != null);
      }

      @Override
      public T next() {
        if (!hasNext()) {
          throw new NoSuchElementException("Reading past iterator end");
        }
        return aIterator.next();
      }

      @Override
      public void remove() {
        aIterator.remove();
      }

    }

    private final Iterable<? extends T>[] aIterables;

    public MergedIterable(final Iterable<? extends T>[] pIterables) {
      aIterables = pIterables;
    }

    @Override
    public Iterator<T> iterator() {
      return new MergedIterator();
    }

  }

  private Iterators() {}

  @SafeVarargs
  public static <T> Iterable<T> merge(final Iterable<? extends T>... pIterables) {
    if (pIterables.length == 0) {
      return Collections.emptyList();
    } else if (pIterables.length == 1) {
      @SuppressWarnings("unchecked")
      final Iterable<T> result = (Iterable<T>) pIterables[0];
      return result;
    }
    return new MergedIterable<>(pIterables);
  }

  public static <T> Iterable<T> toIterable(final Enumeration<T> e) {
    return new Iterable<T>() {

      @Override
      public Iterator<T> iterator() {
        return new EnumIterator<>(e);
      }


    };
  }

  public static <T> List<T> toList(final Iterator<T> pIterator) {
    if (!pIterator.hasNext()) {
      return Collections.<T> emptyList();
    }
    final T value = pIterator.next();
    if (!pIterator.hasNext()) {
      return Collections.singletonList(value);
    }
    final List<T> result = new ArrayList<>();
    result.add(value);
    do {
      result.add(pIterator.next());
    } while (pIterator.hasNext());
    return result;
  }

  public static <T> List<T> toList(final Enumeration<T> pEnumeration) {
    return toList(new EnumIterator<>(pEnumeration));
  }

  public static <T> List<T> toList(final Iterable<T> pIterable) {
    return toList(pIterable.iterator());
  }
  
  public static <T extends Iterable<V> & AutoCloseable, V> Iterable<V> autoClose(T iterable) {
    return new AutoCloseIterable<>(iterable);
  }
}
