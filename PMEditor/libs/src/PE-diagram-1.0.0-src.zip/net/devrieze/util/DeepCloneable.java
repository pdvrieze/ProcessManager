/*
 * Created on Jan 27, 2004
 *
 */

package net.devrieze.util;

/**
 * This interface signifies that a class can be deepcloned.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
public interface DeepCloneable {

  /**
   * Clone the object with a deep clone.
   * 
   * @return A clone of the object
   */
  DeepCloneable deepClone();
}
