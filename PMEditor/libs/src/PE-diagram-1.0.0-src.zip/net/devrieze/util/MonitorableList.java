package net.devrieze.util;

import java.util.List;


public interface MonitorableList<V> extends MonitorableCollection<V>, List<V> {
  // No specific methods, just the ones in the parent interfaces
}
