package net.devrieze.util;

import java.lang.ref.WeakReference;
import java.util.Map.Entry;
import java.util.WeakHashMap;

import javax.sql.DataSource;

import net.devrieze.util.db.DBHandleMap;


/**
 * A {@link DBHandleMap} that uses {@link WeakReference WeakReferences} to store
 * its results. Note that the {@link WrappingIterator#remove() remove} method on
 * the iterator is not efficient if the elements do not implement Handle as it
 * will loop through the cache to find the underlying value.
 *
 * @author Paul de Vrieze
 * @param <V> The type of the elements in the map.
 */
public class CachingDBHandleMap<V> extends DBHandleMap<V> {


  private class WrappingIterator implements AutoCloseableIterator<V> {

    private final AutoCloseableIterator<V> aIterator;
    private V aLast;

    public WrappingIterator(AutoCloseableIterator<V> pIterator) {
      aIterator = pIterator;
    }

    @Override
    public boolean hasNext() {
      return aIterator.hasNext();
    }

    @Override
    public V next() {
      V result = aIterator.next();
      putCache(result);
      aLast = result;
      return result;
    }

    @Override
    public void remove() {
      if (aLast!=null) {
        synchronized(aCache) {
          if (aLast instanceof Handle<?>) {
            aCache.remove(Long.valueOf(((Handle<?>)aLast).getHandle()));
          } else {
            for (Entry<Long, V> entry: aCache.entrySet()) {
              if (entry.getValue()==aLast) {
                aCache.remove(entry.getKey());
                break;
              }
            }
          }
        }
      }
      aIterator.remove();
    }

    @Override
    public void close() throws Exception {
      aIterator.close();
    }

  }

  final WeakHashMap<Long, V> aCache;

  public CachingDBHandleMap(DataSource pConnectionProvider, net.devrieze.util.db.DBHandleMap.HMElementFactory<V> pElementFactory) {
    super(pConnectionProvider, pElementFactory);
    aCache = new WeakHashMap<>();
  }

  @Override
  public void clear() {
    super.clear();
  }

  @Override
  public boolean contains(long pHandle) {
    synchronized(aCache) {
      if (aCache.containsKey(Long.valueOf(pHandle))) {
        return true;
      }
    }
    return super.contains(pHandle);
  }

  @Override
  public long put(V pValue) {
    long handle = super.put(pValue);
    putCache(handle, pValue);
    return handle;
  }
  
  private void putCache(V pValue) {
    if (pValue instanceof HandleAware) {
      putCache(((HandleAware<?>)pValue).getHandle(), pValue);
    }
  }
  
  private void putCache(long pHandle, V pValue) {
    synchronized (aCache) {
      aCache.put(Long.valueOf(pHandle), pValue);
    }
  }

  @Override
  public V get(long pHandle) {
    Long key = Long.valueOf(pHandle);
    final V val;
    synchronized(aCache) {
      val = aCache.get(key);
    }
    if (val!=null) {
      return val;
    }
    return super.get(pHandle);
  }

  @Override
  public boolean remove(long pHandle) {
    Long key = Long.valueOf(pHandle);
    synchronized (aCache) {
      aCache.remove(key);
    }
    return super.remove(pHandle);
  }

  @Override
  public AutoCloseableIterator<V> unsafeIterator(boolean pReadOnly) {
    return new WrappingIterator(super.unsafeIterator(pReadOnly));
  }

  @Override
  public void close() {
    super.close();
    aCache.clear();
  }

}
