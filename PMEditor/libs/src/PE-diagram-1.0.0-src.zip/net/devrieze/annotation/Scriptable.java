/*
 * Created on 24-Oct-2005
 */
package net.devrieze.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * An annotation that indicates that the method or field should be accessible by
 * a script. This works together with the {@link ScriptSupport} annotation that
 * indicates to users that the Scriptable Annotation must be obeyed as the class
 * knows about scripting.
 * 
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD, ElementType.FIELD })
public @interface Scriptable {
  // Empty marker annotation
}
