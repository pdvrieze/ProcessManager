/*
 * Created on Feb 5, 2005
 *
 */
package net.devrieze.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * An annotation that indicates that the element is part of the public interface
 * of a certain project. If a class is published in a project, and the members
 * have no published annotation, the public and protected members are assumed to
 * be part of the interface.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.ANNOTATION_TYPE, ElementType.METHOD })
@Published({ "net.devrieze.core" })
public @interface Published {

  /**
   * The list of projects it is a published interface for.
   */
  String[] value();
  /* Just indicate public interface */
}
