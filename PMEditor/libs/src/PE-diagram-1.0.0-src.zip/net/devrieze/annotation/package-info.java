/**
 * This package contains various annotation types.
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.annotation;

