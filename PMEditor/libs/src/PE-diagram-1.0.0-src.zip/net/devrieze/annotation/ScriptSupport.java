/*
 * Created on 24-Oct-2005
 */
package net.devrieze.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * A marker annotation that indicates that the type knows about scripting. This
 * allows the {@link Scriptable} annotation to be interpreted by scripting
 * engines.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface ScriptSupport {
  // Just a marker
}
