/*
 * Created on Feb 5, 2005
 *
 */
package net.devrieze.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


/**
 * An annotation to specify why elements are visible.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
@Retention(RetentionPolicy.SOURCE)
public @interface VisibleFor {

  /**
   * The classes that this element is visible for.
   */
  Class<?>[] value();
}
