/*
 * Created on 28-Oct-2005
 */
package net.devrieze.security;

import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import static net.devrieze.util.Annotations.*;

import net.devrieze.annotations.NotNull;


public class InsecureTrustManager implements X509TrustManager {

  private final X509TrustManager aSunJSSEX509TrustManager;

  public InsecureTrustManager() throws Exception {
    final KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
    final TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
    tmf.init(ks);
    for (final TrustManager tm : tmf.getTrustManagers()) {
      if (tm instanceof X509TrustManager) {
        aSunJSSEX509TrustManager = (X509TrustManager) tm;
        return;
      }
    }
    throw new Exception("Couldn't initialize");
  }

  @Override
  public void checkClientTrusted(final X509Certificate[] pChain, final String pAuthType) throws CertificateException {
    try {
      aSunJSSEX509TrustManager.checkClientTrusted(pChain, pAuthType);
    } catch (final CertificateException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void checkServerTrusted(final X509Certificate[] pChain, final String pAuthType) throws CertificateException {
    try {
      aSunJSSEX509TrustManager.checkServerTrusted(pChain, pAuthType);
    } catch (final CertificateException e) {
      //      e.printStackTrace();
    }

  }

  @Override
  @NotNull
  public X509Certificate[] getAcceptedIssuers() {
    return notNull(aSunJSSEX509TrustManager.getAcceptedIssuers());
  }

  public static void init() {
    try {
      final TrustManager[] tms = new TrustManager[] { new InsecureTrustManager() };
      final SSLContext sc = SSLContext.getInstance("SSL");
      sc.init(null, tms, new SecureRandom());
      HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    } catch (final Exception e) {
      e.printStackTrace();
    }
  }

}
