/**
 * The net.devrieze.dom package provides wrappers that hide the complexity of
 * dom, while still allowing subclasses to be dom compliant.
 *
 * @author Paul de Vrieze
 * @version 1.0 $Revision$
 */
package net.devrieze.dom;

