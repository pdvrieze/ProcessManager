/*
 * Created on May 5, 2005
 *
 */
package net.devrieze.dom;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * The NextSiblingNodeList class is a class that implements
 * {@link org.w3c.dom.NodeList} using the nextsibling property of nodes.
 * 
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class NextSiblingNodeList implements NodeList {

  private final Node aFirstChild;

  private int aLength = -1;

  /**
   * Get a nodelist that represents is based on the nextsibling method.
   * 
   * @param pFirstChild The first node in the list.
   */
  public NextSiblingNodeList(final Node pFirstChild) {
    aFirstChild = pFirstChild;
  }

  /** {@inheritDoc} */
  @Override
  public Node item(final int pIndex) {
    if (pIndex < 0) {
      return null;
    }
    int i = 0;
    Node cur = aFirstChild;
    while ((i < pIndex) && (cur != null)) {
      cur = cur.getNextSibling();
      i++;
    }
    return cur;
  }

  /** {@inheritDoc} */
  @Override
  public int getLength() {
    if (aLength < 0) {
      Node cur = aFirstChild;
      aLength = 0;
      while (cur != null) {
        aLength++;
        cur = cur.getNextSibling();
      }
    }
    return aLength;
  }

}
