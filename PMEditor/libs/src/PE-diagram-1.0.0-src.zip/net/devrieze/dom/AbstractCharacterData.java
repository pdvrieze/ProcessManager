/*
 * Created on May 5, 2005
 *
 */
package net.devrieze.dom;

import org.w3c.dom.*;
import org.w3c.dom.CharacterData;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractCharacterData extends AbstractNode implements CharacterData {

  /**
   * Implement in terms of the length of the return value of getData().
   * 
   * @return The length of the data
   * @see org.w3c.dom.CharacterData#getLength()
   */
  @Override
  public int getLength() {
    return getData().length();
  }

  @Override
  public String substringData(final int pOffset, final int pCount) throws DOMException {
    final String data = getData();
    try {
      return data.substring(pOffset, Math.min(data.length(), pOffset + pCount));
    } catch (final IndexOutOfBoundsException e) {
      final DOMException f = new DOMException(DOMException.INDEX_SIZE_ERR, e.getMessage());
      f.initCause(e);
      throw f;
    }
  }

  /**
   * Just call insert at the end of the data.
   * 
   * @param pArg The data to append
   * @throws DOMException When something goes wrong.
   * @see org.w3c.dom.CharacterData#appendData(java.lang.String)
   */
  @Override
  public void appendData(final String pArg) throws DOMException {
    insertData(getLength(), pArg);
  }

  @Override
  public void replaceData(final int pOffset, final int pCount, final String pArg) throws DOMException {
    deleteData(pOffset, pCount);
    insertData(pOffset, pArg);
  }

  @Override
  public String getNodeValue() throws DOMException {
    return getData();
  }

  @Override
  public void setNodeValue(final String pNodeValue) throws DOMException {
    setData(pNodeValue);
  }

  @Override
  public String getLocalName() {
    return null;
  }

  @Override
  public String getTextContent() throws DOMException {
    return getNodeValue();
  }

  @Override
  public void setTextContent(final String pContent) throws DOMException {
    setTextContent(pContent);
  }

  @Override
  public String lookupPrefix(final String pNamespaceURI) {
    final Node parent = getParentNode();
    if (parent != null) {
      return parent.lookupPrefix(pNamespaceURI);
    }
    return null;
  }

  @Override
  public boolean isDefaultNamespace(final String pNamespaceURI) {
    final Node parent = getParentNode();
    if (parent != null) {
      return parent.isDefaultNamespace(pNamespaceURI);
    }
    return false;
  }

  @Override
  public String lookupNamespaceURI(final String pPrefix) {
    final Node parent = getParentNode();
    if (parent != null) {
      return parent.lookupNamespaceURI(pPrefix);
    }
    return null;
  }

  @Override
  public NamedNodeMap getAttributes() {
    return null;
  }

  @Override
  public void normalize() {
    // Null op for texts as we don't do character normalization.
  }

  @Override
  public String getNamespaceURI() {
    return null;
  }

  @Override
  public String getPrefix() {
    return null;
  }

  @Override
  public void setPrefix(final String pPrefix) throws DOMException {
    // Do nothing, character data has a defined null prefix
  }

  @Override
  public Node getFirstChild() {
    return null;
  }

  @Override
  public Node getLastChild() {
    return null;
  }

  @Override
  public boolean hasAttributes() {
    return false;
  }

  @Override
  public String getBaseURI() {
    return getParentNode().getBaseURI();
  }

  public Text splitText(final int pOffset) throws DOMException {
    final String newText = substringData(pOffset, getLength() - pOffset);
    deleteData(pOffset, getLength() - pOffset);
    final Text result = getOwnerDocument().createTextNode(newText);
    getParentNode().insertBefore(result, getNextSibling());
    return result;
  }

}
