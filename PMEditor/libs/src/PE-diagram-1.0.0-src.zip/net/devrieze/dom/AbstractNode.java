/*
 * Created on May 5, 2005
 *
 */
package net.devrieze.dom;

import java.util.HashMap;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;

import net.devrieze.util.Tupple;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractNode implements Node {

  private HashMap<String, Tupple<Object, UserDataHandler>> aUserData;

  /**
   * Creates a list of all child nodes of this node. Is implemented using
   * {@link NextSiblingNodeList} so not overly efficient.
   * 
   * @return Get a list of all child nodes.
   * @see org.w3c.dom.Node#getChildNodes()
   */
  @Override
  public NodeList getChildNodes() {
    return new NextSiblingNodeList(getFirstChild());
  }

  /** {@inheritDoc} */
  @Override
  public Node appendChild(final Node pNewChild) throws DOMException {
    return insertBefore(pNewChild, null);
  }

  /** {@inheritDoc} */
  @Override
  public boolean hasChildNodes() {
    return getFirstChild() != null;
  }

  @Override
  public boolean isSupported(final String pFeature, final String pVersion) {
    String feature = pFeature;
    if (feature.charAt(0) == '+') {
      feature = pFeature.substring(1);
    }
    if (feature.equals("Core")) {
      return (pVersion == null) || pVersion.equals("2.0") || pVersion.equals("3.0") || pVersion.equals("");
    }
    return false;
  }

  @Override
  public short compareDocumentPosition(final Node pArg0) throws DOMException {
    // @todo Auto-generated method stub
    return 0;
  }

  @Override
  public boolean isSameNode(final Node pOther) {
    return this == pOther;
  }

  @Override
  public Object getFeature(final String pFeature, final String pVersion) {
    String feature = pFeature;
    if (feature.charAt(0) == '+') {
      feature = pFeature.substring(1);
    }
    if (feature.equals("Core")) {
      if ((pVersion == null) || pVersion.equals("2.0") || pVersion.equals("3.0") || pVersion.equals("")) {
        return this;
      }
    }
    return null;
  }

  @Override
  public Object setUserData(final String pKey, final Object pData, final UserDataHandler pHandler) {
    if (aUserData == null) {
      aUserData = new HashMap<>();
    }
    if ((pData == null) && (pHandler == null)) {
      final Object old = aUserData.remove(pKey);
      if (aUserData.size() == 0) {
        aUserData = null;
      }
      return old;
    }
    return aUserData.put(pKey, new Tupple<>(pData, pHandler));
  }

  @Override
  public Object getUserData(final String pKey) {
    if (aUserData == null) {
      return null;
    }
    return aUserData.get(pKey);
  }

}
