/*
 * Created on May 5, 2005
 *
 */
package net.devrieze.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.Text;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public abstract class AbstractText extends AbstractCharacterData implements Text {

  @Override
  public String getWholeText() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Text replaceWholeText(final String pContent) throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public String getNodeName() {
    return "#text";
  }

  @Override
  public short getNodeType() {
    return Node.TEXT_NODE;
  }

}
