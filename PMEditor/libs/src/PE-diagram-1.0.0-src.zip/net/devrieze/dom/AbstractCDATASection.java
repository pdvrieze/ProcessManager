/*
 * Created on May 5, 2005
 *
 */
package net.devrieze.dom;

import org.w3c.dom.*;


/**
 * @author Paul de Vrieze
 * @version 0.1 $Revision$
 */
public class AbstractCDATASection extends AbstractCharacterData implements CDATASection {

  @Override
  public boolean isElementContentWhitespace() {
    // @todo Auto-generated method stub
    return false;
  }

  @Override
  public String getWholeText() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Text replaceWholeText(final String pContent) throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public String getData() throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public void setData(final String pData) throws DOMException {
    // @todo Auto-generated method stub

  }

  @Override
  public void insertData(final int pOffset, final String pArg) throws DOMException {
    // @todo Auto-generated method stub

  }

  @Override
  public void deleteData(final int pOffset, final int pCount) throws DOMException {
    // @todo Auto-generated method stub

  }

  @Override
  public String getNodeName() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public short getNodeType() {
    // @todo Auto-generated method stub
    return 0;
  }

  @Override
  public Node getParentNode() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node getPreviousSibling() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node getNextSibling() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Document getOwnerDocument() {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node insertBefore(final Node pNewChild, final Node pRefChild) throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node replaceChild(final Node pNewChild, final Node pOldChild) throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node removeChild(final Node pOldChild) throws DOMException {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public Node cloneNode(final boolean pDeep) {
    // @todo Auto-generated method stub
    return null;
  }

  @Override
  public boolean isEqualNode(final Node pArg) {
    // @todo Auto-generated method stub
    return false;
  }

}
