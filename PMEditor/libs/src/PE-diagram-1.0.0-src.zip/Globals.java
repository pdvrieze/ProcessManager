import static meta.lang.compiletime.CompilerDirectives.*;
import meta.lang.Literal;
import meta.lang.compiletime;

import net.devrieze.meta.compile.CompilationException;
import net.devrieze.meta.compile.Scope;


public class Globals {

  public static @compiletime(SCOPE)
  void import_(final Scope pScope, final Literal<?> pLiteral) throws CompilationException {
    final Object val = pLiteral.getObjValue();
    if (!(val instanceof String)) {
      pScope.getContext().error(pLiteral, "Import expects string literals");
    }
    final String name = (String) val;
    if (name.endsWith(".*")) {
      pScope.addPackageImport(name.substring(0, name.length() - 2));
    } else {
      pScope.addTypeImport(name);
    }
  }
}