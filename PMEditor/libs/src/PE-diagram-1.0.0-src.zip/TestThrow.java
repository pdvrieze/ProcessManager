public class TestThrow {

  public TestThrow() {
    //throw RuntimeException("TestThrow"),
    throw new RuntimeException("TestThrow"/* 1 */);
  }

}
