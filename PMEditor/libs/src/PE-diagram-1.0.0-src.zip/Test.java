import meta.lang.Lambda;


public class Test extends Lambda<Integer> {

  boolean o = false;

  int x;

  @Override
  public Integer lambda(final Object... pParams) {
    System.out.println("bla" == pParams[0]);
    if ("bla".endsWith("a")) {
      System.out.println("x");
    } else {
      System.out.println("y");
    }
    System.out.println(Integer.valueOf(45));

    return Integer.valueOf(0);
  }


  void test() {
    lambda("1", "2", "3");
  }
}
