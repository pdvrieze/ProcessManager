public class AddOne extends LambdaII {

  @Override
  public int lambda(final int pParam) {
    return pParam + 1;
  }

}
