import meta.lang.Lambda;


public abstract class LambdaII extends Lambda<Integer> {

  public abstract int lambda(int pParam);

  @Override
  public Integer lambda(final Object... pParams) {
    return Integer.valueOf(lambda(((Integer) pParams[0]).intValue()));
  }

}
