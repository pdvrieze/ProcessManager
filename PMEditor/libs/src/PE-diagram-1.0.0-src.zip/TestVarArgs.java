import java.util.Arrays;
import java.util.List;


public class TestVarArgs {

  public static List<String> test() {
    return Arrays.asList("1", "2", "3", "5");
  }
}