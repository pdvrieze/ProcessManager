
public class IntContainer {

  private final int y;

  public IntContainer(final int x) {
    y = x;
  }

  public int addX(final int x) {
    return x + y;
  }

}
