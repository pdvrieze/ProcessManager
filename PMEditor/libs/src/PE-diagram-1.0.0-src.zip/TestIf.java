import meta.lang.compiletime;


public class TestIf {

  public static @compiletime(compiletime.CompilerDirectives.SCOPE)
  String import2(final String name) {
    if (name.endsWith(".*")) {
      return "Yes";
    } else {
      return "No";
    }
  }

  public static void main(final String[] args) {
    System.out.println(import2("foo"));
  }
}
